# Gözlem verisi

EVDS `bie_odeayrsunum6` (Ödemeler Dengesi - Ayrıntılı Sunum, aylık, mn USD), 14.10.2026 çekimi.
Seriler: `TP.ODEAYRSUNUM6.Q5` (toplam mal ihracatı), `Q6` (mal ithalatı), `Q76` (1.3.2.b yatırım geliri gideri), `Q75` (1.3.2.a gelir), `Q70` (1.3 birincil gelir gideri).
Yenilemek: `python etki_cephesi/evds_gozlem_cek.py` (ağ gerekir; `_incoming/zarar-teorisi-main/evds_cek.py` kullanır).
İlk/son gözlem: 2015-01 / 2026-08.
