# Gözlem verisi

EVDS `bie_odeayrsunum6` (Ödemeler Dengesi - Ayrıntılı Sunum, aylık, mn USD), 14.10.2026 çekimi.
Seriler: `TP.ODEAYRSUNUM6.Q5` (toplam mal ihracatı), `Q6` (mal ithalatı), `Q76` (1.3.2.b yatırım geliri gideri), `Q75` (1.3.2.a gelir), `Q70` (1.3 birincil gelir gideri).
Yenilemek: `python etki_cephesi/evds_gozlem_cek.py` (ağ gerekir; `_incoming/zarar-teorisi-main/evds_cek.py` kullanır).
İlk/son gözlem: 2015-01 / 2026-08.

## Borç çevirme oranları
EVDS `bie_oderoll` (aylık, %), 14.10.2026 çekimi. `K1` bankalar, `K2` diğer sektörler (kısa+uzun vade); `K3`/`K4` tahvil dahil. İlk/son gözlem: 2006-06 / 2026-08.
Yenilemek: `python etki_cephesi/evds_gozlem_cek.py` (ağ gerekir).

## Dış ticaret ve GSYH (Çin/Rusya kayıp modellemesi)
`dis_ticaret_gsyh_2023.json`, 14.10.2026 çekimi. İhracat: UN Comtrade public preview API (yıllık 2023, HS TOTAL, bölge ortakları); Çin, İran, İsrail, Mısır için raporlayanın kendi ihracatı. Rusya 2022'den beri Comtrade'e raporlamıyor: Rusya satırı, bölge ülkelerinin Rusya'dan ithalatı (ayna veri; CIF/FOB farkı; Suriye, Libya, Cezayir, Somali, Türkmenistan raporlamıyor, eksik). GSYH: World Bank NY.GDP.MKTP.CD, 2023 (Suriye 2022).
Kullanım: `projeksiyon.py` `_cekim` / `_dis_veri_kayip`. Ortak ülkenin kaybı, ihracatın GSYH payı kadar ihracat gelirini düşürür; φ, kaybı modelli referans aktörlerde (İran, İsrail, Mısır) model kaybının çekim tahminine oranıdır.
Yenilemek: Comtrade `reporterCode/partnerCode` listesiyle aynı sorgular (ağ gerekir); `dis_ticaret_gsyh_2023.json` şemasını koruyun.
