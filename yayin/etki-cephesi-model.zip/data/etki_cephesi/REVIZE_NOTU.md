# Revize notu (SFC köprüsü)

Düzeltilen hatalar (hepsi kodda doğrulandı, `reports_before/after` karşılaştırması patch çıktısında):

1. **Tavan gerçekleşme gibi kullanılıyordu.** `stok_silim_tavan` (0,2582) hazneler arası brüt çift düzeyinin ÜST SINIRIDIR; F.4 stokuna ait değil, gerçekleşen silinme değil. `_stok_f4_yolu` bunu 10 yılda lineer uyguluyordu (25.339,8 → 18.797,1). Artık baz yol sabit (silinen ölçülmedi); oranlar `silinen_oran_senaryo` varsayım bandıdır, 0,2582 yalnız tutarlılık kontrolüdür.
2. **λ iki üst sınırın oranından türetiliyordu.** `ic_dongu_kazanim = 1 − eski_tavan/yeni_tavan = 0,7181`. Kazanım değil, iki üst sınırın oranı; zarar-teorisi `OKU.txt` λ'yı "tanımlanamadı" diye işaretler. Artık λ açık senaryo parametresi (varsayılan 0,5 = `akis_model.simulate` varsayılanı), bant 0,25 / 0,5 / 0,75.
3. **Sıfır toplam kimliği bozuluyordu.** Karşı bacağı tanımsız "refah/tasarruf/yaşam maliyeti" darbeleri (+0,660 tr TL) SFC'ye girip tüm sektörleri artıya çekiyordu. Artık `dissal: true` işaretli darbeler SFC dışında raporlanır; kapanış farkı (`kapanis`) ilan edilir.
4. **Kur uyumsuzluğu.** 2026-Q1 matrisi 2024 ortalama kuruyla (32,87) çevriliyordu. Artık matris dönemi kuru (zarar-teorisi `akis_model_ozeti.json`, 2026-Q1 = 44,38).
5. **Finans katmanı etiketi.** İşaret dönüşü (−3,237 → +0,241) atanmış çarpanlarla üretilir; rapor "varsayım çarpanlı ham" etiketi taşır.

6. **D'nin çift muamelesi.** Dış rant F'ye "zarar" yazılıp L ile D'ye kayıp olarak yayılıyordu (D −0,218) ve ayrıca "D kârı" G ile yerli sektörlere dağıtılıyordu (D'de kalmıyordu). Rant bir transferdir: artık F −A, D +A, doğrudan NFP'ye, toplam sıfır. Ödeyen F, transfer payı %100 (kullanıcı kararı): 22.550 mn $ × 44,38 = 1,001 tr TL, kapsam dışı rant yok. `bolge_stok_akis` TR net tanımı yerli sektörler toplamı (H+F+B+K) oldu: eski formül D'yi 0,45 ağırlıkla ayrıca düşüyordu (ikinci çift sayım). `test_stok_akis_senaryo_coklu` işareti buna göre güncellendi (C ≤ A ≤ B: C en az rant kaçırır).

7. **Olasılık duyarlılığı (yeni rapor).** `olasilik_duyarlilik.py`: P(C) 0,30–0,80 (adım 0,05), kalan A:B taban oranla bölünür. Çıktı `reports/etki_cephesi/OLASILIK_DUYARLILIK.{json,md}`. Yeni olasılık üretmez; olasılıklar ölçülmemiştir. `degerlendir()` isteğe bağlı `olasilik` parametresi aldı (varsayılan davranış değişmedi: mevcut raporlar birebir aynı).

8. **C için dinamik ölçüt (yeni).** `c_dinamik_olcut.py` → `C_DINAMIK_OLCUT.{json,md}`: merkez sızıntı oranının (12a yatırım geliri gideri / 12a mal ihracatı, EVDS ödemeler dengesi, `data/etki_cephesi/gozlem/`) senaryo sürüklenmesine göre sıralı Bayes güncellemesi. Ölçüm baz yıldan sonra başlar (ilk güncelleme 2027-12 verisi); eksik gözlem güncellemez. Güç analizi: bu gösterge C'yi 10 yılda ayırt edemez (≥ 307 yıl). Çapa uyumsuzluğu bayrağı: kalibrasyon 2024 yatırım geliri gideri 18.841 mn $, EVDS 26.483 (×1,41); `gerceklik_capa.json` değiştirilmedi.

Düzeltilmeyen / açık:
- Ödeyenin yalnız F olması kullanıcı kararıdır; rantın bir kısmını H veya kamu ödüyorsa transfer F'ye fazla yazılır.
- `bolge_stok_akis` ve `lm_rant_sektor` darbeleri de sıfır toplamlı değil: yalnız ilan edildi (`x_toplam_trilyonTL`, `kapanis_ok`), yeniden tasarlanmadı.
- λ ve kappa hâlâ ölçülmüş değil. Sonuçlar senaryo bandıdır.
