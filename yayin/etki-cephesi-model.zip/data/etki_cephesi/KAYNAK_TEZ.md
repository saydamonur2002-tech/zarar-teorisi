# Kaynak tez — uluslararası sistem ve artı değer

**Dosya:** `uluslararasi_sistem_arti_deger_kronoloji.docx` (Onur Saydam hattı, Eylül 2026 derlemesi)  
**Metin dökümü:** `_kaynak_metin.txt`

## Modele yansıyan çekirdek

| Kavram | Model karşılığı |
| --- | --- |
| Wallerstein yarı-çevre (Türkiye) | `turkiye_yaricevre` + bölge `rol` alanı |
| Merkez (finans, standart) | `merkez_finans` akış hedefi (coğrafi bölge değil, sızıntı havuzu) |
| Beş halka (üretim → … → dış kısıt) | `kanallar.json` ağırlıkları |
| Artı değer ≠ jeopolitik “etki kazancı” | Net = tampon/koridor **zararı** − rakip ikame; merkeze **sızıntı** ayrı satır |
| Çok kutupluluk | Senaryo B: alıcı değişir, **boru dışarı** akar |
| 2024–26 ölçüm (Ponzi değil, spekülatif) | Senaryo A notu; kanıt B/C |

**Korelasyon nedensellik değildir.** Kavramlar ayrı değişken; ölçü vekil endekstir.
