# Etki çeperi / artı değer modeli (v0.2 — tez revizyonu)

**Kaynak:** `KAYNAK_TEZ.md`, `KAYNAK_KONUM_ORTA_DOGU.md` (docx dökümleri)

## Zincir

`YARI-ÇEVRE (TR) BOŞALMA → BEŞ HALKA → MERKEZE SIZINTI | TAMPON SOK | RAKİP İKAME`

Bölgesel **net** = rakip ikame − tampon/koridor sok. **Merkez finans** ayrı havuz (coğrafi fayda değil). **MFIN** kenar toplamını tutar; kalan merkez stok **belirsiz pay** olarak evren ülkelerine eşit (`merkez_belirsiz.json`, `fayda_endeks` dışı).

## Dosyalar

| Dosya | Rol |
| --- | --- |
| `bolgeler.json` | Havza + Wallerstein `rol` |
| `kanallar.json` | Beş halka ağırlıkları |
| `bolge_akis.json` | Alt havza akış payları |
| `yerel_rant_kanal.json` | Dış bağlanma zararı + rant kanalı çıkışı |
| `dominion_bag.json` | Bağ vekili, pasif boşluk, donmuş enigma |
| `senaryolar.json` | A pasif, B araçsallaşma, **C en olası** (kısmi kullanım) |

```bash
.\.venv\Scripts\python.exe etki_cephesi/kalibrasyon.py
.\.venv\Scripts\python.exe etki_cephesi/projeksiyon.py
.\.venv\Scripts\python.exe etki_cephesi/akis_olcum.py
.\.venv\Scripts\python.exe etki_cephesi/zarar_cozum_entegrasyon.py
.\.venv\Scripts\python.exe etki_cephesi/senaryo_gerceklik_kalibre.py
.\.venv\Scripts\python.exe etki_cephesi/refah_dis_entegrasyon.py
.\.venv\Scripts\python.exe etki_cephesi/zarar_10y_gsyh.py
.\.venv\Scripts\python.exe etki_cephesi/modul_entegrasyon_kalibre.py --modules-only
```

**Modül koşulları** (`modul_kosullari.json`): dış rant USD, yaşam maliyeti 10y, stok-akış, bölge SFC, uluslararası matris, uygulanabilirlik skoru.

**Kalibre / sözlük:** `kalibre/gerceklik_capa.json`, `kalibre/uluslararasi_stok_akis_capa.json`, `kalibre/vekil_usd_sozlugu.json`.

### Rapor çıktıları (`reports/etki_cephesi/`)

| Rapor | Modül |
| --- | --- |
| `PROJEKSIYON.*` | projeksiyon |
| `GERCEKLIK_KALIBRE.*` | senaryo_gerceklik_kalibre |
| `DIS_ULKE_REFAH.*` | refah_dis_entegrasyon |
| `DIS_ULKE_REFAH_GENIS.*` + `DIS_ULKE_KURUM.md` | dış ülkeler + IMF/WB/BIS/NATO… |
| `DIS_RANT_PARASAL.*` | dis_rant_parasal_akisi |
| `ZARAR_10Y_GSYH.*` | zarar_10y_gsyh |
| `YASAM_MALIYET_KATMAN.*` | yasam_maliyet_katman (gerçekleşme tavanı: `iyilesme_tavan_usd_mn_10y`) |
| `STOK_AKIS_SIM.*` | stok_akis_sim |
| `BOLGE_STOK_AKIS.*` | bolge_stok_akis |
| `ULUSLARARASI_STOK_AKIS.*` | uluslararasi_stok_akis (HAVZA clearing + yapısal MFIN) |
| `SENARYO_UYGULANABILIRLIK.*` | senaryo_uygulanabilirlik |
| `SENARYO_COKLU_P2.*` + `_*_{A,B,C}.json` | senaryo_coklu_p2 (olasılık beklentisi) |
| `ULUSLARARASI_STOK_AKIS_10Y.*` | uluslararasi_stok_akis_10y |
| `LM_RANT_SEKTOR.*` | lm_rant_sektor (Lm × rant kanalı) |
| `FINANS_SENET_FAIZ.*` | finans_senet_faiz_kopru |
| `MFIN_TUTARLILIK.*` | mfin_tutarlilik |
| `SENARYO_BEKLENEN_KALIBRE.*` | senaryo_beklenen_kalibre (P(A,B,C) kalibre yol) |
| `SENARYO_UYGULANABILIRLIK.*` | skor C + beklenen karışım |
| `DURUM_OZETI.*` | durum_ozeti |
| `GERCEKLIK_CAPA_SENKRON.*` | empirik → capa (P3) |
| `ZARAR_10Y_SENARYO_COKLU.*` | A/B/C 10y yol + erosyon |
| `ULUSLARARASI_STOK_AKIS_{2027,2030,2036}.json` | snapshot_disa |
| `FINANS_KATMAN_{A,B,C}.json`, `FINANS_KATMAN_COKLU.json` | finans senaryo (P4) |
| `ZARAR_COZUM_{A,B,C}.json`, `ZARAR_COZUM_COKLU.json` | zarar teorisi × A/B/C |
| `URETIM_IC_AKIS_{A,B,C}.json` | üretim/halka senaryo başına |
| `GERCEKLIK_KALIBRE_{A,B,C}.json`, `GERCEKLIK_SENARYO_COKLU.json` | kalibre yol A/B/C |
| `ULKE_KANAL_DOKUM.*` | ülke × kanal × kurum dokümü |
| `ULKE_KANAL_DOKUM_10Y.*` | ülke × kanal 10y seri (A/B/C) |
| `MODUL_KALIBRE.*` | modul_entegrasyon_kalibre |

Tam zincir + P2: `etki_cephesi/run_all.py`
