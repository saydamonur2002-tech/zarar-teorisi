# Ülkenin konumu ve Orta Doğu

**Kaynak:** `Ulke konumu ve Orta Dogu.docx`  
**Döküm:** `_kaynak_ulke_orta_dogu.txt`

## Modele giren çekirdek

| Tez | Model |
| --- | --- |
| Maks/min değil; **kullanım / atıl / araçsallaşma** | `senaryolar.json` → `bag_modu` |
| Pasiflik → boşluk | `pasif_bosluk_dolgu` (atıl pay) |
| Araçsallaşma → dar çıkar, temsil kaybı | `aracsallasma_zarar`, `mesruiyet_temsil_zedesi` |
| Dış hegemon mimarisi | `dis_hegemon_mimari_insaa` |
| TR dışarıda güç merkezi değil | `dis_goreceli_sonuc` (dış açmaz vekili) |
| İç dinamik tıkanması | `ic_dinamik_tikanma` |
| Suriye: donmuş enigma | `donmus_enigma_carpan` (Levant) |
| Çeper geniş, gövde zayıf | `ceper_govde_acigi` (TR özeti) |
| Dar çeper: Levant, Körfez, Kafkasya, Karadeniz | `makro_ceper` alanı |
| Bağ tipleri (derleyen not) | ticaret, diaspora, borç, güvenlik, koridor vekilleri |

Korelasyon ≠ nedensellik. Bağ vekil skorları kalibrasyon D.
