"""P1: uluslararası stok kapanış + yaşam maliyeti tavanı."""
from __future__ import annotations

import json
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "etki_cephesi"


def test_uluslararasi_stok_kapanis():
    p = OUT / "ULUSLARARASI_STOK_AKIS.json"
    assert p.is_file(), "Run modul_entegrasyon_kalibre.py first"
    d = json.loads(p.read_text(encoding="utf-8"))
    k = d["kalibrasyon"]
    tol = float(k["kapanis_tolerans_vekil"])
    assert abs(float(k["stok_net_toplam_vekil"])) <= tol
    assert k.get("kapanis_ok") is True
    m = k.get("mfin_havza_denge") or {}
    assert m.get("uygulandi") is True
    assert "havza_stok_vekil" in m
    assert "HAVZA" in d["stok"]
    assert d["stok"]["HAVZA"].get("tur") == "clearing_meta"


def test_yasam_maliyet_tavan_alani():
    p = OUT / "YASAM_MALIYET_KATMAN.json"
    assert p.is_file()
    d = json.loads(p.read_text(encoding="utf-8"))
    assert "gerceklesme_tavan_usd_mn" in d
    assert d["gerceklesme"] <= 1.0
