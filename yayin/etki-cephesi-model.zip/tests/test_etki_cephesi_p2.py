"""P2: çoklu senaryo kapanış + 10y seri."""
from __future__ import annotations

import json
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "etki_cephesi"


def test_senaryo_coklu_p2_kapanis():
    p = OUT / "SENARYO_COKLU_P2.json"
    assert p.is_file(), "Run senaryo_coklu_p2.py"
    d = json.loads(p.read_text(encoding="utf-8"))
    for r in d["senaryolar"]:
        assert r["stok_kapanis_ok"] is True
        assert abs(float(r["stok_net_vekil"])) < 0.01
    b = d["beklenti"]
    assert b.get("beklenen_refah_dis_usd_mn") is not None


def test_uluslararasi_10y_seri():
    p = OUT / "ULUSLARARASI_STOK_AKIS_10Y.json"
    assert p.is_file(), "Run uluslararasi_stok_akis_10y.py"
    d = json.loads(p.read_text(encoding="utf-8"))
    seri = d["yillik_seri"]
    assert len(seri) >= 8
    for row in seri:
        assert row["kapanis_ok"] is True


def test_lm_rant_sektor():
    p = OUT / "LM_RANT_SEKTOR.json"
    assert p.is_file()
    d = json.loads(p.read_text(encoding="utf-8"))
    assert d["entegre"]["usd_mn_toplam"] > 0
    assert "H" in d["entegre"]["sektor_etkisi_trilyonTL"]


def test_finans_senet_faiz():
    p = OUT / "FINANS_SENET_FAIZ.json"
    assert p.is_file()
    d = json.loads(p.read_text(encoding="utf-8"))
    assert d["faiz_rant_usd_mn"] >= 0
    assert "ic_faiz_alacakli_paylari" in d


def test_mfin_tutarlilik():
    p = OUT / "MFIN_TUTARLILIK.json"
    assert p.is_file()
    d = json.loads(p.read_text(encoding="utf-8"))
    assert abs(float(d["stok_kapanis_vekil"])) < 0.01


def test_10y_refah_usd_artar():
    p = OUT / "ULUSLARARASI_STOK_AKIS_10Y.json"
    d = json.loads(p.read_text(encoding="utf-8"))
    seri = d["yillik_seri"]
    u0 = float(seri[0]["refah_dis_usd_kalibre_mn"])
    u1 = float(seri[-1]["refah_dis_usd_kalibre_mn"])
    assert u1 >= u0


def test_balkan_kenar_matris():
    p = OUT / "ULUSLARARASI_STOK_AKIS.json"
    d = json.loads(p.read_text(encoding="utf-8"))
    aktarim = [e for e in d["akis_kenarlari"] if e.get("tur") == "balkan_eu_aktarim"]
    assert len(aktarim) >= 1


def test_beklenen_kalibre():
    p = OUT / "SENARYO_BEKLENEN_KALIBRE.json"
    assert p.is_file(), "Run senaryo_beklenen_kalibre.py"
    d = json.loads(p.read_text(encoding="utf-8"))
    b = d["beklenti"]
    assert len(d["senaryolar"]) == 3
    assert b["beklenen_tr_net_10y_yasam"] is not None
    assert b["beklenen_tr_net_10y_yasam"] > -35


def test_uygulanabilirlik_beklenen_skor():
    p = OUT / "SENARYO_UYGULANABILIRLIK.json"
    d = json.loads(p.read_text(encoding="utf-8"))
    assert d.get("skor_beklenen_ab_c") is not None
    assert d.get("referans_beklenen") is not None


def test_10y_anlik_goruntuler():
    p = OUT / "ULUSLARARASI_STOK_AKIS_10Y.json"
    d = json.loads(p.read_text(encoding="utf-8"))
    anlik = d.get("anlik_goruntuler") or []
    assert len(anlik) >= 3
    assert "stok" in anlik[0]


def test_durum_ozeti():
    p = OUT / "DURUM_OZETI.json"
    assert p.is_file()
    d = json.loads(p.read_text(encoding="utf-8"))
    assert d.get("tamam") is True


def test_balkan_defter_c():
    p = OUT / "DIS_ULKE_REFAH_C.json"
    if not p.is_file():
        p = OUT / "DIS_ULKE_REFAH.json"
    d = json.loads(p.read_text(encoding="utf-8"))
    meta = d.get("balkan_eu_defter") or {}
    assert meta.get("uygulandi") is True
    ledger = {r["ulke"]: r for r in d["ulke_defteri"]}
    assert "RS" in ledger or "BA" in ledger
