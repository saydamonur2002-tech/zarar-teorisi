"""Dış ülkeler + uluslararası kurumlar."""
from __future__ import annotations

import json
from pathlib import Path

OUT = Path(__file__).resolve().parents[1] / "reports" / "etki_cephesi"


def test_genis_defter_kurumlar():
    p = OUT / "DIS_ULKE_REFAH_GENIS.json"
    assert p.is_file(), "Run dis_kurum_entegrasyon.py"
    d = json.loads(p.read_text(encoding="utf-8"))
    assert d.get("kurum_sayisi", 0) >= 10
    ids = {k["ulke"] for k in d.get("kurum_defteri") or []}
    assert "IMF" in ids and "WB" in ids and "EBRD" in ids and "AIIB" in ids


def test_ulke_rol_metadata():
    p = OUT / "DIS_ULKE_REFAH_GENIS.json"
    d = json.loads(p.read_text(encoding="utf-8"))
    iq = next((r for r in d["ulke_defteri"] if r.get("ulke") == "IQ"), None)
    assert iq is not None
    assert iq.get("rol") == "bolge_guc"


def test_matris_kurum_stok():
    p = OUT / "ULUSLARARASI_STOK_AKIS.json"
    d = json.loads(p.read_text(encoding="utf-8"))
    assert "IMF" in d.get("stok", {}) or "WB" in d.get("stok", {})
