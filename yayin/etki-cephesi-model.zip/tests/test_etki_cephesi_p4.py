"""P4: finans A/B/C, ulke kanal dokum."""
from __future__ import annotations

import json
from pathlib import Path

OUT = Path(__file__).resolve().parents[1] / "reports" / "etki_cephesi"


def test_finans_katman_coklu():
    p = OUT / "FINANS_KATMAN_COKLU.json"
    assert p.is_file()
    d = json.loads(p.read_text(encoding="utf-8"))
    assert d["beklenti"]["beklenen_tr_net_finans"] is not None
    by_id = {x["id"]: x for x in d["senaryolar"]}
    assert by_id["A"]["tr_net_finans"] != by_id["B"]["tr_net_finans"]
    for sid in ("A", "B", "C"):
        assert (OUT / f"FINANS_KATMAN_{sid}.json").is_file()


def test_ulke_kanal_dokum():
    p = OUT / "ULKE_KANAL_DOKUM.json"
    assert p.is_file()
    d = json.loads(p.read_text(encoding="utf-8"))
    assert d["kurum_sayisi"] >= 10
    assert len(d["top_ulke_refah_dis_usd_mn"]) >= 5


def test_zarar_cozum_senaryo_coklu():
    p = OUT / "ZARAR_COZUM_COKLU.json"
    assert p.is_file()
    for sid in ("A", "B", "C"):
        assert (OUT / f"ZARAR_COZUM_{sid}.json").is_file()


def test_finans_tr_net_senaryo_monotonic():
    d = json.loads((OUT / "FINANS_KATMAN_COKLU.json").read_text(encoding="utf-8"))
    by_id = {x["id"]: x for x in d["senaryolar"]}
    assert by_id["C"]["tr_net_finans"] >= by_id["A"]["tr_net_finans"]
    assert by_id["A"]["tr_net_finans"] >= by_id["B"]["tr_net_finans"]


def test_ulke_kanal_dokum_10y():
    p = OUT / "ULKE_KANAL_DOKUM_10Y.json"
    assert p.is_file()
    d = json.loads(p.read_text(encoding="utf-8"))
    by_id = {x["id"]: x for x in d["senaryolar"]}
    assert len(by_id["C"]["yillik"]) == 10
    assert by_id["C"]["yillik"][-1]["refah_olgunluk_olcek"] >= by_id["C"]["yillik"][0]["refah_olgunluk_olcek"]


def test_gerceklik_senaryo_coklu():
    p = OUT / "GERCEKLIK_SENARYO_COKLU.json"
    assert p.is_file()
    d = json.loads(p.read_text(encoding="utf-8"))
    by_id = {x["id"]: x for x in d["senaryolar"]}
    assert by_id["C"]["tr_net_yol_10_son"] >= by_id["B"]["tr_net_yol_10_son"]
