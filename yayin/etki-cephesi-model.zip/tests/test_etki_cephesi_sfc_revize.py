"""Revize: SFC köprüsü hataları (tavan=gerçekleşme, türetilmiş λ, kapanış, kur, etiket)."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "etki_cephesi"
DATA = REPO / "data" / "etki_cephesi"
ZARAR = REPO / "_incoming" / "zarar-teorisi-main"


def _j(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))


def test_lambda_turetilmis_degil():
    c = _j(DATA / "zarar_teorisi_kopru.json")["etki_cephesi_carpanlari"]
    b = _j(DATA / "zarar_teorisi_kopru.json")["bes_adim_kanit"]
    turetilmis = round(1 - b["eski_tavan"] / b["yeni_tavan"], 4)
    assert c["ic_dongu_kazanim"] != turetilmis
    assert c["ic_dongu_kazanim_etiket"] == "senaryo_parametresi"
    assert c["ic_dongu_kazanim"] in c["ic_dongu_kazanim_bant"]


def test_stok_yolu_tavani_gerceklesme_saymaz():
    d = _j(OUT / "STOK_AKIS_SIM.json")
    bes = d["bes_adim_kisit"]
    assert "stok_silim_tavan" not in bes
    son = d["yillik_stok_akis"][-1]["stok_f4"]
    assert son["etiket"] == "olculmedi_sabit"
    assert son["stok_f4_milyar"] == bes["stok_bas_milyar"]
    for r in d["stok_f4_bandi_son_yil"].values():
        assert r["ust_sinir_icinde"] is True


def test_sfc_kapanis_ilan_ve_dissal_ayrik():
    d = _j(OUT / "STOK_AKIS_SIM.json")
    e = d["entegre_puls"]
    toplam_etki = sum(e["sektor_etkisi_trilyonTL"].values())
    # simulate toplamı korur: etki toplamı = darbe toplamı
    assert abs(toplam_etki - e["kapanis"]["x_kapali_toplam_trilyonTL"]) <= 5e-3
    assert e["kapanis"]["acik_fark_trilyonTL"] == e["kapanis"]["x_kapali_toplam_trilyonTL"]
    dissal = {p["id"] for p in d["pulslar"] if not p["sfc_dahil"] and not p.get("devre_disi")}
    assert dissal == set(d["dissal_enjeksiyon"]["pulslar"])
    assert dissal  # refah/tasarruf/yasam darbeleri SFC dışında
    kapali_toplam = sum(p["x_trilyonTL"] for p in d["pulslar"] if p["sfc_dahil"])
    assert abs(kapali_toplam - e["kapanis"]["x_kapali_toplam_trilyonTL"]) <= 5e-3


def test_kur_matris_donemi():
    d = _j(OUT / "STOK_AKIS_SIM.json")
    oz = _j(ZARAR / "akis_model_ozeti.json")
    beklenen = float(oz["dis_borc_artisi"]["stok_milyar_USD"][d["matris_donem"]]["USDTRY"])
    assert d["kur_tl_usd"] == beklenen
    assert d["kur_tl_usd"] != 32.87


def test_simulate_toplami_korur():
    sys.path.insert(0, str(ZARAR))
    from akis_model import simulate  # noqa: E402

    L = np.loadtxt(ZARAR / "L_v2_2026-Q1.csv", delimiter=",", skiprows=1, usecols=range(1, 6))
    G = np.loadtxt(ZARAR / "G_v2_2026-Q1.csv", delimiter=",", skiprows=1, usecols=range(1, 6))
    nfp = np.array([1.0, -3.0, 0.5, -0.6, 1.5]) * 1e9
    for s in range(5):
        x = np.zeros(5)
        x[s] = -1e9
        assert abs(float(simulate(L, G, nfp, x, lam=0.5, kappa=0.1).sum()) - float(x.sum())) <= 1e-4 * abs(float(x.sum()))


def test_finans_katman_etiketi():
    d = _j(OUT / "FINANS_KATMAN.json")
    assert d["etiket"] == "varsayim_carpanli_ham"
    assert "varsayım çarpanlı ham" in (OUT / "FINANS_KATMAN.md").read_text(encoding="utf-8")


def test_lm_rant_kapanis_ilani():
    d = _j(OUT / "LM_RANT_SEKTOR.json")
    assert "kapanis_ok" in d["entegre"] and "x_toplam_trilyonTL" in d["entegre"]
    assert d["kur_tl_usd"] != 32.87


def test_uygulanabilirlik_ozeti_sayidan_turetilir():
    d = _j(OUT / "SENARYO_UYGULANABILIRLIK.json")
    # sabit "10 yılda TR net iyileşir" cümlesi yok; özet sayıları içerir
    assert f"{d['iyilesme_beklenen_vekil']:+.2f}" in d["ozet"]
    assert f"{d['iyilesme_c_vekil']:+.2f}" in d["ozet"]
    if d["iyilesme_beklenen_vekil"] <= 0.05:
        assert "kısmi gerçekleşme ile 10 yılda TR net iyileşir" not in d["ozet"]
        assert any("iyileşme yok" in e for e in d["engeller"])


def test_pipeline_kararli_duruma_oturdu():
    d = _j(OUT / "RUN_ALL_KARARLILIK.json")
    assert d["kararli"] is True


def test_d_cift_muamelesi_duzeltildi():
    d = _j(OUT / "STOK_AKIS_SIM.json")
    tr = [p for p in d["pulslar"] if p["tur"] == "transfer"]
    assert len(tr) == 1
    xs = tr[0]["x_sektor_trilyonTL"]
    assert abs(sum(xs.values())) <= 1e-3  # toplam sıfır
    assert xs["F"] < 0 and abs(xs["D"] + xs["F"]) <= 1e-3  # F -A, D +A
    assert all(abs(xs[s]) <= 1e-3 for s in ("H", "B", "K"))
    e = d["entegre_puls"]
    assert e["kapanis"]["kapanis_ok"] is True
    # transfer yayılmaz: entegre etki doğrudan transfer
    for s in ("H", "F", "B", "K", "D"):
        assert abs(e["sektor_etkisi_trilyonTL"][s] - xs[s]) <= 1e-3
    # devre dışı eski D "kârı" SFC'ye girmez
    off = [p for p in d["pulslar"] if p.get("devre_disi")]
    assert off and all(p["sfc_dahil"] is False for p in off)
    # eski muamele kıyasta durur ve farklıdır: D kayıp yazılıyor, yerli sektörlere sızıyor
    cm = d["cift_muamele"]
    assert cm["duzeltildi"] is True
    assert cm["eski_sektor_etkisi_trilyonTL"]["D"] != cm["yeni_sektor_etkisi_trilyonTL"]["D"]
    assert cm["kapsam_disi_rant_usd_mn"] == 0.0  # transfer payı %100 (ödeyen F)
    # transfer tutarı = tüm dış rant (USD) × kur
    rant = _j(OUT / "DIS_RANT_PARASAL_C.json")["ozet"]["zarar_usd_mn_toplam"] if (OUT / "DIS_RANT_PARASAL_C.json").is_file() else _j(OUT / "DIS_RANT_PARASAL.json")["ozet"]["zarar_usd_mn_toplam"]
    assert abs(tr[0]["usd_mn_girdi"] - rant * d["pulslar"][0]["gerceklesme"]) <= 0.1


def test_bolge_tr_net_d_cift_sayim_yok():
    d = _j(OUT / "BOLGE_STOK_AKIS.json")
    s = _j(OUT / "STOK_AKIS_SIM.json")["entegre_puls"]["sektor_etkisi_trilyonTL"]
    tr = [a for a in d["aktorler"] if a["ulke"] == "TR"][0]
    assert abs(tr["sfc_net_trilyonTL"] - round(s["H"] + s["F"] + s["B"] + s["K"], 3)) <= 1e-3


def test_olasilik_duyarlilik_bandi():
    d = _j(OUT / "OLASILIK_DUYARLILIK.json")
    assert d["etiket"] == "olasilik_olculmedi_duyarlilik_bandi"
    ps = [r["p_C"] for r in d["satirlar"]]
    assert ps[0] == 0.30 and ps[-1] == 0.80 and len(ps) == 11
    for r in d["satirlar"]:
        assert abs(r["p_A"] + r["p_B"] + r["p_C"] - 1.0) <= 1e-3
    # A:B oranı tabanla aynı
    taban = d["taban_olasilik"]
    r0 = d["satirlar"][0]
    assert abs(r0["p_A"] / r0["p_B"] - taban["A"] / taban["B"]) <= 1e-2
    # C'nin ağırlığı arttıkça beklenen TR net iyileşir (C en iyi senaryo)
    es = [r["beklenen_tr_net_10y_yasam"] for r in d["satirlar"]]
    assert all(b >= a for a, b in zip(es, es[1:]))


def test_olasilik_duyarlilik_taban_ana_rapor_ile_tutarli():
    d = _j(OUT / "OLASILIK_DUYARLILIK.json")
    ana = _j(OUT / "SENARYO_UYGULANABILIRLIK.json")
    assert d["taban_satir_ana_rapor_ile_tutarli"] is True
    taban = d["taban_satir"]
    assert taban["skor_0_100"] == ana["skor_0_100"]
    assert taban["karar"] == ana["karar"]


def _dinamik():
    sys.path.insert(0, str(REPO / "etki_cephesi"))
    import c_dinamik_olcut as m  # noqa: E402

    return m


def test_c_dinamik_olcum_baslamadi_prior_degismez():
    d = _j(OUT / "C_DINAMIK_OLCUT.json")
    assert d["olcum_penceresi"]["uygun_gozlem_sayisi"] == 0
    assert d["posterior"] == d["prior"]  # bilinmiyor sıfır değildir: güncelleme yok
    assert d["guncelleme_durumu"].startswith("yok")


def test_c_dinamik_suruklenme_senaryodan_turetilir():
    m = _dinamik()
    sen = _j(DATA / "senaryolar.json")
    d = m._surukleme(sen, 10.0)
    assert d["A"] == 0.0 and d["B"] > 0 and d["C"] < 0  # merkez_sizinti_carpan 1,0 / 1,15 / 0,9


def test_c_dinamik_eksik_ay_12_ay_penceresini_bozar():
    m = _dinamik()
    ay = {f"2020-{i:02d}": {"X": 100.0, "YG": 10.0} for i in range(1, 13)}
    assert "2020-12" in m._oran12(ay)
    del ay["2020-06"]  # boşluk: 12 ardışık ay yok → oran yazılmaz (bilinmiyor ≠ 0)
    assert "2020-12" not in m._oran12(ay)


def test_c_dinamik_posterior_yonu_ve_bos_gozlem():
    m = _dinamik()
    prior = {"A": 0.22, "B": 0.18, "C": 0.60}
    drift = {"A": 0.0, "B": 0.014, "C": -0.0105}
    bos = m._posterior(prior, [], 0.0, 0.177, drift)
    assert all(abs(bos[k] - prior[k]) <= 1e-12 for k in prior)  # gözlem yok → güncelleme yok
    # yalnız birim mantığı için SENTETİK gözlem: C sürüklenmesi tekrar edilirse P(C) artar, B edilirse P(B) artar
    pc = m._posterior(prior, [drift["C"]] * 200, 0.0, 0.05, drift)
    pb = m._posterior(prior, [drift["B"]] * 200, 0.0, 0.05, drift)
    assert pc["C"] > prior["C"] and pb["B"] > prior["B"]


def test_c_dinamik_guc_bayragi_tutarli_ve_capa_uyumsuzlugu_ilan_edildi():
    d = _j(OUT / "C_DINAMIK_OLCUT.json")
    g = d["guc_analizi"]
    assert g["ayirt_edebilir"] == (g["C_icin_min_gerekli_yil"] <= g["horizon_yil"])
    cu = d["capa_uyumsuzluk"]
    assert cu["uyumsuz"] is True and cu["oran_evds_capa"] > 1.05
    capa = _j(DATA / "kalibre" / "gerceklik_capa.json")
    assert capa["usd_mn"]["yatirim_geliri_gideri"] == cu["capa_yatirim_geliri_gideri_mn_usd"]  # çapa değiştirilmedi


def test_kapilar_prior_tekduze_ve_gozlem_yokken_guncelleme_yok():
    d = _j(OUT / "OLASILIK_KAPILAR.json")
    assert all(abs(v - 1 / 3) < 1e-3 for v in d["prior"].values())
    assert d["bugunku_P"] == {"A": 0.333, "B": 0.333, "C": 0.333}  # baz 2026: kontrol noktaları gelecekte
    assert d["eski_el_atamasi"]["C"] == 0.6  # eski değer yalnız karşılaştırma için
    durum = {k["kapi"][:2]: k["durum"] for k in d["kapilar"]}
    assert durum["K3"] == "veri_yok" and durum["K4"] == "olculmedi"  # veri yok → olasılığa girmez


def test_kapilar_k2_sonuc_tablosu_monoton_ve_esik_tutarli():
    d = _j(OUT / "OLASILIK_KAPILAR.json")
    t = d["k2_sonuc_tablosu"]
    pc = [r["P"]["C"] for r in t]
    assert pc == sorted(pc)  # daha çok 'açık' → C artar
    for r in t:
        assert abs(sum(r["P"].values()) - 1) < 2e-3
    ds = _j(OUT / "OLASILIK_DUYARLILIK.json")
    esik = ds["gecisler"]["karar_kosullu_skor_62"]
    for r in ds["kapi_sonuclari"]:
        assert r["esigi_gecer"] == (r["skor_0_100"] >= 62.0)
        assert r["esigi_gecer"] == (r["P"]["C"] >= esik - 5e-3)  # enterpolasyon yuvarlaması payı
    assert d["en_iyi_tek_kapi_P_C"] == max(pc)
    # δ=0 → kapı bilgi taşımaz
    z = next(x for x in d["k2_duyarlilik"] if x["delta"] == 0.0)
    assert z["tekduze"]["k=0"] == z["tekduze"]["k=n"] == 0.333


def test_olasilik_baglandi_ve_dongu_yok():
    src = (REPO / "etki_cephesi" / "_olasilik.py").read_text(encoding="utf-8")
    assert "reports" not in src and "OUT" not in src  # saf hesap: pipeline raporu okumaz → döngü yok
    sen = _j(DATA / "senaryolar.json")
    assert all("olasilik_vekili" not in s for s in sen["senaryolar"])  # eski el ataması yeniden adlandırıldı
    sys.path.insert(0, str(REPO / "etki_cephesi"))
    import _olasilik  # noqa: E402

    v = _olasilik.vekil()
    assert abs(sum(v.values()) - 1) < 1e-12
    k = _j(OUT / "OLASILIK_KAPILAR.json")
    assert all(abs(v[s] - k["bugunku_P"][s]) < 1e-3 for s in v)
    ana = _j(OUT / "SENARYO_UYGULANABILIRLIK.json")
    assert abs(ana["bilesenler"]["olasilik_senaryo_c"] - v["C"]) < 1e-3


def test_referans_senaryo_etiketi_olasilik_iddiasi_tasimiyor():
    sen = _j(DATA / "senaryolar.json")
    assert sen["referans_senaryo"] == "C" and "en_olasi" not in sen
    assert _j(OUT / "PROJEKSIYON.json")["referans_senaryo"] == "C"
    eski = [p.name for p in OUT.glob("*") if p.suffix in (".md", ".json") and ("en olası" in p.read_text(encoding="utf-8") or "en_olasi" in p.read_text(encoding="utf-8"))]
    assert eski == []  # bayat rapor kalmadı (UZUN_VADE_ESIK artık run_all içinde)


def test_senaryo_raporlari_a_b_c_ayni_iskelet_ve_alanlar():
    import re

    iskelet = {}
    for sid in ("A", "B", "C"):
        t = (OUT / f"SENARYO_RAPOR_{sid}.md").read_text(encoding="utf-8")
        iskelet[sid] = [l.split("|")[1].strip() for l in t.splitlines() if l.startswith("| ") and not l.startswith("| Alan") and not l.startswith("| ---")]
        assert re.search(r"^## 9\. ", t, re.M)
    assert iskelet["A"] == iskelet["B"] == iskelet["C"]  # aynı alanlar, aynı sıra
    for sid in ("A", "B", "C"):
        for ad in ("AKIS_OLCUM_%s.json", "AKIS_OLCUM_%s.md", "ZARAR_COZUM_%s.md", "ULKE_KAYIP_%s.md", "DIS_AKTOR_%s.md"):
            assert (OUT / (ad % sid)).is_file(), ad % sid
    k = (OUT / "SENARYO_KARSILASTIRMA.md").read_text(encoding="utf-8")
    assert "F.4 stok 2036, baz" in k and "| — | — | — |" not in k.split("## 6.")[1].split("## 7.")[0]  # stok bandı üç senaryoda dolu


def test_uretim_finans_katmani_senaryoya_ozgu_gerceklesme():
    sys.path.insert(0, str(REPO / "etki_cephesi"))
    import uretim_ic_akis as u  # noqa: E402

    sen = {s["id"]: s for s in _j(DATA / "senaryolar.json")["senaryolar"]}
    uk = _j(DATA / "uretim_ic_akis_kopru.json")
    fk = _j(DATA / "finans_katman_kopru.json")
    g = {}
    for sid in "ABC":
        ur = _j(OUT / f"URETIM_IC_AKIS_{sid}.json")
        fi = _j(OUT / f"FINANS_KATMAN_{sid}.json")
        zc = _j(OUT / f"ZARAR_COZUM_{sid}.json")
        g[sid] = (ur["senaryo_gerceklesme"]["g_uretim"], fi["senaryo_gerceklesme"]["g_finans"])
        # katmanlar yalnız iyileştirir: zarar çözümü ≤ üretim ≤ finans (TR net)
        z = zc["zarar_cozum_sonrasi"]["tr_net_birlesik_vekil"]
        a = ur["uretim_ic_akis_tam"]["tr_net_birlesik_vekil"]
        b = fi["finans_katman_tam"]["tr_net_birlesik_vekil"]
        assert z <= a  # üretim katmanı yalnız iyileştirir
        if fi["senaryo_gerceklesme"]["ters_cevrildi"]:
            assert b < a  # araçsallaşmada finans katmanı ters çevrilir: üretimden kötü
        else:
            assert a <= b
        assert "senaryo_finans_carpanlari" not in fi  # çift sayan C-göreli ölçekleme kalktı
    assert g["C"] == (1.0, 1.0)  # C'nin sayıları değişmez
    assert g["C"][0] > g["A"][0] > g["B"][0] and g["C"][1] > g["A"][1] > g["B"][1]
    assert abs(g["A"][0] - sen["A"]["bag_modu"]["kullanim"] / sen["C"]["bag_modu"]["kullanim"]) < 1e-3
    assert u.etkin_carpan({"x": 0.5}, 1.0) == {"x": 0.5} and u.etkin_carpan({"x": 0.5}, 0.0) == {"x": 1.0}
    assert uk["senaryo_gerceklesme"]["aktif"] and fk["senaryo_gerceklesme"]["aktif"]


def test_b_finans_katmani_arac_sallasmada_ters_cevrildi():
    d = {sid: _j(OUT / f"FINANS_KATMAN_{sid}.json") for sid in "ABC"}
    assert [d[s]["senaryo_gerceklesme"]["baskin_mod"] for s in "ABC"] == ["atil", "aracsal", "kullanim"]
    assert [d[s]["senaryo_gerceklesme"]["ters_cevrildi"] for s in "ABC"] == [False, True, False]
    assert d["B"]["senaryo_gerceklesme"]["g_finans"] == -d["B"]["senaryo_gerceklesme"]["g_finans_pozitif"]
    f = d["B"]["finans_katman_tam"]
    assert f["tr_finans_geri_kazanim_vekili"] < 0  # kazanım kayba döndü
    u = d["B"]["uretim_ic_akis_taban"]
    assert f["turkiye_yaricevre_bosalma"] > f["turkiye_yaricevre_bosalma"] - 1e-12 and f["merkez_finans_sizinti_toplam"] > 0
    b = d["B"]["ters_cevirme_bandi"]
    # güç arttıkça B kötüleşir: çevrilmemiş > etkisiz > yarım > tam
    assert b["cevrilmemis_pozitif"] > b["guc_0.0_etkisiz"] > b["guc_0.5"] > b["guc_1.0_tam_ayna"]
    assert abs(b["guc_0.0_etkisiz"] - u["tr_net_birlesik_vekil"]) < 1e-9  # güç 0 = finans katmanı yok
    assert abs(b["guc_1.0_tam_ayna"] - f["tr_net_birlesik_vekil"]) < 1e-9
    assert d["A"]["ters_cevirme_bandi"] is None and d["C"]["ters_cevirme_bandi"] is None
