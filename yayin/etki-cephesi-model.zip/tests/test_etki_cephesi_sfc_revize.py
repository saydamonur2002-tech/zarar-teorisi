"""Revize: SFC köprüsü hataları (tavan=gerçekleşme, türetilmiş λ, kapanış, kur, etiket)."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "etki_cephesi"
DATA = REPO / "data" / "etki_cephesi"
ZARAR = REPO / "_incoming" / "zarar-teorisi-main"


def _j(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))


def test_lambda_turetilmis_degil():
    c = _j(DATA / "zarar_teorisi_kopru.json")["etki_cephesi_carpanlari"]
    b = _j(DATA / "zarar_teorisi_kopru.json")["bes_adim_kanit"]
    turetilmis = round(1 - b["eski_tavan"] / b["yeni_tavan"], 4)
    assert c["ic_dongu_kazanim"] != turetilmis
    assert c["ic_dongu_kazanim_etiket"] == "senaryo_parametresi"
    assert c["ic_dongu_kazanim"] in c["ic_dongu_kazanim_bant"]


def test_stok_yolu_tavani_gerceklesme_saymaz():
    d = _j(OUT / "STOK_AKIS_SIM.json")
    bes = d["bes_adim_kisit"]
    assert "stok_silim_tavan" not in bes
    son = d["yillik_stok_akis"][-1]["stok_f4"]
    assert son["etiket"] == "olculmedi_sabit"
    assert son["stok_f4_milyar"] == bes["stok_bas_milyar"]
    for r in d["stok_f4_bandi_son_yil"].values():
        assert r["ust_sinir_icinde"] is True


def test_sfc_kapanis_ilan_ve_dissal_ayrik():
    d = _j(OUT / "STOK_AKIS_SIM.json")
    e = d["entegre_puls"]
    toplam_etki = sum(e["sektor_etkisi_trilyonTL"].values())
    # simulate toplamı korur: etki toplamı = darbe toplamı
    assert abs(toplam_etki - e["kapanis"]["x_kapali_toplam_trilyonTL"]) <= 5e-3
    assert e["kapanis"]["acik_fark_trilyonTL"] == e["kapanis"]["x_kapali_toplam_trilyonTL"]
    dissal = {p["id"] for p in d["pulslar"] if not p["sfc_dahil"] and not p.get("devre_disi")}
    assert dissal == set(d["dissal_enjeksiyon"]["pulslar"])
    assert dissal  # refah/tasarruf/yasam darbeleri SFC dışında
    kapali_toplam = sum(p["x_trilyonTL"] for p in d["pulslar"] if p["sfc_dahil"])
    assert abs(kapali_toplam - e["kapanis"]["x_kapali_toplam_trilyonTL"]) <= 5e-3


def test_kur_matris_donemi():
    d = _j(OUT / "STOK_AKIS_SIM.json")
    oz = _j(ZARAR / "akis_model_ozeti.json")
    beklenen = float(oz["dis_borc_artisi"]["stok_milyar_USD"][d["matris_donem"]]["USDTRY"])
    assert d["kur_tl_usd"] == beklenen
    assert d["kur_tl_usd"] != 32.87


def test_simulate_toplami_korur():
    sys.path.insert(0, str(ZARAR))
    from akis_model import simulate  # noqa: E402

    L = np.loadtxt(ZARAR / "L_v2_2026-Q1.csv", delimiter=",", skiprows=1, usecols=range(1, 6))
    G = np.loadtxt(ZARAR / "G_v2_2026-Q1.csv", delimiter=",", skiprows=1, usecols=range(1, 6))
    nfp = np.array([1.0, -3.0, 0.5, -0.6, 1.5]) * 1e9
    for s in range(5):
        x = np.zeros(5)
        x[s] = -1e9
        assert abs(float(simulate(L, G, nfp, x, lam=0.5, kappa=0.1).sum()) - float(x.sum())) <= 1e-4 * abs(float(x.sum()))


def test_finans_katman_etiketi():
    d = _j(OUT / "FINANS_KATMAN.json")
    assert d["etiket"] == "varsayim_carpanli_ham"
    assert "varsayım çarpanlı ham" in (OUT / "FINANS_KATMAN.md").read_text(encoding="utf-8")


def test_lm_rant_kapanis_ilani():
    d = _j(OUT / "LM_RANT_SEKTOR.json")
    assert "kapanis_ok" in d["entegre"] and "x_toplam_trilyonTL" in d["entegre"]
    assert d["kur_tl_usd"] != 32.87


def test_uygulanabilirlik_ozeti_sayidan_turetilir():
    d = _j(OUT / "SENARYO_UYGULANABILIRLIK.json")
    # sabit "10 yılda TR net iyileşir" cümlesi yok; özet sayıları içerir
    assert f"{d['iyilesme_beklenen_vekil']:+.2f}" in d["ozet"]
    assert f"{d['iyilesme_c_vekil']:+.2f}" in d["ozet"]
    if d["iyilesme_beklenen_vekil"] <= 0.05:
        assert "kısmi gerçekleşme ile 10 yılda TR net iyileşir" not in d["ozet"]
        assert any("iyileşme yok" in e for e in d["engeller"])


def test_pipeline_kararli_duruma_oturdu():
    d = _j(OUT / "RUN_ALL_KARARLILIK.json")
    assert d["kararli"] is True


def test_d_cift_muamelesi_duzeltildi():
    d = _j(OUT / "STOK_AKIS_SIM.json")
    tr = [p for p in d["pulslar"] if p["tur"] == "transfer"]
    assert len(tr) == 1
    xs = tr[0]["x_sektor_trilyonTL"]
    assert abs(sum(xs.values())) <= 1e-3  # toplam sıfır
    assert xs["F"] < 0 and abs(xs["D"] + xs["F"]) <= 1e-3  # F -A, D +A
    assert all(abs(xs[s]) <= 1e-3 for s in ("H", "B", "K"))
    e = d["entegre_puls"]
    assert e["kapanis"]["kapanis_ok"] is True
    # transfer yayılmaz: entegre etki doğrudan transfer
    for s in ("H", "F", "B", "K", "D"):
        assert abs(e["sektor_etkisi_trilyonTL"][s] - xs[s]) <= 1e-3
    # devre dışı eski D "kârı" SFC'ye girmez
    off = [p for p in d["pulslar"] if p.get("devre_disi")]
    assert off and all(p["sfc_dahil"] is False for p in off)
    # eski muamele kıyasta durur ve farklıdır: D kayıp yazılıyor, yerli sektörlere sızıyor
    cm = d["cift_muamele"]
    assert cm["duzeltildi"] is True
    assert cm["eski_sektor_etkisi_trilyonTL"]["D"] != cm["yeni_sektor_etkisi_trilyonTL"]["D"]
    assert cm["kapsam_disi_rant_usd_mn"] == 0.0  # transfer payı %100 (ödeyen F)
    # transfer tutarı = tüm dış rant (USD) × kur
    rant = _j(OUT / "DIS_RANT_PARASAL_C.json")["ozet"]["zarar_usd_mn_toplam"] if (OUT / "DIS_RANT_PARASAL_C.json").is_file() else _j(OUT / "DIS_RANT_PARASAL.json")["ozet"]["zarar_usd_mn_toplam"]
    assert abs(tr[0]["usd_mn_girdi"] - rant * d["pulslar"][0]["gerceklesme"]) <= 0.1


def test_bolge_tr_net_d_cift_sayim_yok():
    d = _j(OUT / "BOLGE_STOK_AKIS.json")
    s = _j(OUT / "STOK_AKIS_SIM.json")["entegre_puls"]["sektor_etkisi_trilyonTL"]
    tr = [a for a in d["aktorler"] if a["ulke"] == "TR"][0]
    assert abs(tr["sfc_net_trilyonTL"] - round(s["H"] + s["F"] + s["B"] + s["K"], 3)) <= 1e-3
