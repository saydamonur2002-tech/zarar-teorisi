"""Revize: SFC köprüsü hataları (tavan=gerçekleşme, türetilmiş λ, kapanış, kur, etiket)."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "etki_cephesi"
DATA = REPO / "data" / "etki_cephesi"
ZARAR = REPO / "_incoming" / "zarar-teorisi-main"


def _j(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))


def test_lambda_turetilmis_degil():
    c = _j(DATA / "zarar_teorisi_kopru.json")["etki_cephesi_carpanlari"]
    b = _j(DATA / "zarar_teorisi_kopru.json")["bes_adim_kanit"]
    turetilmis = round(1 - b["eski_tavan"] / b["yeni_tavan"], 4)
    assert c["ic_dongu_kazanim"] != turetilmis
    assert c["ic_dongu_kazanim_etiket"] == "senaryo_parametresi"
    assert c["ic_dongu_kazanim"] in c["ic_dongu_kazanim_bant"]


def test_stok_yolu_tavani_gerceklesme_saymaz():
    d = _j(OUT / "STOK_AKIS_SIM.json")
    bes = d["bes_adim_kisit"]
    assert "stok_silim_tavan" not in bes
    son = d["yillik_stok_akis"][-1]["stok_f4"]
    assert son["etiket"] == "olculmedi_sabit"
    assert son["stok_f4_milyar"] == bes["stok_bas_milyar"]
    for r in d["stok_f4_bandi_son_yil"].values():
        assert r["ust_sinir_icinde"] is True


def test_sfc_kapanis_ilan_ve_dissal_ayrik():
    d = _j(OUT / "STOK_AKIS_SIM.json")
    e = d["entegre_puls"]
    toplam_etki = sum(e["sektor_etkisi_trilyonTL"].values())
    # simulate toplamı korur: etki toplamı = darbe toplamı
    assert abs(toplam_etki - e["kapanis"]["x_kapali_toplam_trilyonTL"]) <= 5e-3
    assert e["kapanis"]["acik_fark_trilyonTL"] == e["kapanis"]["x_kapali_toplam_trilyonTL"]
    dissal = {p["id"] for p in d["pulslar"] if not p["sfc_dahil"] and not p.get("devre_disi")}
    assert dissal == set(d["dissal_enjeksiyon"]["pulslar"])
    assert dissal  # refah/tasarruf/yasam darbeleri SFC dışında
    kapali_toplam = sum(p["x_trilyonTL"] for p in d["pulslar"] if p["sfc_dahil"])
    assert abs(kapali_toplam - e["kapanis"]["x_kapali_toplam_trilyonTL"]) <= 5e-3


def test_kur_matris_donemi():
    d = _j(OUT / "STOK_AKIS_SIM.json")
    oz = _j(ZARAR / "akis_model_ozeti.json")
    beklenen = float(oz["dis_borc_artisi"]["stok_milyar_USD"][d["matris_donem"]]["USDTRY"])
    assert d["kur_tl_usd"] == beklenen
    assert d["kur_tl_usd"] != 32.87


def test_simulate_toplami_korur():
    sys.path.insert(0, str(ZARAR))
    from akis_model import simulate  # noqa: E402

    L = np.loadtxt(ZARAR / "L_v2_2026-Q1.csv", delimiter=",", skiprows=1, usecols=range(1, 6))
    G = np.loadtxt(ZARAR / "G_v2_2026-Q1.csv", delimiter=",", skiprows=1, usecols=range(1, 6))
    nfp = np.array([1.0, -3.0, 0.5, -0.6, 1.5]) * 1e9
    for s in range(5):
        x = np.zeros(5)
        x[s] = -1e9
        assert abs(float(simulate(L, G, nfp, x, lam=0.5, kappa=0.1).sum()) - float(x.sum())) <= 1e-4 * abs(float(x.sum()))


def test_finans_katman_etiketi():
    d = _j(OUT / "FINANS_KATMAN.json")
    assert d["etiket"] == "varsayim_carpanli_ham"
    assert "varsayım çarpanlı ham" in (OUT / "FINANS_KATMAN.md").read_text(encoding="utf-8")


def test_lm_rant_kapanis_ilani():
    d = _j(OUT / "LM_RANT_SEKTOR.json")
    assert "kapanis_ok" in d["entegre"] and "x_toplam_trilyonTL" in d["entegre"]
    assert d["kur_tl_usd"] != 32.87


def test_uygulanabilirlik_ozeti_sayidan_turetilir():
    d = _j(OUT / "SENARYO_UYGULANABILIRLIK.json")
    # sabit "10 yılda TR net iyileşir" cümlesi yok; özet sayıları içerir
    assert f"{d['iyilesme_beklenen_vekil']:+.2f}" in d["ozet"]
    assert f"{d['iyilesme_c_vekil']:+.2f}" in d["ozet"]
    if d["iyilesme_beklenen_vekil"] <= 0.05:
        assert "kısmi gerçekleşme ile 10 yılda TR net iyileşir" not in d["ozet"]
        assert any("iyileşme yok" in e for e in d["engeller"])


def test_pipeline_kararli_duruma_oturdu():
    d = _j(OUT / "RUN_ALL_KARARLILIK.json")
    assert d["kararli"] is True


def test_d_cift_muamelesi_duzeltildi():
    d = _j(OUT / "STOK_AKIS_SIM.json")
    tr = [p for p in d["pulslar"] if p["tur"] == "transfer"]
    assert len(tr) == 1
    xs = tr[0]["x_sektor_trilyonTL"]
    assert abs(sum(xs.values())) <= 1e-3  # toplam sıfır
    assert xs["F"] < 0 and abs(xs["D"] + xs["F"]) <= 1e-3  # F -A, D +A
    assert all(abs(xs[s]) <= 1e-3 for s in ("H", "B", "K"))
    e = d["entegre_puls"]
    assert e["kapanis"]["kapanis_ok"] is True
    # transfer yayılmaz: entegre etki doğrudan transfer
    for s in ("H", "F", "B", "K", "D"):
        assert abs(e["sektor_etkisi_trilyonTL"][s] - xs[s]) <= 1e-3
    # devre dışı eski D "kârı" SFC'ye girmez
    off = [p for p in d["pulslar"] if p.get("devre_disi")]
    assert off and all(p["sfc_dahil"] is False for p in off)
    # eski muamele kıyasta durur ve farklıdır: D kayıp yazılıyor, yerli sektörlere sızıyor
    cm = d["cift_muamele"]
    assert cm["duzeltildi"] is True
    assert cm["eski_sektor_etkisi_trilyonTL"]["D"] != cm["yeni_sektor_etkisi_trilyonTL"]["D"]
    assert cm["kapsam_disi_rant_usd_mn"] == 0.0  # transfer payı %100 (ödeyen F)
    # transfer tutarı = tüm dış rant (USD) × kur
    rant = _j(OUT / "DIS_RANT_PARASAL_C.json")["ozet"]["zarar_usd_mn_toplam"] if (OUT / "DIS_RANT_PARASAL_C.json").is_file() else _j(OUT / "DIS_RANT_PARASAL.json")["ozet"]["zarar_usd_mn_toplam"]
    assert abs(tr[0]["usd_mn_girdi"] - rant * d["pulslar"][0]["gerceklesme"]) <= 0.1


def test_bolge_tr_net_d_cift_sayim_yok():
    d = _j(OUT / "BOLGE_STOK_AKIS.json")
    s = _j(OUT / "STOK_AKIS_SIM.json")["entegre_puls"]["sektor_etkisi_trilyonTL"]
    tr = [a for a in d["aktorler"] if a["ulke"] == "TR"][0]
    assert abs(tr["sfc_net_trilyonTL"] - round(s["H"] + s["F"] + s["B"] + s["K"], 3)) <= 1e-3


def test_olasilik_duyarlilik_bandi():
    d = _j(OUT / "OLASILIK_DUYARLILIK.json")
    assert d["etiket"] == "olasilik_olculmedi_duyarlilik_bandi"
    ps = [r["p_C"] for r in d["satirlar"]]
    assert ps[0] == 0.30 and ps[-1] == 0.80 and len(ps) == 11
    for r in d["satirlar"]:
        assert abs(r["p_A"] + r["p_B"] + r["p_C"] - 1.0) <= 1e-3
    # A:B oranı tabanla aynı
    taban = d["taban_olasilik"]
    r0 = d["satirlar"][0]
    assert abs(r0["p_A"] / r0["p_B"] - taban["A"] / taban["B"]) <= 1e-2
    # C'nin ağırlığı arttıkça beklenen TR net iyileşir (C en iyi senaryo)
    es = [r["beklenen_tr_net_10y_yasam"] for r in d["satirlar"]]
    assert all(b >= a for a, b in zip(es, es[1:]))


def test_olasilik_duyarlilik_taban_ana_rapor_ile_tutarli():
    d = _j(OUT / "OLASILIK_DUYARLILIK.json")
    ana = _j(OUT / "SENARYO_UYGULANABILIRLIK.json")
    assert d["taban_satir_ana_rapor_ile_tutarli"] is True
    taban = d["taban_satir"]
    assert taban["skor_0_100"] == ana["skor_0_100"]
    assert taban["karar"] == ana["karar"]


def _dinamik():
    sys.path.insert(0, str(REPO / "etki_cephesi"))
    import c_dinamik_olcut as m  # noqa: E402

    return m


def test_c_dinamik_olcum_baslamadi_prior_degismez():
    d = _j(OUT / "C_DINAMIK_OLCUT.json")
    assert d["olcum_penceresi"]["uygun_gozlem_sayisi"] == 0
    assert d["posterior"] == d["prior"]  # bilinmiyor sıfır değildir: güncelleme yok
    assert d["guncelleme_durumu"].startswith("yok")


def test_c_dinamik_suruklenme_senaryodan_turetilir():
    m = _dinamik()
    sen = _j(DATA / "senaryolar.json")
    d = m._surukleme(sen, 10.0)
    sys.path.insert(0, str(REPO / "etki_cephesi"))
    import _gecmis  # noqa: E402

    assert d == _gecmis.suruklenme()  # geçmişten: A medyan, B q75, C q25
    assert d["C"] < d["A"] < d["B"]


def test_c_dinamik_eksik_ay_12_ay_penceresini_bozar():
    m = _dinamik()
    ay = {f"2020-{i:02d}": {"X": 100.0, "YG": 10.0} for i in range(1, 13)}
    assert "2020-12" in m._oran12(ay)
    del ay["2020-06"]  # boşluk: 12 ardışık ay yok → oran yazılmaz (bilinmiyor ≠ 0)
    assert "2020-12" not in m._oran12(ay)


def test_c_dinamik_posterior_yonu_ve_bos_gozlem():
    m = _dinamik()
    prior = {"A": 0.22, "B": 0.18, "C": 0.60}
    drift = {"A": 0.0, "B": 0.014, "C": -0.0105}
    bos = m._posterior(prior, [], 0.0, 0.177, drift)
    assert all(abs(bos[k] - prior[k]) <= 1e-12 for k in prior)  # gözlem yok → güncelleme yok
    # yalnız birim mantığı için SENTETİK gözlem: C sürüklenmesi tekrar edilirse P(C) artar, B edilirse P(B) artar
    pc = m._posterior(prior, [drift["C"]] * 200, 0.0, 0.05, drift)
    pb = m._posterior(prior, [drift["B"]] * 200, 0.0, 0.05, drift)
    assert pc["C"] > prior["C"] and pb["B"] > prior["B"]


def test_c_dinamik_guc_bayragi_tutarli_ve_capa_uyumsuzlugu_ilan_edildi():
    d = _j(OUT / "C_DINAMIK_OLCUT.json")
    g = d["guc_analizi"]
    assert g["ayirt_edebilir"] == (g["C_icin_min_gerekli_yil"] <= g["horizon_yil"])
    cu = d["capa_uyumsuzluk"]
    assert cu["uyumsuz"] is True and cu["oran_evds_capa"] > 1.05
    capa = _j(DATA / "kalibre" / "gerceklik_capa.json")
    assert capa["usd_mn"]["yatirim_geliri_gideri"] == cu["capa_yatirim_geliri_gideri_mn_usd"]  # çapa değiştirilmedi


def test_kapilar_prior_tekduze_ve_gozlem_yokken_guncelleme_yok():
    d = _j(OUT / "OLASILIK_KAPILAR.json")
    assert all(abs(v - 1 / 3) < 1e-3 for v in d["prior"].values())
    assert d["bugunku_P"] == {"A": 0.333, "B": 0.333, "C": 0.333}  # baz 2026: kontrol noktaları gelecekte
    assert d["eski_el_atamasi"]["C"] == 0.6  # eski değer yalnız karşılaştırma için
    durum = {k["kapi"][:2]: k["durum"] for k in d["kapilar"]}
    assert durum["K3"] == "veri_yok" and durum["K4"] == "olculmedi"  # veri yok → olasılığa girmez


def test_kapilar_k2_sonuc_tablosu_monoton_ve_esik_tutarli():
    d = _j(OUT / "OLASILIK_KAPILAR.json")
    t = d["k2_sonuc_tablosu"]
    pc = [r["P"]["C"] for r in t]
    # geçmişte açık dış finansman B-benzeri rejimde (2023–25) görüldü: P(C) açık sayısıyla monoton DEĞİL
    assert pc != sorted(pc) and t[-1]["P"]["B"] == max(t[-1]["P"].values())
    for r in t:
        assert abs(sum(r["P"].values()) - 1) < 2e-3
    ds = _j(OUT / "OLASILIK_DUYARLILIK.json")
    esik = ds["gecisler"]["karar_kosullu_skor_62"]
    for r in ds["kapi_sonuclari"]:
        assert r["esigi_gecer"] == (r["skor_0_100"] >= 62.0)
        # eşik bantta hiç geçilmiyorsa (None) hiçbir kapı sonucu da geçmemeli
        assert r["esigi_gecer"] == (esik is not None and r["P"]["C"] >= esik - 5e-3)  # enterpolasyon yuvarlaması payı
    assert d["en_iyi_tek_kapi_P_C"] == max(pc)
    # λ=1 → kapı bilgi taşımaz (tüm senaryolara taban oran)
    z = next(x for x in d["k2_duyarlilik"] if x["lambda"] == 1.0)
    assert z["tekduze"]["k=0"] == z["tekduze"]["k=n"] == 0.333


def test_olasilik_baglandi_ve_dongu_yok():
    src = (REPO / "etki_cephesi" / "_olasilik.py").read_text(encoding="utf-8")
    assert "reports" not in src and "OUT" not in src  # saf hesap: pipeline raporu okumaz → döngü yok
    sen = _j(DATA / "senaryolar.json")
    assert all("olasilik_vekili" not in s for s in sen["senaryolar"])  # eski el ataması yeniden adlandırıldı
    sys.path.insert(0, str(REPO / "etki_cephesi"))
    import _olasilik  # noqa: E402

    v = _olasilik.vekil()
    assert abs(sum(v.values()) - 1) < 1e-12
    k = _j(OUT / "OLASILIK_KAPILAR.json")
    assert all(abs(v[s] - k["bugunku_P"][s]) < 1e-3 for s in v)
    ana = _j(OUT / "SENARYO_UYGULANABILIRLIK.json")
    assert abs(ana["bilesenler"]["olasilik_senaryo_c"] - v["C"]) < 1e-3


def test_referans_senaryo_etiketi_olasilik_iddiasi_tasimiyor():
    sen = _j(DATA / "senaryolar.json")
    assert sen["referans_senaryo"] == "C" and "en_olasi" not in sen
    assert _j(OUT / "PROJEKSIYON.json")["referans_senaryo"] == "C"
    eski = [p.name for p in OUT.glob("*") if p.suffix in (".md", ".json") and ("en olası" in p.read_text(encoding="utf-8") or "en_olasi" in p.read_text(encoding="utf-8"))]
    assert eski == []  # bayat rapor kalmadı (UZUN_VADE_ESIK artık run_all içinde)


def test_senaryo_raporlari_a_b_c_ayni_iskelet_ve_alanlar():
    import re

    iskelet = {}
    for sid in ("A", "B", "C"):
        t = (OUT / f"SENARYO_RAPOR_{sid}.md").read_text(encoding="utf-8")
        iskelet[sid] = [l.split("|")[1].strip() for l in t.splitlines() if l.startswith("| ") and not l.startswith("| Alan") and not l.startswith("| ---")]
        assert re.search(r"^## 9\. ", t, re.M)
    assert iskelet["A"] == iskelet["B"] == iskelet["C"]  # aynı alanlar, aynı sıra
    for sid in ("A", "B", "C"):
        for ad in ("AKIS_OLCUM_%s.json", "AKIS_OLCUM_%s.md", "ZARAR_COZUM_%s.md", "ULKE_KAYIP_%s.md", "DIS_AKTOR_%s.md"):
            assert (OUT / (ad % sid)).is_file(), ad % sid
    k = (OUT / "SENARYO_KARSILASTIRMA.md").read_text(encoding="utf-8")
    assert "F.4 stok 2036, baz" in k and "| — | — | — |" not in k.split("## 6.")[1].split("## 7.")[0]  # stok bandı üç senaryoda dolu


def test_uretim_finans_katmani_senaryoya_ozgu_gerceklesme():
    sys.path.insert(0, str(REPO / "etki_cephesi"))
    import uretim_ic_akis as u  # noqa: E402

    sen = {s["id"]: s for s in _j(DATA / "senaryolar.json")["senaryolar"]}
    uk = _j(DATA / "uretim_ic_akis_kopru.json")
    fk = _j(DATA / "finans_katman_kopru.json")
    g = {}
    for sid in "ABC":
        ur = _j(OUT / f"URETIM_IC_AKIS_{sid}.json")
        fi = _j(OUT / f"FINANS_KATMAN_{sid}.json")
        zc = _j(OUT / f"ZARAR_COZUM_{sid}.json")
        g[sid] = (ur["senaryo_gerceklesme"]["g_uretim"], fi["senaryo_gerceklesme"]["g_finans"])
        # katmanlar yalnız iyileştirir: zarar çözümü ≤ üretim ≤ finans (TR net)
        z = zc["zarar_cozum_sonrasi"]["tr_net_birlesik_vekil"]
        a = ur["uretim_ic_akis_tam"]["tr_net_birlesik_vekil"]
        b = fi["finans_katman_tam"]["tr_net_birlesik_vekil"]
        assert z <= a  # üretim katmanı yalnız iyileştirir
        if fi["senaryo_gerceklesme"]["ters_cevrildi"]:
            assert b < a  # araçsallaşmada finans katmanı ters çevrilir: üretimden kötü
        else:
            assert a <= b
        assert "senaryo_finans_carpanlari" not in fi  # çift sayan C-göreli ölçekleme kalktı
    assert g["C"] == (1.0, 1.0)  # C'nin sayıları değişmez
    assert g["C"][0] > g["A"][0] > g["B"][0] and g["C"][1] > g["A"][1] > g["B"][1]
    assert abs(g["A"][0] - sen["A"]["bag_modu"]["kullanim"] / sen["C"]["bag_modu"]["kullanim"]) < 1e-3
    assert u.etkin_carpan({"x": 0.5}, 1.0) == {"x": 0.5} and u.etkin_carpan({"x": 0.5}, 0.0) == {"x": 1.0}
    assert uk["senaryo_gerceklesme"]["aktif"] and fk["senaryo_gerceklesme"]["aktif"]


def test_b_finans_katmani_arac_sallasmada_ters_cevrildi():
    d = {sid: _j(OUT / f"FINANS_KATMAN_{sid}.json") for sid in "ABC"}
    assert [d[s]["senaryo_gerceklesme"]["baskin_mod"] for s in "ABC"] == ["atil", "aracsal", "kullanim"]
    assert [d[s]["senaryo_gerceklesme"]["ters_cevrildi"] for s in "ABC"] == [False, True, False]
    assert d["B"]["senaryo_gerceklesme"]["g_finans"] == -d["B"]["senaryo_gerceklesme"]["g_finans_pozitif"]
    f = d["B"]["finans_katman_tam"]
    assert f["tr_finans_geri_kazanim_vekili"] < 0  # kazanım kayba döndü
    u = d["B"]["uretim_ic_akis_taban"]
    assert f["turkiye_yaricevre_bosalma"] > f["turkiye_yaricevre_bosalma"] - 1e-12 and f["merkez_finans_sizinti_toplam"] > 0
    b = d["B"]["ters_cevirme_bandi"]
    # güç arttıkça B kötüleşir: çevrilmemiş > etkisiz > yarım > tam
    assert b["cevrilmemis_pozitif"] > b["guc_0.0_etkisiz"] > b["guc_0.5"] > b["guc_1.0_tam_ayna"]
    assert abs(b["guc_0.0_etkisiz"] - u["tr_net_birlesik_vekil"]) < 1e-9  # güç 0 = finans katmanı yok
    assert abs(b["guc_1.0_tam_ayna"] - f["tr_net_birlesik_vekil"]) < 1e-9
    assert d["A"]["ters_cevirme_bandi"] is None and d["C"]["ters_cevirme_bandi"] is None


def test_finans_katmani_kalibre_yola_bagli():
    cfg = _j(DATA / "finans_katman_kopru.json")["kalibre_yola_baglama"]
    assert cfg["aktif"] and cfg["mod"] == "uretimle_es_zamanli"
    for sid in "ABC":
        g = _j(OUT / f"GERCEKLIK_KALIBRE_{sid}.json")
        assert g["yol_modu"] == "uretimle_es_zamanli"
        yol = g["yol_koridor"]
        yillar = [r["yil"] for r in yol]
        assert yillar == list(range(yillar[0], yillar[0] + len(yillar)))  # eski sıralı yoldaki yıl boşluğu yok
        k = {r["katman"]: r["tr_net"] for r in g["katman_yigini_kalibre"]}
        z, u, f = k["zarar_teorisi"], k["uretim_ic_akis"], k["finans_katman"]
        assert abs(yol[-1]["tr_net"] - f) < 2e-3  # yol sonunda üç katman da tamam
        assert yol[7]["faz"] == "uretim+finans"
        # 10. yıl: finans, üretimle birlikte 3 yıl yükseldi (eski sıralı yolda finans hiç yoktu)
        beklenen = z + (u - z) * 3 / 12 + (f - u) * 3 / 10
        assert abs(g["tr_net_yol_10_son"] - beklenen) < 2e-3
    # B'de ters çevrilmiş finans 10 yıllık yola girer: çevrilmemiş bir finansla karşılaştır
    b = _j(OUT / "GERCEKLIK_KALIBRE_B.json")
    assert b["gerceklesme_oranlari"]["finans_katman"] > 0.9  # zarar (ters çevirme) gerçekleşme tavanına tabi değil
    k = {r["katman"]: r["tr_net"] for r in b["katman_yigini_kalibre"]}
    assert k["finans_katman"] < k["uretim_ic_akis"]


def test_gecmis_projeksiyon_yalniz_gecmis_kullanir():
    import ast

    src = (REPO / "etki_cephesi" / "gecmis_projeksiyon.py").read_text(encoding="utf-8")
    tree = ast.parse(src)
    ice = {n.module for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)} | {a.name for n in ast.walk(tree) if isinstance(n, ast.Import) for a in n.names}
    assert ice <= {"__future__", "csv", "json", "math", "pathlib", "typing", "numpy"}  # başka proje modülü yok
    kod = "\n".join(l for l in src.splitlines() if not l.lstrip().startswith("#"))
    govde = kod.split("def hesapla")[1].split("def _md")[0]
    assert "senaryolar" not in govde and "_load(" not in govde and "json.loads" not in govde  # girdi yalnız gözlem CSV'si
    d = _j(OUT / "GECMIS_PROJEKSIYON.json")
    assert d["etiket"] == "yalniz_gecmis_ileri_uzatma" and d["tam_yillar"] == [2015, 2025]
    assert set(d["projeksiyon"]) == {"r", "net"} and set(d["projeksiyon"]["r"]["yontemler"]) == {"duz", "trend5", "trendT"}
    # düz yöntem son 12 ayı sabit tutar; PI trend yöntemlerinde var, düzde yok
    p = d["projeksiyon"]["r"]["yontemler"]
    assert p["duz"]["2036"]["nokta"] == d["son12ay"]["r"] and p["duz"]["2036"]["alt95"] is None
    assert p["trend5"]["2036"]["alt95"] < p["trend5"]["2036"]["nokta"] < p["trend5"]["2036"]["ust95"]
    # geriye test 2023–2025: üç yöntem de eksik tahmin etti (rejim değişimi geçmişten görülmez)
    for alan in ("r", "net"):
        for yon, rows in d["geriye_test_2022_baslangic"][alan].items():
            assert all(rows[h]["hata_yuzde"] < 0 for h in ("2023", "2024", "2025")), (alan, yon)


def test_gecmisten_turetilen_senaryo_buyuklukleri():
    sys.path.insert(0, str(REPO / "etki_cephesi"))
    import ast
    import math

    import _gecmis  # noqa: E402

    src = (REPO / "etki_cephesi" / "_gecmis.py").read_text(encoding="utf-8")
    ice = {n.module for n in ast.walk(ast.parse(src)) if isinstance(n, ast.ImportFrom)} | {a.name for n in ast.walk(ast.parse(src)) if isinstance(n, ast.Import) for a in n.names}
    assert ice <= {"__future__", "csv", "json", "math", "functools", "pathlib", "typing", "numpy"}
    assert "senaryolar.json" not in src.split("def tam_olgunluk")[0]  # senaryo parametresi okunmaz; yalnız gözlem ve T
    q25, q50, q75 = _gecmis.ceyrekler()
    assert q25 < q50 < q75
    c = _gecmis.merkez_carpan()
    t = _gecmis.tam_olgunluk()
    assert c["A"] == 1.0 and c["C"] < 1.0 < c["B"]
    assert abs(c["B"] - math.exp((q75 - q50) * t)) < 1e-12 and abs(c["C"] - math.exp((q25 - q50) * t)) < 1e-12
    sen = _j(DATA / "senaryolar.json")
    assert all("merkez_sizinti_carpan" not in s for s in sen["senaryolar"])  # atanmış değer yeniden adlandırıldı
    k2 = _gecmis.k2_olabilirlik()
    assert all(0 < v < 1 for v in k2["p"].values())
    # projeksiyon çarpanı geçmişten kullanır: B sızıntısı / A sızıntısı = geçmiş çarpanı (boşalma kalemi hariç)
    proj = {s["id"]: s for s in _j(OUT / "PROJEKSIYON.json")["senaryolar"]}
    assert proj["C"]["merkez_finans_sizinti_toplam"] < proj["A"]["merkez_finans_sizinti_toplam"] < proj["B"]["merkez_finans_sizinti_toplam"]


def test_kazanc_boslugu_asmaz_kanal_kaldirildi():
    d = _j(OUT / "KAZANC_KAYIP_MUHASEBE.json")
    assert [s["id"] for s in d["senaryolar"]] == ["A", "B", "C"]
    for s in d["senaryolar"]:
        k = s["kazanc"]
        assert k["kanal"] == 0.0 and s["normalizasyon"]["kanal_kaldirildi"]  # kanal kuralı kaldırıldı
        assert abs(k["toplam"] - (k["matris"] + k["ikame"] + k["merkez"])) < 2e-3
        assert k["toplam"] <= s["bosluk_V"] + 5e-3  # özdeşlik: Σ kazanç ≤ V
        n = s["normalizasyon"]
        # korunum: aktör kazancı + havza girişi (rakip ikame) birlikte V'ye sığar; katsayı bu ikisini hesaba katar
        assert abs(n["katsayi"] - min(1.0, max(0.0, s["bosluk_V"] - n["havza_girisi_dusuldu"]) / n["ham_toplam"])) < 5e-3
        assert k["toplam"] + n["havza_girisi_dusuldu"] <= s["bosluk_V"] + 5e-3 and k["ikame"] == 0.0 and n["ikame_aktor_kazancindan_dusuldu"]
        assert abs(s["kayip"]["toplam"] - (s["kayip"]["tr"] + s["kayip"]["diger"])) < 2e-3
    kat = {s["id"]: s["normalizasyon"]["katsayi"] for s in d["senaryolar"]}
    assert kat["C"] == 1.0 and kat["B"] < kat["A"] < 1.0  # C V'yi aşmıyordu; B en çok aşıyordu
    p = _j(OUT / "PROJEKSIYON.json")
    for sen in p["senaryolar"]:
        assert all(x["kanal_kazanc"] == 0.0 for x in sen["dis_aktör_kazanc"])


def test_modellenmeyenler_sifir_degil_bilinmiyor_isaretli():
    p = _j(OUT / "PROJEKSIYON.json")
    for sen in p["senaryolar"]:
        by = {a["aktor"]: a for a in sen["aktör_birlesik"]}
        assert all("kazanc_kapsam" in a and "kayip_kapsam" in a for a in by.values())
        assert by["CN"]["kayip_kapsam"] == "bilinmiyor" and by["CN"]["net_kapsam"] == "kismi"  # Çin'in havza kaybı modelde yok
        assert by["IQ"]["kazanc_kapsam"] == "kismi"  # Irak: kazanç kanallarından yalnız biri modelli
        assert by["IR"]["net_kapsam"] == "tam" and by["TR"]["net_kapsam"] == "tam"
        assert by["MFIN"]["kayip_kapsam"] == "bilinmiyor" and by["MFIN"]["kazanc_kapsam"] == "tam"  # MFIN: kazanç ölçülü, kaybı vekil
    md = (OUT / "DIS_AKTOR_A.md").read_text(encoding="utf-8")
    birlesik = md.split("## Birleşik")[1]
    satir = next(l for l in birlesik.splitlines() if l.startswith("| Çin |"))
    assert "‡" in satir and "kayıp bilinmiyor" in satir and "≈" in satir  # sıfır değil: referans-oran vekil, işaretli
    assert "| 0.0 |" not in satir.split("|")[3] + "|"  # havza kaybı sütunu 0.0 yazmaz
    satirlar = [l for l in birlesik.splitlines() if l.startswith("| ") and not l.startswith("| Aktör") and not l.startswith("| ---")]
    assert len(satirlar) == len(_j(OUT / "PROJEKSIYON.json")["senaryolar"][0]["aktör_birlesik"])  # kesilmiş tablo yok (eskiden ilk 30)


def test_defter_ve_projeksiyon_ayni_neti_verir_misir_kirilgan_degil():
    proj = {s["id"]: s for s in _j(OUT / "PROJEKSIYON.json")["senaryolar"]}
    for sid in "ABC":
        led = {r["ulke"]: r for r in _j(OUT / f"DIS_ULKE_REFAH_{sid}.json")["ulke_defteri"]}
        ab = {a["aktor"]: a for a in proj[sid]["aktör_birlesik"]}
        for iso in ("EG", "IR", "IL", "SA", "AE", "CN", "RU", "US"):
            if iso not in led or iso not in ab:
                continue
            # defter neti = projeksiyon neti + refah rant payı (belirsiz merkez payı kazanç sayılmaz)
            assert abs(led[iso]["net_refah_entegre"] - (ab[iso]["net_birlesik_vekil"] + led[iso]["refah_rant"])) < 0.01, (sid, iso)
            assert led[iso]["dis_toplam_vekili"] == round(led[iso]["kanal_kazanc"] + led[iso]["ikame_kazanc"] + led[iso]["merkez_sizinti"] + led[iso]["refah_rant"], 3)
    b = {a["ulke"]: a for a in _j(OUT / "BOLGE_STOK_AKIS.json")["aktorler"]}
    assert b["EG"]["sinif"] == "rant_kanali_bosluk_taraftari" and abs(b["EG"]["net_refah_entegre_vekil"]) < b["EG"]["net_bandi"]  # net, bandın içinde: kazanan da kaybeden de denmez


def test_sinif_belirsizlik_bandina_gore_sabit_esik_yok():
    sys.path.insert(0, str(REPO / "etki_cephesi"))
    import bolge_stok_akis as bsa  # noqa: E402

    # birim: net ± bant sıfırı kapsıyorsa kazanan da kaybeden de denmez
    assert bsa._sinif_etiket("XX", "bolge_guc", 0.10, None, 0.20) == "belirsiz_bant_ici"
    assert bsa._sinif_etiket("XX", "bolge_guc", 0.30, None, 0.20) == "cevre_entegre_kazanan"
    assert bsa._sinif_etiket("XX", "bolge_guc", -0.30, None, 0.20) == "cevre_entegre_kaybeden"
    assert bsa._sinif_etiket("XX", "bolge_guc", 0.10, 500.0, 0.20) == "rant_kanali_bosluk_taraftari"
    assert bsa._sinif_etiket("XX", "bolge_guc", 0.0, None, 0.0) == "belirsiz_bant_ici"  # eski 'notr' sınıfı yok
    b = _j(OUT / "BOLGE_STOK_AKIS.json")
    kaz = {"cevre_entegre_kazanan", "merkez_entegre_kazanan", "entegre_kazanan"}
    kay = {"cevre_entegre_kaybeden", "entegre_kaybeden"}
    for a in b["aktorler"]:
        alt, ust = a["net_alt_ust"]
        if a["sinif"] in kaz:
            assert alt > 0, a["ulke"]
        elif a["sinif"] in kay:
            assert ust < 0, a["ulke"]
        elif a["ulke"] != "TR":
            assert alt <= 0 <= ust, a["ulke"]  # bant içi: sıfırdan ayırt edilemiyor
        assert a["sinif"] != "notr"
    by = {a["ulke"]: a for a in b["aktorler"]}
    assert by["EG"]["sinif"] in ("belirsiz_bant_ici", "rant_kanali_bosluk_taraftari") and by["EG"]["net_alt_ust"][0] < 0 < by["EG"]["net_alt_ust"][1]
    led = _j(OUT / "DIS_ULKE_REFAH_C.json")["ulke_defteri"]
    tam = sorted(r["net_bandi_kayip_haric"] for r in led if r["bant_kapsami"] == "tam" and r["ulke"] not in ("TR", "MFIN") and r["net_bandi_kayip_haric"] > 0)
    med = tam[len(tam) // 2]
    assert all(a["net_bandi"] >= med - 1e-9 for a in b["aktorler"] if a["bant_kapsami"] == "kismi")  # kısmi kapsamda bant, tam kapsamın medyanından dar olamaz
    assert [a["ulke"] for a in b["halka_cevre_kazanan"]] == [a["ulke"] for a in b["halka_cevre_kazanan"] if a["net_alt_ust"][0] > 0]


def test_yunanistan_balkan_bant_sinamasi():
    d = _j(OUT / "BANT_SINAMA.json")
    assert [s["id"] for s in d["senaryolar"]] == ["A", "B", "C"]
    b = {a["ulke"]: a for a in _j(OUT / "BOLGE_STOK_AKIS.json")["aktorler"]}
    c = {a["ulke"]: a for a in next(s for s in d["senaryolar"] if s["id"] == "C")["aktorler"]}
    for iso, a in c.items():  # taban, ana raporla tutarlı
        assert abs(a["net"] - b[iso]["net_refah_entegre_vekil"]) < 0.01, iso
        if abs(a["marj"]) > 0.005:  # marj yuvarlama düzeyindeyse (BA: 0,001) sınıf eşitliği beklenmez
            esdeger = {"belirsiz_bant_ici", "rant_kanali_bosluk_taraftari"}  # bant içi; fark>400 mn $ ise taraftar etiketi (sinama rant farkını görmez)
            assert a["taban_sinif"] == b[iso]["sinif"] or ({a["taban_sinif"], b[iso]["sinif"]} <= esdeger), iso
    for s in d["senaryolar"]:
        by = {a["ulke"]: a for a in s["aktorler"]}
        assert not by["GR"]["dayanikli"]  # kazanç×0,5 ile bant içine düşer
        assert "belirsiz_bant_ici" in by["GR"]["sinif_kumesi"]
        for iso in ("RS", "BA", "BG", "AL", "MK"):
            if s["id"] == "B" and iso in ("RS", "BG"):
                # B'de (en büyük kayıp ölçeği) Sırbistan ve Bulgaristan salınıma dayanıklı KAYBEDEN; kazanan hiçbir Balkan ülkesi dayanıklı değil
                assert by[iso]["dayanikli"] and "kaybeden" in by[iso]["taban_sinif"], iso
            else:
                assert not by[iso]["dayanikli"], (s["id"], iso)  # diğerlerinin sınıfı atanmış parametre salınımına dayanıklı değil
        # Balkan kırılma noktaları: p* hesaplanmış ve sıralı (net=0, kazanan başlar, kaybeden biter)
        for iso in ("RS", "BA", "BG", "AL", "MK"):
            k = by[iso]["kirilma_p"]
            assert k["p_kaybeden_biter"] <= k["p_net_sifir"] <= k["p_kazanan_baslar"]
    cc = {a["ulke"]: a for a in next(s for s in d["senaryolar"] if s["id"] == "C")["aktorler"]}
    assert cc["AL"]["kirilma_p"]["p_net_sifir"] < 0.68 < cc["BG"]["kirilma_p"]["p_net_sifir"]  # AL taban p'de kazanan tarafta, BG kaybeden tarafta


def test_kaybi_bilinmeyenler_referans_oranla_modellendi():
    p = _j(OUT / "PROJEKSIYON.json")
    for sen in p["senaryolar"]:
        ab = {a["aktor"]: a for a in sen["aktör_birlesik"]}
        ref = ab["MFIN"]["kayip_referans_orani"]  # ticareti olmayan tek vekil aktör: ortak referans oran
        assert ref["min"] <= ref["medyan"] <= ref["maks"] and ref["medyan"] > 0
        # referans: İran, İsrail, Mısır (kaybı ve kazancı tam, bölünmesiz) — yalnız bunlardan hesaplanır
        oranlar = sorted(ab[i]["havza_kayip"] / ab[i]["dis_kazanc_vekili"] for i in ("IR", "IL", "EG"))
        assert abs(ref["min"] - oranlar[0]) < 2e-3 and abs(ref["maks"] - oranlar[-1]) < 2e-3
        for iso in ("CN", "RU", "US", "AE", "SA", "FR", "EU", "GR"):
            a = ab[iso]
            assert a["kayip_kapsam"] == "bilinmiyor" and a["havza_kayip"] == 0.0  # modelli kayıp alanı sıfıra çekilmedi/uydurulmadı
            if iso in ("CN", "RU", "US", "AE", "SA", "FR", "EU", "GR"):
                # dış veriden (ticaret) modellenen: kayıp = çekim tahmini × φ; oran aktöre özgü
                assert a["kayip_yontemi"] == "dis_veri_cekim"
                dv = a["kayip_dis_veri"]
                assert abs(a["havza_kayip_referans"] - dv["cekim_tahmini"] * dv["phi"]["medyan"]) < 3e-3 + 1e-3 * a["havza_kayip_referans"]
                assert dv["phi"]["min"] <= dv["phi"]["medyan"] <= dv["phi"]["maks"] and dv["cekim_tahmini"] > 0
                assert abs(a["havza_kayip_referans"] - a["kayip_referans_orani"]["medyan"] * a["dis_kazanc_vekili"]) < 3e-3 + 1e-3 * a["havza_kayip_referans"]
                assert a["kayip_referans_belirsizlik"] > 0
                continue
            assert abs(a["havza_kayip_referans"] - ref["medyan"] * a["dis_kazanc_vekili"]) < 2e-3
            assert abs(a["net_birlesik_referansli"] - (a["dis_kazanc_vekili"] - a["havza_kayip_referans"])) < 2e-3
            assert a["kayip_referans_belirsizlik"] > 0
        assert ab["MFIN"]["kayip_yontemi"] == "referans_oran"
        assert "havza_kayip_referans" not in ab["IR"] and "havza_kayip_referans" not in ab["TR"]  # kaybı modelli aktöre vekil eklenmez
    d = _j(OUT / "BANT_SINAMA.json")
    kaz = {"cevre_entegre_kazanan", "merkez_entegre_kazanan", "entegre_kazanan"}
    for s in d["senaryolar"]:
        by = {a["ulke"]: a for a in s["aktorler"]}
        assert by["IR"]["dayanikli"] and by["IR"]["en_kotu_marj"] > 0.02  # ikame kazancı düşülünce marj daraldı (C: 0,026)
        for iso in ("CN", "RU", "US", "AE", "SA", "EU"):
            assert by[iso]["kayip_kapsam"] == "bilinmiyor" and by[iso]["dayanikli"] is False
            v = by[iso]["varyant_siniflari"]
            assert next(x for k, x in v.items() if "en yüksek" in k) not in kaz or iso == "SA"  # en yüksek kayıp oranı kazananlığı yıkar (SA: ticaret kaybı çok küçük)
    c = {a["ulke"]: a for a in next(s for s in d["senaryolar"] if s["id"] == "C")["aktorler"]}
    # dış ticaret verisi (mutlak kayıp) + ikame çift sayımı düzeltmesi (K1): C'de yalnız Suudi Arabistan bant dışı kazanan;
    # AB, BAE, Fransa, Yunanistan bant dışı kaybeden; ABD, Çin, Rusya bant içi
    assert c["SA"]["taban_sinif"] in kaz
    for iso in ("AE", "EU", "FR"):
        assert c[iso]["taban_sinif"] == "entegre_kaybeden", iso
    assert "kaybeden" in c["GR"]["taban_sinif"]
    for iso in ("CN", "RU", "US"):
        assert c[iso]["taban_sinif"] == "belirsiz_bant_ici", iso
    b = {a["ulke"]: a for a in next(s for s in d["senaryolar"] if s["id"] == "B")["aktorler"]}
    for iso in ("CN", "RU", "US", "AE", "SA", "FR", "GR"):
        assert b[iso]["taban_sinif"] == "belirsiz_bant_ici", iso  # B'de bantlar çok geniş
    assert b["EU"]["taban_sinif"] == "entegre_kaybeden"


def test_dis_aktor_surdurme_maliyeti():
    cfg = _j(DATA / "surdurme_maliyeti.json")
    sen = {s["id"]: s for s in _j(DATA / "senaryolar.json")["senaryolar"]}
    proj = {s["id"]: s for s in _j(OUT / "PROJEKSIYON.json")["senaryolar"]}
    oran = {}
    for sid in "ABC":
        pol = max(0.25, min(1.0, 1.05 - sen[sid]["etki_erosyon_carpani"] + sen[sid]["tr_diplomatik_flex"]))
        oran[sid] = cfg["kappa"] * pol
        ab = {a["aktor"]: a for a in proj[sid]["aktör_birlesik"]}
        assert "surdurme_maliyeti" not in ab["TR"] and ab["MFIN"]["surdurme_maliyeti"] > 0  # yalnız TR muaf; MFIN de sürdürme maliyetine katlanır
        for iso in ("CN", "RU", "US", "IR", "IL", "EU", "AE", "SA"):
            a = ab[iso]
            assert abs(a["surdurme_maliyeti"] - oran[sid] * a["dis_kazanc_vekili"]) < 2e-3, (sid, iso)
            assert a["surdurme_maliyeti"] < a["dis_kazanc_vekili"]  # maliyet kazancı aşmaz
            base = a.get("net_birlesik_referansli", a["net_birlesik_vekil"])
            assert abs(a["net_birlesik_maliyetli"] - (base - a["surdurme_maliyeti"])) < 2e-3
        led = {r["ulke"]: r for r in _j(OUT / f"DIS_ULKE_REFAH_{sid}.json")["ulke_defteri"]}
        for iso in ("CN", "US", "IR"):
            r = led[iso]
            assert abs(r["net_maliyetli"] - (r["net_referansli"] - r["surdurme_maliyeti"])) < 2e-3
            assert r["net_bandi"] >= r["net_bandi_kayip_haric"]
        assert led["TR"]["surdurme_maliyeti"] == 0.0 and led["MFIN"]["surdurme_maliyeti"] > 0
    # TR ne kadar güçlü karşı-hamle yapabiliyorsa (pol), kaybı sürdürmek o kadar pahalı: C > A > B
    assert oran["C"] > oran["A"] > oran["B"]
    b = {a["ulke"]: a for a in _j(OUT / "BOLGE_STOK_AKIS.json")["aktorler"]}
    assert b["CN"]["sinif"] in ("belirsiz_bant_ici", "rant_kanali_bosluk_taraftari")  # C: maliyet düşülünce Çin bant içi
    assert b["US"]["surdurme_maliyeti"] > 0


def test_mfin_ayri_pay_kazanc_kayip_maliyet():
    m = _j(OUT / "KAZANC_KAYIP_MUHASEBE.json")
    proj = {s["id"]: s for s in _j(OUT / "PROJEKSIYON.json")["senaryolar"]}
    for s in m["senaryolar"]:
        mp = s["mfin_payi"]
        ab = {a["aktor"]: a for a in proj[s["id"]]["aktör_birlesik"]}
        f = ab["MFIN"]
        assert f["kayip_kapsam"] == "bilinmiyor" and f["havza_kayip"] == 0.0  # modelli kayıp alanı uydurulmaz
        assert abs(mp["kazanc"] - f["dis_kazanc_vekili"]) < 2e-3  # kazanç = açık sızıntı kenarları (normalize)
        ref = f["kayip_referans_orani"]["medyan"]
        assert abs(mp["kayip_referans"] - ref * f["dis_kazanc_vekili"]) < 5e-3 + 1e-3 * f["dis_kazanc_vekili"]  # oran 3 hane yuvarlı
        assert abs(mp["net_maliyetli"] - (mp["kazanc"] - mp["kayip_referans"] - mp["surdurme_maliyeti"])) < 5e-3
        # ayrı pay: MFIN + ülke aktörleri + dağıtılmayan = V'nin tamamı
        assert abs(mp["V_payi"] + mp["ulke_aktorleri_V_payi"] + mp["dagitilmayan_V_payi"] - 1.0) < 5e-3
        assert 0 < mp["V_payi"] < 1
    pay = {s["id"]: s["mfin_payi"]["V_payi"] for s in m["senaryolar"]}
    assert pay["B"] > pay["A"] > pay["C"]  # B'de merkez sızıntı çarpanı en yüksek
    # defter: MFIN kapanışı etkilenmedi
    assert _j(OUT / "MFIN_TUTARLILIK.json")["uyum_ok"] is True
    assert all(_j(OUT / f"ULUSLARARASI_STOK_AKIS_{x}.json")["kalibrasyon"]["kapanis_ok"] for x in "ABC")


def test_direnc_sinif_etiketinden_bagimsiz():
    """Direnç = rant-kanal farkı > 1000 mn $ olan tüm dış aktörler; net kazanan etiketli ABD/AB de sayılır."""
    b = _j(OUT / "BOLGE_STOK_AKIS.json")
    u = _j(OUT / "SENARYO_UYGULANABILIRLIK.json")
    agir = [a["ulke"] for a in b["aktorler"] if a["ulke"] != "TR" and (a.get("rant_kanal_bosluk_fark_usd_mn") or 0) > 1000]
    assert {"CN", "RU", "US", "EU"} <= set(agir)
    assert u["bilesenler"]["direnc_dusuk"] == round(max(0.0, 1.0 - len(agir) / 8.0), 3)


def test_goreceli_konum_direnc_alternatifi_ve_kirilma_orani():
    g = _j(OUT / "GORECELI_KONUM.json")
    for sid in ("A", "B", "C"):
        x = g["goreceli"][sid]
        # en geç batan listesi sıralı ve hepsi net < 0; ayırt edilebilir olan, medyandan ortak bant kadar iyi olandır
        nets = [a["net"] for a in x["en_gec_batan"]]
        assert nets == sorted(nets, reverse=True) and all(n < 0 for n in nets)
        for a in x["en_gec_batan"]:
            assert a["ayirt_edilebilir_iyi"] == (a["kayip_medyanina_gore"] - a["ortak_bant"] > 0)
        assert x["kaybeden_net_toplam"] < 0
    d = _j(OUT / "SENARYO_UYGULANABILIRLIK.json")
    a = g["direnc_alternatif_C"]
    assert a["ana_direnc_sayisi"] == round((1 - d["bilesenler"]["direnc_dusuk"]) * 8)
    assert a["alternatif_direnc_sayisi"] <= a["ana_direnc_sayisi"]
    assert a["skor_ana"] == d["skor_0_100"]  # ana skor tanıdan etkilenmez
    for sid, v in g["kirilma_orani"].items():
        for iso, k in v["aktorler"].items():
            assert k["r_bant_dis_kazanan_sinir"] < k["r_net_sifir"] < 1  # bant büyükse kazanan sınıfını koruyan oran negatif olabilir


def test_cin_rusya_kaybi_dis_ticaret_verisinden_ve_bagimsiz_hesap():
    """Çekim tahmini bağımsız yeniden hesaplanır (veri dosyası + modelin kendi ortak-ülke kayıpları)."""
    dv = _j(REPO / "data" / "etki_cephesi" / "gozlem" / "dis_ticaret_gsyh_2023.json")
    assert dv["yil"] == 2023 and set(dv["dis_veri_aktorleri"]) == {"CN", "RU", "US", "EU", "AE", "SA", "FR", "GR"} and "RU" in dv["ayna_veri_eksik_ortak"]
    esik = dv["hub_kurali"]["esik_ihracat_gsyh"]
    p = _j(OUT / "PROJEKSIYON.json")
    for sen in p["senaryolar"]:
        ab = {a["aktor"]: a for a in sen["aktör_birlesik"]}
        L = {k: a["havza_kayip"] for k, a in ab.items()}

        def cekim(i, hub=True):
            return sum(
                x / dv["gsyh_mn_usd"][j] * L.get(j, 0.0)
                for j, x in dv["ihracat_mn_usd"][i].items()
                if j != i and not (hub and x / dv["gsyh_mn_usd"][j] > esik)
            )

        phi = sorted(L[i] / cekim(i) for i in dv["kalibrasyon_aktorleri"])
        for iso in dv["dis_veri_aktorleri"]:
            d = ab[iso]["kayip_dis_veri"]
            assert abs(d["cekim_tahmini"] - cekim(iso)) < 2e-3
            assert abs(d["cekim_hub_kuralsiz"] - cekim(iso, hub=False)) < 2e-3
            assert d["hublar"] == sorted(j for j, x in dv["ihracat_mn_usd"][iso].items() if x / dv["gsyh_mn_usd"][j] > esik)
            assert d["cekim_tahmini"] <= d["cekim_hub_kuralsiz"] + 1e-9
            assert abs(d["phi"]["min"] - phi[0]) < 2e-3 and abs(d["phi"]["maks"] - phi[-1]) < 2e-3
        # kaybı modelli aktörler ve diğer vekil aktörler dış-veri yöntemini almaz
        assert "kayip_dis_veri" not in ab["MFIN"] and "kayip_dis_veri" not in ab["IR"]
        assert ab["CN"]["kayip_dis_veri"]["hublar"] == ["KG"]  # tek transit merkezi: Çin→Kırgızistan (GSYH'nin %130'u)


def test_sistem_tanisi_tutarli_ve_hub_kurali_ticaret_artefaktini_ayirir():
    t = _j(OUT / "GORECELI_KONUM.json")["sistem_tani"]
    for sid in "ABC":
        led = _j(OUT / f"DIS_ULKE_REFAH_{sid}.json")["ulke_defteri"]
        top = sum(float(r.get("net_maliyetli", r.get("net_refah_entegre")) or 0.0) for r in led)
        assert abs(t["sistem_net_toplam"][sid] - top) < 5e-3
        assert abs(t["pozitif_net_toplam"][sid] + t["negatif_net_toplam"][sid] - t["sistem_net_toplam"][sid]) < 5e-3
    for u, en in t["aktor_en_iyi_senaryo"].items():
        assert t["buyuk_aktor_net"][en][u] == max(t["buyuk_aktor_net"][x][u] for x in "ABC")
    # ortak en iyi senaryo iddiası, her büyük aktör için o senaryonun en iyi olması demektir
    for sid in t["tum_buyuk_aktorlerin_ortak_en_iyi_senaryosu"]:
        assert all(en == sid for en in t["aktor_en_iyi_senaryo"].values())
    assert t["olay_etkisi_tr_net_ust_sinir"] >= 0
    # hub kuralı yalnız çekimi azaltır, hiçbir aktörün çekimini artırmaz
    for sen in _j(OUT / "PROJEKSIYON.json")["senaryolar"]:
        for a in sen["aktör_birlesik"]:
            if "kayip_dis_veri" in a:
                assert a["kayip_dis_veri"]["cekim_tahmini"] <= a["kayip_dis_veri"]["cekim_hub_kuralsiz"] + 1e-9


def test_defter_dis_veri_kaybi_projeksiyonla_ayni_mutlak_deger():
    """Defter, dış-veri kaybını 'oran × defter kazancı' ile yeniden ölçeklememeli (AB'nin Balkan'a bölünen payı düşük defter kazancı kaybı 3,5 kat eksik gösterirdi)."""
    for sen in _j(OUT / "PROJEKSIYON.json")["senaryolar"]:
        led = {r["ulke"]: r for r in _j(OUT / f"DIS_ULKE_REFAH_{sen['id']}.json")["ulke_defteri"]}
        for a in sen["aktör_birlesik"]:
            if a.get("kayip_yontemi") == "dis_veri_cekim":
                assert abs(led[a["aktor"]]["havza_kayip_referans"] - a["havza_kayip_referans"]) < 2e-3, a["aktor"]
                assert abs(led[a["aktor"]]["kayip_belirsizligi"] - a["kayip_referans_belirsizlik"]) < 2e-3, a["aktor"]


def test_tr_olcek_sinamasi_ledger_ile_tutarli_ve_gozlem_sinirlari():
    d = _j(OUT / "TR_OLCEK_SINAMA.json")
    g = _j(OUT / "GORECELI_KONUM.json")["sistem_tani"]
    obs = d["gozlem"]
    # gözlem: WDI serilerinden bağımsız yeniden hesap
    w = _j(DATA / "gozlem" / "tr_bagimsiz_olcek.json")
    yy = w["yillar"]
    brut = [w["TUR"]["birincil_gelir_odeme_usd"][y] / w["TUR"]["gsyh_usd"][y] * 100 for y in yy]
    assert abs(obs["brut_birincil_gelir_odemesi_gsyh_yuzde"]["ort"] - sum(brut) / len(brut)) < 6e-3
    for sid in "ABC":
        satirlar = {r["s"]: r for r in d["yayilim"][sid]}
        led = {r["ulke"]: r for r in _j(OUT / f"DIS_ULKE_REFAH_{sid}.json")["ulke_defteri"]}
        # s=1: ledger ile birebir (dış-veri aktörleri ve sistem toplamı)
        for i, a in satirlar[1.0]["aktorler"].items():
            assert abs(a["net"] - led[i]["net_maliyetli"]) < 2e-3, (sid, i)
        assert abs(satirlar[1.0]["sistem_net_toplam"] - g["sistem_net_toplam"][sid]) < 5e-3
        # s küçüldükçe TR net'i iyileşir, φ aralığı genişler
        assert satirlar[0.1]["tr_net"] > satirlar[1.0]["tr_net"]
        assert satirlar[0.1]["phi"][1] > satirlar[1.0]["phi"][1]
        # model TR kaybı gözlemlenebilir üst sınırların (brüt birincil gelir ödemesi, cari açık ortalaması) en düşük köprüde bile üstünde
        assert d["model_tr_kaybi"][sid]["bop_merkez_rant"]["gsyh_yuzde"] > obs["brut_birincil_gelir_odemesi_gsyh_yuzde"]["ort"]
        assert d["gereken_olcek"][sid]["brut_birincil_gelir_odemesi_ort"]["s_maks"] < 1.0


def test_havza_kazanan_ve_kisa_vade_akis_tutarli():
    d = _j(OUT / "HAVZA_KAZANAN_KISA_VADE.json")
    muh = {s["id"]: s for s in _j(OUT / "KAZANC_KAYIP_MUHASEBE.json")["senaryolar"]}
    w = _j(DATA / "gozlem" / "tr_bagimsiz_olcek.json")
    y = w["yillar"]
    gsyh = w["TUR"]["gsyh_usd"][y[-1]] / 1e6
    cari = sum(-w["TUR"]["cari_denge_gsyh"][k] for k in y) / len(y) / 100 * gsyh
    assert abs(d["kisa_vade"]["kapasite_mn_usd"]["cari_acik_ort"] - cari) < 1.5
    rezerv = w["TUR"]["toplam_rezerv_usd"][y[-1]] / 1e6
    for sid in "ABC":
        t = d["kazanan_tablosu"][sid]
        # ölü ağırlık = kayıp havuzu − V ile sınırlı kazanç = muhasebenin kazanç − kayıp farkı (işaret ters)
        assert abs(t["olu_agirlik"] + muh[sid]["kazanc_eksi_kayip"]) < 5e-3
        assert abs(sum(t["grup_brut_pay"].values()) - 1.0) < 3e-3
        assert t["net_kaybeden_havza"] == t["havza_sayisi"]  # her senaryoda tüm havzalar net kaybeder
        assert abs(-t["havza_net_toplam"] - muh[sid]["kayip"]["diger"]) < 0.1 * muh[sid]["kayip"]["diger"]  # havza kaybı ≈ diğer kayıp (farkı ülke paylaştırması)
        kv = d["kisa_vade"][sid]
        assert 0 < kv["alicilara_ulasan_pay"] <= 1.0 and len(kv["tr_kayip_vekil"]) == 3
        for k, r in kv["koprular"].items():
            for i, f in enumerate(r["akis_mn_usd"]):
                parca = r["bolgeye_akis_mn_usd"][i] + r["merkeze_akis_mn_usd"][i] + r["dis_rakip_guce_akis_mn_usd"][i] + r["kimseye_ulasmayan_mn_usd"][i]
                assert abs(parca - f) <= 4 + 2e-3 * f  # grup payları 3 hane yuvarlı
            asim = sum(max(0.0, f - cari) for f in r["akis_mn_usd"])
            assert abs(asim - r["ucyil_asim_mn_usd"]) < 5.0 + 3e-3 * asim
            beklenen = "gecerli_cari_denge" if asim == 0 else ("gecerli_rezervle" if asim <= rezerv else "gecersiz")
            assert r["karar"] == beklenen


def test_olu_agirlik_ayrisimi_toplamlar_ve_aralik_tutarli():
    d = _j(OUT / "OLU_AGIRLIK_AYRISMA.json")["senaryolar"]
    muh = {s["id"]: s for s in _j(OUT / "KAZANC_KAYIP_MUHASEBE.json")["senaryolar"]}
    hk = {sid: v for sid, v in _j(OUT / "HAVZA_KAZANAN_KISA_VADE.json")["kazanan_tablosu"].items()}
    for sid in "ABC":
        s = d[sid]
        # D, muhasebe ve önceki rapordaki ölü ağırlıkla aynı; üç kova D'yi tam kapatır
        assert abs(s["olu_agirlik"] - hk[sid]["olu_agirlik"]) < 5e-3
        assert abs(s["olu_agirlik"] + muh[sid]["kazanc_eksi_kayip"]) < 5e-3
        assert abs(s["gercek_yikim_alt"] + s["olcum_boslugu_alt"] + s["belirsiz"] - s["olu_agirlik"]) < 6e-3
        c = s["bilesenler"]
        assert abs(c["v_ici_dagitilmayan"] + c["tr_bosalma_disi_kayip"] + c["havza_alicisiz_zarar"] + c["havza_alicisi_belli_rant_cikisi"] + c["havza_dis_baglama_belirsiz"] - s["olu_agirlik"]) < 6e-3
        # aralıklar: alt ≤ üst, kapasite sınırı aralığı daraltır ama dışına çıkarmaz
        for k in ("gercek_yikim_pay_aralik", "olcum_boslugu_pay_aralik"):
            assert 0 <= s[k][0] <= s[k][1] <= 1
        a, b = s["gercek_yikim_pay_aralik"], s["gercek_yikim_pay_aralik_kapasite_sinirli"]
        assert a[0] <= b[0] <= b[1] <= a[1] + 1e-9
        f = s["dis_baglama_gelir_odemesi_siniri"]
        assert 0 < f["rant_koprusu"] <= f["bop_koprusu"] <= 1.0
        # yıkım üst + ölçüm boşluğu alt = D (belirsiz kova iki uca da tam yazılır)
        assert abs(s["gercek_yikim_aralik"][1] + s["olcum_boslugu_aralik"][0] - s["olu_agirlik"]) < 6e-3
        # ham kazançla D, V sınırı yokken en çok V sınırlı D kadar; ikame çift sayımı D'yi artırır
        assert s["olu_agirlik_ham_kazanc"] <= s["olu_agirlik"] + 1e-9


def test_ikame_cift_sayim_k1_sonrasi_ozdeslik_ve_korunum():
    d = _j(OUT / "IKAME_CIFT_SAYIM.json")["senaryolar"]
    proj = {s["id"]: s for s in _j(OUT / "PROJEKSIYON.json")["senaryolar"]}
    muh = {s["id"]: s for s in _j(OUT / "KAZANC_KAYIP_MUHASEBE.json")["senaryolar"]}
    ob = _j(OUT / "OLU_AGIRLIK_AYRISMA.json")["senaryolar"]
    for sid in "ABC":
        s, p = d[sid], proj[sid]
        # kenar listesindeki ikame akışı = havzaların ikame girişi; aktöre yazılmıyor (K1)
        kenar = sum(e["akis_endeks"] for e in p["akis_kenarlari"] if e["tur"] == "rakip_ikame")
        ig = sum(b["rakip_ikame_gelen"] for b in p["bolgesel_net"])
        assert abs(kenar - ig) < 0.02 and abs(s["kenar_ikame_toplam"] - kenar) < 2e-3
        assert s["aktor_ikame_kazanci_toplam"] == 0.0 and all(a["ikame_kazanc"] == 0.0 for a in p["dis_aktör_kazanc"])
        assert 0 < s["ham_ikame_dagilimi_tani"] <= s["kenar_ikame_toplam"] + 1e-9  # ham dağılım yalnız tanı
        # korunum: aktör kazancı + havza girişi V'yi aşmaz
        assert s["korunum_asimi"] < 0.02 and s["korunum_boslugu"] > -0.02  # kenar ve havza girişi 3 hane yuvarlı
        assert abs(s["kredi_toplam_aktor_arti_havza_girisi"] - (muh[sid]["kazanc"]["toplam"] + ig)) < 5e-3
        assert abs(s["olu_agirlik"] - ob[sid]["olu_agirlik"]) < 5e-3


def test_zarar_durdurma_senaryosu_c_ile_tutarli_ve_dogrusal():
    d = _j(OUT / "ZARAR_DURDURMA_SENARYOSU.json")
    cfg = _j(DATA / "zarar_durdurma.json")
    c = d["c_referans"]
    izgara = [str(x) for x in cfg["durdurma_izgara"]]
    # d=0 + mevcut bağ = C (aynı kod yolu): TR net, sistem ve dış aktör net'leri eşit
    r0 = d["varyantlar"]["mevcut"][izgara[0]]
    assert abs(r0["tr_net"] - c["tr_net"]) < 5e-3 and abs(r0["sistem_net_toplam"] - c["sistem_net_toplam"]) < 0.02
    for k, v in c["dis_aktor_net"].items():
        assert abs(r0["dis_aktor_net"][k] - v) < 0.02, k
    for ad, tab in d["varyantlar"].items():
        bos = [tab[x]["bosalma"] for x in izgara]
        # boşalma erozyonla doğrusal: d arttıkça (1−d) ile orantılı azalır
        for x, b in zip(izgara, bos):
            assert abs(b - bos[0] * (1.0 - float(x))) < 0.01 * bos[0] + 0.01, (ad, x)
        trn = [tab[x]["tr_net"] for x in izgara]
        assert trn == sorted(trn)  # durdurdukça TR net'i yalnız iyileşir
        sis = [tab[x]["sistem_net_toplam"] for x in izgara]
        assert sis == sorted(sis)
        # durdurma, ticaret ortaklarının kaybını azaltır (φ sabit): Çin, Rusya, AB net'i iyileşir
        for k in ("CN", "RU", "EU"):
            assert tab[izgara[-1]]["dis_aktor_net"][k] > tab[izgara[0]]["dis_aktor_net"][k], (ad, k)
    # refah bağlama (bağlı) TR'nin refah iç rantını artırır ve her d'de TR net'ini iyileştirir
    for x in izgara[:-1]:
        assert d["varyantlar"]["bagli"][x]["tr_refah_ic_rant"] > d["varyantlar"]["mevcut"][x]["tr_refah_ic_rant"]
        assert d["varyantlar"]["bagli"][x]["tr_net"] >= d["varyantlar"]["mevcut"][x]["tr_net"]
    # durdurmaya karşı çıkanlar: d=0'da net kazanan her aktör durdurunca kaybeder
    pozitif = [k for k, v in d["varyantlar"]["bagli"][izgara[0]]["dis_aktor_net"].items() if v > 0]
    assert pozitif and all(k in d["durdurmaya_karsi_cikanlar_bagli_dson_eksi_d0"] for k in pozitif)


def test_durdurma_yolu_kural_bazli_tutarli():
    d = _j(OUT / "DURDURMA_YOLU_KURAL.json")
    z = next(s for s in _j(OUT / "ZARAR_10Y_SENARYO_COKLU.json")["senaryolar"] if s["id"] == "C")
    assert abs(sum(d["halka_agirliklari"].values()) - 1.0) < 3e-3
    # kalibrasyon: kural yolunun 10. yıl d'si kalibre yolun 10. yıl d'sine eşit; kalibre yolu bağımsız yeniden hesapla
    base = float(z["tr_c_refah"])
    d_cal = [1.0 - float(r["tr_net"]) / base for r in z["yillik_seri"]]
    assert abs(d["kalibrasyon"]["d_kalibre_yol"][-1] - d_cal[-1]) < 2e-4
    assert abs(d["kalibrasyon"]["d_kural_yolu"][-1] - d_cal[-1]) < 2e-3
    assert d["kalibrasyon"]["rmse_d"] < 0.03  # kural yolu kalibre yolun şeklini kabaca izler (geometrik ↔ doğrusal fark)
    v = d["varyantlar"]
    for ad, r in v.items():
        yol = r["d_yol"]
        assert all(0.0 <= x <= 1.0 + 1e-9 for x in yol) and yol == sorted(yol), ad  # tekdüze, [0,1]
    # hız çarpanı ve sıra kuralının kaldırılması yolu yalnız hızlandırır
    assert all(b >= a - 1e-9 for a, b in zip(v["kalibre"]["d_yol"], v["hiz_x2"]["d_yol"]))
    assert all(b >= a - 1e-9 for a, b in zip(v["hiz_x2"]["d_yol"], v["hiz_x3"]["d_yol"]))
    assert all(b >= a - 1e-9 for a, b in zip(v["kalibre"]["d_yol"], v["sirasiz"]["d_yol"]))
    # dış kısıt halkası kendi katmanı olmadığından kalibre yolda hiç açılmaz; d üst sınırı 1 − w_dış_kısıt
    assert v["kalibre"]["halka_acilis_yili"]["dis_kisit"] is None
    assert v["kalibre"]["d_yol"][-1] <= 1 - d["halka_agirliklari"]["dis_kisit"] + 1e-9
    # finansman: kümülatif aşım ve tükenme yılı akıştan bağımsız yeniden hesaplanır
    cari, rezerv = d["kapasite_mn_usd"]["cari_acik_ort"], d["kapasite_mn_usd"]["brut_rezerv"]
    for ad, r in v.items():
        for k, f in r["finansman"].items():
            kum, tuk = 0.0, None
            for yil, akis in zip(d["kalibrasyon"]["yillar"], f["akis_mn_usd"]):
                kum += max(0.0, akis - cari)
                if tuk is None and kum > rezerv:
                    tuk = yil
            assert abs(kum - f["kumulatif_asim_mn_usd"]) < 6.0 + 1e-3 * kum, (ad, k)
            assert tuk == f["rezerv_tukenme_yili"], (ad, k)
    ms = d["gereken_hiz_carpani_rezerv_tukenmesin"]
    assert ms["bop_merkez_rant"] <= ms["mal_net_ticaret"] <= ms["tum_havza_rant"]  # daha büyük köprü daha hızlı kural ister

def test_uretim_katman_modeli_belge_sayilarini_yeniden_uretir_ve_sisteme_baglanir():
    d = _j(OUT / "URETIM_KATMAN_MODEL.json")
    dog = d["belge_degerleri"]
    yr = d["yeniden_uretim"]
    # Drive belgesindeki revizyon sayıları parametrelerden yeniden üretilir (belge yuvarlamasına tolerans)
    assert abs(yr["adreslenebilir_taban_mrd_usd"] - dog["adreslenebilir_ara_mali_tabani_mrd_usd"]) < 5e-3
    for s, v in dog["brut_ithalat_tasarrufu_mrd_usd"].items():
        assert abs(yr["brut_ithalat_tasarrufu_mrd_usd"][s] - v) < 5e-3, s
    for s, v in dog["revize_net_iyilesme_mrd_usd"].items():
        assert abs(yr["revize_net_iyilesme_mrd_usd"][s] - v) < 2e-3, s
    for s, v in dog["revize_cari_acik_kapanma_orani"].items():
        assert abs(yr["revize_cari_acik_kapanma_orani"][s] - v) < 1.5e-3, s
    # Model değişmezleri: koordinasyon tek başına cari dengeyi iyileştirmez (kötüleştirir); ε ≥ 0,75'te orta/güçlü reform nötr ya da negatif
    assert yr["revize_net_iyilesme_mrd_usd"]["koordinasyon"] < 0 < yr["revize_net_iyilesme_mrd_usd"]["orta_reform"] < yr["revize_net_iyilesme_mrd_usd"]["guclu_reform"]
    e = d["ihracat_esnekligi_duyarlilik_net_iyilesme_mrd_usd"]
    assert e["0.75"]["orta_reform"] < 0.01 and e["0.75"]["guclu_reform"] < 0.1 and e["1.0"]["orta_reform"] < 0
    ep = sorted(e, key=float)
    assert all(e[a]["orta_reform"] >= e[b]["orta_reform"] for a, b in zip(ep, ep[1:]))  # ε arttıkça iyileşme azalır
    # sisteme bağ: halka çarpanı ve tavan modelden; URETIM_IC_AKIS çıktısı çarpanla bağımsız yeniden hesaplanır
    b = d["sisteme_baglama"]
    c_u = b["halka_carpani"]["sistemde_kullanilan"]
    assert abs(c_u - (1.0 - 4264.48 / b["halka_usd_mn_mal_koprusu"])) < 2e-3
    kopru = _j(DATA / "uretim_ic_akis_kopru.json")
    uic = _j(OUT / "URETIM_IC_AKIS_C.json")
    ham = uic["halka_toplam_ham"]
    carpan = {**kopru["halka_duzeltme_carpan"], "uretim_bagimlilik": c_u}  # C: g_u = 1
    beklenen = sum(ham[k] * carpan[k] for k in ham) / sum(ham.values())
    assert abs(uic["bosalma_oran_halka_duzeltme"] - beklenen) < 2e-3
    kal = _j(OUT / "GERCEKLIK_KALIBRE_C.json")
    assert abs(kal["iyilesme_tavan_usd_mn"]["uretim"] - b["tavan_usd_mn"]["sistemde_kullanilan"]) < 0.2
    # gerçekleşmeyi taban mı belirliyor: model tavan/ihtiyaç < taban ise taban belirleyici
    g = d["gerceklesme_belirleyicisi"]
    assert (g["tavan_over_ihtiyac_model"] < g["taban_atanmis"]) == (g["belirleyici"] == "taban (atanmış)")
