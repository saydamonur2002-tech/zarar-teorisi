# Uluslararası stok-akış matrisi (kalibre)

Senaryo **C** · refah · rant/inv geliri payı **0.320** → ölçek **1.0**

- Refah dış (kalibre): **6,029.1** mn $
- Stok kapanış (Σ net vekil): **0.0** · **OK**
- **HAVZA (clearing):** giriş **27.07** · çıkış **20.686** · stok **6.384** vekil (brüt kayıp kenar USD: 145,721.8 mn — stokla toplanmaz)
- **MFIN yapısal:** defter **3.918** → stok **5.057** (Σ net **0.0**)

## Balkan / EU ayrımı

- EU satır (ham): **0.814** vekil → **EU merkez (Balkan hariç): 0.26**
- Balkan grup toplam: **0.941** vekil (bireysel 0.387 + EU'dan aktarım 0.554)

  - **RS:** -0.065 vekil
  - **BA:** 0.143 vekil
  - **BG:** -0.051 vekil
  - **AL:** 0.178 vekil
  - **MK:** 0.182 vekil

## Akış türleri (mn USD/yıl vekili)

- **havza_kayip_brut_kenar:** 145,721.8
- **kanal_ikame:** 72,860.79999999997
- **havza_net_stok:** 34,366.0
- **merkez_sizinti:** 27,960.699999999997
- **balkan_eu_aktarim:** 9,318.4
- **refah_rant_dis:** 7,794.500000000001
- **mfin_havza_denge:** 6,131.4
- **refah_tr_ic:** 2,740.0

## Stok (seçili)

- **TR:** -17.191 vekil · -92,541.6 mn $
- **MFIN:** 5.057 vekil · 27,222.5 mn $
- **HAVZA:** 6.384 vekil · 34,366.0 mn $
- **IMF:** 0.135 vekil · 726.7 mn $
- **WB:** 0.113 vekil · 608.3 mn $
- **EUINST:** 0.121 vekil · 651.4 mn $
- **EU:** 0.814 vekil · 4,381.9 mn $
- **IR:** 1.24 vekil · 6,675.1 mn $
- **CN:** 2.626 vekil · 14,136.1 mn $
- **RS:** -0.065 vekil · -349.9 mn $
- **BA:** 0.143 vekil · 769.8 mn $
- **BG:** -0.051 vekil · -274.5 mn $
