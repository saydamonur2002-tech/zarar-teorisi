# Uluslararası stok-akış matrisi (kalibre)

Senaryo **C** · refah · rant/inv geliri payı **0.320** → ölçek **1.0**

- Refah dış (kalibre): **6,029.1** mn $
- Stok kapanış (Σ net vekil): **0.0** · **OK**
- **HAVZA (clearing):** giriş **27.07** · çıkış **17.301** · stok **9.769** vekil (brüt kayıp kenar USD: 145,721.8 mn — stokla toplanmaz)
- **MFIN yapısal:** defter **3.918** → stok **5.053** (Σ net **0.0**)

## Balkan / EU ayrımı

- EU satır (ham): **0.688** vekil → **EU merkez (Balkan hariç): 0.22**
- Balkan grup toplam: **0.589** vekil (bireysel 0.121 + EU'dan aktarım 0.468)

  - **RS:** -0.115 vekil
  - **BA:** 0.089 vekil
  - **BG:** -0.105 vekil
  - **AL:** 0.124 vekil
  - **MK:** 0.128 vekil

## Akış türleri (mn USD/yıl vekili)

- **havza_kayip_brut_kenar:** 145,721.8
- **kanal_ikame:** 54,639.0
- **havza_net_stok:** 52,587.9
- **merkez_sizinti:** 27,960.699999999997
- **balkan_eu_aktarim:** 7,864.8
- **refah_rant_dis:** 7,794.500000000001
- **mfin_havza_denge:** 6,109.9
- **refah_tr_ic:** 2,740.0

## Stok (seçili)

- **TR:** -17.191 vekil · -92,541.6 mn $
- **MFIN:** 5.053 vekil · 27,201.0 mn $
- **HAVZA:** 9.769 vekil · 52,587.9 mn $
- **IMF:** 0.135 vekil · 726.7 mn $
- **WB:** 0.113 vekil · 608.3 mn $
- **EUINST:** 0.121 vekil · 651.4 mn $
- **EU:** 0.688 vekil · 3,703.6 mn $
- **IR:** 0.983 vekil · 5,291.6 mn $
- **CN:** 1.889 vekil · 10,168.8 mn $
- **RS:** -0.115 vekil · -619.1 mn $
- **BA:** 0.089 vekil · 479.1 mn $
- **BG:** -0.105 vekil · -565.2 mn $
