# Uluslararası stok-akış matrisi (kalibre)

Senaryo **C** · refah · rant/inv geliri payı **0.320** → ölçek **1.0**

- Refah dış (kalibre): **6,029.1** mn $
- Stok kapanış (Σ net vekil): **0.0** · **OK**
- **HAVZA (clearing):** giriş **27.07** · çıkış **23.458** · stok **3.612** vekil (brüt kayıp kenar USD: 145,721.8 mn — stokla toplanmaz)
- **MFIN yapısal:** defter **3.918** → stok **4.25** (Σ net **0.0**)

## Balkan / EU ayrımı

- EU satır (ham): **1.009** vekil → **EU merkez (Balkan hariç): 0.366**
- Balkan grup toplam: **1.311** vekil (bireysel 0.668 + EU'dan aktarım 0.643)

  - **RS:** -0.012 vekil
  - **BA:** 0.2 vekil
  - **BG:** 0.006 vekil
  - **AL:** 0.235 vekil
  - **MK:** 0.239 vekil

## Akış türleri (mn USD/yıl vekili)

- **havza_kayip_brut_kenar:** 145,721.80000000002
- **kanal_ikame:** 87,783.19999999998
- **merkez_sizinti:** 27,960.699999999997
- **havza_net_stok:** 19,443.9
- **balkan_eu_aktarim:** 10,830.899999999998
- **refah_rant_dis:** 7,794.500000000001
- **refah_tr_ic:** 2,740.0
- **mfin_havza_denge:** 1,787.2

## Stok (seçili)

- **TR:** -17.191 vekil · -92,541.6 mn $
- **MFIN:** 4.25 vekil · 22,878.3 mn $
- **HAVZA:** 3.612 vekil · 19,443.9 mn $
- **IMF:** 0.135 vekil · 726.7 mn $
- **WB:** 0.113 vekil · 608.3 mn $
- **EUINST:** 0.121 vekil · 651.4 mn $
- **EU:** 1.009 vekil · 5,431.6 mn $
- **IR:** 1.173 vekil · 6,314.4 mn $
- **CN:** 3.806 vekil · 20,488.2 mn $
- **RS:** -0.012 vekil · -64.6 mn $
- **BA:** 0.2 vekil · 1,076.6 mn $
- **BG:** 0.006 vekil · 32.3 mn $
