# Akım ölçümü — USD (2024) ↔ vekil (Senaryo C)

**Çapa:** `birincil_gelir_yatirim_gideri` = **18,841.0** mn USD → model paketi (`merkez_artı_rant` = 7.277) için 1 vekil birim ≈ 2589.1 mn USD (birincil_gelir_yatirim_gideri).

## Gözlemlenebilir finans (mn USD)

| Satır | USD mn |
| --- | ---: |
| birincil_gelir_yatirim_gideri | 18,841 |
| dis_borc_servisi_tds | 89,572 |
| kamu_dis_borc_servisi_tl_cevrilmis | 16,670 |
| hazine_kefalet_koi_yeni_finansman | 9,110 |

## Mal ticareti (mn USD)

- İhracat: **261,925.0**
- İthalat: **344,100.0**
- Net: **-82,175.0**

## Model vekili → USD (aynı çapa)

| Bileşen | Vekil | USD mn (vekili) |
| --- | ---: | ---: |
| MFIN kenar | 3.918 | 10,144.2 |
| Merkez belirsiz havuz | 2.239 | 5,797.0 |
| Merkez toplam | 6.157 | 15,941.2 |
| Rant çıkış (tüm havza) | 1.12 | 2,899.8 |

## USD köprüleri (vekil birimi)

- **bop_merkez_rant:** 1 vekil ≈ **2,589.12** mn USD (usd = vekil × (yatırım geliri gideri / merkez+rant))
- **tum_havza_rant:** 1 vekil ≈ **5,383.14** mn USD (TCMB yatırım geliri × rant-kanal BOP pay vekili (~tahvil+petro+KÖİ))
- **mal_net_ticaret:** 1 vekil ≈ **4,785.41** mn USD (|ihracat−ithalat| ↔ turkiye_yaricevre_bosalma (TİM 2024))

TR net vekil **-17.7** → USD: BoP **45,827.4** · rant **95,281.6** · mal **84,701.8** · orta **71,780.9** mn

## Küresel pay (vekili payda)

- TR dış borç servisi / küresel TDS vekili: **%2.889**
- TR yatırım geliri gideri / küresel vekili: **%0.897**
- TR TDS / BIS cross-border claims vekili: **%0.2421**

## MFIN — havza kenarları (top 25, USD vekili)

| Havza | Vekil | USD mn |
| --- | ---: | ---: |
| Körfez bağlantı hattı | 0.3 | 776.7 |
| Karadeniz çeperi | 0.261 | 675.8 |
| Balkan — Bulgaristan | 0.222 | 574.8 |
| Fırat — Irak merkez | 0.219 | 567.0 |
| Kuzey Afrika — Fas | 0.204 | 528.2 |
| Doğu Akdeniz — KÖİ/kefalet | 0.198 | 512.6 |
| Fırat — KRG | 0.176 | 455.7 |
| Doğu Akdeniz — gaz/LNG | 0.17 | 440.1 |
| Orta Asya — Kazakistan | 0.17 | 440.1 |
| Orta Asya — Özbekistan | 0.159 | 411.7 |
| Balkan — Sırbistan | 0.149 | 385.8 |
| Kuzey Afrika — Mısır (Nil) | 0.146 | 378.0 |
| Kuzey Afrika — Cezayir | 0.122 | 315.9 |
| Balkan — Bosna-Hersek | 0.116 | 300.3 |
| Kuzey Afrika — Libya | 0.114 | 295.2 |
| Balkan — Arnavutluk | 0.114 | 295.2 |
| Kuzey Afrika — Tunus | 0.11 | 284.8 |
| Balkan — Kuzey Makedonya | 0.104 | 269.3 |
| Kafkasya — Azerbaycan | 0.098 | 253.7 |
| Orta Asya — Türkmenistan | 0.096 | 248.6 |
| Orta Asya — Kırgızistan | 0.087 | 225.3 |
| Kafkasya — Gürcistan | 0.08 | 207.1 |
| Orta Asya — Tacikistan | 0.08 | 207.1 |
| İran — Doğu/Orta Asya kapısı | 0.071 | 183.8 |
| Kafkasya — Ermenistan | 0.068 | 176.1 |

## Rant kanalları (USD vekili, top 20)

| Kanal | Rant vekil pay | USD mn |
| --- | ---: | ---: |
| refah_rant | 0.3265 | 946.8 |
| boru | 0.069 | 200.1 |
| transit | 0.0587 | 170.2 |
| enerji | 0.051 | 147.9 |
| montaj_ihale | 0.0481 | 139.5 |
| liman | 0.042 | 121.8 |
| fon_liman | 0.0392 | 113.7 |
| ihale | 0.0378 | 109.6 |
| savunma_tedarik | 0.0354 | 102.7 |
| petro_dolar | 0.0336 | 97.4 |
| AB_fon | 0.0321 | 93.1 |
| maden | 0.031 | 89.9 |
| transit_rant | 0.0277 | 80.3 |
| montaj | 0.0259 | 75.1 |
| petrol | 0.0251 | 72.8 |
| tahıl | 0.0226 | 65.5 |
| LNG | 0.0222 | 64.4 |
| petrol_servis | 0.0217 | 62.9 |
| tahvil | 0.0174 | 50.5 |
| sınır_ticaret | 0.0167 | 48.4 |

## Kaynaklar

- TCMB — Balance of Payments Statistics, Yearly Detailed Presentation (2006–2025): birincil gelir / yatırım geliri debit 2024 ≈ 18.841 mn $
- World Bank — DT.TDS.DECT.CD: debt service on external debt, total (TDS), Turkey 2024 ≈ 89.572 mn $
- Hazine ve Maliye — Public Debt Management Report 2025: kamu dış borç servisi 2024 = 547,9 milyar TL (nakit); kefalet/KÖİ yeni finansman 2024 ≈ 9,11 milyar $
- TİM/Ticaret — tr_dis_ticaret_2024.json (mal akışı)
