# Akım ölçümü — USD (2024) ↔ vekil (Senaryo C)

**Çapa:** `birincil_gelir_yatirim_gideri` = **18,841.0** mn USD → model paketi (`merkez_artı_rant` = 9.024) için 1 vekil birim ≈ 2087.9 mn USD (birincil_gelir_yatirim_gideri).

## Gözlemlenebilir finans (mn USD)

| Satır | USD mn |
| --- | ---: |
| birincil_gelir_yatirim_gideri | 18,841 |
| dis_borc_servisi_tds | 89,572 |
| kamu_dis_borc_servisi_tl_cevrilmis | 16,670 |
| hazine_kefalet_koi_yeni_finansman | 9,110 |

## Mal ticareti (mn USD)

- İhracat: **261,925.0**
- İthalat: **344,100.0**
- Net: **-82,175.0**

## Model vekili → USD (aynı çapa)

| Bileşen | Vekil | USD mn (vekili) |
| --- | ---: | ---: |
| MFIN kenar | 5.662 | 11,821.6 |
| Merkez belirsiz havuz | 2.242 | 4,681.0 |
| Merkez toplam | 7.904 | 16,502.6 |
| Rant çıkış (tüm havza) | 1.12 | 2,338.4 |

## USD köprüleri (vekil birimi)

- **bop_merkez_rant:** 1 vekil ≈ **2,087.88** mn USD (usd = vekil × (yatırım geliri gideri / merkez+rant))
- **tum_havza_rant:** 1 vekil ≈ **5,383.14** mn USD (TCMB yatırım geliri × rant-kanal BOP pay vekili (~tahvil+petro+KÖİ))
- **mal_net_ticaret:** 1 vekil ≈ **4,785.41** mn USD (|ihracat−ithalat| ↔ turkiye_yaricevre_bosalma (TİM 2024))

TR net vekil **-17.7** → USD: BoP **36,955.5** · rant **95,281.6** · mal **84,701.8** · orta **66,812.9** mn

## Küresel pay (vekili payda)

- TR dış borç servisi / küresel TDS vekili: **%2.889**
- TR yatırım geliri gideri / küresel vekili: **%0.897**
- TR TDS / BIS cross-border claims vekili: **%0.2421**

## MFIN — havza kenarları (top 25, USD vekili)

| Havza | Vekil | USD mn |
| --- | ---: | ---: |
| Körfez bağlantı hattı | 0.434 | 906.1 |
| Karadeniz çeperi | 0.377 | 787.1 |
| Balkan — Bulgaristan | 0.321 | 670.2 |
| Fırat — Irak merkez | 0.316 | 659.8 |
| Kuzey Afrika — Fas | 0.295 | 615.9 |
| Doğu Akdeniz — KÖİ/kefalet | 0.287 | 599.2 |
| Fırat — KRG | 0.254 | 530.3 |
| Doğu Akdeniz — gaz/LNG | 0.247 | 515.7 |
| Orta Asya — Kazakistan | 0.246 | 513.6 |
| Orta Asya — Özbekistan | 0.23 | 480.2 |
| Balkan — Sırbistan | 0.215 | 448.9 |
| Kuzey Afrika — Mısır (Nil) | 0.211 | 440.5 |
| Kuzey Afrika — Cezayir | 0.176 | 367.5 |
| Balkan — Bosna-Hersek | 0.168 | 350.8 |
| Kuzey Afrika — Libya | 0.165 | 344.5 |
| Balkan — Arnavutluk | 0.165 | 344.5 |
| Kuzey Afrika — Tunus | 0.159 | 332.0 |
| Balkan — Kuzey Makedonya | 0.15 | 313.2 |
| Kafkasya — Azerbaycan | 0.142 | 296.5 |
| Orta Asya — Türkmenistan | 0.138 | 288.1 |
| Orta Asya — Kırgızistan | 0.126 | 263.1 |
| Kafkasya — Gürcistan | 0.116 | 242.2 |
| Orta Asya — Tacikistan | 0.115 | 240.1 |
| İran — Doğu/Orta Asya kapısı | 0.103 | 215.1 |
| Kafkasya — Ermenistan | 0.098 | 204.6 |

## Rant kanalları (USD vekili, top 20)

| Kanal | Rant vekil pay | USD mn |
| --- | ---: | ---: |
| refah_rant | 0.3265 | 763.5 |
| boru | 0.069 | 161.3 |
| transit | 0.0587 | 137.3 |
| enerji | 0.051 | 119.3 |
| montaj_ihale | 0.0481 | 112.5 |
| liman | 0.042 | 98.2 |
| fon_liman | 0.0392 | 91.7 |
| ihale | 0.0378 | 88.4 |
| savunma_tedarik | 0.0354 | 82.8 |
| petro_dolar | 0.0336 | 78.6 |
| AB_fon | 0.0321 | 75.1 |
| maden | 0.031 | 72.5 |
| transit_rant | 0.0277 | 64.8 |
| montaj | 0.0259 | 60.6 |
| petrol | 0.0251 | 58.7 |
| tahıl | 0.0226 | 52.8 |
| LNG | 0.0222 | 51.9 |
| petrol_servis | 0.0217 | 50.7 |
| tahvil | 0.0174 | 40.7 |
| sınır_ticaret | 0.0167 | 39.1 |

## Kaynaklar

- TCMB — Balance of Payments Statistics, Yearly Detailed Presentation (2006–2025): birincil gelir / yatırım geliri debit 2024 ≈ 18.841 mn $
- World Bank — DT.TDS.DECT.CD: debt service on external debt, total (TDS), Turkey 2024 ≈ 89.572 mn $
- Hazine ve Maliye — Public Debt Management Report 2025: kamu dış borç servisi 2024 = 547,9 milyar TL (nakit); kefalet/KÖİ yeni finansman 2024 ≈ 9,11 milyar $
- TİM/Ticaret — tr_dis_ticaret_2024.json (mal akışı)
