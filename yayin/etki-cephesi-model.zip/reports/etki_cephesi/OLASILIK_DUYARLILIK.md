# C senaryosu olasılığı — duyarlılık bandı

**Etiket: olasilik_olculmedi_duyarlilik_bandi.** Taban olasılık kapı iskeletinden (`_olasilik.py`); bu rapor yeni olasılık üretmez. C = p, kalan A:B taban oranla (0.333:0.333) bölünür.

| P(C) | P(A) | P(B) | E[TR net 10y, yaşam dahil] | E[GSYH %] | E[iyileşme] | Skor | Karar |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| 0.30 | 0.350 | 0.350 | -23.637 | 7.063 | -6.45 | 47.1 | kisitli_uygulanabilir |
| 0.35 | 0.325 | 0.325 | -22.861 | 6.831 | -5.67 | 48.0 | kisitli_uygulanabilir |
| 0.40 | 0.300 | 0.300 | -22.084 | 6.598 | -4.89 | 48.9 | kisitli_uygulanabilir |
| 0.45 | 0.275 | 0.275 | -21.308 | 6.366 | -4.12 | 49.8 | kisitli_uygulanabilir |
| 0.50 | 0.250 | 0.250 | -20.532 | 6.133 | -3.34 | 50.7 | kisitli_uygulanabilir |
| 0.55 | 0.225 | 0.225 | -19.755 | 5.9 | -2.56 | 51.6 | kisitli_uygulanabilir |
| 0.60 | 0.200 | 0.200 | -18.979 | 5.668 | -1.79 | 52.5 | kisitli_uygulanabilir |
| 0.65 | 0.175 | 0.175 | -18.203 | 5.435 | -1.01 | 53.4 | kisitli_uygulanabilir |
| 0.70 | 0.150 | 0.150 | -17.427 | 5.203 | -0.24 | 54.3 | kisitli_uygulanabilir |
| 0.75 | 0.125 | 0.125 | -16.65 | 4.97 | +0.54 | 56.1 | kisitli_uygulanabilir |
| 0.80 | 0.100 | 0.100 | -15.874 | 4.737 | +1.32 | 58.4 | kisitli_uygulanabilir |

## Kapı sonuçları (K2: 3 kontrol noktasından kaçı açık)

| Açık | P(A) | P(B) | P(C) | Skor | Karar | Eşiği geçer |
| ---: | ---: | ---: | ---: | ---: | --- | --- |
| 0/3 | 0.785 | 0.024 | 0.192 | 45.1 | kisitli_uygulanabilir | hayır |
| 1/3 | 0.427 | 0.156 | 0.417 | 49.2 | kisitli_uygulanabilir | hayır |
| 2/3 | 0.108 | 0.472 | 0.42 | 49.2 | kisitli_uygulanabilir | hayır |
| 3/3 | 0.014 | 0.76 | 0.225 | 45.7 | kisitli_uygulanabilir | hayır |

Taban (kapı iskeleti, gözlem yok): P(C) = 0.333 → skor 47.7 · kisitli_uygulanabilir (bandın dışında, ızgarada değil).


- E[TR net 10y] aralığı: **-23.637 … -15.874** (P(C) 0,30 → 0,80).
- Skor aralığı: **47.1 … 58.4**.
- Karar eşiği (skor 62) geçişi: bantta geçiş yok
- Beklenen karışımda iyileşme (Δ > 0,05) başlangıcı: P(C) ≈ **0.719**
- Taban satır ana raporla tutarlı: True.
