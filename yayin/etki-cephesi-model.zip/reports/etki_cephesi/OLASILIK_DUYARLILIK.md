# C senaryosu olasılığı — duyarlılık bandı

**Etiket: olasilik_olculmedi_duyarlilik_bandi.** Taban olasılık kapı iskeletinden (`_olasilik.py`); bu rapor yeni olasılık üretmez. C = p, kalan A:B taban oranla (0.333:0.333) bölünür.

| P(C) | P(A) | P(B) | E[TR net 10y, yaşam dahil] | E[GSYH %] | E[iyileşme] | Skor | Karar |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| 0.30 | 0.350 | 0.350 | -22.978 | 6.406 | -5.79 | 57.3 | kisitli_uygulanabilir |
| 0.35 | 0.325 | 0.325 | -22.263 | 6.209 | -5.07 | 58.2 | kisitli_uygulanabilir |
| 0.40 | 0.300 | 0.300 | -21.547 | 6.011 | -4.36 | 59.1 | kisitli_uygulanabilir |
| 0.45 | 0.275 | 0.275 | -20.832 | 5.814 | -3.64 | 60.0 | kisitli_uygulanabilir |
| 0.50 | 0.250 | 0.250 | -20.117 | 5.617 | -2.93 | 60.9 | kisitli_uygulanabilir |
| 0.55 | 0.225 | 0.225 | -19.401 | 5.42 | -2.21 | 61.8 | kisitli_uygulanabilir |
| 0.60 | 0.200 | 0.200 | -18.686 | 5.223 | -1.50 | 62.7 | uygulanabilir_kosullu |
| 0.65 | 0.175 | 0.175 | -17.971 | 5.026 | -0.78 | 63.6 | uygulanabilir_kosullu |
| 0.70 | 0.150 | 0.150 | -17.255 | 4.829 | -0.06 | 64.5 | uygulanabilir_kosullu |
| 0.75 | 0.125 | 0.125 | -16.54 | 4.632 | +0.65 | 66.5 | uygulanabilir_kosullu |
| 0.80 | 0.100 | 0.100 | -15.824 | 4.434 | +1.37 | 68.7 | uygulanabilir_kosullu |

## Kapı sonuçları (K2: 3 kontrol noktasından kaçı açık)

| Açık | P(A) | P(B) | P(C) | Skor | Karar | Eşiği geçer |
| ---: | ---: | ---: | ---: | ---: | --- | --- |
| 0/3 | 0.305 | 0.547 | 0.148 | 54.6 | kisitli_uygulanabilir | hayır |
| 1/3 | 0.341 | 0.409 | 0.25 | 56.4 | kisitli_uygulanabilir | hayır |
| 2/3 | 0.344 | 0.276 | 0.38 | 58.8 | kisitli_uygulanabilir | hayır |
| 3/3 | 0.312 | 0.167 | 0.521 | 61.3 | kisitli_uygulanabilir | hayır |

Taban (kapı iskeleti, gözlem yok): P(C) = 0.333 → skor 57.9 · kisitli_uygulanabilir (bandın dışında, ızgarada değil).


- E[TR net 10y] aralığı: **-22.978 … -15.824** (P(C) 0,30 → 0,80).
- Skor aralığı: **57.3 … 68.7**.
- Karar eşiği (skor 62) geçişi: P(C) ≈ **0.561**
- Beklenen karışımda iyileşme (Δ > 0,05) başlangıcı: P(C) ≈ **0.708**
- Taban satır ana raporla tutarlı: True.
