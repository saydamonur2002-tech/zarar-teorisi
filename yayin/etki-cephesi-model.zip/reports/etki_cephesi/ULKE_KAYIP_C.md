# Senaryo C (referans) — ülke bazlı kayıp (10 yıl vekil)

| Ülke | Kayıp endeks | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Türkiye | 17.7 | -17.7 | 0.164 | 0.086 | 0.092 |
| Irak | 1.36 | -1.36 | 0.374 | 0.197 | 0.222 |
| Körfez (vekil) | 1.114 | -1.114 | 0.286 | 0.151 | 0.17 |
| Suriye | 0.443 | -0.443 | 0.104 | 0.055 | 0.075 |
| Lübnan | 0.441 | -0.441 | 0.078 | 0.041 | 0.056 |
| Somali | 0.436 | -0.436 | 0.041 | 0.022 | 0.03 |
| Bulgaristan | 0.402 | -0.402 | 0.114 | 0.06 | 0.053 |
| Sırbistan | 0.392 | -0.392 | 0.133 | 0.07 | 0.068 |
| Fas | 0.388 | -0.388 | 0.092 | 0.049 | 0.055 |
| Ukrayna/Karadeniz (vekil) | 0.374 | -0.374 | 0.115 | 0.061 | 0.068 |
| Libya | 0.368 | -0.368 | 0.104 | 0.055 | 0.055 |
| Mısır | 0.316 | -0.316 | 0.158 | 0.084 | 0.089 |
| Kazakistan | 0.302 | -0.302 | 0.1 | 0.053 | 0.06 |
| Özbekistan | 0.278 | -0.278 | 0.077 | 0.041 | 0.046 |
| İran | 0.277 | -0.277 | 0.166 | 0.088 | 0.095 |
| Cezayir | 0.273 | -0.273 | 0.072 | 0.038 | 0.038 |
| Azerbaycan | 0.249 | -0.249 | 0.115 | 0.061 | 0.069 |
| Gürcistan | 0.243 | -0.243 | 0.077 | 0.041 | 0.046 |
| Türkmenistan | 0.227 | -0.227 | 0.054 | 0.028 | 0.032 |
| Bosna-Hersek | 0.208 | -0.208 | 0.056 | 0.029 | 0.026 |
| Ermenistan | 0.204 | -0.204 | 0.059 | 0.031 | 0.035 |
| Kırgızistan | 0.179 | -0.179 | 0.039 | 0.021 | 0.023 |
| Arnavutluk | 0.173 | -0.173 | 0.049 | 0.026 | 0.023 |
| Kuzey Makedonya | 0.169 | -0.169 | 0.045 | 0.024 | 0.021 |
| Tacikistan | 0.169 | -0.169 | 0.033 | 0.017 | 0.019 |
| Tunus | 0.155 | -0.155 | 0.046 | 0.024 | 0.021 |
| İsrail (vekil) | 0.124 | -0.124 | 0.039 | 0.021 | 0.021 |
| Kıbrıs (vekil) | 0.106 | -0.106 | 0.033 | 0.018 | 0.018 |

## Levant — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Suriye | 0.443 | -0.443 | 0.104 | 0.055 | 0.075 |
| Lübnan | 0.441 | -0.441 | 0.078 | 0.041 | 0.056 |

## Orta Doğu (Fırat / Doğu Akdeniz) — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Irak | 1.36 | -1.36 | 0.374 | 0.197 | 0.222 |
| Kıbrıs (vekil) | 0.106 | -0.106 | 0.033 | 0.018 | 0.018 |
| İsrail (vekil) | 0.124 | -0.124 | 0.039 | 0.021 | 0.021 |
| Mısır | 0.316 | -0.316 | 0.158 | 0.084 | 0.089 |

## Körfez — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Körfez (vekil) | 1.114 | -1.114 | 0.286 | 0.151 | 0.17 |

## Kuzey Afrika — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Libya | 0.368 | -0.368 | 0.104 | 0.055 | 0.055 |
| Mısır | 0.316 | -0.316 | 0.158 | 0.084 | 0.089 |
| Tunus | 0.155 | -0.155 | 0.046 | 0.024 | 0.021 |
| Cezayir | 0.273 | -0.273 | 0.072 | 0.038 | 0.038 |
| Fas | 0.388 | -0.388 | 0.092 | 0.049 | 0.055 |

## Karadeniz — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Ukrayna/Karadeniz (vekil) | 0.374 | -0.374 | 0.115 | 0.061 | 0.068 |
| Sırbistan | 0.392 | -0.392 | 0.133 | 0.07 | 0.068 |

## Kafkasya — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Azerbaycan | 0.249 | -0.249 | 0.115 | 0.061 | 0.069 |
| Gürcistan | 0.243 | -0.243 | 0.077 | 0.041 | 0.046 |
| Ermenistan | 0.204 | -0.204 | 0.059 | 0.031 | 0.035 |

## Balkan — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Sırbistan | 0.392 | -0.392 | 0.133 | 0.07 | 0.068 |
| Bosna-Hersek | 0.208 | -0.208 | 0.056 | 0.029 | 0.026 |
| Arnavutluk | 0.173 | -0.173 | 0.049 | 0.026 | 0.023 |
| Kuzey Makedonya | 0.169 | -0.169 | 0.045 | 0.024 | 0.021 |
| Bulgaristan | 0.402 | -0.402 | 0.114 | 0.06 | 0.053 |

## Orta Asya — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Kazakistan | 0.302 | -0.302 | 0.1 | 0.053 | 0.06 |
| Özbekistan | 0.278 | -0.278 | 0.077 | 0.041 | 0.046 |
| Türkmenistan | 0.227 | -0.227 | 0.054 | 0.028 | 0.032 |
| Kırgızistan | 0.179 | -0.179 | 0.039 | 0.021 | 0.023 |
| Tacikistan | 0.169 | -0.169 | 0.033 | 0.017 | 0.019 |

## İran (yaricevre vekili) — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| İran | 0.277 | -0.277 | 0.166 | 0.088 | 0.095 |

## Afrika Boynu / geniş güney — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Somali | 0.436 | -0.436 | 0.041 | 0.022 | 0.03 |
