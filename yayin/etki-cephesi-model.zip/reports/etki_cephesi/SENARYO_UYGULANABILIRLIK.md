# Senaryo C + refah — uygulanabilirlik

**Skor: 57.9/100** · **kisitli_uygulanabilir** (C: 62.3, beklenen A/B/C: 49.7)

Model yön doğru; merkez/rakip direnç ve düşük üretim/finans gerçekleşmesi tempo kısar. C yolunda 10 yılda TR net -17.19 → -13.10 (Δ +4.09 vekil: iyileşir); olasılık ağırlıklı beklenen karışımda Δ -4.99 (kötüleşir); katman gerçekleşme ortalaması 0.37.

## Bileşenler (0–1)

| Bileşen | Değer | Ağırlık |
| --- | ---: | ---: |
| olasilik_senaryo_c | 0.333 | 18 |
| katman_gerceklesme_ort | 0.374 | 18 |
| bop_rant_uyumu | 1.0 | 12 |
| tr_10y_iyilesme | 0.682 | 15 |
| gsyh_pp_iyilesme | 0.238 | 10 |
| direnc_dusuk | 1.0 | 12 |
| halka_cevre_koalisyon | 0.75 | 8 |
| stok_kapanis | 1.0 | 7 |

## Beklenen (A/B/C olasılık)

- TR net 10y (yaşam dahil): **-22.18**
- GSYH % orta: **6.185**

## Skor — senaryo başına

| Senaryo | Skor |
| --- | ---: |
| A | 52.1 |
| B | 52.1 |
| C | 68.2 |


## Engeller

- Olasılık ağırlıklı beklenen karışımda TR net başlangıç düzeyinin altında (Δ -4.99); iyileşme yok.

## Kolaylaştırıcılar

- Halka çevre entegre kazanan: IR, IL, EG.
- Refah vs boşluk TR kazancı ~16,520.9 mn $/yıl vekili.
- Zarar teorisi katmanı en yüksek gerçekleşme (≈0,7).

**10y TR net (kalibre yol):** -13.101 vekil · GSYH % orta **3.646**
