# Senaryo C + refah — uygulanabilirlik

**Skor: 47.7/100** · **kisitli_uygulanabilir** (C: 52.5, beklenen A/B/C: 38.7)

Model yön doğru; merkez/rakip direnç ve düşük üretim/finans gerçekleşmesi tempo kısar. C yolunda 10 yılda TR net -17.19 → -12.72 (Δ +4.47 vekil: iyileşir); olasılık ağırlıklı beklenen karışımda Δ -5.91 (kötüleşir); katman gerçekleşme ortalaması 0.37.

## Bileşenler (0–1)

| Bileşen | Değer | Ağırlık |
| --- | ---: | ---: |
| olasilik_senaryo_c | 0.333 | 18 |
| katman_gerceklesme_ort | 0.374 | 18 |
| bop_rant_uyumu | 1.0 | 12 |
| tr_10y_iyilesme | 0.745 | 15 |
| gsyh_pp_iyilesme | 0.26 | 10 |
| direnc_dusuk | 0.25 | 12 |
| halka_cevre_koalisyon | 0.5 | 8 |
| stok_kapanis | 1.0 | 7 |

## Beklenen (A/B/C olasılık)

- TR net 10y (yaşam dahil): **-23.102**
- GSYH % orta: **6.903**

## Skor — senaryo başına

| Senaryo | Skor |
| --- | ---: |
| A | 41.3 |
| B | 41.3 |
| C | 58.3 |


## Engeller

- Rant kanalında boşluk senaryosunu tercih eden güçlü dış aktörler (EU, US, CN…).
- Olasılık ağırlıklı beklenen karışımda TR net başlangıç düzeyinin altında (Δ -5.91); iyileşme yok.

## Kolaylaştırıcılar

- Halka çevre entegre kazanan: IR, IL.
- Refah vs boşluk TR kazancı ~16,520.9 mn $/yıl vekili.
- Zarar teorisi katmanı en yüksek gerçekleşme (≈0,7).

**10y TR net (kalibre yol):** -12.72 vekil · GSYH % orta **3.803**
