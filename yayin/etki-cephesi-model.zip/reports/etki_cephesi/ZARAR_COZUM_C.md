# Zarar teorisi × etki cephesi (çözüm varsayımı)

**GitHub:** [https://github.com/saydamonur2002-tech/zarar-teorisi](https://github.com/saydamonur2002-tech/zarar-teorisi) (`87f0317`) — beş adım koşusu **bitti**, kredi ihtiyacı **0.0**, tavan **0.0728→0.2582**.

**Etki cephesi taban:** Senaryo **C**.

*ic_dongu=0.5000; merkez×(1−ic×0.55); boşalma×(1−ic×fin×0.45); rant×(1−ic×0.18); TR iç geri +0.14×ic×boşalma, havza×(1−ic×0.45×0.85)*

| Gösterge | C (ham) | C + zarar çözümü | Δ |
| --- | ---: | ---: | ---: |
| TR boşalma | 17.172 | 14.622 | -2.55 |
| Merkez sızıntı | 7.904 | 5.73 | -2.174 |
| MFIN kenar | 5.662 | 4.23 | -1.432 |
| Rant Σ | 1.12 | 1.019 | -0.101 |
| Merkez+rant | 9.024 | 6.749 | -2.275 |
| TR havza kaybı | 17.7 | 14.315 | -3.385 |
| TR iç geri kazanım (vekili) | — | 1.202 | — |
| TR net birleşik vekil | -17.7 | -13.113 | 4.587 |

## Yorum

- **Zarar teorisi** tarafında çözüm = stok eşleşme tavanı genişler, **yeni kredi itişi 0** (adım 3).
- **Etki cephesi** tarafında bu, finans/rant sızıntısını kısar ve TR'ye **iç döngü geri kazanım** satırı ekler; dış aktörler hâlâ kazanır ama **MFIN/CN payı görece düşer**.
- Bu birleşik koşu **kanıt A/B değil**; SFC beş adım etiketi `temiz` + kullanıcı varsayımı.
