# Stok-akış simülasyonu (SFC × etki cephesi) — revize

Matris **2026-Q1** · λ=0.5 (**senaryo**, tanımsız) · κ=0.1 · kur **44.38** (akis_model_ozeti.dis_borc_artisi.2026-Q1.USDTRY)

## Entegre sektör etkisi (trilyon TL) — yalnız SFC'ye giren darbeler

| Sektör | Δ (trilyon TL) |
| --- | ---: |
| H | 0.000 |
| F | -1.001 |
| B | 0.000 |
| K | 0.000 |
| D | 1.001 |

**Kapanış:** Σ darbe = 0.0 tr TL → OK. Sıfır toplam kimliği (Σ NFP = 0) için SFC'ye giren darbelerin toplamı 0 olmalı. Fark ilan edilir, gizlenmez. Dış rant transfer olarak yazılır (F −A, D +A); tutarın geri kalanı kapsam dışıdır.

**Dış rant (F→D transfer):** H=0.0, F=-1.001, B=0.0, K=0.0, D=1.001; eski çift muamele: H=0.114, F=0.091, B=-0.115, K=0.034, D=-0.223. Kapsam dışı rant: 0.0 mn USD.

**Dışsal enjeksiyon (SFC dışı):** 0.892 tr TL. Karşı bacağı tanımsız 'refah/tasarruf' girdileri. SFC'ye girmez: sıfır toplam kimliğini bozar.

## λ bandı (sektör etkisi, tr TL)

- λ=0.25: H=0.0, F=0.0, B=0.0, K=0.0, D=0.0
- λ=0.5: H=0.0, F=0.0, B=0.0, K=0.0, D=0.0
- λ=0.75: H=0.0, F=0.0, B=0.0, K=0.0, D=0.0

## Akış pulsları

- **zarar_bosluk_rant_dis** (transfer, F, SFC): 22,550.0 mn USD → D dağılımı H=0.0, F=-1.001, D=1.001
- **zarar_bosluk_rant_d_absorpsiyon** (kar, D, devre dışı): 10,147.5 mn USD → D dağılımı H=0.166, F=0.118, D=0.0
- **refah_tasarruf** (kar, F, dışsal): 10,986.4 mn USD → D dağılımı H=0.144, F=0.0, D=0.199
- **refah_tr_ic** (kar, H, dışsal): 2,740.0 mn USD → D dağılımı H=0.0, F=0.028, D=0.054
- **yasam_maliyet_10y** (kar, H, dışsal): 6,372.6 mn USD → D dağılımı H=0.0, F=0.065, D=0.126

## F.4 stok yolu — silinen ölçülmedi; oranlar varsayım bandıdır

- **2027:** F.4 stok **25339.8** milyar TL (olculmedi_sabit)
- **2028:** F.4 stok **25339.8** milyar TL (olculmedi_sabit)
- **2029:** F.4 stok **25339.8** milyar TL (olculmedi_sabit)
- **2030:** F.4 stok **25339.8** milyar TL (olculmedi_sabit)
- **2031:** F.4 stok **25339.8** milyar TL (olculmedi_sabit)
- **2032:** F.4 stok **25339.8** milyar TL (olculmedi_sabit)
- **2033:** F.4 stok **25339.8** milyar TL (olculmedi_sabit)
- **2034:** F.4 stok **25339.8** milyar TL (olculmedi_sabit)
- **2035:** F.4 stok **25339.8** milyar TL (olculmedi_sabit)
- **2036:** F.4 stok **25339.8** milyar TL (olculmedi_sabit)

Son yıl bandı:
- silinen oran 0.0 (varsayım, ≤ üst sınır: True): 25339.8 milyar TL
- silinen oran 0.1 (varsayım, ≤ üst sınır: True): 22805.8 milyar TL
- silinen oran 0.2 (varsayım, ≤ üst sınır: True): 20271.8 milyar TL
