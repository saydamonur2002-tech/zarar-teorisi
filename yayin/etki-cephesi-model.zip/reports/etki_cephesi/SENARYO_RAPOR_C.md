# Senaryo C — ayrıntılı rapor

Üç senaryo (A, B, C) için aynı bölümler ve alanlar. Referans etiketi ayrıcalık değildir.

## 1. Tanım (senaryo parametreleri)

| Alan | Değer |
| --- | ---: |
| Ad | Katmanlı oyun inşası — kısmi kullanım |
| Olasılık (kapı iskeleti, gözlem yokken tekdüze) | 0.333 |
| Etki erozyonu çarpanı | 0.22 |
| TR diplomatik esneklik | 0.12 |
| Merkez sızıntı çarpanı | 0.9 |
| Bağ modu kullanım / atıl / araçsal | 0.52 / 0.26 / 0.22 |

## 2. Projeksiyon (10 yıl vekil)

| Alan | Değer |
| --- | ---: |
| TR yarıçevre boşalma | 17.172 |
| Merkez finans sızıntı Σ | 7.904 |
| MFIN kenar Σ | 5.662 |
| Tüm havza rant Σ | 1.12 |
| Merkez + rant Σ | 9.024 |
| Pasif boşluk Σ | 2.823 |
| Araçsallaşma Σ | 1.491 |
| Temsil zedesi Σ | 1.626 |
| Dış mimari Σ | 2.072 |
| İç dinamik tıkanma | 0.334 |

## 3. Akış ölçümü (USD köprüsü, mn $)

| Alan | Değer |
| --- | ---: |
| MFIN kenar | 11,821.6 |
| Belirsiz merkez | 4,681 |
| Merkez toplam | 16,502.6 |
| Rant toplam | 2,338.4 |

## 4. Zarar çözümü (beş adım varsayımı)

| Alan | Değer |
| --- | ---: |
| TR net ham | -17.7 |
| TR net çözüm sonrası | -13.113 |
| TR net farkı | 4.587 |
| TR boşalma ham → sonrası | 17.172 → 14.622 |

## 5. Üretim iç akışı ve finans katmanı

| Alan | Değer |
| --- | ---: |
| Üretim iç akış TR net | -4.383 |
| Üretim: sıfır yılı tahmini | 2044 |
| Finans katmanı TR net | -0.489 |
| Finans: sıfır üstü takvim yılı | 2037 |
| Finans etiketi | varsayim_carpanli_ham |

## 6. Stok-akış (SFC, tr TL)

| Alan | Değer |
| --- | ---: |
| Matris dönemi / kur | 2026-Q1 / 44.38 |
| H | 0 |
| F | -1.001 |
| B | 0 |
| K | 0 |
| D | 1.001 |
| Kapanış (Σ=0) | evet |
| F.4 stok 2036, baz (mr TL) | 25,339.8 |
| F.4 stok 2036, silme %20 varsayımı | 20,271.8 |

## 7. Gerçeklik kalibrasyonu

| Alan | Değer |
| --- | ---: |
| TR net son (kalibre) | -11.211 |
| GSYH % | 3.12 |
| TR net 10. yıl yolu | -13.623 |
| Gerçekleşme: zarar / üretim / finans | 0.665 / 0.237 / 0.22 |

## 8. Dış rant parasal akışı

| Alan | Değer |
| --- | ---: |
| Boşluk rantı toplam (vekil) | 4.189 |
| Refah dış toplam (vekil) | 1.12 |
| Refah TR iç toplam (vekil) | 0.509 |
| Boşluk rantı (mn $) | 22,550.0 |
| Refah dış (mn $) | 6,029.1 |

## 9. Uluslararası stok-akış

| Alan | Değer |
| --- | ---: |
| Kapanış tamam | evet |
| Havza net stok (mn $) | 16,520.9 |
| Havza kayıp brüt kenar (mn $) | 145,721.8 |
| Merkez sızıntı (mn $) | 34,818.7 |
| Kanal ikame (mn $) | 85,619.1 |

## Ülke ve aktör ayrıntısı

- `ULKE_KAYIP_C.md`, `DIS_AKTOR_C.md`, `AKIS_OLCUM_C.md`, `ZARAR_COZUM_C.md`

## Not

**Yapısal sınır (A, B, C için aynı):** üretim iç akışı ve finans katmanı A ve B için C tabanından ölçeklenir (`politika_C_bazli`, `merkez_sizinti_C_bazli`). Bu bölümlerde A/B bağımsız modellenmemiştir; fark çarpandan gelir. F.4 stok yolu (bölüm 6) beş adımın kredi itişinden gelir ve senaryodan bağımsızdır; üç sütunda aynı olması senaryo farkı değil model yapısıdır. Olasılık ölçülmemiştir (gözlem yokken tekdüze); bu rapor senaryolar arasında sıra kurmaz.
