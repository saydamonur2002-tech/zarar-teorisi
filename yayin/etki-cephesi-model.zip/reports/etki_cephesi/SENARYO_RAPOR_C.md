# Senaryo C — ayrıntılı rapor

Üç senaryo (A, B, C) için aynı bölümler ve alanlar. Referans etiketi ayrıcalık değildir.

## 1. Tanım (senaryo parametreleri)

| Alan | Değer |
| --- | ---: |
| Ad | Katmanlı oyun inşası — kısmi kullanım |
| Olasılık (kapı iskeleti, gözlem yokken tekdüze) | 0.333 |
| Etki erozyonu çarpanı | 0.22 |
| TR diplomatik esneklik | 0.12 |
| Merkez sızıntı çarpanı (geçmişten, A=1) | 0.622 |
| Merkez sızıntı çarpanı (eski, atanmış) | 0.9 |
| Bağ modu kullanım / atıl / araçsal | 0.52 / 0.26 / 0.22 |

## 2. Projeksiyon (10 yıl vekil)

| Alan | Değer |
| --- | ---: |
| TR yarıçevre boşalma | 17.172 |
| Merkez finans sızıntı Σ | 6.157 |
| MFIN kenar Σ | 3.918 |
| Tüm havza rant Σ | 1.12 |
| Merkez + rant Σ | 7.277 |
| Pasif boşluk Σ | 2.823 |
| Araçsallaşma Σ | 1.491 |
| Temsil zedesi Σ | 1.626 |
| Dış mimari Σ | 2.072 |
| İç dinamik tıkanma | 0.334 |

## 3. Akış ölçümü (USD köprüsü, mn $)

| Alan | Değer |
| --- | ---: |
| MFIN kenar | 10,144.2 |
| Belirsiz merkez | 5,797 |
| Merkez toplam | 15,941.2 |
| Rant toplam | 2,899.8 |

## 4. Zarar çözümü (beş adım varsayımı)

| Alan | Değer |
| --- | ---: |
| TR net ham | -17.7 |
| TR net çözüm sonrası | -13.113 |
| TR net farkı | 4.587 |
| TR boşalma ham → sonrası | 17.172 → 14.622 |

## 5. Üretim iç akışı ve finans katmanı

| Alan | Değer |
| --- | ---: |
| Üretim iç akış TR net | -4.383 |
| Üretim: sıfır yılı tahmini | 2044 |
| Finans katmanı TR net | -1.23 |
| Finans: sıfır üstü takvim yılı | 2040 |
| Üretime bağlanma gerçekleşmesi g_u (bağ kullanımı / C) | 1 |
| Finans dış koşul gerçekleşmesi g_f (politika / C; < 0: ters çevrilmiş) | 1 |
| Finans ters çevrildi (araçsallaşma) | hayır |
| Finans TR net: çevrilmemiş olsaydı (varsayım bandı üstü) | — |
| Finans etiketi | varsayim_carpanli_ham |

## 6. Stok-akış (SFC, tr TL)

| Alan | Değer |
| --- | ---: |
| Matris dönemi / kur | 2026-Q1 / 44.38 |
| H | 0 |
| F | -1.001 |
| B | 0 |
| K | 0 |
| D | 1.001 |
| Kapanış (Σ=0) | evet |
| F.4 stok 2036, baz (mr TL) | 25,339.8 |
| F.4 stok 2036, silme %20 varsayımı | 20,271.8 |

## 7. Gerçeklik kalibrasyonu

| Alan | Değer |
| --- | ---: |
| TR net son (kalibre) | -11.377 |
| GSYH % | 3.401 |
| TR net 10. yıl yolu | -13.415 |
| Yol modu (finans üretimle eşzamanlı mı) | uretimle_es_zamanli |
| Finans kalibre gerçekleşme r_f (tersse harm: tavan yok) | 0.219 |
| Gerçekleşme: zarar / üretim / finans | 0.665 / 0.237 / 0.219 |

## 8. Dış rant parasal akışı

| Alan | Değer |
| --- | ---: |
| Boşluk rantı toplam (vekil) | 4.189 |
| Refah dış toplam (vekil) | 1.12 |
| Refah TR iç toplam (vekil) | 0.509 |
| Boşluk rantı (mn $) | 22,550.0 |
| Refah dış (mn $) | 6,029.1 |

## 9. Uluslararası stok-akış

| Alan | Değer |
| --- | ---: |
| Kapanış tamam | evet |
| Havza net stok (mn $) | 40,831.1 |
| Havza kayıp brüt kenar (mn $) | 145,721.8 |
| Merkez sızıntı (mn $) | 25,430.5 |
| Kanal ikame (mn $) | 70,696.7 |

## 10. Dış aktörlerin kaybın devamlılığı için maliyeti (varsayım)

| Alan | Değer |
| --- | ---: |
| Maliyet katsayısı κ × TR karşı-hamle gücü pol | 0.2 × 0.95 |
| Σ sürdürme maliyeti (TR, MFIN hariç) | 2.375 |
| Σ dış kazanç (TR, MFIN hariç) | 14.248 |
| Maliyet / kazanç | 0.167 |
| Kazançtan maliyet düşülünce Σ dış net | 11.873 |

## Ülke ve aktör ayrıntısı

- `ULKE_KAYIP_C.md`, `DIS_AKTOR_C.md`, `AKIS_OLCUM_C.md`, `ZARAR_COZUM_C.md`

## Not

**Yapısal sınır (A, B, C için aynı):** üretim ve finans katmanları senaryoya özgü gerçekleşmeyle kurulur: g_u = bağ kullanımı / C'ninki (üretime bağlama kanalı), g_f = politika gerçekleşmesi / C'ninki (dış koşul: erozyon, diplomatik esneklik). Etkin çarpan = 1 − g (1 − çarpan); C'de g = 1. Çarpanların kendisi (halka düzeltmesi, MFIN, TDS, iç tutma) tüm senaryolarda ortak ve atanmıştır; g türetilmiştir ama doğrusal ölçekleme varsayımdır. Baskın modu araçsal olan senaryoda (B) finans katmanı ters çevrilir (g_f < 0, ayna simetri, güç 1: varsayım; duyarlılık finans raporunda). F.4 stok yolu (bölüm 6) beş adımın kredi itişinden gelir ve senaryodan bağımsızdır; üç sütunda aynı olması senaryo farkı değil model yapısıdır. Finans katmanı kalibre yola bağlıdır (üretimle eşzamanlı yükselir); çarpanları atanmıştır. Olasılık ölçülmemiştir (gözlem yokken tekdüze); bu rapor senaryolar arasında sıra kurmaz.
