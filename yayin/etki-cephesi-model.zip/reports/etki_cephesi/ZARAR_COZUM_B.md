# Zarar teorisi × etki cephesi (çözüm varsayımı)

**GitHub:** [https://github.com/saydamonur2002-tech/zarar-teorisi](https://github.com/saydamonur2002-tech/zarar-teorisi) (`87f0317`) — beş adım koşusu **bitti**, kredi ihtiyacı **0.0**, tavan **0.0728→0.2582**.

**Etki cephesi taban:** Senaryo **B**.

*ic_dongu=0.5000; merkez×(1−ic×0.55); boşalma×(1−ic×fin×0.45); rant×(1−ic×0.18); TR iç geri +0.14×ic×boşalma, havza×(1−ic×0.45×0.85)*

| Gösterge | B (ham) | B + zarar çözümü | Δ |
| --- | ---: | ---: | ---: |
| TR boşalma | 40.166 | 34.201 | -5.965 |
| Merkez sızıntı | 20.729 | 15.029 | -5.7 |
| MFIN kenar | 16.867 | 12.6 | -4.267 |
| Rant Σ | 4.083 | 3.716 | -0.367 |
| Merkez+rant | 24.812 | 18.745 | -6.067 |
| TR havza kaybı | 41.76 | 33.773 | -7.987 |
| TR iç geri kazanım (vekili) | — | 2.812 | — |
| TR net birleşik vekil | -41.76 | -30.961 | 10.799 |

## Yorum

- **Zarar teorisi** tarafında çözüm = stok eşleşme tavanı genişler, **yeni kredi itişi 0** (adım 3).
- **Etki cephesi** tarafında bu, finans/rant sızıntısını kısar ve TR'ye **iç döngü geri kazanım** satırı ekler; dış aktörler hâlâ kazanır ama **MFIN/CN payı görece düşer**.
- Bu birleşik koşu **kanıt A/B değil**; SFC beş adım etiketi `temiz` + kullanıcı varsayımı.
