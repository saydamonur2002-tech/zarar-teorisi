# Senaryo — gerçeklik kalibrasyonu (2024 çapa)

Taban: C + refah rant entegrasyonu. Reform katmanları politika USD tavanlarına göre gerçekleşme ile kısıldı. TR net USD: üç köprü + geometrik orta; GSYH WB TL/kur.

- **BoP (merkez+rant):** 1 vekil ≈ 2,589.12 mn USD
- **GSYH (vekili):** 1,356,471.7 mn USD

### USD köprüleri

- **bop_merkez_rant:** 1 vekil ≈ **2,589.12** mn USD
- **tum_havza_rant:** 1 vekil ≈ **5,383.14** mn USD
- **mal_net_ticaret:** 1 vekil ≈ **4,785.41** mn USD


## Doğrulama (2024)

- MFIN kenar USD (model C): 10,144.2 mn
- Yatırım geliri gideri: 18,841.0 mn
- Net ticaret: -82,175.0 mn
- TR küresel yatırım geliri payı: %0.897
- TİM/Ticaret kalibrasyonu aktif: True
- Rant modeli: **refah**
- Refah rant (toplam / TR iç): 2.062 / 0.509 vekil

## İyileşme tavanları (10 yıl, USD mn)

- Zarar teorisi: 1507.3
- Üretim/rant: 4264.5
- Finans: 1884.1

## Gerçekleşme oranları

- Zarar: **0.665**
- Üretim/iç akış: **0.2375**
- Finans: **0.2186**

## Kalibre katman yığını

| Katman | TR net | USD BoP | USD rant | USD mal | Orta | GSYH% orta |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| C_refah_entegre | -17.191 | 44,509.6 | 92,541.6 | 82,266.0 | 69,716.7 | 5.14 |
| zarar_teorisi | -14.141 | 36,612.7 | 76,123.0 | 67,670.5 | 57,347.7 | 4.228 |
| uretim_ic_akis | -12.124 | 31,390.5 | 65,265.2 | 58,018.3 | 49,167.9 | 3.625 |
| finans_katman | -11.433 | 29,601.4 | 61,545.4 | 54,711.6 | 46,365.6 | 3.418 |

**Ham model (finans son):** -0.9509999999999996 vekil — kalibre sonrası **-11.433** vekil (USD orta **46,365.6** mn, **%3.418** GSYH).

**Sıfır noktası (kalibre orta yol):** — (net pozitife çıkmıyor)
