# Senaryo — gerçeklik kalibrasyonu (2024 çapa)

Taban: C + refah rant entegrasyonu. Reform katmanları politika USD tavanlarına göre gerçekleşme ile kısıldı. TR net USD: üç köprü + geometrik orta; GSYH WB TL/kur.

- **BoP (merkez+rant):** 1 vekil ≈ 2,087.88 mn USD
- **GSYH (vekili):** 1,356,471.7 mn USD

### USD köprüleri

- **bop_merkez_rant:** 1 vekil ≈ **2,087.88** mn USD
- **tum_havza_rant:** 1 vekil ≈ **5,383.14** mn USD
- **mal_net_ticaret:** 1 vekil ≈ **4,785.41** mn USD


## Doğrulama (2024)

- MFIN kenar USD (model C): 11,821.6 mn
- Yatırım geliri gideri: 18,841.0 mn
- Net ticaret: -82,175.0 mn
- TR küresel yatırım geliri payı: %0.897
- TİM/Ticaret kalibrasyonu aktif: True
- Rant modeli: **refah**
- Refah rant (toplam / TR iç): 2.062 / 0.509 vekil

## İyileşme tavanları (10 yıl, USD mn)

- Zarar teorisi: 1507.3
- Üretim/rant: 2054.4
- Finans: 1884.1

## Gerçekleşme oranları

- Zarar: **0.665**
- Üretim/iç akış: **0.2375**
- Finans: **0.2201**

## Kalibre katman yığını

| Katman | TR net | USD BoP | USD rant | USD mal | Orta | GSYH% orta |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| C_refah_entegre | -17.191 | 35,892.7 | 92,541.6 | 82,266.0 | 64,891.5 | 4.784 |
| zarar_teorisi | -14.141 | 29,524.7 | 76,123.0 | 67,670.5 | 53,378.6 | 3.935 |
| uretim_ic_akis | -12.068 | 25,196.5 | 64,963.7 | 57,750.3 | 45,553.5 | 3.358 |
| finans_katman | -11.211 | 23,407.2 | 60,350.4 | 53,649.2 | 42,318.6 | 3.12 |

**Ham model (finans son):** 0.02000000000000035 vekil — kalibre sonrası **-11.211** vekil (USD orta **42,318.6** mn, **%3.12** GSYH).

**Sıfır noktası (kalibre orta yol):** — (net pozitife çıkmıyor)
