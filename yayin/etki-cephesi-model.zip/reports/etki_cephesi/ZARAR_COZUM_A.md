# Zarar teorisi × etki cephesi (çözüm varsayımı)

**GitHub:** [https://github.com/saydamonur2002-tech/zarar-teorisi](https://github.com/saydamonur2002-tech/zarar-teorisi) (`87f0317`) — beş adım koşusu **bitti**, kredi ihtiyacı **0.0**, tavan **0.0728→0.2582**.

**Etki cephesi taban:** Senaryo **A**.

*ic_dongu=0.5000; merkez×(1−ic×0.55); boşalma×(1−ic×fin×0.45); rant×(1−ic×0.18); TR iç geri +0.14×ic×boşalma, havza×(1−ic×0.45×0.85)*

| Gösterge | A (ham) | A + zarar çözümü | Δ |
| --- | ---: | ---: | ---: |
| TR boşalma | 24.952 | 21.247 | -3.705 |
| Merkez sızıntı | 13.133 | 9.521 | -3.612 |
| MFIN kenar | 9.192 | 6.866 | -2.326 |
| Rant Σ | 1.984 | 1.805 | -0.179 |
| Merkez+rant | 15.117 | 11.326 | -3.791 |
| TR havza kaybı | 25.822 | 20.884 | -4.938 |
| TR iç geri kazanım (vekili) | — | 1.747 | — |
| TR net birleşik vekil | -25.822 | -19.137 | 6.685 |

## Yorum

- **Zarar teorisi** tarafında çözüm = stok eşleşme tavanı genişler, **yeni kredi itişi 0** (adım 3).
- **Etki cephesi** tarafında bu, finans/rant sızıntısını kısar ve TR'ye **iç döngü geri kazanım** satırı ekler; dış aktörler hâlâ kazanır ama **MFIN/CN payı görece düşer**.
- Bu birleşik koşu **kanıt A/B değil**; SFC beş adım etiketi `temiz` + kullanıcı varsayımı.
