# Dış ülkeler + uluslararası kurumlar

**37** ülke · **10** kurum · kurum refah USD vekili **5,342.5** mn/yıl

## Kurumlar (net entegre vekil)

| Kurum | Tür | Net | USD vekili |
| --- | --- | ---: | ---: |
| IMF | uluslararasi_kurum | 0.194 | 797.9 |
| AB kurumları (Komisyon/ECB vekili) | bolgesel_kurum | 0.171 | 737.6 |
| Dünya Bankası | uluslararasi_kurum | 0.159 | 690.6 |
| EBRD (Avrupa İmar ve Kalkınma Bankası) | uluslararasi_kurum | 0.131 | 575.6 |
| BIS (Bank for International Settlements) | uluslararasi_kurum | 0.128 | 544.2 |
| AIIB (Asya Altyapı Yatırım Bankası) | uluslararasi_kurum | 0.127 | 613.4 |
| NATO | uluslararasi_kurum | 0.113 | 480.7 |
| SWIFT / ödeme altyapısı (vekil) | altyapi_kurum | 0.105 | 482.0 |
| WTO | uluslararasi_kurum | 0.057 | 240.9 |
| Birleşmiş Milletler | uluslararasi_kurum | 0.042 | 179.6 |

## Ülkeler (top 12 net)

- **Merkez finans** (merkez_finans): net **5.662**
- **Çin** (rakip_yaricevre): net **3.806**
- **Rusya** (rakip_yaricevre): net **3.713**
- **ABD** (merkez_vekil): net **1.926**
- **İran** (bolge_guc): net **1.173**
- **AB (vekil)** (merkez_yakin): net **1.009**
- **BAE** (rant_havza): net **0.79**
- **Suudi Arabistan** (rant_havza): net **0.731**
- **İsrail** (bolge_guc): net **0.635**
- **Fransa** (merkez_yakin): net **0.595**
- **Yunanistan** (rakip_yaricevre): net **0.374**
- **Kuzey Makedonya** (tampon): net **0.239**
