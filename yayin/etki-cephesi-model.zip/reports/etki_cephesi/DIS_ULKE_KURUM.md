# Dış ülkeler + uluslararası kurumlar

**37** ülke · **10** kurum · kurum refah USD vekili **3,934.2** mn/yıl

## Kurumlar (net entegre vekil)

| Kurum | Tür | Net | USD vekili |
| --- | --- | ---: | ---: |
| IMF | uluslararasi_kurum | 0.135 | 565.9 |
| AB kurumları (Komisyon/ECB vekili) | bolgesel_kurum | 0.121 | 538.8 |
| Dünya Bankası | uluslararasi_kurum | 0.113 | 508.3 |
| EBRD (Avrupa İmar ve Kalkınma Bankası) | uluslararasi_kurum | 0.094 | 426.5 |
| AIIB (Asya Altyapı Yatırım Bankası) | uluslararasi_kurum | 0.093 | 480.9 |
| BIS (Bank for International Settlements) | uluslararasi_kurum | 0.09 | 395.1 |
| NATO | uluslararasi_kurum | 0.08 | 348.2 |
| SWIFT / ödeme altyapısı (vekil) | altyapi_kurum | 0.076 | 366.0 |
| WTO | uluslararasi_kurum | 0.04 | 174.6 |
| Birleşmiş Milletler | uluslararasi_kurum | 0.03 | 129.9 |

## Ülkeler (top 12 net)

- **Merkez finans** (merkez_finans): net **3.918**
- **Çin** (rakip_yaricevre): net **2.688**
- **Rusya** (rakip_yaricevre): net **2.59**
- **ABD** (merkez_vekil): net **1.986**
- **İran** (bolge_guc): net **1.302**
- **BAE** (rant_havza): net **0.911**
- **AB (vekil)** (merkez_yakin): net **0.877**
- **Suudi Arabistan** (rant_havza): net **0.76**
- **İsrail** (bolge_guc): net **0.538**
- **Fransa** (merkez_yakin): net **0.408**
- **Yunanistan** (rakip_yaricevre): net **0.229**
- **Kuzey Makedonya** (tampon): net **0.182**
