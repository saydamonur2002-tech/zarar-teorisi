# 10 yıl — zarar (TR net) azalması ve GSYH etkisi

TR net vekil (negatif = yapısal kayıp). Kalibre yol (GERCEKLIK_KALIBRE); GSYH % = |kayıp| USD orta / GSYH 2024 vekili. Kumulatif kazanım = yıllık tabana göre azalan kayıp USD (geometrik orta köprü, basit toplam vekili).

**Dönem:** 2027–2036 · GSYH çapası (2024 vekili): **1,356,471.7** mn USD

## Özet

| | Taban (C+refah) | 10. yıl sonu |
| --- | ---: | ---: |
| TR net vekil | -17.191 | **-13.429** |
| İyileşme (vekil) | — | **3.762** |
| GSYH % (USD orta köprü) | 5.14 | **4.015** |
| GSYH puan düşüş | — | **1.125** pp |
| Yapısal kayıp USD (orta) | 69,716.7 | **54,460.2** mn |

**Yorum:** 10 yıl içinde tam paket (zarar→üretim→finans, kalibre gerçekleşme) bitmez; finans fazının tamamı ~2057 vekiline uzanır. Bu tablo **ilk 10 takvim yılında** gerçekleşen kısmi iyileşmeyi gösterir (ağırlık zarar + üretim başlangıcı).

## Yıllık seri

| Yıl | Faz | TR net | Δ vekil (tabana göre) | GSYH % orta | GSYH % mal | Kum. kazanım USD orta |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 2027 | zarar | -16.755 | 0.436 | 5.009 | 5.911 | 1,768.2 |
| 2028 | zarar | -16.32 | 0.871 | 4.879 | 5.757 | 5,300.5 |
| 2029 | zarar | -15.884 | 1.307 | 4.749 | 5.604 | 10,600.9 |
| 2030 | zarar | -15.448 | 1.743 | 4.618 | 5.45 | 17,669.5 |
| 2031 | zarar | -15.012 | 2.179 | 4.488 | 5.296 | 26,506.2 |
| 2032 | zarar | -14.577 | 2.614 | 4.358 | 5.143 | 37,107.1 |
| 2033 | zarar | -14.141 | 3.05 | 4.228 | 4.989 | 49,476.1 |
| 2034 | uretim+finans | -13.904 | 3.287 | 4.157 | 4.905 | 62,806.3 |
| 2035 | uretim+finans | -13.667 | 3.524 | 4.086 | 4.821 | 77,097.6 |
| 2036 | uretim+finans | -13.429 | 3.762 | 4.015 | 4.738 | 92,354.1 |

**Zarar teorisi ağırlıklı 7 yıl sonu vekili (yaklaşık):** -14.141
