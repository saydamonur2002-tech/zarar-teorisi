# 10 yıl — zarar (TR net) azalması ve GSYH etkisi

TR net vekil (negatif = yapısal kayıp). Kalibre yol (GERCEKLIK_KALIBRE); GSYH % = |kayıp| USD orta / GSYH 2024 vekili. Kumulatif kazanım = yıllık tabana göre azalan kayıp USD (geometrik orta köprü, basit toplam vekili).

**Dönem:** 2027–2036 · GSYH çapası (2024 vekili): **1,356,471.7** mn USD

## Özet

| | Taban (C+refah) | 10. yıl sonu |
| --- | ---: | ---: |
| TR net vekil | -17.191 | **-13.796** |
| İyileşme (vekil) | — | **3.395** |
| GSYH % (USD orta köprü) | 4.784 | **3.839** |
| GSYH puan düşüş | — | **0.945** pp |
| Yapısal kayıp USD (orta) | 64,891.5 | **52,076.3** mn |

**Yorum:** 10 yıl içinde tam paket (zarar→üretim→finans, kalibre gerçekleşme) bitmez; finans fazının tamamı ~2057 vekiline uzanır. Bu tablo **ilk 10 takvim yılında** gerçekleşen kısmi iyileşmeyi gösterir (ağırlık zarar + üretim başlangıcı).

## Yıllık seri

| Yıl | Faz | TR net | Δ vekil (tabana göre) | GSYH % orta | GSYH % mal | Kum. kazanım USD orta |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 2027 | zarar | -16.755 | 0.436 | 4.663 | 5.911 | 1,645.8 |
| 2028 | zarar | -16.32 | 0.871 | 4.541 | 5.757 | 4,933.6 |
| 2029 | zarar | -15.884 | 1.307 | 4.42 | 5.604 | 9,867.1 |
| 2030 | zarar | -15.448 | 1.743 | 4.299 | 5.45 | 16,446.4 |
| 2031 | zarar | -15.012 | 2.179 | 4.177 | 5.296 | 24,671.5 |
| 2032 | zarar | -14.577 | 2.614 | 4.056 | 5.143 | 34,538.7 |
| 2033 | zarar | -14.141 | 3.05 | 3.935 | 4.989 | 46,051.6 |
| 2034 | zarar | -14.141 | 3.05 | 3.935 | 4.989 | 57,564.5 |
| 2035 | uretim | -13.968 | 3.223 | 3.887 | 4.928 | 69,730.5 |
| 2036 | uretim | -13.796 | 3.395 | 3.839 | 4.867 | 82,545.7 |

**Zarar teorisi ağırlıklı 7 yıl sonu vekili (yaklaşık):** -14.141
