# 10 yıl — zarar (TR net) azalması ve GSYH etkisi

TR net vekil (negatif = yapısal kayıp). Kalibre yol (GERCEKLIK_KALIBRE); GSYH % = |kayıp| USD orta / GSYH 2024 vekili. Kumulatif kazanım = yıllık tabana göre azalan kayıp USD (geometrik orta köprü, basit toplam vekili).

**Dönem:** 2027–2036 · GSYH çapası (2024 vekili): **1,356,471.7** mn USD

## Özet

| | Taban (C+refah) | 10. yıl sonu |
| --- | ---: | ---: |
| TR net vekil | -17.191 | **-13.415** |
| İyileşme (vekil) | — | **3.776** |
| GSYH % (USD orta köprü) | 5.14 | **4.011** |
| GSYH puan düşüş | — | **1.129** pp |
| Yapısal kayıp USD (orta) | 69,716.7 | **54,403.4** mn |

**Yorum:** 10 yıl içinde tam paket (zarar→üretim→finans, kalibre gerçekleşme) bitmez; finans fazının tamamı ~2057 vekiline uzanır. Bu tablo **ilk 10 takvim yılında** gerçekleşen kısmi iyileşmeyi gösterir (ağırlık zarar + üretim başlangıcı).

## Yıllık seri

| Yıl | Faz | TR net | Δ vekil (tabana göre) | GSYH % orta | GSYH % mal | Kum. kazanım USD orta |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 2027 | zarar | -16.755 | 0.436 | 5.009 | 5.911 | 1,768.2 |
| 2028 | zarar | -16.32 | 0.871 | 4.879 | 5.757 | 5,300.5 |
| 2029 | zarar | -15.884 | 1.307 | 4.749 | 5.604 | 10,600.9 |
| 2030 | zarar | -15.448 | 1.743 | 4.618 | 5.45 | 17,669.5 |
| 2031 | zarar | -15.012 | 2.179 | 4.488 | 5.296 | 26,506.2 |
| 2032 | zarar | -14.577 | 2.614 | 4.358 | 5.143 | 37,107.1 |
| 2033 | zarar | -14.141 | 3.05 | 4.228 | 4.989 | 49,476.1 |
| 2034 | uretim+finans | -13.899 | 3.292 | 4.155 | 4.903 | 62,826.5 |
| 2035 | uretim+finans | -13.657 | 3.534 | 4.083 | 4.818 | 77,158.4 |
| 2036 | uretim+finans | -13.415 | 3.776 | 4.011 | 4.733 | 92,471.7 |

**Zarar teorisi ağırlıklı 7 yıl sonu vekili (yaklaşık):** -14.141
