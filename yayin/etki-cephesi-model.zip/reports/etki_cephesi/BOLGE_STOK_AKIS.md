# Bölgesel stok-akış — kazanan / kaybeden

*1) Rant kanalı: boşluk→refah geçişinde hayalet rant kaybedenler (EU, US, CN…). 2) Entegre defter: havza+ikame+kanal+refah — çevrede IR, EG, GR vb. net pozitif.*

## Halka çevre — İran, Mısır, Yunanistan, … (entegre net > 0)

- **IR** (İran): net **1.302** vekil ≈ 7,008.8 mn $/yıl — refah rant 0.121, havza kaybı 0.277
- **IL** (İsrail): net **0.538** vekil ≈ 2,896.1 mn $/yıl — refah rant 0.044, havza kaybı 0.124

*(Balkan vekili çoğunlukla **EU** satırında; **FR** ayrı net +0,595 vekil.)*

## Rakip yarıçevre (CN, RU — entegre kazanan)

- **CN:** net 2.688 vekil
- **RU:** net 2.59 vekil
- **GR:** net 0.229 vekil

## Çevre kaybeden (Balkan / Kafkas tampon)

- **AZ** (Azerbaycan): net -0.229 vekil (havza 0.249)

## Tüm entegre kazananlar (top 12, vekil)

| Ülke | Rol | Net entegre | USD mn | Refah rant | Rant kanalı fark |
| --- | --- | ---: | ---: | ---: | ---: |
| CN | rakip_yaricevre | 2.688 | 14,469.9 | 0.197 | 2,628.8 |
| RU | rakip_yaricevre | 2.59 | 13,942.3 | 0.181 | 2,324.2 |
| US | merkez_vekil | 1.986 | 10,690.9 | 0.177 | 2,778.2 |
| IR | bolge_guc | 1.302 | 7,008.8 | 0.121 | 1,400.4 |
| AE | rant_havza | 0.911 | 4,904.0 | 0.068 | 1,105.1 |
| EU | merkez_yakin | 0.877 | 4,721.0 | 0.064 | 3,114.0 |
| SA | rant_havza | 0.76 | 4,091.2 | 0.045 | 657.4 |
| IL | bolge_guc | 0.538 | 2,896.1 | 0.044 | 979.2 |
| FR | merkez_yakin | 0.408 | 2,196.3 | 0.029 | 389.0 |
| GR | rakip_yaricevre | 0.229 | 1,232.7 | 0.014 | 378.7 |
| MK |  | 0.182 | 979.7 | 0.027 | — |
| AL |  | 0.178 | 958.2 | 0.027 | — |

## TR (özel)

- Yapısal **net entegre -17.191** vekil (havza baskın); **refah reform kazancı** ≈ 19,260.9 mn $/yıl (boşluk−refah + TR iç).

## Rant kanalı: boşluk senaryosunu tercih edenler (büyük fark)

- **EG:** fark 505.9 mn $
