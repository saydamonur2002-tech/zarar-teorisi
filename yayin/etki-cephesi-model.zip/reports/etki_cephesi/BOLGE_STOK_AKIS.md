# Bölgesel stok-akış — kazanan / kaybeden

*1) Rant kanalı: boşluk→refah geçişinde hayalet rant kaybedenler (EU, US, CN…). 2) Entegre defter: havza+ikame+kanal+refah — çevrede IR, EG, GR vb. net pozitif.*

## Halka çevre — bant dışı kazananlar (net − bant > 0)

- **IR** (İran): net **0.952** vekil ≈ 5,124.7 mn $/yıl — refah rant 0.121, havza kaybı 0.277
- **IL** (İsrail): net **0.362** vekil ≈ 1,948.7 mn $/yıl — refah rant 0.044, havza kaybı 0.124

*(Balkan vekili çoğunlukla **EU** satırında.)*

## Bant içi: sıfırdan ayırt edilemeyen (kazanan da kaybeden de denmez)

- **CN** (Çin): net -1.044 ± 1.956 → [-3.0; 0.912] (rant_kanali_bosluk_taraftari; bant kapsamı tam)
- **RU** (Rusya): net -0.733 ± 1.805 → [-2.538; 1.072] (rant_kanali_bosluk_taraftari; bant kapsamı tam)
- **GR** (Yunanistan): net -0.204 ± 0.231 → [-0.435; 0.027] (belirsiz_bant_ici; bant kapsamı tam)
- **BA** (Bosna-Hersek): net 0.143 ± 0.143 → [0.0; 0.286] (belirsiz_bant_ici; bant kapsamı kismi)
- **BG** (Bulgaristan): net -0.051 ± 0.143 → [-0.194; 0.092] (belirsiz_bant_ici; bant kapsamı kismi)
- **EG** (Mısır): net -0.05 ± 0.148 → [-0.198; 0.098] (rant_kanali_bosluk_taraftari; bant kapsamı tam)
- **CY** (Kıbrıs Rum Kesimi (vekil)): net -0.046 ± 0.143 → [-0.189; 0.097] (belirsiz_bant_ici; bant kapsamı kismi)

## Rakip yarıçevre (CN, RU — entegre kazanan)


## Çevre kaybeden (Balkan / Kafkas tampon)

- **AZ** (Azerbaycan): net -0.229 vekil (havza 0.249)
- **RS** (Sırbistan): net -0.065 vekil (havza 0.392)

## Tüm entegre kazananlar (top 12, vekil)

| Ülke | Rol | Net entegre | USD mn | Refah rant | Rant kanalı fark |
| --- | --- | ---: | ---: | ---: | ---: |
| IR | bolge_guc | 0.952 | 5,124.7 | 0.121 | 1,400.4 |
| US | merkez_vekil | 0.609 | 3,278.3 | 0.177 | 2,778.2 |
| IL | bolge_guc | 0.362 | 1,948.7 | 0.044 | 979.2 |
| SA | rant_havza | 0.35 | 1,884.1 | 0.045 | 657.4 |
| MK |  | 0.182 | 979.7 | 0.027 | — |
| AL |  | 0.178 | 958.2 | 0.027 | — |

## TR (özel)

- Yapısal **net entegre -17.191** vekil (havza baskın); **refah reform kazancı** ≈ 19,260.9 mn $/yıl (boşluk−refah + TR iç).

## Rant kanalı: boşluk senaryosunu tercih edenler (büyük fark)

- **CN:** fark 2,628.8 mn $
- **RU:** fark 2,324.2 mn $
- **EG:** fark 505.9 mn $
