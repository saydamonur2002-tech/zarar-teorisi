# Bölgesel stok-akış — kazanan / kaybeden

*1) Rant kanalı: boşluk→refah geçişinde hayalet rant kaybedenler (EU, US, CN…). 2) Entegre defter: havza+ikame+kanal+refah — çevrede IR, EG, GR vb. net pozitif.*

## Halka çevre — İran, Mısır, Yunanistan, … (entegre net > 0)

- **IR** (İran): net **1.173** vekil ≈ 6,314.4 mn $/yıl — refah rant 0.121, havza kaybı 0.277
- **IL** (İsrail): net **0.635** vekil ≈ 3,418.3 mn $/yıl — refah rant 0.044, havza kaybı 0.124
- **EG** (Mısır): net **0.202** vekil ≈ 1,087.4 mn $/yıl — refah rant 0.022, havza kaybı 0.316

*(Balkan vekili çoğunlukla **EU** satırında; **FR** ayrı net +0,595 vekil.)*

## Rakip yarıçevre (CN, RU — entegre kazanan)

- **CN:** net 3.806 vekil
- **RU:** net 3.713 vekil
- **GR:** net 0.374 vekil

## Çevre kaybeden (Balkan / Kafkas tampon)

- **AZ** (Azerbaycan): net -0.229 vekil (havza 0.249)

## Tüm entegre kazananlar (top 12, vekil)

| Ülke | Rol | Net entegre | USD mn | Refah rant | Rant kanalı fark |
| --- | --- | ---: | ---: | ---: | ---: |
| CN | rakip_yaricevre | 3.806 | 20,488.2 | 0.197 | 2,628.8 |
| RU | rakip_yaricevre | 3.713 | 19,987.6 | 0.181 | 2,324.2 |
| US | merkez_vekil | 1.926 | 10,367.9 | 0.177 | 2,778.2 |
| IR | bolge_guc | 1.173 | 6,314.4 | 0.121 | 1,400.4 |
| EU | merkez_yakin | 1.009 | 5,431.6 | 0.064 | 3,114.0 |
| AE | rant_havza | 0.79 | 4,252.7 | 0.068 | 1,105.1 |
| SA | rant_havza | 0.731 | 3,935.1 | 0.045 | 657.4 |
| IL | bolge_guc | 0.635 | 3,418.3 | 0.044 | 979.2 |
| FR | merkez_yakin | 0.595 | 3,203.0 | 0.029 | 389.0 |
| GR | rakip_yaricevre | 0.374 | 2,013.3 | 0.014 | 378.7 |
| MK |  | 0.239 | 1,286.6 | 0.027 | — |
| AL |  | 0.235 | 1,265.0 | 0.027 | — |

## TR (özel)

- Yapısal **net entegre -17.191** vekil (havza baskın); **refah reform kazancı** ≈ 19,260.9 mn $/yıl (boşluk−refah + TR iç).

## Rant kanalı: boşluk senaryosunu tercih edenler (büyük fark)

