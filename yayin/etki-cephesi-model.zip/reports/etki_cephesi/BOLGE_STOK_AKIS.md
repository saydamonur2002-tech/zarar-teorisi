# Bölgesel stok-akış — kazanan / kaybeden

*1) Rant kanalı: boşluk→refah geçişinde hayalet rant kaybedenler (EU, US, CN…). 2) Entegre defter: havza+ikame+kanal+refah — çevrede IR, EG, GR vb. net pozitif.*

## Halka çevre — İran, Mısır, Yunanistan, … (entegre net > 0)

- **IR** (İran): net **1.24** vekil ≈ 6,675.1 mn $/yıl — refah rant 0.121, havza kaybı 0.277
- **IL** (İsrail): net **0.476** vekil ≈ 2,562.4 mn $/yıl — refah rant 0.044, havza kaybı 0.124

*(Balkan vekili çoğunlukla **EU** satırında; **FR** ayrı net +0,595 vekil.)*

## Rakip yarıçevre (CN, RU — entegre kazanan)

- **CN:** net 2.626 vekil
- **RU:** net 2.528 vekil
- **GR:** net 0.167 vekil

## Çevre kaybeden (Balkan / Kafkas tampon)

- **AZ** (Azerbaycan): net -0.229 vekil (havza 0.249)

## Tüm entegre kazananlar (top 12, vekil)

| Ülke | Rol | Net entegre | USD mn | Refah rant | Rant kanalı fark |
| --- | --- | ---: | ---: | ---: | ---: |
| CN | rakip_yaricevre | 2.626 | 14,136.1 | 0.197 | 2,628.8 |
| RU | rakip_yaricevre | 2.528 | 13,608.6 | 0.181 | 2,324.2 |
| US | merkez_vekil | 1.924 | 10,357.2 | 0.177 | 2,778.2 |
| IR | bolge_guc | 1.24 | 6,675.1 | 0.121 | 1,400.4 |
| AE | rant_havza | 0.849 | 4,570.3 | 0.068 | 1,105.1 |
| EU | merkez_yakin | 0.814 | 4,381.9 | 0.064 | 3,114.0 |
| SA | rant_havza | 0.698 | 3,757.4 | 0.045 | 657.4 |
| IL | bolge_guc | 0.476 | 2,562.4 | 0.044 | 979.2 |
| FR | merkez_yakin | 0.346 | 1,862.6 | 0.029 | 389.0 |
| MK |  | 0.182 | 979.7 | 0.027 | — |
| AL |  | 0.178 | 958.2 | 0.027 | — |
| GR | rakip_yaricevre | 0.167 | 899.0 | 0.014 | 378.7 |

## TR (özel)

- Yapısal **net entegre -17.191** vekil (havza baskın); **refah reform kazancı** ≈ 19,260.9 mn $/yıl (boşluk−refah + TR iç).

## Rant kanalı: boşluk senaryosunu tercih edenler (büyük fark)

- **EG:** fark 505.9 mn $
