# Bölgesel stok-akış — kazanan / kaybeden

*1) Rant kanalı: boşluk→refah geçişinde hayalet rant kaybedenler (EU, US, CN…). 2) Entegre defter: havza+ikame+kanal+refah — çevrede IR, EG, GR vb. net pozitif.*

## Halka çevre — bant dışı kazananlar (net − bant > 0)

- **IR** (İran): net **0.744** vekil ≈ 4,005.1 mn $/yıl — refah rant 0.121, havza kaybı 0.277
- **IL** (İsrail): net **0.219** vekil ≈ 1,178.9 mn $/yıl — refah rant 0.044, havza kaybı 0.124

*(Balkan vekili çoğunlukla **EU** satırında.)*

## Bant içi: sıfırdan ayırt edilemeyen (kazanan da kaybeden de denmez)

- **MFIN** (Merkez finans (vekil)): net 1.897 ± 2.645 → [-0.748; 4.542] (belirsiz_bant_ici; bant kapsamı tam)
- **CN** (Çin): net -1.641 ± 1.944 → [-3.585; 0.303] (rant_kanali_bosluk_taraftari; bant kapsamı tam)
- **RU** (Rusya): net -1.452 ± 1.79 → [-3.242; 0.338] (rant_kanali_bosluk_taraftari; bant kapsamı tam)
- **US** (ABD): net 0.281 ± 0.512 → [-0.231; 0.793] (rant_kanali_bosluk_taraftari; bant kapsamı tam)
- **EG** (Mısır): net -0.135 ± 0.145 → [-0.28; 0.01] (rant_kanali_bosluk_taraftari; bant kapsamı tam)
- **MK** (Kuzey Makedonya): net 0.072 ± 0.143 → [-0.071; 0.215] (belirsiz_bant_ici; bant kapsamı kismi)
- **AL** (Arnavutluk): net 0.068 ± 0.143 → [-0.075; 0.211] (belirsiz_bant_ici; bant kapsamı kismi)
- **CY** (Kıbrıs Rum Kesimi (vekil)): net -0.046 ± 0.143 → [-0.189; 0.097] (belirsiz_bant_ici; bant kapsamı kismi)
- **BA** (Bosna-Hersek): net 0.033 ± 0.143 → [-0.11; 0.176] (belirsiz_bant_ici; bant kapsamı kismi)

## Rakip yarıçevre (CN, RU — entegre kazanan)


## Çevre kaybeden (Balkan / Kafkas tampon)

- **GR** (Yunanistan): net -0.246 vekil (havza 0.0)
- **AZ** (Azerbaycan): net -0.233 vekil (havza 0.249)
- **RS** (Sırbistan): net -0.168 vekil (havza 0.392)

## Tüm entegre kazananlar (top 12, vekil)

| Ülke | Rol | Net entegre | USD mn | Refah rant | Rant kanalı fark |
| --- | --- | ---: | ---: | ---: | ---: |
| IR | bolge_guc | 0.744 | 4,005.1 | 0.121 | 1,400.4 |
| IL | bolge_guc | 0.219 | 1,178.9 | 0.044 | 979.2 |
| SA | rant_havza | 0.212 | 1,141.2 | 0.045 | 657.4 |

## TR (özel)

- Yapısal **net entegre -17.191** vekil (havza baskın); **refah reform kazancı** ≈ 19,260.9 mn $/yıl (boşluk−refah + TR iç).

## Rant kanalı: boşluk senaryosunu tercih edenler (büyük fark)

- **US:** fark 2,778.2 mn $
- **CN:** fark 2,628.8 mn $
- **RU:** fark 2,324.2 mn $
- **EG:** fark 505.9 mn $
