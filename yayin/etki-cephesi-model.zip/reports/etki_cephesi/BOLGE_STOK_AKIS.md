# Bölgesel stok-akış — kazanan / kaybeden

*1) Rant kanalı: boşluk→refah geçişinde hayalet rant kaybedenler (EU, US, CN…). 2) Entegre defter: havza+ikame+kanal+refah — çevrede IR, EG, GR vb. net pozitif.*

## Halka çevre — bant dışı kazananlar (net − bant > 0)

- **IR** (İran): net **0.952** vekil ≈ 5,124.7 mn $/yıl — refah rant 0.121, havza kaybı 0.277
- **IL** (İsrail): net **0.362** vekil ≈ 1,948.7 mn $/yıl — refah rant 0.044, havza kaybı 0.124

*(Balkan vekili çoğunlukla **EU** satırında.)*

## Bant içi: sıfırdan ayırt edilemeyen (kazanan da kaybeden de denmez)

- **CN** (Çin): net -2.08 ± 2.388 → [-4.468; 0.308] (rant_kanali_bosluk_taraftari; bant kapsamı tam)
- **RU** (Rusya): net -0.948 ± 1.887 → [-2.835; 0.939] (rant_kanali_bosluk_taraftari; bant kapsamı tam)
- **FR** (Fransa): net 0.203 ± 0.247 → [-0.044; 0.45] (belirsiz_bant_ici; bant kapsamı tam)
- **BA** (Bosna-Hersek): net 0.143 ± 0.143 → [0.0; 0.286] (belirsiz_bant_ici; bant kapsamı kismi)
- **GR** (Yunanistan): net 0.098 ± 0.174 → [-0.076; 0.272] (belirsiz_bant_ici; bant kapsamı tam)
- **BG** (Bulgaristan): net -0.051 ± 0.143 → [-0.194; 0.092] (belirsiz_bant_ici; bant kapsamı kismi)
- **EG** (Mısır): net -0.05 ± 0.148 → [-0.198; 0.098] (rant_kanali_bosluk_taraftari; bant kapsamı tam)
- **CY** (Kıbrıs Rum Kesimi (vekil)): net -0.046 ± 0.143 → [-0.189; 0.097] (belirsiz_bant_ici; bant kapsamı kismi)

## Rakip yarıçevre (CN, RU — entegre kazanan)


## Çevre kaybeden (Balkan / Kafkas tampon)

- **AZ** (Azerbaycan): net -0.229 vekil (havza 0.249)
- **RS** (Sırbistan): net -0.065 vekil (havza 0.392)

## Tüm entegre kazananlar (top 12, vekil)

| Ülke | Rol | Net entegre | USD mn | Refah rant | Rant kanalı fark |
| --- | --- | ---: | ---: | ---: | ---: |
| US | merkez_vekil | 1.129 | 6,077.6 | 0.177 | 2,778.2 |
| IR | bolge_guc | 0.952 | 5,124.7 | 0.121 | 1,400.4 |
| AE | rant_havza | 0.499 | 2,686.2 | 0.068 | 1,105.1 |
| EU | merkez_yakin | 0.477 | 2,567.8 | 0.064 | 3,114.0 |
| SA | rant_havza | 0.409 | 2,201.7 | 0.045 | 657.4 |
| IL | bolge_guc | 0.362 | 1,948.7 | 0.044 | 979.2 |
| MK |  | 0.182 | 979.7 | 0.027 | — |
| AL |  | 0.178 | 958.2 | 0.027 | — |

## TR (özel)

- Yapısal **net entegre -17.191** vekil (havza baskın); **refah reform kazancı** ≈ 19,260.9 mn $/yıl (boşluk−refah + TR iç).

## Rant kanalı: boşluk senaryosunu tercih edenler (büyük fark)

- **CN:** fark 2,628.8 mn $
- **RU:** fark 2,324.2 mn $
- **EG:** fark 505.9 mn $
