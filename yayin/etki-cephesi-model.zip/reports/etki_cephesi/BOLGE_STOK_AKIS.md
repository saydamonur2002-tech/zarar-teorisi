# Bölgesel stok-akış — kazanan / kaybeden

*1) Rant kanalı: boşluk→refah geçişinde hayalet rant kaybedenler (EU, US, CN…). 2) Entegre defter: havza+ikame+kanal+refah — çevrede IR, EG, GR vb. net pozitif.*

## Halka çevre — bant dışı kazananlar (net − bant > 0)

- **IR** (İran): net **1.24** vekil ≈ 6,675.1 mn $/yıl — refah rant 0.121, havza kaybı 0.277
- **IL** (İsrail): net **0.476** vekil ≈ 2,562.4 mn $/yıl — refah rant 0.044, havza kaybı 0.124

*(Balkan vekili çoğunlukla **EU** satırında.)*

## Bant içi: sıfırdan ayırt edilemeyen (kazanan da kaybeden de denmez)

- **BA** (Bosna-Hersek): net 0.143 ± 0.143 → [0.0; 0.286] (belirsiz_bant_ici; bant kapsamı kismi)
- **GR** (Yunanistan): net 0.13 ± 0.173 → [-0.043; 0.303] (belirsiz_bant_ici; bant kapsamı tam)
- **BG** (Bulgaristan): net -0.051 ± 0.143 → [-0.194; 0.092] (belirsiz_bant_ici; bant kapsamı kismi)
- **CY** (Kıbrıs Rum Kesimi (vekil)): net -0.032 ± 0.143 → [-0.175; 0.111] (belirsiz_bant_ici; bant kapsamı kismi)
- **EG** (Mısır): net 0.012 ± 0.142 → [-0.13; 0.154] (rant_kanali_bosluk_taraftari; bant kapsamı tam)

## Rakip yarıçevre (CN, RU — entegre kazanan)

- **CN:** net 2.04 vekil
- **RU:** net 1.964 vekil

## Çevre kaybeden (Balkan / Kafkas tampon)

- **AZ** (Azerbaycan): net -0.229 vekil (havza 0.249)
- **RS** (Sırbistan): net -0.065 vekil (havza 0.392)

## Tüm entegre kazananlar (top 12, vekil)

| Ülke | Rol | Net entegre | USD mn | Refah rant | Rant kanalı fark |
| --- | --- | ---: | ---: | ---: | ---: |
| CN | rakip_yaricevre | 2.04 | 10,981.6 | 0.197 | 2,628.8 |
| RU | rakip_yaricevre | 1.964 | 10,572.5 | 0.181 | 2,324.2 |
| US | merkez_vekil | 1.495 | 8,047.8 | 0.177 | 2,778.2 |
| IR | bolge_guc | 1.24 | 6,675.1 | 0.121 | 1,400.4 |
| AE | rant_havza | 0.66 | 3,552.9 | 0.068 | 1,105.1 |
| EU | merkez_yakin | 0.632 | 3,402.1 | 0.064 | 3,114.0 |
| SA | rant_havza | 0.542 | 2,917.7 | 0.045 | 657.4 |
| IL | bolge_guc | 0.476 | 2,562.4 | 0.044 | 979.2 |
| FR | merkez_yakin | 0.269 | 1,448.1 | 0.029 | 389.0 |
| MK |  | 0.182 | 979.7 | 0.027 | — |
| AL |  | 0.178 | 958.2 | 0.027 | — |

## TR (özel)

- Yapısal **net entegre -17.191** vekil (havza baskın); **refah reform kazancı** ≈ 19,260.9 mn $/yıl (boşluk−refah + TR iç).

## Rant kanalı: boşluk senaryosunu tercih edenler (büyük fark)

- **EG:** fark 505.9 mn $
