# Finans katmanı (üretim + halka üstü)

> **Etiket: varsayım çarpanlı ham.** İşaret dönüşü atanmış çarpanlarla üretilir; ölçüm değildir, yayınlanan sonuç değildir.

MFIN kenar, merkez sızıntı, finans halkaları (3)(4)(5), **birincil_gelir_yatirim_gideri** (18,841.0 mn USD) ve TDS vekili.

## Katman yığını (TR net vekil)

| Katman | TR net |
| --- | ---: |
| C | -17.7 |
| C_zarar_cozum | -13.113 |
| uretim_ic_akis | -4.383 |
| finans_katman | -0.489 |

## Üretim → finans

| | Üretim tam | + Finans |
| --- | ---: | ---: |
| TR net | -4.383 | **-0.489** |
| Boşalma | 9.104 | 6.697 |
| Merkez sızıntı | 4.757 | 2.548 |
| MFIN kenar | 3.512 | 1.826 |
| Finans geri kazanım | — | 2.03 |

**Finans katmanı iyileşmesi:** 3.894 vekil

## USD ↔ vekil

- İçde tutulan yatırım geliri vekili: **1.263** (2,637.7 mn USD)
- TDS rahatı vekili: **0.006**

## Sıfır noktası

- Finans tam olgunluk sonrası net: **-0.489**
- Tahmini takvim yılı (TR net ≥ 0, orta yol): **2037**
