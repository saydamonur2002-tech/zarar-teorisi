# Finans katmanı (üretim + halka üstü)

> **Etiket: varsayım çarpanlı ham.** Çarpanlar atanmıştır, ölçülmemiştir. Katman kalibre 10 yıllık yola bağlıdır; bu tablodaki ham TR net kalibre değildir (kalibre: `GERCEKLIK_KALIBRE`, `ZARAR_10Y_GSYH`).

MFIN kenar, merkez sızıntı, finans halkaları (3)(4)(5), **birincil_gelir_yatirim_gideri** (18,841.0 mn USD) ve TDS vekili.

## Katman yığını (TR net vekil)

| Katman | TR net |
| --- | ---: |
| C | -17.7 |
| C_zarar_cozum | -13.113 |
| uretim_ic_akis | -4.383 |
| finans_katman | -1.23 |

## Üretim → finans

| | Üretim tam | + Finans |
| --- | ---: | ---: |
| TR net | -4.383 | **-1.23** |
| Boşalma | 9.104 | 6.697 |
| Merkez sızıntı | 3.706 | 2.38 |
| MFIN kenar | 2.43 | 1.512 |
| Finans geri kazanım | — | 1.289 |

**Finans katmanı iyileşmesi:** 3.153 vekil

## USD ↔ vekil

- İçde tutulan yatırım geliri vekili: **1.019** (2,637.7 mn USD)
- TDS rahatı vekili: **0.005**

## Sıfır noktası

- Finans tam olgunluk sonrası net: **-1.23**
- Tahmini takvim yılı (TR net ≥ 0, orta yol): **2040**
