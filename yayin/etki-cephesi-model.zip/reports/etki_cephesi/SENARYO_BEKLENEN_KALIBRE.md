# Beklenen senaryo — kalibre (P2+)

| Senaryo | P | TR taban | TR 10y katman | TR 10y + yaşam | GSYH % |
| --- | ---: | ---: | ---: | ---: | ---: |
| **A** | 0.3333 | -24.917 | -19.368 | -18.881 | 5.645 |
| **B** | 0.3333 | -39.896 | -37.993 | -37.708 | 11.273 |
| **C** | 0.3333 | -17.191 | -13.429 | -12.769 | 3.807 |

## Olasılık ağırlıklı

- Beklenen TR net (10y, yaşam dahil): **-23.117** vekil
- Beklenen GSYH % orta: **6.908**
- Beklenen refah dış USD: **12897.967** mn/yıl
