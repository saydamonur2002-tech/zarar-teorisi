# Beklenen senaryo — kalibre (P2+)

| Senaryo | P | TR taban | TR 10y katman | TR 10y + yaşam | GSYH % |
| --- | ---: | ---: | ---: | ---: | ---: |
| **A** | 0.3333 | -24.917 | -19.322 | -18.835 | 5.241 |
| **B** | 0.3333 | -39.896 | -37.574 | -37.289 | 10.377 |
| **C** | 0.3333 | -17.191 | -13.366 | -12.706 | 3.526 |

## Olasılık ağırlıklı

- Beklenen TR net (10y, yaşam dahil): **-22.941** vekil
- Beklenen GSYH % orta: **6.381**
- Beklenen refah dış USD: **12897.967** mn/yıl
