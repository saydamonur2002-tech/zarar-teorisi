# Beklenen senaryo — kalibre (P2+)

| Senaryo | P | TR taban | TR 10y katman | TR 10y + yaşam | GSYH % |
| --- | ---: | ---: | ---: | ---: | ---: |
| **A** | 0.3333 | -24.917 | -19.975 | -19.489 | 5.423 |
| **B** | 0.3333 | -39.896 | -35.337 | -35.052 | 9.754 |
| **C** | 0.3333 | -17.191 | -13.623 | -12.963 | 3.646 |

## Olasılık ağırlıklı

- Beklenen TR net (10y, yaşam dahil): **-22.499** vekil
- Beklenen GSYH % orta: **6.274**
- Beklenen refah dış USD: **12897.967** mn/yıl
