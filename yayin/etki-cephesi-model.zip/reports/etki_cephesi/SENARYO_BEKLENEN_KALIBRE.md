# Beklenen senaryo — kalibre (P2+)

| Senaryo | P | TR taban | TR 10y katman | TR 10y + yaşam | GSYH % |
| --- | ---: | ---: | ---: | ---: | ---: |
| **A** | 0.3333 | -24.917 | -19.355 | -18.869 | 5.641 |
| **B** | 0.3333 | -39.896 | -37.975 | -37.69 | 11.268 |
| **C** | 0.3333 | -17.191 | -13.415 | -12.755 | 3.803 |

## Olasılık ağırlıklı

- Beklenen TR net (10y, yaşam dahil): **-23.102** vekil
- Beklenen GSYH % orta: **6.903**
- Beklenen refah dış USD: **12897.967** mn/yıl
