# Beklenen senaryo — kalibre (P2+)

| Senaryo | P | TR taban | TR 10y katman | TR 10y + yaşam | GSYH % |
| --- | ---: | ---: | ---: | ---: | ---: |
| **A** | 0.22 | -24.917 | -19.547 | -19.061 | 5.304 |
| **B** | 0.18 | -39.896 | -34.809 | -34.524 | 9.607 |
| **C** | 0.6 | -17.191 | -13.623 | -12.963 | 3.646 |

## Olasılık ağırlıklı

- Beklenen TR net (10y, yaşam dahil): **-18.186** vekil
- Beklenen GSYH % orta: **5.084**
- Beklenen refah dış USD: **9924.328** mn/yıl
