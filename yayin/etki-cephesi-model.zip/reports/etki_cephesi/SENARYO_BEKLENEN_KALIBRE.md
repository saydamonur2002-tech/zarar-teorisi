# Beklenen senaryo — kalibre (P2+)

| Senaryo | P | TR taban | TR 10y katman | TR 10y + yaşam | GSYH % |
| --- | ---: | ---: | ---: | ---: | ---: |
| **A** | 0.3333 | -24.917 | -19.547 | -19.061 | 5.304 |
| **B** | 0.3333 | -39.896 | -34.809 | -34.524 | 9.607 |
| **C** | 0.3333 | -17.191 | -13.623 | -12.963 | 3.646 |

## Olasılık ağırlıklı

- Beklenen TR net (10y, yaşam dahil): **-22.18** vekil
- Beklenen GSYH % orta: **6.185**
- Beklenen refah dış USD: **12897.967** mn/yıl
