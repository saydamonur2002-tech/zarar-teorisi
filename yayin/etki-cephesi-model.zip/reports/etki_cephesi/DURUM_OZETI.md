# Etki cephesi — durum özeti

**Tamam:** evet
- Uygulanabilirlik: **57.9** (C: 62.3, beklenen: 49.7)
- Stok kapanış: **True**
- Beklenen TR 10y: **-22.499** vekil
