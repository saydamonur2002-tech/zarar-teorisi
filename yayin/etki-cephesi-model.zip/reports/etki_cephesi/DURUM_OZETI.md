# Etki cephesi — durum özeti

**Tamam:** evet
- Uygulanabilirlik: **53.7** (C: 58.5, beklenen: 44.7)
- Stok kapanış: **True**
- Beklenen TR 10y: **-23.102** vekil
