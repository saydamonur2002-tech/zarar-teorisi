# Etki cephesi — durum özeti

**Tamam:** evet
- Uygulanabilirlik: **58.8** (C: 63.7, beklenen: 49.7)
- Stok kapanış: **True**
- Beklenen TR 10y: **-22.941** vekil
