# Etki cephesi — durum özeti

**Tamam:** evet
- Uygulanabilirlik: **58.7** (C: 63.5, beklenen: 49.7)
- Stok kapanış: **True**
- Beklenen TR 10y: **-23.102** vekil
