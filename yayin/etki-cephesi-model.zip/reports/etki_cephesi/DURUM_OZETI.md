# Etki cephesi — durum özeti

**Tamam:** evet
- Uygulanabilirlik: **62.7** (C: 67.1, beklenen: 54.5)
- Stok kapanış: **True**
- Beklenen TR 10y: **-18.186** vekil
