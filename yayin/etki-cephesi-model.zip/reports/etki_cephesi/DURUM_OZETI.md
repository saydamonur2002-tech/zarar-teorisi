# Etki cephesi — durum özeti

**Tamam:** evet
- Uygulanabilirlik: **47.7** (C: 52.5, beklenen: 38.7)
- Stok kapanış: **True**
- Beklenen TR 10y: **-23.117** vekil
