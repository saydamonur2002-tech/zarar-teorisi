# Etki cephesi — durum özeti

**Tamam:** evet
- Uygulanabilirlik: **56.7** (C: 61.5, beklenen: 47.7)
- Stok kapanış: **True**
- Beklenen TR 10y: **-23.102** vekil
