# Dış ülkeler — refah rantı entegrasyonu

Senaryo **C** · rant modeli: **refah** (boşluk dolgusu rant üretmez).

## Refah rant özeti

- Toplam: **2.062** vekil
- TR iç refah payı: **0.509**
- Dış ülke havuzu: **1.12**
- Eski boşluk-rant formülü (karşılaştırma): 4.189

## Ülke defteri (entegre)

| Ülke | Refah rant | Kanal | İkame | MFIN | Net entegre |
| --- | ---: | ---: | ---: | ---: | ---: |
| Merkez finans (vekil) | 0.0 | 0.0 | 0.0 | 3.918 | 3.918 |
| Çin | 0.197 | 1.692 | 0.737 | 0.062 | 2.626 |
| Rusya | 0.181 | 1.46 | 0.887 | 0.062 | 2.528 |
| ABD | 0.177 | 1.341 | 0.406 | 0.062 | 1.924 |
| İran | 0.121 | 1.139 | 0.257 | 0.062 | 1.24 |
| BAE | 0.068 | 0.648 | 0.133 | 0.062 | 0.849 |
| AB (Balkan vekil) | 0.064 | 0.624 | 0.126 | 0.062 | 0.814 |
| Suudi Arabistan | 0.045 | 0.482 | 0.171 | 0.062 | 0.698 |
| İsrail | 0.044 | 0.38 | 0.176 | 0.062 | 0.476 |
| Türkiye | 0.509 | 0.0 | 0.0 | 0.0 | -17.191 |
| Bulgaristan | 0.027 | 0.27 | 0.055 | 0.0 | -0.051 |
| Bosna-Hersek | 0.027 | 0.27 | 0.055 | 0.0 | 0.143 |
| Arnavutluk | 0.027 | 0.27 | 0.055 | 0.0 | 0.178 |
| Kuzey Makedonya | 0.027 | 0.27 | 0.055 | 0.0 | 0.182 |
| Fransa | 0.029 | 0.252 | 0.065 | 0.062 | 0.346 |
| Mısır | 0.022 | 0.201 | 0.105 | 0.062 | 0.012 |
| Sırbistan | 0.029 | 0.248 | 0.05 | 0.0 | -0.065 |
| Yunanistan | 0.014 | 0.101 | 0.052 | 0.062 | 0.167 |
| Kıbrıs Rum Kesimi (vekil) | 0.0 | 0.074 | 0.0 | 0.062 | -0.032 |
| Ukrayna (vekil) | 0.0 | 0.026 | 0.0 | 0.062 | -0.348 |
| Azerbaycan | 0.02 | 0.0 | 0.0 | 0.0 | -0.229 |
| Irak | 0.0 | 0.0 | 0.0 | 0.0 | -1.36 |

**TR:** refah rant **0.509**, havza kayıp **17.7**, net **-17.191**.
