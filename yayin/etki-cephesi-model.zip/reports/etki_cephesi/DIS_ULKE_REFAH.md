# Dış ülkeler — refah rantı entegrasyonu

Senaryo **C** · rant modeli: **refah** (boşluk dolgusu rant üretmez).

## Refah rant özeti

- Toplam: **2.062** vekil
- TR iç refah payı: **0.509**
- Dış ülke havuzu: **1.12**
- Eski boşluk-rant formülü (karşılaştırma): 4.189

## Ülke defteri (entegre)

| Ülke | Refah rant | Kanal | İkame | MFIN | Net entegre |
| --- | ---: | ---: | ---: | ---: | ---: |
| Merkez finans (vekil) | 0.0 | 0.0 | 0.0 | 3.918 | 3.918 |
| Çin | 0.197 | 1.692 | 0.0 | 0.062 | 1.889 |
| Rusya | 0.181 | 1.46 | 0.0 | 0.062 | 1.641 |
| ABD | 0.177 | 1.341 | 0.0 | 0.062 | 1.518 |
| İran | 0.121 | 1.139 | 0.0 | 0.062 | 0.983 |
| BAE | 0.068 | 0.648 | 0.0 | 0.062 | 0.716 |
| AB (Balkan vekil) | 0.064 | 0.624 | 0.0 | 0.062 | 0.688 |
| Suudi Arabistan | 0.045 | 0.482 | 0.0 | 0.062 | 0.527 |
| Türkiye | 0.509 | 0.0 | 0.0 | 0.0 | -17.191 |
| İsrail | 0.044 | 0.38 | 0.0 | 0.062 | 0.3 |
| Bulgaristan | 0.027 | 0.27 | 0.0 | 0.0 | -0.105 |
| Bosna-Hersek | 0.027 | 0.27 | 0.0 | 0.0 | 0.089 |
| Arnavutluk | 0.027 | 0.27 | 0.0 | 0.0 | 0.124 |
| Kuzey Makedonya | 0.027 | 0.27 | 0.0 | 0.0 | 0.128 |
| Fransa | 0.029 | 0.252 | 0.0 | 0.062 | 0.281 |
| Sırbistan | 0.029 | 0.248 | 0.0 | 0.0 | -0.115 |
| Mısır | 0.022 | 0.201 | 0.0 | 0.062 | -0.093 |
| Yunanistan | 0.014 | 0.101 | 0.0 | 0.062 | 0.115 |
| Kıbrıs Rum Kesimi (vekil) | 0.0 | 0.074 | 0.0 | 0.062 | -0.032 |
| Ukrayna (vekil) | 0.0 | 0.026 | 0.0 | 0.062 | -0.348 |
| Azerbaycan | 0.02 | 0.0 | 0.0 | 0.0 | -0.229 |
| Irak | 0.0 | 0.0 | 0.0 | 0.0 | -1.36 |

**TR:** refah rant **0.509**, havza kayıp **17.7**, net **-17.191**.
