# Gerçeklik çapası — empirik senkron (P3)

| Alan | Mevcut | Öneri | Fark |
| --- | ---: | ---: | ---: |
| ihracat | 261925.0 | 261,925.0 | 0.0 |
| ithalat | 344100.0 | 344,100.0 | 0.0 |
| net_ticaret | -82175.0 | -82,175.0 | 0.0 |
| yatirim_geliri_gideri | 18841.0 | 18,841.0 | 0.0 |
| dis_borc_servisi_tds | 89572.0 | 89,572.0 | 0.0 |

**Dosyaya yazıldı:** False
