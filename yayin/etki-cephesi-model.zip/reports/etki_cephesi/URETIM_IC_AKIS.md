# Üretime bağlı akış — halka düzeltmesi + rant artı değer

Taban: **C + zarar-teorisi**; üst katman: çevre halkalarının üretime bağlanması, GSYH’deki iç-talep/üretim kopukluğu vekili, rantın TR artı değeri.

## Halka toplamı (C ham delta)

- `uretim_bagimlilik`: 3.933
- `koordinasyon_kopuk`: 1.772
- `para_sizintisi`: 3.257
- `zarar_aktarimi`: 2.956
- `dis_kisit`: 5.479

**Boşalma oranı (düzeltme sonrası):** 0.6437

| | C+zarar | + üretim/iç akış |
| --- | ---: | ---: |
| TR net vekil | -13.113 | **-4.622** |
| TR boşalma | 14.622 | 9.413 |
| Rant çıkış | 1.019 | 0.811 |
| Rant TR artı | — | 0.245 |
| Merkez sızıntı | 4.464 | 3.748 |

**TR net iyileşme:** 8.491 vekil

## Sıfır noktası (TR net ≥ 0)

- Tam olgunluk vekili: **12.0 yıl**
- Tam katman sonrası net: **-4.622**
- Tahmini takvim yılı (orta yol): **2045**
- Tam olgunlukta net hâlâ negatifse sıfır yılı, aynı eğimin devamı varsayımıdır.
