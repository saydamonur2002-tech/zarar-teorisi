# Akım ölçümü — USD (2024) ↔ vekil (Senaryo B)

**Çapa:** `birincil_gelir_yatirim_gideri` = **18,841.0** mn USD → model paketi (`merkez_artı_rant` = 35.945) için 1 vekil birim ≈ 524.2 mn USD (birincil_gelir_yatirim_gideri).

## Gözlemlenebilir finans (mn USD)

| Satır | USD mn |
| --- | ---: |
| birincil_gelir_yatirim_gideri | 18,841 |
| dis_borc_servisi_tds | 89,572 |
| kamu_dis_borc_servisi_tl_cevrilmis | 16,670 |
| hazine_kefalet_koi_yeni_finansman | 9,110 |

## Mal ticareti (mn USD)

- İhracat: **261,925.0**
- İthalat: **344,100.0**
- Net: **-82,175.0**

## Model vekili → USD (aynı çapa)

| Bileşen | Vekil | USD mn (vekili) |
| --- | ---: | ---: |
| MFIN kenar | 27.997 | 14,675.0 |
| Merkez belirsiz havuz | 3.865 | 2,025.9 |
| Merkez toplam | 31.862 | 16,700.8 |
| Rant çıkış (tüm havza) | 4.083 | 2,140.2 |

## USD köprüleri (vekil birimi)

- **bop_merkez_rant:** 1 vekil ≈ **524.16** mn USD (usd = vekil × (yatırım geliri gideri / merkez+rant))
- **tum_havza_rant:** 1 vekil ≈ **1,476.64** mn USD (TCMB yatırım geliri × rant-kanal BOP pay vekili (~tahvil+petro+KÖİ))
- **mal_net_ticaret:** 1 vekil ≈ **2,045.88** mn USD (|ihracat−ithalat| ↔ turkiye_yaricevre_bosalma (TİM 2024))

TR net vekil **-41.76** → USD: BoP **21,888.9** · rant **61,664.5** · mal **85,435.9** · orta **48,674.3** mn

## Küresel pay (vekili payda)

- TR dış borç servisi / küresel TDS vekili: **%2.889**
- TR yatırım geliri gideri / küresel vekili: **%0.897**
- TR TDS / BIS cross-border claims vekili: **%0.2421**

## MFIN — havza kenarları (top 25, USD vekili)

| Havza | Vekil | USD mn |
| --- | ---: | ---: |
| Körfez bağlantı hattı | 2.02 | 1,058.8 |
| Doğu Akdeniz — KÖİ/kefalet | 2.008 | 1,052.5 |
| Karadeniz çeperi | 1.758 | 921.5 |
| Doğu Akdeniz — gaz/LNG | 1.726 | 904.7 |
| Balkan — Bulgaristan | 1.5 | 786.2 |
| Fırat — Irak merkez | 1.473 | 772.1 |
| Kuzey Afrika — Fas | 1.378 | 722.3 |
| Fırat — KRG | 1.186 | 621.7 |
| Orta Asya — Kazakistan | 1.15 | 602.8 |
| Orta Asya — Özbekistan | 1.076 | 564.0 |
| Balkan — Sırbistan | 1.004 | 526.3 |
| Kuzey Afrika — Mısır (Nil) | 0.985 | 516.3 |
| Kuzey Afrika — Cezayir | 0.823 | 431.4 |
| Balkan — Bosna-Hersek | 0.786 | 412.0 |
| Balkan — Arnavutluk | 0.769 | 403.1 |
| Kuzey Afrika — Libya | 0.768 | 402.6 |
| Kuzey Afrika — Tunus | 0.744 | 390.0 |
| Balkan — Kuzey Makedonya | 0.701 | 367.4 |
| Kafkasya — Azerbaycan | 0.66 | 345.9 |
| Orta Asya — Türkmenistan | 0.646 | 338.6 |
| Orta Asya — Kırgızistan | 0.589 | 308.7 |
| Levant — Lübnan kıyı | 0.561 | 294.1 |
| Kafkasya — Gürcistan | 0.541 | 283.6 |
| Orta Asya — Tacikistan | 0.54 | 283.0 |
| İran — Doğu/Orta Asya kapısı | 0.481 | 252.1 |

## Rant kanalları (USD vekili, top 20)

| Kanal | Rant vekil pay | USD mn |
| --- | ---: | ---: |
| refah_rant | 0.3304 | 707.1 |
| boru | 0.0724 | 155.0 |
| transit | 0.0554 | 118.6 |
| enerji | 0.0487 | 104.2 |
| montaj_ihale | 0.046 | 98.4 |
| liman | 0.0426 | 91.2 |
| ihale | 0.0396 | 84.8 |
| fon_liman | 0.0373 | 79.8 |
| savunma_tedarik | 0.0336 | 71.9 |
| petro_dolar | 0.0319 | 68.3 |
| AB_fon | 0.0306 | 65.5 |
| maden | 0.0293 | 62.7 |
| LNG | 0.0272 | 58.2 |
| transit_rant | 0.0263 | 56.3 |
| montaj | 0.0249 | 53.3 |
| tahvil | 0.0241 | 51.6 |
| petrol | 0.0236 | 50.5 |
| tahıl | 0.0216 | 46.2 |
| petrol_servis | 0.0206 | 44.1 |
| sınır_ticaret | 0.018 | 38.5 |

## Kaynaklar

- TCMB — Balance of Payments Statistics, Yearly Detailed Presentation (2006–2025): birincil gelir / yatırım geliri debit 2024 ≈ 18.841 mn $
- World Bank — DT.TDS.DECT.CD: debt service on external debt, total (TDS), Turkey 2024 ≈ 89.572 mn $
- Hazine ve Maliye — Public Debt Management Report 2025: kamu dış borç servisi 2024 = 547,9 milyar TL (nakit); kefalet/KÖİ yeni finansman 2024 ≈ 9,11 milyar $
- TİM/Ticaret — tr_dis_ticaret_2024.json (mal akışı)
