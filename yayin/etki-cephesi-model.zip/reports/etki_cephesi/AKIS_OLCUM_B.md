# Akım ölçümü — USD (2024) ↔ vekil (Senaryo B)

**Çapa:** `birincil_gelir_yatirim_gideri` = **18,841.0** mn USD → model paketi (`merkez_artı_rant` = 24.812) için 1 vekil birim ≈ 759.4 mn USD (birincil_gelir_yatirim_gideri).

## Gözlemlenebilir finans (mn USD)

| Satır | USD mn |
| --- | ---: |
| birincil_gelir_yatirim_gideri | 18,841 |
| dis_borc_servisi_tds | 89,572 |
| kamu_dis_borc_servisi_tl_cevrilmis | 16,670 |
| hazine_kefalet_koi_yeni_finansman | 9,110 |

## Mal ticareti (mn USD)

- İhracat: **261,925.0**
- İthalat: **344,100.0**
- Net: **-82,175.0**

## Model vekili → USD (aynı çapa)

| Bileşen | Vekil | USD mn (vekili) |
| --- | ---: | ---: |
| MFIN kenar | 16.867 | 12,808.0 |
| Merkez belirsiz havuz | 3.862 | 2,932.6 |
| Merkez toplam | 20.729 | 15,740.6 |
| Rant çıkış (tüm havza) | 4.083 | 3,100.4 |

## USD köprüleri (vekil birimi)

- **bop_merkez_rant:** 1 vekil ≈ **759.35** mn USD (usd = vekil × (yatırım geliri gideri / merkez+rant))
- **tum_havza_rant:** 1 vekil ≈ **1,476.64** mn USD (TCMB yatırım geliri × rant-kanal BOP pay vekili (~tahvil+petro+KÖİ))
- **mal_net_ticaret:** 1 vekil ≈ **2,045.88** mn USD (|ihracat−ithalat| ↔ turkiye_yaricevre_bosalma (TİM 2024))

TR net vekil **-41.76** → USD: BoP **31,710.5** · rant **61,664.5** · mal **85,435.9** · orta **55,075.6** mn

## Küresel pay (vekili payda)

- TR dış borç servisi / küresel TDS vekili: **%2.889**
- TR yatırım geliri gideri / küresel vekili: **%0.897**
- TR TDS / BIS cross-border claims vekili: **%0.2421**

## MFIN — havza kenarları (top 25, USD vekili)

| Havza | Vekil | USD mn |
| --- | ---: | ---: |
| Körfez bağlantı hattı | 1.217 | 924.1 |
| Doğu Akdeniz — KÖİ/kefalet | 1.21 | 918.8 |
| Karadeniz çeperi | 1.059 | 804.2 |
| Doğu Akdeniz — gaz/LNG | 1.04 | 789.7 |
| Balkan — Bulgaristan | 0.904 | 686.5 |
| Fırat — Irak merkez | 0.887 | 673.5 |
| Kuzey Afrika — Fas | 0.83 | 630.3 |
| Fırat — KRG | 0.715 | 542.9 |
| Orta Asya — Kazakistan | 0.693 | 526.2 |
| Orta Asya — Özbekistan | 0.648 | 492.1 |
| Balkan — Sırbistan | 0.605 | 459.4 |
| Kuzey Afrika — Mısır (Nil) | 0.593 | 450.3 |
| Kuzey Afrika — Cezayir | 0.496 | 376.6 |
| Balkan — Bosna-Hersek | 0.474 | 359.9 |
| Kuzey Afrika — Libya | 0.463 | 351.6 |
| Balkan — Arnavutluk | 0.463 | 351.6 |
| Kuzey Afrika — Tunus | 0.448 | 340.2 |
| Balkan — Kuzey Makedonya | 0.422 | 320.4 |
| Kafkasya — Azerbaycan | 0.398 | 302.2 |
| Orta Asya — Türkmenistan | 0.389 | 295.4 |
| Orta Asya — Kırgızistan | 0.355 | 269.6 |
| Levant — Lübnan kıyı | 0.338 | 256.7 |
| Kafkasya — Gürcistan | 0.326 | 247.5 |
| Orta Asya — Tacikistan | 0.325 | 246.8 |
| İran — Doğu/Orta Asya kapısı | 0.29 | 220.2 |

## Rant kanalları (USD vekili, top 20)

| Kanal | Rant vekil pay | USD mn |
| --- | ---: | ---: |
| refah_rant | 0.3304 | 1,024.4 |
| boru | 0.0724 | 224.5 |
| transit | 0.0554 | 171.8 |
| enerji | 0.0487 | 151.0 |
| montaj_ihale | 0.046 | 142.6 |
| liman | 0.0426 | 132.1 |
| ihale | 0.0396 | 122.8 |
| fon_liman | 0.0373 | 115.6 |
| savunma_tedarik | 0.0336 | 104.2 |
| petro_dolar | 0.0319 | 98.9 |
| AB_fon | 0.0306 | 94.9 |
| maden | 0.0293 | 90.8 |
| LNG | 0.0272 | 84.3 |
| transit_rant | 0.0263 | 81.5 |
| montaj | 0.0249 | 77.2 |
| tahvil | 0.0241 | 74.7 |
| petrol | 0.0236 | 73.2 |
| tahıl | 0.0216 | 67.0 |
| petrol_servis | 0.0206 | 63.9 |
| sınır_ticaret | 0.018 | 55.8 |

## Kaynaklar

- TCMB — Balance of Payments Statistics, Yearly Detailed Presentation (2006–2025): birincil gelir / yatırım geliri debit 2024 ≈ 18.841 mn $
- World Bank — DT.TDS.DECT.CD: debt service on external debt, total (TDS), Turkey 2024 ≈ 89.572 mn $
- Hazine ve Maliye — Public Debt Management Report 2025: kamu dış borç servisi 2024 = 547,9 milyar TL (nakit); kefalet/KÖİ yeni finansman 2024 ≈ 9,11 milyar $
- TİM/Ticaret — tr_dis_ticaret_2024.json (mal akışı)
