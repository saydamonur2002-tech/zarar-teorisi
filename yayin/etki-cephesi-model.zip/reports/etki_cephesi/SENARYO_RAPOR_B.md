# Senaryo B — ayrıntılı rapor

Üç senaryo (A, B, C) için aynı bölümler ve alanlar. Referans etiketi ayrıcalık değildir.

## 1. Tanım (senaryo parametreleri)

| Alan | Değer |
| --- | ---: |
| Ad | Araçsallaşma + donmuş enigma |
| Olasılık (kapı iskeleti, gözlem yokken tekdüze) | 0.333 |
| Etki erozyonu çarpanı | 0.58 |
| TR diplomatik esneklik | -0.06 |
| Merkez sızıntı çarpanı (geçmişten, A=1) | 1.909 |
| Merkez sızıntı çarpanı (eski, atanmış) | 1.15 |
| Bağ modu kullanım / atıl / araçsal | 0.14 / 0.32 / 0.54 |

## 2. Projeksiyon (10 yıl vekil)

| Alan | Değer |
| --- | ---: |
| TR yarıçevre boşalma | 40.166 |
| Merkez finans sızıntı Σ | 31.862 |
| MFIN kenar Σ | 27.997 |
| Tüm havza rant Σ | 4.083 |
| Merkez + rant Σ | 35.945 |
| Pasif boşluk Σ | 3.695 |
| Araçsallaşma Σ | 3.891 |
| Temsil zedesi Σ | 3.186 |
| Dış mimari Σ | 3.642 |
| İç dinamik tıkanma | 0.789 |

## 3. Akış ölçümü (USD köprüsü, mn $)

| Alan | Değer |
| --- | ---: |
| MFIN kenar | 14,675.0 |
| Belirsiz merkez | 2,025.9 |
| Merkez toplam | 16,700.8 |
| Rant toplam | 2,140.2 |

## 4. Zarar çözümü (beş adım varsayımı)

| Alan | Değer |
| --- | ---: |
| TR net ham | -41.76 |
| TR net çözüm sonrası | -30.961 |
| TR net farkı | 10.799 |
| TR boşalma ham → sonrası | 40.166 → 34.201 |

## 5. Üretim iç akışı ve finans katmanı

| Alan | Değer |
| --- | ---: |
| Üretim iç akış TR net | -24.82 |
| Üretim: sıfır yılı tahmini | 2087 |
| Finans katmanı TR net | -32.16 |
| Finans: sıfır üstü takvim yılı | — |
| Üretime bağlanma gerçekleşmesi g_u (bağ kullanımı / C) | 0.269 |
| Finans dış koşul gerçekleşmesi g_f (politika / C; < 0: ters çevrilmiş) | -0.432 |
| Finans ters çevrildi (araçsallaşma) | evet |
| Finans TR net: çevrilmemiş olsaydı (varsayım bandı üstü) | -17.48 |
| Finans etiketi | varsayim_carpanli_ham |

## 6. Stok-akış (SFC, tr TL)

| Alan | Değer |
| --- | ---: |
| Matris dönemi / kur | 2026-Q1 / 44.38 |
| H | 0 |
| F | -3.482 |
| B | 0 |
| K | 0 |
| D | 3.482 |
| Kapanış (Σ=0) | evet |
| F.4 stok 2036, baz (mr TL) | 25,339.8 |
| F.4 stok 2036, silme %20 varsayımı | 20,271.8 |

## 7. Gerçeklik kalibrasyonu

| Alan | Değer |
| --- | ---: |
| TR net son (kalibre) | -43.277 |
| GSYH % | 12.938 |
| TR net 10. yıl yolu | -37.975 |
| Yol modu (finans üretimle eşzamanlı mı) | uretimle_es_zamanli |
| Finans kalibre gerçekleşme r_f (tersse harm: tavan yok) | 0.95 |
| Gerçekleşme: zarar / üretim / finans | 0.287 / 0.237 / 0.95 |

## 8. Dış rant parasal akışı

| Alan | Değer |
| --- | ---: |
| Boşluk rantı toplam (vekil) | 14.574 |
| Refah dış toplam (vekil) | 4.084 |
| Refah TR iç toplam (vekil) | 1.864 |
| Boşluk rantı (mn $) | 78,453.9 |
| Refah dış (mn $) | 21,984.7 |

## 9. Uluslararası stok-akış

| Alan | Değer |
| --- | ---: |
| Kapanış tamam | evet |
| Havza net stok (mn $) | -20,865.1 |
| Havza kayıp brüt kenar (mn $) | 354,705.8 |
| Merkez sızıntı (mn $) | 158,199.8 |
| Kanal ikame (mn $) | 200,182.8 |

## Ülke ve aktör ayrıntısı

- `ULKE_KAYIP_B.md`, `DIS_AKTOR_B.md`, `AKIS_OLCUM_B.md`, `ZARAR_COZUM_B.md`

## Not

**Yapısal sınır (A, B, C için aynı):** üretim ve finans katmanları senaryoya özgü gerçekleşmeyle kurulur: g_u = bağ kullanımı / C'ninki (üretime bağlama kanalı), g_f = politika gerçekleşmesi / C'ninki (dış koşul: erozyon, diplomatik esneklik). Etkin çarpan = 1 − g (1 − çarpan); C'de g = 1. Çarpanların kendisi (halka düzeltmesi, MFIN, TDS, iç tutma) tüm senaryolarda ortak ve atanmıştır; g türetilmiştir ama doğrusal ölçekleme varsayımdır. Baskın modu araçsal olan senaryoda (B) finans katmanı ters çevrilir (g_f < 0, ayna simetri, güç 1: varsayım; duyarlılık finans raporunda). F.4 stok yolu (bölüm 6) beş adımın kredi itişinden gelir ve senaryodan bağımsızdır; üç sütunda aynı olması senaryo farkı değil model yapısıdır. Finans katmanı kalibre yola bağlıdır (üretimle eşzamanlı yükselir); çarpanları atanmıştır. Olasılık ölçülmemiştir (gözlem yokken tekdüze); bu rapor senaryolar arasında sıra kurmaz.
