# MFIN tutarlılık (P2)

Projeksiyon MFIN kenar: **3.918** vekil
Defter MFIN: **3.918** → yapısal stok **5.053** (düzeltme 1.135)
Kenar−defter fark: **0.0** · Σ stok **0.0** · **OK**
