# MFIN tutarlılık (P2)

Projeksiyon MFIN kenar: **3.918** vekil
Defter MFIN: **3.918** → yapısal stok **5.057** (düzeltme 1.139)
Kenar−defter fark: **0.0** · Σ stok **0.0** · **OK**
