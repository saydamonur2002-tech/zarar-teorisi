# MFIN tutarlılık (P2)

Projeksiyon MFIN kenar: **3.918** vekil
Defter MFIN: **3.918** → yapısal stok **4.25** (düzeltme 0.332)
Kenar−defter fark: **0.0** · Σ stok **0.0** · **OK**
