# MFIN tutarlılık (P2)

Projeksiyon MFIN kenar: **5.662** vekil
Defter MFIN: **5.662** → yapısal stok **6.111** (düzeltme 0.449)
Kenar−defter fark: **0.0** · Σ stok **0.0** · **OK**
