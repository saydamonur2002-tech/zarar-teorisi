# Artı değer — dominion bağı + bölünmüş çeper

**Ölçüm:** `arti_deger_havza_dominion_10y` | **Kanıt:** C-D
**Konum tezi:** `data/etki_cephesi/KAYNAK_KONUM_ORTA_DOGU.md`

Bağ modu: kullanım / atıl / araçsallaşma. Net = ikame − sok − dış bağlanma − rant − temsil zedesi + kullanım telafisi. Dış sonuç TR merkezli değil; dis_hegemon_acmaz vekil.

Atıl bağ → pasif boşluk. Araçsallaşma → dar çıkar ağı + meşruiyet/temsil zedesi. Kullanım → kısmi telafi (katmanlı oyun inşası vekili).

*Bağ modu: kullanım / atıl / araçsallaşma (maks-min değil). Dış aktörler TR'yi merkez sanmaz — göreceli fayda/zarar.*

## Senaryo özeti (aynı alanlar)

| Senaryo | TR boşalma | Merkez+rant Σ | MFIN kenar | Rant Σ |
| --- | ---: | ---: | ---: | ---: |
| A | 24.952 | 15.117 | 9.192 | 1.984 |
| B | 40.166 | 24.812 | 16.867 | 4.083 |
| C | 17.172 | 9.024 | 5.662 | 1.12 |

Her senaryo için aynı ayrıntı: `SENARYO_RAPOR_{A,B,C}.md`, `SENARYO_KARSILASTIRMA.md`.

## Senaryo A: Atıl bağ — pasif tutum

Bağ duruyor, iktisadi-sosyopolitik ağırlık işletilmiyor; boşluk dolduruluyor.

**Bağ modu (kullanım/atıl/araçsal):** 0.22/0.5/0.28 | **Çeper / gövde açığı:** 3.288 / 2.986
**Pasif boşluk:** 5.566 | **Araçsallaşma:** 1.946 | **Temsil zedesi:** 2.688 | **Dış mimari:** 3.608
**İç dinamik tıkanma:** 0.642 | **Dış hegemon açmaz (vekil):** 8.205
**TR boşalma:** 24.952 | **Rant (OD+Levant+Körfez+Kuzey Af. alt küme):** 1.044 | **Tüm havza rant Σ:** 1.984
**Dış bağlanma (alt küme / tüm Σ):** 6.848 / 13.062 | **Merkez sızıntı + rant Σ:** 15.117
**MFIN kenar / belirsiz havuz / evren:** 9.192 / 3.941 / 36 ülke × 0.1095

### Alt havza tablosu

| Bölge | Çeper | Atıl | Araçsal | Temsil z. | Dış mimari | Net |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| İran — Irak/Suriye hattı | iran | 0.107 | 0.037 | 0.05 | 0.069 | -0.102 |
| İran — Doğu/Orta Asya kapısı | iran | 0.094 | 0.033 | 0.047 | 0.061 | -0.156 |
| İran — Körfez/güney | iran | 0.119 | 0.042 | 0.056 | 0.077 | -0.159 |
| Kuzey Afrika — Tunus | kuzey_afrika | 0.089 | 0.031 | 0.035 | 0.058 | -0.238 |
| Balkan — Kuzey Makedonya | karadeniz | 0.086 | 0.03 | 0.034 | 0.056 | -0.252 |
| Balkan — Arnavutluk | karadeniz | 0.095 | 0.033 | 0.037 | 0.061 | -0.255 |
| Orta Asya — Tacikistan | ortasya | 0.063 | 0.022 | 0.031 | 0.041 | -0.258 |
| Orta Asya — Kırgızistan | ortasya | 0.075 | 0.026 | 0.037 | 0.048 | -0.273 |
| Balkan — Bosna-Hersek | karadeniz | 0.107 | 0.037 | 0.042 | 0.069 | -0.306 |
| Kafkasya — Ermenistan | kafkasya | 0.114 | 0.04 | 0.057 | 0.074 | -0.31 |
| Kuzey Afrika — Mısır (Nil) | kuzey_afrika | 0.248 | 0.087 | 0.117 | 0.161 | -0.331 |
| Balkan — Sırbistan | karadeniz | 0.157 | 0.055 | 0.062 | 0.102 | -0.334 |
| Orta Asya — Türkmenistan | ortasya | 0.103 | 0.036 | 0.051 | 0.067 | -0.343 |
| Kafkasya — Gürcistan | kafkasya | 0.148 | 0.052 | 0.074 | 0.096 | -0.371 |
| Kafkasya — Azerbaycan | kafkasya | 0.221 | 0.077 | 0.11 | 0.143 | -0.384 |
| Kuzey Afrika — Cezayir | kuzey_afrika | 0.138 | 0.048 | 0.061 | 0.089 | -0.413 |
| Orta Asya — Özbekistan | ortasya | 0.148 | 0.052 | 0.074 | 0.096 | -0.427 |
| Orta Asya — Kazakistan | ortasya | 0.192 | 0.067 | 0.095 | 0.124 | -0.461 |
| Doğu Akdeniz — KÖİ/kefalet | levant | 0.18 | 0.063 | 0.08 | 0.117 | -0.464 |
| Kuzey Afrika — Libya | kuzey_afrika | 0.199 | 0.07 | 0.089 | 0.129 | -0.559 |
| Kuzey Afrika — Fas | kuzey_afrika | 0.177 | 0.062 | 0.088 | 0.115 | -0.569 |
| Doğu Akdeniz — gaz/LNG | levant | 0.227 | 0.079 | 0.101 | 0.147 | -0.58 |
| Balkan — Bulgaristan | karadeniz | 0.219 | 0.077 | 0.086 | 0.142 | -0.584 |
| Afrika Boynu | genis | 0.08 | 0.028 | 0.048 | 0.052 | -0.652 |
| Levant — Suriye tampon | levant | 0.24 | 0.084 | 0.144 | 0.156 | -0.776 |
| Levant — Lübnan kıyı | levant | 0.181 | 0.063 | 0.109 | 0.117 | -0.778 |
| Fırat — KRG | korfez | 0.314 | 0.11 | 0.156 | 0.204 | -0.899 |
| Fırat — Irak merkez | korfez | 0.405 | 0.142 | 0.201 | 0.263 | -1.141 |
| Karadeniz çeperi | karadeniz | 0.491 | 0.171 | 0.243 | 0.318 | -1.227 |
| Körfez bağlantı hattı | korfez | 0.549 | 0.192 | 0.273 | 0.356 | -1.645 |

### Makro özet (tüm bölgeler, aynı kapsam)

| Makro | Havza | Net Σ | Boşalma Σ | Rant Σ | Dış bağ. Σ | Pasif Σ |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Levant | 2 | -1.554 | 1.065 | 0.073 | 0.824 | 0.421 |
| Orta Doğu (Fırat / Doğu Akdeniz) | 4 | -3.084 | 5.036 | 0.424 | 2.614 | 1.126 |
| Körfez | 1 | -1.645 | 1.869 | 0.196 | 1.095 | 0.549 |
| Kuzey Afrika | 5 | -2.11 | 4.371 | 0.351 | 2.315 | 0.851 |
| Karadeniz | 1 | -1.227 | 1.832 | 0.133 | 0.984 | 0.491 |
| Kafkasya | 3 | -1.065 | 1.927 | 0.162 | 1.19 | 0.483 |
| Balkan | 5 | -1.731 | 3.481 | 0.226 | 1.383 | 0.664 |
| Orta Asya | 5 | -1.762 | 3.456 | 0.262 | 1.655 | 0.581 |
| İran (yaricevre vekili) | 3 | -0.417 | 1.365 | 0.119 | 0.66 | 0.32 |
| Afrika Boynu / geniş güney | 1 | -0.652 | 0.55 | 0.038 | 0.342 | 0.08 |

### Levant — havza detayı

- **Levant — Suriye tampon:** net -0.776 | boşalma 0.49 | ikame 0.053 | sok 0.214 | dış bağ. 0.422 | rant 0.034 (güvenlik_rant, sınır_ticaret, refah_rant)
- **Levant — Lübnan kıyı:** net -0.778 | boşalma 0.575 | ikame 0.036 | sok 0.259 | dış bağ. 0.402 | rant 0.039 (bankacılık_rant, liman, refah_rant)

### Orta Doğu (Fırat / Doğu Akdeniz) — havza detayı

- **Doğu Akdeniz — KÖİ/kefalet:** net -0.464 | boşalma 1.12 | ikame 0.15 | sok 0.082 | dış bağ. 0.387 | rant 0.08 (KÖİ, Londra_hukuku, tahvil, refah_rant)
- **Doğu Akdeniz — gaz/LNG:** net -0.58 | boşalma 1.153 | ikame 0.194 | sok 0.074 | dış bağ. 0.51 | rant 0.102 (LNG, hatt_kefalet, refah_rant)
- **Fırat — KRG:** net -0.899 | boşalma 1.32 | ikame 0.346 | sok 0.207 | dış bağ. 0.778 | rant 0.116 (petrol, transit, refah_rant)
- **Fırat — Irak merkez:** net -1.141 | boşalma 1.443 | ikame 0.324 | sok 0.195 | dış bağ. 0.939 | rant 0.126 (petrol_servis, ihale, refah_rant)

### Körfez — havza detayı

- **Körfez bağlantı hattı:** net -1.645 | boşalma 1.869 | ikame 0.143 | sok 0.21 | dış bağ. 1.095 | rant 0.196 (petro_dolar, fon_liman, refah_rant)

### Kuzey Afrika — havza detayı

- **Kuzey Afrika — Tunus:** net -0.238 | boşalma 0.566 | ikame 0.11 | sok 0.04 | dış bağ. 0.239 | rant 0.042 (montaj, turizm_rant, refah_rant)
- **Kuzey Afrika — Mısır (Nil):** net -0.331 | boşalma 1.027 | ikame 0.574 | sok 0.084 | dış bağ. 0.621 | rant 0.096 (Süveyş, enerji_hattı, refah_rant)
- **Kuzey Afrika — Cezayir:** net -0.413 | boşalma 0.765 | ikame 0.142 | sok 0.077 | dış bağ. 0.369 | rant 0.057 (enerji, LNG, ihale, refah_rant)
- **Kuzey Afrika — Libya:** net -0.559 | boşalma 0.916 | ikame 0.389 | sok 0.126 | dış bağ. 0.665 | rant 0.079 (enerji, müteahhit, refah_rant)
- **Kuzey Afrika — Fas:** net -0.569 | boşalma 1.097 | ikame 0.125 | sok 0.122 | dış bağ. 0.421 | rant 0.077 (montaj, liman, güneş_KEF, refah_rant)

### Karadeniz — havza detayı

- **Karadeniz çeperi:** net -1.227 | boşalma 1.832 | ikame 0.348 | sok 0.226 | dış bağ. 0.984 | rant 0.133 (tahıl, savunma_tedarik, refah_rant)

### Kafkasya — havza detayı

- **Kafkasya — Ermenistan:** net -0.31 | boşalma 0.478 | ikame 0.115 | sok 0.054 | dış bağ. 0.279 | rant 0.037 (transit_rant, güvenlik_hattı, refah_rant)
- **Kafkasya — Gürcistan:** net -0.371 | boşalma 0.602 | ikame 0.195 | sok 0.061 | dış bağ. 0.386 | rant 0.049 (transit_rant, liman, refah_rant)
- **Kafkasya — Azerbaycan:** net -0.384 | boşalma 0.847 | ikame 0.425 | sok 0.105 | dış bağ. 0.525 | rant 0.076 (transit_rant, enerji_koridor, refah_rant)

### Balkan — havza detayı

- **Balkan — Kuzey Makedonya:** net -0.252 | boşalma 0.499 | ikame 0.048 | sok 0.032 | dış bağ. 0.204 | rant 0.035 (montaj_ihale, koridor, refah_rant)
- **Balkan — Arnavutluk:** net -0.255 | boşalma 0.535 | ikame 0.063 | sok 0.032 | dış bağ. 0.217 | rant 0.038 (montaj_ihale, liman, refah_rant)
- **Balkan — Bosna-Hersek:** net -0.306 | boşalma 0.571 | ikame 0.043 | sok 0.037 | dış bağ. 0.235 | rant 0.039 (montaj_ihale, AB_fon, sınır_ticaret, refah_rant)
- **Balkan — Sırbistan:** net -0.334 | boşalma 0.762 | ikame 0.133 | sok 0.049 | dış bağ. 0.306 | rant 0.056 (montaj_ihale, AB_fon, refah_rant)
- **Balkan — Bulgaristan:** net -0.584 | boşalma 1.114 | ikame 0.037 | sok 0.067 | dış bağ. 0.421 | rant 0.058 (montaj_ihale, AB_fon, enerji_geçiş, refah_rant)

### Orta Asya — havza detayı

- **Orta Asya — Tacikistan:** net -0.258 | boşalma 0.441 | ikame 0.05 | sok 0.049 | dış bağ. 0.204 | rant 0.031 (hidro, transit, refah_rant)
- **Orta Asya — Kırgızistan:** net -0.273 | boşalma 0.505 | ikame 0.074 | sok 0.053 | dış bağ. 0.228 | rant 0.036 (maden, transit, refah_rant)
- **Orta Asya — Türkmenistan:** net -0.343 | boşalma 0.6 | ikame 0.102 | sok 0.067 | dış bağ. 0.291 | rant 0.044 (gaz, boru, korfez_kopru, refah_rant)
- **Orta Asya — Özbekistan:** net -0.427 | boşalma 0.899 | ikame 0.221 | sok 0.09 | dış bağ. 0.429 | rant 0.069 (maden, pamuk, boru, refah_rant)
- **Orta Asya — Kazakistan:** net -0.461 | boşalma 1.011 | ikame 0.318 | sok 0.113 | dış bağ. 0.503 | rant 0.082 (maden, boru, hub_transit, refah_rant)

### İran (yaricevre vekili) — havza detayı

- **İran — Irak/Suriye hattı:** net -0.102 | boşalma 0.425 | ikame 0.209 | sok 0.031 | dış bağ. 0.196 | rant 0.038 (sınır_ticaret, enerji_swaps, refah_rant)
- **İran — Doğu/Orta Asya kapısı:** net -0.156 | boşalma 0.472 | ikame 0.212 | sok 0.047 | dış bağ. 0.241 | rant 0.041 (transit, maden, koridor, refah_rant)
- **İran — Körfez/güney:** net -0.159 | boşalma 0.468 | ikame 0.187 | sok 0.031 | dış bağ. 0.223 | rant 0.04 (petrol, liman, gaz, refah_rant)

### Afrika Boynu / geniş güney — havza detayı

- **Afrika Boynu:** net -0.652 | boşalma 0.55 | ikame 0.046 | sok 0.278 | dış bağ. 0.342 | rant 0.038 (liman, askeri_üs, refah_rant)

### Rant kanalları (tüm havzalar)

- **İran — Irak/Suriye hattı** (iran): sınır_ticaret, enerji_swaps, refah_rant → 0.038
- **İran — Doğu/Orta Asya kapısı** (iran): transit, maden, koridor, refah_rant → 0.041
- **İran — Körfez/güney** (iran): petrol, liman, gaz, refah_rant → 0.04
- **Kuzey Afrika — Tunus** (kuzey_afrika): montaj, turizm_rant, refah_rant → 0.042
- **Balkan — Kuzey Makedonya** (balkan): montaj_ihale, koridor, refah_rant → 0.035
- **Balkan — Arnavutluk** (balkan): montaj_ihale, liman, refah_rant → 0.038
- **Orta Asya — Tacikistan** (ortasya): hidro, transit, refah_rant → 0.031
- **Orta Asya — Kırgızistan** (ortasya): maden, transit, refah_rant → 0.036
- **Balkan — Bosna-Hersek** (balkan): montaj_ihale, AB_fon, sınır_ticaret, refah_rant → 0.039
- **Kafkasya — Ermenistan** (kafkasya): transit_rant, güvenlik_hattı, refah_rant → 0.037
- **Kuzey Afrika — Mısır (Nil)** (kuzey_afrika): Süveyş, enerji_hattı, refah_rant → 0.096
- **Balkan — Sırbistan** (balkan): montaj_ihale, AB_fon, refah_rant → 0.056
- **Orta Asya — Türkmenistan** (ortasya): gaz, boru, korfez_kopru, refah_rant → 0.044
- **Kafkasya — Gürcistan** (kafkasya): transit_rant, liman, refah_rant → 0.049
- **Kafkasya — Azerbaycan** (kafkasya): transit_rant, enerji_koridor, refah_rant → 0.076
- **Kuzey Afrika — Cezayir** (kuzey_afrika): enerji, LNG, ihale, refah_rant → 0.057
- **Orta Asya — Özbekistan** (ortasya): maden, pamuk, boru, refah_rant → 0.069
- **Orta Asya — Kazakistan** (ortasya): maden, boru, hub_transit, refah_rant → 0.082
- **Doğu Akdeniz — KÖİ/kefalet** (orta_dogu): KÖİ, Londra_hukuku, tahvil, refah_rant → 0.08
- **Kuzey Afrika — Libya** (kuzey_afrika): enerji, müteahhit, refah_rant → 0.079
- **Kuzey Afrika — Fas** (kuzey_afrika): montaj, liman, güneş_KEF, refah_rant → 0.077
- **Doğu Akdeniz — gaz/LNG** (orta_dogu): LNG, hatt_kefalet, refah_rant → 0.102
- **Balkan — Bulgaristan** (balkan): montaj_ihale, AB_fon, enerji_geçiş, refah_rant → 0.058
- **Afrika Boynu** (afrika): liman, askeri_üs, refah_rant → 0.038
- **Levant — Suriye tampon** (levant): güvenlik_rant, sınır_ticaret, refah_rant → 0.034
- **Levant — Lübnan kıyı** (levant): bankacılık_rant, liman, refah_rant → 0.039
- **Fırat — KRG** (orta_dogu): petrol, transit, refah_rant → 0.116
- **Fırat — Irak merkez** (orta_dogu): petrol_servis, ihale, refah_rant → 0.126
- **Karadeniz çeperi** (karadeniz): tahıl, savunma_tedarik, refah_rant → 0.133
- **Körfez bağlantı hattı** (korfez): petro_dolar, fon_liman, refah_rant → 0.196

### Akış şeması (≥ 0,18)

```mermaid
flowchart LR
  korfez["Körfez bağlantı hattı"]
  MFIN["Merkez finans"]
  korfez -->|0.689 sız| MFIN
  karadeni["Karadeniz çeperi"]
  karadeni -->|0.599 sız| MFIN
  dogu_akd["Doğu Akdeniz — KÖİ/kefal"]
  dogu_akd -->|0.545 sız| MFIN
  balkan_b["Balkan — Bulgaristan"]
  balkan_b -->|0.509 sız| MFIN
  irak_bag["Fırat — Irak merkez"]
  irak_bag -->|0.502 sız| MFIN
  dogu_akd -->|0.468 sız| MFIN
  kuzeyafr["Kuzey Afrika — Fas"]
  kuzeyafr -->|0.467 sız| MFIN
  irak_krg["Fırat — KRG"]
  irak_krg -->|0.404 sız| MFIN
  ortasya_["Orta Asya — Kazakistan"]
  ortasya_ -->|0.39 sız| MFIN
  ortasya_ -->|0.364 sız| MFIN
  balkan_r["Balkan — Sırbistan"]
  balkan_r -->|0.341 sız| MFIN
  misir["Kuzey Afrika — Mısır (Ni"]
  misir -->|0.335 sız| MFIN
  kuzeyafr -->|0.279 sız| MFIN
  balkan_b -->|0.267 sız| MFIN
  libya["Kuzey Afrika — Libya"]
  libya -->|0.261 sız| MFIN
  balkan_a["Balkan — Arnavutluk"]
  balkan_a -->|0.26 sız| MFIN
  kuzeyafr -->|0.252 sız| MFIN
  balkan_m["Balkan — Kuzey Makedonya"]
  balkan_m -->|0.238 sız| MFIN
  kafkasya["Kafkasya — Azerbaycan"]
  kafkasya -->|0.225 sız| MFIN
  ortasya_ -->|0.219 sız| MFIN
  ortasya_ -->|0.199 sız| MFIN
  kafkasya -->|0.184 sız| MFIN
  ortasya_ -->|0.183 sız| MFIN
```

### Ülke bazlı kayıp / fayda (10 yıl vekil)

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil | Durum |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| Türkiye | 25.822 | -25.822 | 0.343 | 0.12 | 0.161 | kayip |
| Irak | 2.04 | -2.04 | 0.719 | 0.252 | 0.357 | kayip |
| Körfez (vekil) | 1.645 | -1.645 | 0.549 | 0.192 | 0.273 | kayip |
| Lübnan | 0.778 | -0.778 | 0.181 | 0.063 | 0.109 | kayip |
| Suriye | 0.776 | -0.776 | 0.24 | 0.084 | 0.144 | kayip |
| Somali | 0.652 | -0.652 | 0.08 | 0.028 | 0.048 | kayip |
| Bulgaristan | 0.584 | -0.584 | 0.219 | 0.077 | 0.086 | kayip |
| Sırbistan | 0.579 | -0.579 | 0.255 | 0.089 | 0.111 | kayip |
| Fas | 0.569 | -0.569 | 0.177 | 0.062 | 0.088 | kayip |
| Libya | 0.559 | -0.559 | 0.199 | 0.07 | 0.089 | kayip |
| Ukrayna/Karadeniz (vekil) | 0.552 | -0.552 | 0.221 | 0.077 | 0.109 | kayip |
| Mısır | 0.505 | -0.505 | 0.316 | 0.111 | 0.147 | kayip |
| Kazakistan | 0.461 | -0.461 | 0.192 | 0.067 | 0.095 | kayip |
| Özbekistan | 0.427 | -0.427 | 0.148 | 0.052 | 0.074 | kayip |
| İran | 0.417 | -0.417 | 0.32 | 0.112 | 0.153 | kayip |
| Cezayir | 0.413 | -0.413 | 0.138 | 0.048 | 0.061 | kayip |
| Azerbaycan | 0.384 | -0.384 | 0.221 | 0.077 | 0.11 | kayip |
| Gürcistan | 0.371 | -0.371 | 0.148 | 0.052 | 0.074 | kayip |
| Türkmenistan | 0.343 | -0.343 | 0.103 | 0.036 | 0.051 | kayip |
| Ermenistan | 0.31 | -0.31 | 0.114 | 0.04 | 0.057 | kayip |
| Bosna-Hersek | 0.306 | -0.306 | 0.107 | 0.037 | 0.042 | kayip |
| Kırgızistan | 0.273 | -0.273 | 0.075 | 0.026 | 0.037 | kayip |
| Tacikistan | 0.258 | -0.258 | 0.063 | 0.022 | 0.031 | kayip |
| Arnavutluk | 0.255 | -0.255 | 0.095 | 0.033 | 0.037 | kayip |
| Kuzey Makedonya | 0.252 | -0.252 | 0.086 | 0.03 | 0.034 | kayip |
| Tunus | 0.238 | -0.238 | 0.089 | 0.031 | 0.035 | kayip |
| İsrail (vekil) | 0.232 | -0.232 | 0.091 | 0.032 | 0.04 | kayip |
| Kıbrıs (vekil) | 0.197 | -0.197 | 0.077 | 0.027 | 0.034 | kayip |

### Dış aktör kazanç (TR boşalması + ikame + merkez; vekil)

| Aktör | Kazanç Σ | Kanal | Matris | İkame | Merkez sız. | Belirsiz M* |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Merkez finans (vekil) | 9.192 | 0.0 | 0.0 | 0.0 | 9.192 | 0.0 |
| Çin | 7.475 | 4.008 | 2.413 | 1.054 | 0.0 | 0.1095 |
| Rusya | 7.108 | 3.719 | 2.108 | 1.281 | 0.0 | 0.1095 |
| AB (Balkan vekil) | 6.728 | 3.372 | 2.783 | 0.573 | 0.0 | 0.1095 |
| ABD | 4.535 | 1.928 | 2.009 | 0.598 | 0.0 | 0.1095 |
| İran | 3.566 | 1.505 | 1.689 | 0.372 | 0.0 | 0.1095 |
| BAE | 1.878 | 0.753 | 0.925 | 0.2 | 0.0 | 0.1095 |
| İsrail | 1.656 | 0.771 | 0.619 | 0.266 | 0.0 | 0.1095 |
| Suudi Arabistan | 1.627 | 0.668 | 0.701 | 0.258 | 0.0 | 0.1095 |
| Fransa | 1.124 | 0.651 | 0.374 | 0.099 | 0.0 | 0.1095 |
| Mısır | 1.005 | 0.528 | 0.318 | 0.159 | 0.0 | 0.1095 |
| Yunanistan | 0.673 | 0.421 | 0.173 | 0.079 | 0.0 | 0.1095 |
| Kıbrıs Rum Kesimi (vekil) | 0.127 | 0.0 | 0.127 | 0.0 | 0.0 | 0.1095 |
| Ukrayna (vekil) | 0.037 | 0.0 | 0.037 | 0.0 | 0.0 | 0.1095 |

### Aktör birleşik (havza kaybı vs dış kazanç vekili)

| Aktör | Dış kazanç | Havza kayıp | Belirsiz M* | Net birleşik | Durum |
| --- | ---: | ---: | ---: | ---: | --- |
| Merkez finans (vekil) | 9.192 | 0.0 | 0.0 | 9.192 | dis_kazanc |
| Çin | 7.475 | 0.0 | 0.11 | 7.475 | dis_kazanc |
| Rusya | 7.108 | 0.0 | 0.11 | 7.108 | dis_kazanc |
| AB (Balkan vekil) | 6.728 | 0.0 | 0.11 | 6.728 | dis_kazanc |
| ABD | 4.535 | 0.0 | 0.11 | 4.535 | dis_kazanc |
| İran | 3.566 | 0.417 | 0.11 | 3.149 | dis_kazanc |
| BAE | 1.878 | 0.0 | 0.11 | 1.878 | dis_kazanc |
| İsrail | 1.656 | 0.232 | 0.11 | 1.424 | dis_kazanc |
| Suudi Arabistan | 1.627 | 0.0 | 0.11 | 1.627 | dis_kazanc |
| Fransa | 1.124 | 0.0 | 0.11 | 1.124 | dis_kazanc |
| Mısır | 1.005 | 0.505 | 0.11 | 0.5 | dis_kazanc |
| Yunanistan | 0.673 | 0.0 | 0.11 | 0.673 | dis_kazanc |
| Kıbrıs Rum Kesimi (vekil) | 0.127 | 0.197 | 0.11 | -0.07 | havza_kayip |
| Ukrayna (vekil) | 0.037 | 0.552 | 0.11 | -0.515 | havza_kayip |
| Türkiye | 0.0 | 25.822 | 0.0 | -25.822 | havza_kayip |
| Irak | 0.0 | 2.04 | 0.11 | -2.04 | havza_kayip |
| Körfez (vekil) | 0.0 | 1.645 | 0.11 | -1.645 | havza_kayip |
| Lübnan | 0.0 | 0.778 | 0.11 | -0.778 | havza_kayip |
| Suriye | 0.0 | 0.776 | 0.11 | -0.776 | havza_kayip |
| Somali | 0.0 | 0.652 | 0.11 | -0.652 | havza_kayip |
| Bulgaristan | 0.0 | 0.584 | 0.11 | -0.584 | havza_kayip |
| Sırbistan | 0.0 | 0.579 | 0.11 | -0.579 | havza_kayip |
| Fas | 0.0 | 0.569 | 0.11 | -0.569 | havza_kayip |
| Libya | 0.0 | 0.559 | 0.11 | -0.559 | havza_kayip |
| Kazakistan | 0.0 | 0.461 | 0.11 | -0.461 | havza_kayip |

## Senaryo B: Araçsallaşma + donmuş enigma

Bağ dar çıkar ağına dönüşür; dış hegemon mimarisi; Suriye tipi donukluk.

**Bağ modu (kullanım/atıl/araçsal):** 0.14/0.32/0.54 | **Çeper / gövde açığı:** 3.288 / 3.094
**Pasif boşluk:** 3.695 | **Araçsallaşma:** 3.891 | **Temsil zedesi:** 3.186 | **Dış mimari:** 3.642
**İç dinamik tıkanma:** 0.789 | **Dış hegemon açmaz (vekil):** 10.897
**TR boşalma:** 40.166 | **Rant (OD+Levant+Körfez+Kuzey Af. alt küme):** 2.21 | **Tüm havza rant Σ:** 4.083
**Dış bağlanma (alt küme / tüm Σ):** 12.639 / 23.438 | **Merkez sızıntı + rant Σ:** 24.812
**MFIN kenar / belirsiz havuz / evren:** 16.867 / 3.862 / 36 ülke × 0.1073

### Alt havza tablosu

| Bölge | Çeper | Atıl | Araçsal | Temsil z. | Dış mimari | Net |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| İran — Irak/Suriye hattı | iran | 0.068 | 0.072 | 0.057 | 0.067 | -0.153 |
| İran — Körfez/güney | iran | 0.076 | 0.08 | 0.064 | 0.075 | -0.251 |
| İran — Doğu/Orta Asya kapısı | iran | 0.06 | 0.063 | 0.053 | 0.059 | -0.27 |
| Kuzey Afrika — Tunus | kuzey_afrika | 0.057 | 0.06 | 0.04 | 0.056 | -0.404 |
| Balkan — Kuzey Makedonya | karadeniz | 0.055 | 0.058 | 0.038 | 0.054 | -0.409 |
| Balkan — Arnavutluk | karadeniz | 0.061 | 0.064 | 0.042 | 0.06 | -0.416 |
| Orta Asya — Tacikistan | ortasya | 0.04 | 0.042 | 0.035 | 0.039 | -0.433 |
| Orta Asya — Kırgızistan | ortasya | 0.048 | 0.051 | 0.043 | 0.048 | -0.462 |
| Balkan — Bosna-Hersek | karadeniz | 0.068 | 0.072 | 0.048 | 0.067 | -0.49 |
| Kafkasya — Ermenistan | kafkasya | 0.073 | 0.077 | 0.065 | 0.072 | -0.503 |
| Kuzey Afrika — Mısır (Nil) | kuzey_afrika | 0.159 | 0.167 | 0.133 | 0.156 | -0.527 |
| Balkan — Sırbistan | karadeniz | 0.101 | 0.106 | 0.07 | 0.099 | -0.528 |
| Orta Asya — Türkmenistan | ortasya | 0.066 | 0.069 | 0.058 | 0.065 | -0.57 |
| Kafkasya — Gürcistan | kafkasya | 0.095 | 0.1 | 0.084 | 0.094 | -0.615 |
| Kafkasya — Azerbaycan | kafkasya | 0.142 | 0.149 | 0.125 | 0.14 | -0.641 |
| Kuzey Afrika — Cezayir | kuzey_afrika | 0.088 | 0.093 | 0.07 | 0.087 | -0.688 |
| Orta Asya — Özbekistan | ortasya | 0.095 | 0.1 | 0.084 | 0.094 | -0.724 |
| Orta Asya — Kazakistan | ortasya | 0.123 | 0.13 | 0.109 | 0.121 | -0.775 |
| Kuzey Afrika — Fas | kuzey_afrika | 0.114 | 0.12 | 0.101 | 0.112 | -0.909 |
| Balkan — Bulgaristan | karadeniz | 0.14 | 0.148 | 0.098 | 0.138 | -0.914 |
| Kuzey Afrika — Libya | kuzey_afrika | 0.128 | 0.134 | 0.101 | 0.126 | -0.95 |
| Doğu Akdeniz — KÖİ/kefalet | levant | 0.144 | 0.151 | 0.114 | 0.142 | -0.962 |
| Afrika Boynu | genis | 0.051 | 0.054 | 0.055 | 0.05 | -1.079 |
| Doğu Akdeniz — gaz/LNG | levant | 0.181 | 0.191 | 0.143 | 0.179 | -1.223 |
| Fırat — KRG | korfez | 0.201 | 0.211 | 0.177 | 0.198 | -1.469 |
| Levant — Suriye tampon | levant | 0.192 | 0.203 | 0.206 | 0.19 | -1.473 |
| Levant — Lübnan kıyı | levant | 0.145 | 0.152 | 0.155 | 0.143 | -1.52 |
| Fırat — Irak merkez | korfez | 0.259 | 0.273 | 0.229 | 0.255 | -1.838 |
| Karadeniz çeperi | karadeniz | 0.314 | 0.331 | 0.278 | 0.31 | -1.925 |
| Körfez bağlantı hattı | korfez | 0.351 | 0.37 | 0.311 | 0.346 | -2.606 |

### Makro özet (tüm bölgeler, aynı kapsam)

| Makro | Havza | Net Σ | Boşalma Σ | Rant Σ | Dış bağ. Σ | Pasif Σ |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Levant | 2 | -2.993 | 2.073 | 0.182 | 1.75 | 0.337 |
| Orta Doğu (Fırat / Doğu Akdeniz) | 4 | -5.492 | 8.729 | 0.928 | 4.894 | 0.785 |
| Körfez | 1 | -2.606 | 2.911 | 0.391 | 1.869 | 0.351 |
| Kuzey Afrika | 5 | -3.478 | 6.808 | 0.709 | 4.126 | 0.546 |
| Karadeniz | 1 | -1.925 | 2.853 | 0.264 | 1.68 | 0.314 |
| Kafkasya | 3 | -1.759 | 3.001 | 0.322 | 2.071 | 0.31 |
| Balkan | 5 | -2.757 | 5.423 | 0.451 | 2.379 | 0.425 |
| Orta Asya | 5 | -2.964 | 5.385 | 0.523 | 2.919 | 0.372 |
| İran (yaricevre vekili) | 3 | -0.674 | 2.127 | 0.238 | 1.131 | 0.204 |
| Afrika Boynu / geniş güney | 1 | -1.079 | 0.856 | 0.075 | 0.619 | 0.051 |

### Levant — havza detayı

- **Levant — Suriye tampon:** net -1.473 | boşalma 0.954 | ikame 0.093 | sok 0.407 | dış bağ. 0.883 | rant 0.085 (güvenlik_rant, sınır_ticaret, refah_rant)
- **Levant — Lübnan kıyı:** net -1.52 | boşalma 1.119 | ikame 0.069 | sok 0.497 | dış bağ. 0.867 | rant 0.097 (bankacılık_rant, liman, refah_rant)

### Orta Doğu (Fırat / Doğu Akdeniz) — havza detayı

- **Doğu Akdeniz — KÖİ/kefalet:** net -0.962 | boşalma 2.18 | ikame 0.256 | sok 0.158 | dış bağ. 0.823 | rant 0.197 (KÖİ, Londra_hukuku, tahvil, refah_rant)
- **Doğu Akdeniz — gaz/LNG:** net -1.223 | boşalma 2.246 | ikame 0.316 | sok 0.142 | dış bağ. 1.085 | rant 0.249 (LNG, hatt_kefalet, refah_rant)
- **Fırat — KRG:** net -1.469 | boşalma 2.055 | ikame 0.534 | sok 0.319 | dış bağ. 1.356 | rant 0.23 (petrol, transit, refah_rant)
- **Fırat — Irak merkez:** net -1.838 | boşalma 2.248 | ikame 0.508 | sok 0.299 | dış bağ. 1.63 | rant 0.252 (petrol_servis, ihale, refah_rant)

### Körfez — havza detayı

- **Körfez bağlantı hattı:** net -2.606 | boşalma 2.911 | ikame 0.22 | sok 0.323 | dış bağ. 1.869 | rant 0.391 (petro_dolar, fon_liman, refah_rant)

### Kuzey Afrika — havza detayı

- **Kuzey Afrika — Tunus:** net -0.404 | boşalma 0.881 | ikame 0.169 | sok 0.062 | dış bağ. 0.42 | rant 0.084 (montaj, turizm_rant, refah_rant)
- **Kuzey Afrika — Mısır (Nil):** net -0.527 | boşalma 1.6 | ikame 0.967 | sok 0.129 | dış bağ. 1.109 | rant 0.195 (Süveyş, enerji_hattı, refah_rant)
- **Kuzey Afrika — Cezayir:** net -0.688 | boşalma 1.191 | ikame 0.22 | sok 0.119 | dış bağ. 0.648 | rant 0.113 (enerji, LNG, ihale, refah_rant)
- **Kuzey Afrika — Fas:** net -0.909 | boşalma 1.709 | ikame 0.218 | sok 0.189 | dış bağ. 0.74 | rant 0.156 (montaj, liman, güneş_KEF, refah_rant)
- **Kuzey Afrika — Libya:** net -0.95 | boşalma 1.427 | ikame 0.655 | sok 0.194 | dış bağ. 1.209 | rant 0.161 (enerji, müteahhit, refah_rant)

### Karadeniz — havza detayı

- **Karadeniz çeperi:** net -1.925 | boşalma 2.853 | ikame 0.537 | sok 0.348 | dış bağ. 1.68 | rant 0.264 (tahıl, savunma_tedarik, refah_rant)

### Kafkasya — havza detayı

- **Kafkasya — Ermenistan:** net -0.503 | boşalma 0.745 | ikame 0.177 | sok 0.083 | dış bağ. 0.485 | rant 0.073 (transit_rant, güvenlik_hattı, refah_rant)
- **Kafkasya — Gürcistan:** net -0.615 | boşalma 0.937 | ikame 0.301 | sok 0.094 | dış bağ. 0.675 | rant 0.097 (transit_rant, liman, refah_rant)
- **Kafkasya — Azerbaycan:** net -0.641 | boşalma 1.319 | ikame 0.654 | sok 0.161 | dış bağ. 0.911 | rant 0.152 (transit_rant, enerji_koridor, refah_rant)

### Balkan — havza detayı

- **Balkan — Kuzey Makedonya:** net -0.409 | boşalma 0.777 | ikame 0.076 | sok 0.049 | dış bağ. 0.355 | rant 0.069 (montaj_ihale, koridor, refah_rant)
- **Balkan — Arnavutluk:** net -0.416 | boşalma 0.834 | ikame 0.102 | sok 0.05 | dış bağ. 0.378 | rant 0.076 (montaj_ihale, liman, refah_rant)
- **Balkan — Bosna-Hersek:** net -0.49 | boşalma 0.89 | ikame 0.072 | sok 0.056 | dış bağ. 0.408 | rant 0.078 (montaj_ihale, AB_fon, sınır_ticaret, refah_rant)
- **Balkan — Sırbistan:** net -0.528 | boşalma 1.187 | ikame 0.211 | sok 0.075 | dış bağ. 0.522 | rant 0.112 (montaj_ihale, AB_fon, refah_rant)
- **Balkan — Bulgaristan:** net -0.914 | boşalma 1.735 | ikame 0.06 | sok 0.104 | dış bağ. 0.716 | rant 0.116 (montaj_ihale, AB_fon, enerji_geçiş, refah_rant)

### Orta Asya — havza detayı

- **Orta Asya — Tacikistan:** net -0.433 | boşalma 0.687 | ikame 0.078 | sok 0.076 | dış bağ. 0.362 | rant 0.062 (hidro, transit, refah_rant)
- **Orta Asya — Kırgızistan:** net -0.462 | boşalma 0.787 | ikame 0.114 | sok 0.083 | dış bağ. 0.405 | rant 0.073 (maden, transit, refah_rant)
- **Orta Asya — Türkmenistan:** net -0.57 | boşalma 0.935 | ikame 0.158 | sok 0.103 | dış bağ. 0.512 | rant 0.088 (gaz, boru, korfez_kopru, refah_rant)
- **Orta Asya — Özbekistan:** net -0.724 | boşalma 1.401 | ikame 0.342 | sok 0.139 | dış bağ. 0.758 | rant 0.138 (maden, pamuk, boru, refah_rant)
- **Orta Asya — Kazakistan:** net -0.775 | boşalma 1.575 | ikame 0.491 | sok 0.174 | dış bağ. 0.882 | rant 0.162 (maden, boru, hub_transit, refah_rant)

### İran (yaricevre vekili) — havza detayı

- **İran — Irak/Suriye hattı:** net -0.153 | boşalma 0.662 | ikame 0.337 | sok 0.048 | dış bağ. 0.335 | rant 0.077 (sınır_ticaret, enerji_swaps, refah_rant)
- **İran — Körfez/güney:** net -0.251 | boşalma 0.729 | ikame 0.288 | sok 0.047 | dış bağ. 0.376 | rant 0.079 (petrol, liman, gaz, refah_rant)
- **İran — Doğu/Orta Asya kapısı:** net -0.27 | boşalma 0.736 | ikame 0.327 | sok 0.073 | dış bağ. 0.42 | rant 0.082 (transit, maden, koridor, refah_rant)

### Afrika Boynu / geniş güney — havza detayı

- **Afrika Boynu:** net -1.079 | boşalma 0.856 | ikame 0.071 | sok 0.43 | dış bağ. 0.619 | rant 0.075 (liman, askeri_üs, refah_rant)

### Rant kanalları (tüm havzalar)

- **İran — Irak/Suriye hattı** (iran): sınır_ticaret, enerji_swaps, refah_rant → 0.077
- **İran — Körfez/güney** (iran): petrol, liman, gaz, refah_rant → 0.079
- **İran — Doğu/Orta Asya kapısı** (iran): transit, maden, koridor, refah_rant → 0.082
- **Kuzey Afrika — Tunus** (kuzey_afrika): montaj, turizm_rant, refah_rant → 0.084
- **Balkan — Kuzey Makedonya** (balkan): montaj_ihale, koridor, refah_rant → 0.069
- **Balkan — Arnavutluk** (balkan): montaj_ihale, liman, refah_rant → 0.076
- **Orta Asya — Tacikistan** (ortasya): hidro, transit, refah_rant → 0.062
- **Orta Asya — Kırgızistan** (ortasya): maden, transit, refah_rant → 0.073
- **Balkan — Bosna-Hersek** (balkan): montaj_ihale, AB_fon, sınır_ticaret, refah_rant → 0.078
- **Kafkasya — Ermenistan** (kafkasya): transit_rant, güvenlik_hattı, refah_rant → 0.073
- **Kuzey Afrika — Mısır (Nil)** (kuzey_afrika): Süveyş, enerji_hattı, refah_rant → 0.195
- **Balkan — Sırbistan** (balkan): montaj_ihale, AB_fon, refah_rant → 0.112
- **Orta Asya — Türkmenistan** (ortasya): gaz, boru, korfez_kopru, refah_rant → 0.088
- **Kafkasya — Gürcistan** (kafkasya): transit_rant, liman, refah_rant → 0.097
- **Kafkasya — Azerbaycan** (kafkasya): transit_rant, enerji_koridor, refah_rant → 0.152
- **Kuzey Afrika — Cezayir** (kuzey_afrika): enerji, LNG, ihale, refah_rant → 0.113
- **Orta Asya — Özbekistan** (ortasya): maden, pamuk, boru, refah_rant → 0.138
- **Orta Asya — Kazakistan** (ortasya): maden, boru, hub_transit, refah_rant → 0.162
- **Kuzey Afrika — Fas** (kuzey_afrika): montaj, liman, güneş_KEF, refah_rant → 0.156
- **Balkan — Bulgaristan** (balkan): montaj_ihale, AB_fon, enerji_geçiş, refah_rant → 0.116
- **Kuzey Afrika — Libya** (kuzey_afrika): enerji, müteahhit, refah_rant → 0.161
- **Doğu Akdeniz — KÖİ/kefalet** (orta_dogu): KÖİ, Londra_hukuku, tahvil, refah_rant → 0.197
- **Afrika Boynu** (afrika): liman, askeri_üs, refah_rant → 0.075
- **Doğu Akdeniz — gaz/LNG** (orta_dogu): LNG, hatt_kefalet, refah_rant → 0.249
- **Fırat — KRG** (orta_dogu): petrol, transit, refah_rant → 0.23
- **Levant — Suriye tampon** (levant): güvenlik_rant, sınır_ticaret, refah_rant → 0.085
- **Levant — Lübnan kıyı** (levant): bankacılık_rant, liman, refah_rant → 0.097
- **Fırat — Irak merkez** (orta_dogu): petrol_servis, ihale, refah_rant → 0.252
- **Karadeniz çeperi** (karadeniz): tahıl, savunma_tedarik, refah_rant → 0.264
- **Körfez bağlantı hattı** (korfez): petro_dolar, fon_liman, refah_rant → 0.391

### Akış şeması (≥ 0,18)

```mermaid
flowchart LR
  korfez["Körfez bağlantı hattı"]
  MFIN["Merkez finans"]
  korfez -->|1.217 sız| MFIN
  dogu_akd["Doğu Akdeniz — KÖİ/kefal"]
  dogu_akd -->|1.21 sız| MFIN
  karadeni["Karadeniz çeperi"]
  karadeni -->|1.059 sız| MFIN
  dogu_akd -->|1.04 sız| MFIN
  balkan_b["Balkan — Bulgaristan"]
  balkan_b -->|0.904 sız| MFIN
  irak_bag["Fırat — Irak merkez"]
  irak_bag -->|0.887 sız| MFIN
  kuzeyafr["Kuzey Afrika — Fas"]
  kuzeyafr -->|0.83 sız| MFIN
  irak_krg["Fırat — KRG"]
  irak_krg -->|0.715 sız| MFIN
  ortasya_["Orta Asya — Kazakistan"]
  ortasya_ -->|0.693 sız| MFIN
  ortasya_ -->|0.648 sız| MFIN
  balkan_r["Balkan — Sırbistan"]
  balkan_r -->|0.605 sız| MFIN
  misir["Kuzey Afrika — Mısır (Ni"]
  misir -->|0.593 sız| MFIN
  kuzeyafr -->|0.496 sız| MFIN
  balkan_b -->|0.474 sız| MFIN
  libya["Kuzey Afrika — Libya"]
  libya -->|0.463 sız| MFIN
  balkan_a["Balkan — Arnavutluk"]
  balkan_a -->|0.463 sız| MFIN
  kuzeyafr -->|0.448 sız| MFIN
  balkan_m["Balkan — Kuzey Makedonya"]
  balkan_m -->|0.422 sız| MFIN
  kafkasya["Kafkasya — Azerbaycan"]
  kafkasya -->|0.398 sız| MFIN
  ortasya_ -->|0.389 sız| MFIN
  ortasya_ -->|0.355 sız| MFIN
  lubnan["Levant — Lübnan kıyı"]
  lubnan -->|0.338 sız| MFIN
  kafkasya -->|0.326 sız| MFIN
  ortasya_ -->|0.325 sız| MFIN
  iran_dog["İran — Doğu/Orta Asya ka"]
  iran_dog -->|0.29 sız| MFIN
  kafkasya -->|0.276 sız| MFIN
  iran_gun["İran — Körfez/güney"]
  iran_gun -->|0.271 sız| MFIN
  somali_a["Afrika Boynu"]
  somali_a -->|0.257 sız| MFIN
  suriye_k["Levant — Suriye tampon"]
  suriye_k -->|0.245 sız| MFIN
  iran_bat["İran — Irak/Suriye hattı"]
  iran_bat -->|0.23 sız| MFIN
  dogu_akd -->|0.224 ikm| misir
  korfez -->|0.194 ikm| irak_bag
  korfez -->|0.194 ikm| karadeni
```

### Ülke bazlı kayıp / fayda (10 yıl vekil)

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil | Durum |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| Türkiye | 41.76 | -41.76 | 0.247 | 0.26 | 0.206 | kayip |
| Irak | 3.307 | -3.307 | 0.46 | 0.484 | 0.406 | kayip |
| Körfez (vekil) | 2.606 | -2.606 | 0.351 | 0.37 | 0.311 | kayip |
| Lübnan | 1.52 | -1.52 | 0.145 | 0.152 | 0.155 | kayip |
| Suriye | 1.473 | -1.473 | 0.192 | 0.203 | 0.206 | kayip |
| Somali | 1.079 | -1.079 | 0.051 | 0.054 | 0.055 | kayip |
| Libya | 0.95 | -0.95 | 0.128 | 0.134 | 0.101 | kayip |
| Bulgaristan | 0.914 | -0.914 | 0.14 | 0.148 | 0.098 | kayip |
| Sırbistan | 0.913 | -0.913 | 0.164 | 0.172 | 0.126 | kayip |
| Fas | 0.909 | -0.909 | 0.114 | 0.12 | 0.101 | kayip |
| Mısır | 0.891 | -0.891 | 0.213 | 0.224 | 0.176 | kayip |
| Ukrayna/Karadeniz (vekil) | 0.866 | -0.866 | 0.141 | 0.149 | 0.125 | kayip |
| Kazakistan | 0.775 | -0.775 | 0.123 | 0.13 | 0.109 | kayip |
| Özbekistan | 0.724 | -0.724 | 0.095 | 0.1 | 0.084 | kayip |
| Cezayir | 0.688 | -0.688 | 0.088 | 0.093 | 0.07 | kayip |
| İran | 0.674 | -0.674 | 0.204 | 0.215 | 0.174 | kayip |
| Azerbaycan | 0.641 | -0.641 | 0.142 | 0.149 | 0.125 | kayip |
| Gürcistan | 0.615 | -0.615 | 0.095 | 0.1 | 0.084 | kayip |
| Türkmenistan | 0.57 | -0.57 | 0.066 | 0.069 | 0.058 | kayip |
| Ermenistan | 0.503 | -0.503 | 0.073 | 0.077 | 0.065 | kayip |
| Bosna-Hersek | 0.49 | -0.49 | 0.068 | 0.072 | 0.048 | kayip |
| İsrail (vekil) | 0.487 | -0.487 | 0.072 | 0.076 | 0.057 | kayip |
| Kırgızistan | 0.462 | -0.462 | 0.048 | 0.051 | 0.043 | kayip |
| Tacikistan | 0.433 | -0.433 | 0.04 | 0.042 | 0.035 | kayip |
| Arnavutluk | 0.416 | -0.416 | 0.061 | 0.064 | 0.042 | kayip |
| Kıbrıs (vekil) | 0.413 | -0.413 | 0.061 | 0.065 | 0.049 | kayip |
| Kuzey Makedonya | 0.409 | -0.409 | 0.055 | 0.058 | 0.038 | kayip |
| Tunus | 0.404 | -0.404 | 0.057 | 0.06 | 0.04 | kayip |

### Dış aktör kazanç (TR boşalması + ikame + merkez; vekil)

| Aktör | Kazanç Σ | Kanal | Matris | İkame | Merkez sız. | Belirsiz M* |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Merkez finans (vekil) | 16.867 | 0.0 | 0.0 | 0.0 | 16.867 | 0.0 |
| Çin | 11.543 | 6.186 | 3.726 | 1.631 | 0.0 | 0.1073 |
| Rusya | 11.113 | 5.808 | 3.3 | 2.005 | 0.0 | 0.1073 |
| AB (Balkan vekil) | 10.411 | 5.206 | 4.296 | 0.909 | 0.0 | 0.1073 |
| ABD | 7.478 | 3.2 | 3.312 | 0.966 | 0.0 | 0.1073 |
| İran | 5.779 | 2.455 | 2.737 | 0.587 | 0.0 | 0.1073 |
| İsrail | 2.981 | 1.402 | 1.134 | 0.445 | 0.0 | 0.1073 |
| BAE | 2.912 | 1.16 | 1.425 | 0.327 | 0.0 | 0.1073 |
| Suudi Arabistan | 2.614 | 1.078 | 1.105 | 0.431 | 0.0 | 0.1073 |
| Fransa | 1.838 | 1.06 | 0.612 | 0.166 | 0.0 | 0.1073 |
| Mısır | 1.781 | 0.952 | 0.563 | 0.266 | 0.0 | 0.1073 |
| Yunanistan | 1.278 | 0.813 | 0.335 | 0.13 | 0.0 | 0.1073 |
| Kıbrıs Rum Kesimi (vekil) | 0.245 | 0.0 | 0.245 | 0.0 | 0.0 | 0.1073 |
| Ukrayna (vekil) | 0.058 | 0.0 | 0.058 | 0.0 | 0.0 | 0.1073 |

### Aktör birleşik (havza kaybı vs dış kazanç vekili)

| Aktör | Dış kazanç | Havza kayıp | Belirsiz M* | Net birleşik | Durum |
| --- | ---: | ---: | ---: | ---: | --- |
| Merkez finans (vekil) | 16.867 | 0.0 | 0.0 | 16.867 | dis_kazanc |
| Çin | 11.543 | 0.0 | 0.107 | 11.543 | dis_kazanc |
| Rusya | 11.113 | 0.0 | 0.107 | 11.113 | dis_kazanc |
| AB (Balkan vekil) | 10.411 | 0.0 | 0.107 | 10.411 | dis_kazanc |
| ABD | 7.478 | 0.0 | 0.107 | 7.478 | dis_kazanc |
| İran | 5.779 | 0.674 | 0.107 | 5.105 | dis_kazanc |
| İsrail | 2.981 | 0.487 | 0.107 | 2.494 | dis_kazanc |
| BAE | 2.912 | 0.0 | 0.107 | 2.912 | dis_kazanc |
| Suudi Arabistan | 2.614 | 0.0 | 0.107 | 2.614 | dis_kazanc |
| Fransa | 1.838 | 0.0 | 0.107 | 1.838 | dis_kazanc |
| Mısır | 1.781 | 0.891 | 0.107 | 0.89 | dis_kazanc |
| Yunanistan | 1.278 | 0.0 | 0.107 | 1.278 | dis_kazanc |
| Kıbrıs Rum Kesimi (vekil) | 0.245 | 0.413 | 0.107 | -0.168 | havza_kayip |
| Ukrayna (vekil) | 0.058 | 0.866 | 0.107 | -0.808 | havza_kayip |
| Türkiye | 0.0 | 41.76 | 0.0 | -41.76 | havza_kayip |
| Irak | 0.0 | 3.307 | 0.107 | -3.307 | havza_kayip |
| Körfez (vekil) | 0.0 | 2.606 | 0.107 | -2.606 | havza_kayip |
| Lübnan | 0.0 | 1.52 | 0.107 | -1.52 | havza_kayip |
| Suriye | 0.0 | 1.473 | 0.107 | -1.473 | havza_kayip |
| Somali | 0.0 | 1.079 | 0.107 | -1.079 | havza_kayip |
| Libya | 0.0 | 0.95 | 0.107 | -0.95 | havza_kayip |
| Bulgaristan | 0.0 | 0.914 | 0.107 | -0.914 | havza_kayip |
| Sırbistan | 0.0 | 0.913 | 0.107 | -0.913 | havza_kayip |
| Fas | 0.0 | 0.909 | 0.107 | -0.909 | havza_kayip |
| Kazakistan | 0.0 | 0.775 | 0.107 | -0.775 | havza_kayip |

## Senaryo C: Katmanlı oyun inşası — kısmi kullanım

Oyun sahibi dış koşulu içeren yeniden kurulum; enigma çözümleme vekil.

**Bağ modu (kullanım/atıl/araçsal):** 0.52/0.26/0.22 | **Çeper / gövde açığı:** 3.288 / 2.571
**Pasif boşluk:** 2.823 | **Araçsallaşma:** 1.491 | **Temsil zedesi:** 1.626 | **Dış mimari:** 2.072
**İç dinamik tıkanma:** 0.334 | **Dış hegemon açmaz (vekil):** 4.838
**TR boşalma:** 17.172 | **Rant (OD+Levant+Körfez+Kuzey Af. alt küme):** 0.578 | **Tüm havza rant Σ:** 1.12
**Dış bağlanma (alt küme / tüm Σ):** 3.904 / 7.608 | **Merkez sızıntı + rant Σ:** 9.024
**MFIN kenar / belirsiz havuz / evren:** 5.662 / 2.242 / 36 ülke × 0.0623

### Alt havza tablosu

| Bölge | Çeper | Atıl | Araçsal | Temsil z. | Dış mimari | Net |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| İran — Irak/Suriye hattı | iran | 0.055 | 0.029 | 0.031 | 0.04 | -0.072 |
| İran — Doğu/Orta Asya kapısı | iran | 0.049 | 0.026 | 0.029 | 0.036 | -0.1 |
| İran — Körfez/güney | iran | 0.062 | 0.033 | 0.035 | 0.046 | -0.105 |
| Kuzey Afrika — Tunus | kuzey_afrika | 0.046 | 0.024 | 0.021 | 0.034 | -0.155 |
| Balkan — Kuzey Makedonya | karadeniz | 0.045 | 0.024 | 0.021 | 0.033 | -0.169 |
| Orta Asya — Tacikistan | ortasya | 0.033 | 0.017 | 0.019 | 0.024 | -0.169 |
| Balkan — Arnavutluk | karadeniz | 0.049 | 0.026 | 0.023 | 0.036 | -0.173 |
| Orta Asya — Kırgızistan | ortasya | 0.039 | 0.021 | 0.023 | 0.029 | -0.179 |
| Kafkasya — Ermenistan | kafkasya | 0.059 | 0.031 | 0.035 | 0.043 | -0.204 |
| Balkan — Bosna-Hersek | karadeniz | 0.056 | 0.029 | 0.026 | 0.041 | -0.208 |
| Kuzey Afrika — Mısır (Nil) | kuzey_afrika | 0.129 | 0.068 | 0.073 | 0.095 | -0.223 |
| Balkan — Sırbistan | karadeniz | 0.082 | 0.043 | 0.038 | 0.06 | -0.226 |
| Orta Asya — Türkmenistan | ortasya | 0.054 | 0.028 | 0.032 | 0.039 | -0.227 |
| Kafkasya — Gürcistan | kafkasya | 0.077 | 0.041 | 0.046 | 0.057 | -0.243 |
| Kafkasya — Azerbaycan | kafkasya | 0.115 | 0.061 | 0.069 | 0.084 | -0.249 |
| Doğu Akdeniz — KÖİ/kefalet | levant | 0.078 | 0.041 | 0.041 | 0.057 | -0.252 |
| Kuzey Afrika — Cezayir | kuzey_afrika | 0.072 | 0.038 | 0.038 | 0.053 | -0.273 |
| Orta Asya — Özbekistan | ortasya | 0.077 | 0.041 | 0.046 | 0.057 | -0.278 |
| Orta Asya — Kazakistan | ortasya | 0.1 | 0.053 | 0.06 | 0.073 | -0.302 |
| Doğu Akdeniz — gaz/LNG | levant | 0.098 | 0.052 | 0.052 | 0.072 | -0.308 |
| Kuzey Afrika — Libya | kuzey_afrika | 0.104 | 0.055 | 0.055 | 0.076 | -0.368 |
| Kuzey Afrika — Fas | kuzey_afrika | 0.092 | 0.049 | 0.055 | 0.068 | -0.388 |
| Balkan — Bulgaristan | karadeniz | 0.114 | 0.06 | 0.053 | 0.084 | -0.402 |
| Afrika Boynu | genis | 0.041 | 0.022 | 0.03 | 0.03 | -0.436 |
| Levant — Lübnan kıyı | levant | 0.078 | 0.041 | 0.056 | 0.057 | -0.441 |
| Levant — Suriye tampon | levant | 0.104 | 0.055 | 0.075 | 0.076 | -0.443 |
| Fırat — KRG | korfez | 0.163 | 0.086 | 0.097 | 0.12 | -0.596 |
| Fırat — Irak merkez | korfez | 0.211 | 0.111 | 0.125 | 0.155 | -0.764 |
| Karadeniz çeperi | karadeniz | 0.255 | 0.135 | 0.152 | 0.187 | -0.832 |
| Körfez bağlantı hattı | korfez | 0.286 | 0.151 | 0.17 | 0.21 | -1.114 |

### Makro özet (tüm bölgeler, aynı kapsam)

| Makro | Havza | Net Σ | Boşalma Σ | Rant Σ | Dış bağ. Σ | Pasif Σ |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Levant | 2 | -0.884 | 0.625 | 0.036 | 0.407 | 0.182 |
| Orta Doğu (Fırat / Doğu Akdeniz) | 4 | -1.92 | 3.279 | 0.229 | 1.473 | 0.55 |
| Körfez | 1 | -1.114 | 1.316 | 0.113 | 0.649 | 0.286 |
| Kuzey Afrika | 5 | -1.407 | 3.076 | 0.2 | 1.375 | 0.443 |
| Karadeniz | 1 | -0.832 | 1.289 | 0.076 | 0.583 | 0.255 |
| Kafkasya | 3 | -0.696 | 1.357 | 0.093 | 0.71 | 0.251 |
| Balkan | 5 | -1.178 | 2.45 | 0.131 | 0.82 | 0.346 |
| Orta Asya | 5 | -1.155 | 2.433 | 0.151 | 0.994 | 0.303 |
| İran (yaricevre vekili) | 3 | -0.277 | 0.96 | 0.069 | 0.39 | 0.166 |
| Afrika Boynu / geniş güney | 1 | -0.436 | 0.387 | 0.022 | 0.207 | 0.041 |

### Levant — havza detayı

- **Levant — Lübnan kıyı:** net -0.441 | boşalma 0.337 | ikame 0.021 | sok 0.151 | dış bağ. 0.199 | rant 0.019 (bankacılık_rant, liman, refah_rant)
- **Levant — Suriye tampon:** net -0.443 | boşalma 0.288 | ikame 0.034 | sok 0.124 | dış bağ. 0.208 | rant 0.017 (güvenlik_rant, sınır_ticaret, refah_rant)

### Orta Doğu (Fırat / Doğu Akdeniz) — havza detayı

- **Doğu Akdeniz — KÖİ/kefalet:** net -0.252 | boşalma 0.657 | ikame 0.097 | sok 0.048 | dış bağ. 0.193 | rant 0.039 (KÖİ, Londra_hukuku, tahvil, refah_rant)
- **Doğu Akdeniz — gaz/LNG:** net -0.308 | boşalma 0.677 | ikame 0.131 | sok 0.043 | dış bağ. 0.257 | rant 0.05 (LNG, hatt_kefalet, refah_rant)
- **Fırat — KRG:** net -0.596 | boşalma 0.929 | ikame 0.243 | sok 0.145 | dış bağ. 0.465 | rant 0.067 (petrol, transit, refah_rant)
- **Fırat — Irak merkez:** net -0.764 | boşalma 1.016 | ikame 0.224 | sok 0.136 | dış bağ. 0.558 | rant 0.073 (petrol_servis, ihale, refah_rant)

### Körfez — havza detayı

- **Körfez bağlantı hattı:** net -1.114 | boşalma 1.316 | ikame 0.1 | sok 0.147 | dış bağ. 0.649 | rant 0.113 (petro_dolar, fon_liman, refah_rant)

### Kuzey Afrika — havza detayı

- **Kuzey Afrika — Tunus:** net -0.155 | boşalma 0.398 | ikame 0.077 | sok 0.028 | dış bağ. 0.143 | rant 0.024 (montaj, turizm_rant, refah_rant)
- **Kuzey Afrika — Mısır (Nil):** net -0.223 | boşalma 0.723 | ikame 0.378 | sok 0.059 | dış bağ. 0.365 | rant 0.054 (Süveyş, enerji_hattı, refah_rant)
- **Kuzey Afrika — Cezayir:** net -0.273 | boşalma 0.538 | ikame 0.1 | sok 0.054 | dış bağ. 0.221 | rant 0.033 (enerji, LNG, ihale, refah_rant)
- **Kuzey Afrika — Libya:** net -0.368 | boşalma 0.645 | ikame 0.256 | sok 0.088 | dış bağ. 0.396 | rant 0.045 (enerji, müteahhit, refah_rant)
- **Kuzey Afrika — Fas:** net -0.388 | boşalma 0.772 | ikame 0.08 | sok 0.086 | dış bağ. 0.25 | rant 0.044 (montaj, liman, güneş_KEF, refah_rant)

### Karadeniz — havza detayı

- **Karadeniz çeperi:** net -0.832 | boşalma 1.289 | ikame 0.244 | sok 0.158 | dış bağ. 0.583 | rant 0.076 (tahıl, savunma_tedarik, refah_rant)

### Kafkasya — havza detayı

- **Kafkasya — Ermenistan:** net -0.204 | boşalma 0.337 | ikame 0.081 | sok 0.038 | dış bağ. 0.166 | rant 0.021 (transit_rant, güvenlik_hattı, refah_rant)
- **Kafkasya — Gürcistan:** net -0.243 | boşalma 0.424 | ikame 0.137 | sok 0.043 | dış bağ. 0.231 | rant 0.028 (transit_rant, liman, refah_rant)
- **Kafkasya — Azerbaycan:** net -0.249 | boşalma 0.596 | ikame 0.297 | sok 0.073 | dış bağ. 0.313 | rant 0.044 (transit_rant, enerji_koridor, refah_rant)

### Balkan — havza detayı

- **Balkan — Kuzey Makedonya:** net -0.169 | boşalma 0.351 | ikame 0.033 | sok 0.022 | dış bağ. 0.122 | rant 0.02 (montaj_ihale, koridor, refah_rant)
- **Balkan — Arnavutluk:** net -0.173 | boşalma 0.377 | ikame 0.043 | sok 0.023 | dış bağ. 0.129 | rant 0.022 (montaj_ihale, liman, refah_rant)
- **Balkan — Bosna-Hersek:** net -0.208 | boşalma 0.402 | ikame 0.029 | sok 0.026 | dış bağ. 0.14 | rant 0.023 (montaj_ihale, AB_fon, sınır_ticaret, refah_rant)
- **Balkan — Sırbistan:** net -0.226 | boşalma 0.536 | ikame 0.092 | sok 0.034 | dış bağ. 0.181 | rant 0.032 (montaj_ihale, AB_fon, refah_rant)
- **Balkan — Bulgaristan:** net -0.402 | boşalma 0.784 | ikame 0.025 | sok 0.047 | dış bağ. 0.248 | rant 0.034 (montaj_ihale, AB_fon, enerji_geçiş, refah_rant)

### Orta Asya — havza detayı

- **Orta Asya — Tacikistan:** net -0.169 | boşalma 0.31 | ikame 0.035 | sok 0.034 | dış bağ. 0.122 | rant 0.018 (hidro, transit, refah_rant)
- **Orta Asya — Kırgızistan:** net -0.179 | boşalma 0.355 | ikame 0.052 | sok 0.037 | dış bağ. 0.137 | rant 0.021 (maden, transit, refah_rant)
- **Orta Asya — Türkmenistan:** net -0.227 | boşalma 0.423 | ikame 0.072 | sok 0.047 | dış bağ. 0.175 | rant 0.025 (gaz, boru, korfez_kopru, refah_rant)
- **Orta Asya — Özbekistan:** net -0.278 | boşalma 0.633 | ikame 0.155 | sok 0.063 | dış bağ. 0.258 | rant 0.04 (maden, pamuk, boru, refah_rant)
- **Orta Asya — Kazakistan:** net -0.302 | boşalma 0.712 | ikame 0.223 | sok 0.079 | dış bağ. 0.302 | rant 0.047 (maden, boru, hub_transit, refah_rant)

### İran (yaricevre vekili) — havza detayı

- **İran — Irak/Suriye hattı:** net -0.072 | boşalma 0.299 | ikame 0.141 | sok 0.022 | dış bağ. 0.115 | rant 0.022 (sınır_ticaret, enerji_swaps, refah_rant)
- **İran — Doğu/Orta Asya kapısı:** net -0.1 | boşalma 0.332 | ikame 0.148 | sok 0.033 | dış bağ. 0.144 | rant 0.024 (transit, maden, koridor, refah_rant)
- **İran — Körfez/güney:** net -0.105 | boşalma 0.329 | ikame 0.131 | sok 0.021 | dış bağ. 0.131 | rant 0.023 (petrol, liman, gaz, refah_rant)

### Afrika Boynu / geniş güney — havza detayı

- **Afrika Boynu:** net -0.436 | boşalma 0.387 | ikame 0.032 | sok 0.195 | dış bağ. 0.207 | rant 0.022 (liman, askeri_üs, refah_rant)

### Rant kanalları (tüm havzalar)

- **İran — Irak/Suriye hattı** (iran): sınır_ticaret, enerji_swaps, refah_rant → 0.022
- **İran — Doğu/Orta Asya kapısı** (iran): transit, maden, koridor, refah_rant → 0.024
- **İran — Körfez/güney** (iran): petrol, liman, gaz, refah_rant → 0.023
- **Kuzey Afrika — Tunus** (kuzey_afrika): montaj, turizm_rant, refah_rant → 0.024
- **Balkan — Kuzey Makedonya** (balkan): montaj_ihale, koridor, refah_rant → 0.02
- **Orta Asya — Tacikistan** (ortasya): hidro, transit, refah_rant → 0.018
- **Balkan — Arnavutluk** (balkan): montaj_ihale, liman, refah_rant → 0.022
- **Orta Asya — Kırgızistan** (ortasya): maden, transit, refah_rant → 0.021
- **Kafkasya — Ermenistan** (kafkasya): transit_rant, güvenlik_hattı, refah_rant → 0.021
- **Balkan — Bosna-Hersek** (balkan): montaj_ihale, AB_fon, sınır_ticaret, refah_rant → 0.023
- **Kuzey Afrika — Mısır (Nil)** (kuzey_afrika): Süveyş, enerji_hattı, refah_rant → 0.054
- **Balkan — Sırbistan** (balkan): montaj_ihale, AB_fon, refah_rant → 0.032
- **Orta Asya — Türkmenistan** (ortasya): gaz, boru, korfez_kopru, refah_rant → 0.025
- **Kafkasya — Gürcistan** (kafkasya): transit_rant, liman, refah_rant → 0.028
- **Kafkasya — Azerbaycan** (kafkasya): transit_rant, enerji_koridor, refah_rant → 0.044
- **Doğu Akdeniz — KÖİ/kefalet** (orta_dogu): KÖİ, Londra_hukuku, tahvil, refah_rant → 0.039
- **Kuzey Afrika — Cezayir** (kuzey_afrika): enerji, LNG, ihale, refah_rant → 0.033
- **Orta Asya — Özbekistan** (ortasya): maden, pamuk, boru, refah_rant → 0.04
- **Orta Asya — Kazakistan** (ortasya): maden, boru, hub_transit, refah_rant → 0.047
- **Doğu Akdeniz — gaz/LNG** (orta_dogu): LNG, hatt_kefalet, refah_rant → 0.05
- **Kuzey Afrika — Libya** (kuzey_afrika): enerji, müteahhit, refah_rant → 0.045
- **Kuzey Afrika — Fas** (kuzey_afrika): montaj, liman, güneş_KEF, refah_rant → 0.044
- **Balkan — Bulgaristan** (balkan): montaj_ihale, AB_fon, enerji_geçiş, refah_rant → 0.034
- **Afrika Boynu** (afrika): liman, askeri_üs, refah_rant → 0.022
- **Levant — Lübnan kıyı** (levant): bankacılık_rant, liman, refah_rant → 0.019
- **Levant — Suriye tampon** (levant): güvenlik_rant, sınır_ticaret, refah_rant → 0.017
- **Fırat — KRG** (orta_dogu): petrol, transit, refah_rant → 0.067
- **Fırat — Irak merkez** (orta_dogu): petrol_servis, ihale, refah_rant → 0.073
- **Karadeniz çeperi** (karadeniz): tahıl, savunma_tedarik, refah_rant → 0.076
- **Körfez bağlantı hattı** (korfez): petro_dolar, fon_liman, refah_rant → 0.113

### Akış şeması (≥ 0,18)

```mermaid
flowchart LR
  korfez["Körfez bağlantı hattı"]
  MFIN["Merkez finans"]
  korfez -->|0.434 sız| MFIN
  karadeni["Karadeniz çeperi"]
  karadeni -->|0.377 sız| MFIN
  balkan_b["Balkan — Bulgaristan"]
  balkan_b -->|0.321 sız| MFIN
  irak_bag["Fırat — Irak merkez"]
  irak_bag -->|0.316 sız| MFIN
  kuzeyafr["Kuzey Afrika — Fas"]
  kuzeyafr -->|0.295 sız| MFIN
  dogu_akd["Doğu Akdeniz — KÖİ/kefal"]
  dogu_akd -->|0.287 sız| MFIN
  irak_krg["Fırat — KRG"]
  irak_krg -->|0.254 sız| MFIN
  dogu_akd -->|0.247 sız| MFIN
  ortasya_["Orta Asya — Kazakistan"]
  ortasya_ -->|0.246 sız| MFIN
  ortasya_ -->|0.23 sız| MFIN
  balkan_r["Balkan — Sırbistan"]
  balkan_r -->|0.215 sız| MFIN
  misir["Kuzey Afrika — Mısır (Ni"]
  misir -->|0.211 sız| MFIN
```

### Ülke bazlı kayıp / fayda (10 yıl vekil)

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil | Durum |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| Türkiye | 17.7 | -17.7 | 0.164 | 0.086 | 0.092 | kayip |
| Irak | 1.36 | -1.36 | 0.374 | 0.197 | 0.222 | kayip |
| Körfez (vekil) | 1.114 | -1.114 | 0.286 | 0.151 | 0.17 | kayip |
| Suriye | 0.443 | -0.443 | 0.104 | 0.055 | 0.075 | kayip |
| Lübnan | 0.441 | -0.441 | 0.078 | 0.041 | 0.056 | kayip |
| Somali | 0.436 | -0.436 | 0.041 | 0.022 | 0.03 | kayip |
| Bulgaristan | 0.402 | -0.402 | 0.114 | 0.06 | 0.053 | kayip |
| Sırbistan | 0.392 | -0.392 | 0.133 | 0.07 | 0.068 | kayip |
| Fas | 0.388 | -0.388 | 0.092 | 0.049 | 0.055 | kayip |
| Ukrayna/Karadeniz (vekil) | 0.374 | -0.374 | 0.115 | 0.061 | 0.068 | kayip |
| Libya | 0.368 | -0.368 | 0.104 | 0.055 | 0.055 | kayip |
| Mısır | 0.316 | -0.316 | 0.158 | 0.084 | 0.089 | kayip |
| Kazakistan | 0.302 | -0.302 | 0.1 | 0.053 | 0.06 | kayip |
| Özbekistan | 0.278 | -0.278 | 0.077 | 0.041 | 0.046 | kayip |
| İran | 0.277 | -0.277 | 0.166 | 0.088 | 0.095 | kayip |
| Cezayir | 0.273 | -0.273 | 0.072 | 0.038 | 0.038 | kayip |
| Azerbaycan | 0.249 | -0.249 | 0.115 | 0.061 | 0.069 | kayip |
| Gürcistan | 0.243 | -0.243 | 0.077 | 0.041 | 0.046 | kayip |
| Türkmenistan | 0.227 | -0.227 | 0.054 | 0.028 | 0.032 | kayip |
| Bosna-Hersek | 0.208 | -0.208 | 0.056 | 0.029 | 0.026 | kayip |
| Ermenistan | 0.204 | -0.204 | 0.059 | 0.031 | 0.035 | kayip |
| Kırgızistan | 0.179 | -0.179 | 0.039 | 0.021 | 0.023 | kayip |
| Arnavutluk | 0.173 | -0.173 | 0.049 | 0.026 | 0.023 | kayip |
| Kuzey Makedonya | 0.169 | -0.169 | 0.045 | 0.024 | 0.021 | kayip |
| Tacikistan | 0.169 | -0.169 | 0.033 | 0.017 | 0.019 | kayip |
| Tunus | 0.155 | -0.155 | 0.046 | 0.024 | 0.021 | kayip |
| İsrail (vekil) | 0.124 | -0.124 | 0.039 | 0.021 | 0.021 | kayip |
| Kıbrıs (vekil) | 0.106 | -0.106 | 0.033 | 0.018 | 0.018 | kayip |

### Dış aktör kazanç (TR boşalması + ikame + merkez; vekil)

| Aktör | Kazanç Σ | Kanal | Matris | İkame | Merkez sız. | Belirsiz M* |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Merkez finans (vekil) | 5.662 | 0.0 | 0.0 | 0.0 | 5.662 | 0.0 |
| Çin | 5.239 | 2.81 | 1.692 | 0.737 | 0.0 | 0.0623 |
| Rusya | 4.93 | 2.583 | 1.46 | 0.887 | 0.0 | 0.0623 |
| AB (Balkan vekil) | 4.709 | 2.364 | 1.95 | 0.395 | 0.0 | 0.0623 |
| ABD | 3.028 | 1.281 | 1.341 | 0.406 | 0.0 | 0.0623 |
| İran | 2.406 | 1.01 | 1.139 | 0.257 | 0.0 | 0.0623 |
| BAE | 1.308 | 0.527 | 0.648 | 0.133 | 0.0 | 0.0623 |
| Suudi Arabistan | 1.106 | 0.453 | 0.482 | 0.171 | 0.0 | 0.0623 |
| İsrail | 1.033 | 0.477 | 0.38 | 0.176 | 0.0 | 0.0623 |
| Fransa | 0.756 | 0.439 | 0.252 | 0.065 | 0.0 | 0.0623 |
| Mısır | 0.635 | 0.329 | 0.201 | 0.105 | 0.0 | 0.0623 |
| Yunanistan | 0.399 | 0.246 | 0.101 | 0.052 | 0.0 | 0.0623 |
| Kıbrıs Rum Kesimi (vekil) | 0.074 | 0.0 | 0.074 | 0.0 | 0.0 | 0.0623 |
| Ukrayna (vekil) | 0.026 | 0.0 | 0.026 | 0.0 | 0.0 | 0.0623 |

### Aktör birleşik (havza kaybı vs dış kazanç vekili)

| Aktör | Dış kazanç | Havza kayıp | Belirsiz M* | Net birleşik | Durum |
| --- | ---: | ---: | ---: | ---: | --- |
| Merkez finans (vekil) | 5.662 | 0.0 | 0.0 | 5.662 | dis_kazanc |
| Çin | 5.239 | 0.0 | 0.062 | 5.239 | dis_kazanc |
| Rusya | 4.93 | 0.0 | 0.062 | 4.93 | dis_kazanc |
| AB (Balkan vekil) | 4.709 | 0.0 | 0.062 | 4.709 | dis_kazanc |
| ABD | 3.028 | 0.0 | 0.062 | 3.028 | dis_kazanc |
| İran | 2.406 | 0.277 | 0.062 | 2.129 | dis_kazanc |
| BAE | 1.308 | 0.0 | 0.062 | 1.308 | dis_kazanc |
| Suudi Arabistan | 1.106 | 0.0 | 0.062 | 1.106 | dis_kazanc |
| İsrail | 1.033 | 0.124 | 0.062 | 0.909 | dis_kazanc |
| Fransa | 0.756 | 0.0 | 0.062 | 0.756 | dis_kazanc |
| Mısır | 0.635 | 0.316 | 0.062 | 0.319 | dis_kazanc |
| Yunanistan | 0.399 | 0.0 | 0.062 | 0.399 | dis_kazanc |
| Kıbrıs Rum Kesimi (vekil) | 0.074 | 0.106 | 0.062 | -0.032 | nötr |
| Ukrayna (vekil) | 0.026 | 0.374 | 0.062 | -0.348 | havza_kayip |
| Türkiye | 0.0 | 17.7 | 0.0 | -17.7 | havza_kayip |
| Irak | 0.0 | 1.36 | 0.062 | -1.36 | havza_kayip |
| Körfez (vekil) | 0.0 | 1.114 | 0.062 | -1.114 | havza_kayip |
| Suriye | 0.0 | 0.443 | 0.062 | -0.443 | havza_kayip |
| Lübnan | 0.0 | 0.441 | 0.062 | -0.441 | havza_kayip |
| Somali | 0.0 | 0.436 | 0.062 | -0.436 | havza_kayip |
| Bulgaristan | 0.0 | 0.402 | 0.062 | -0.402 | havza_kayip |
| Sırbistan | 0.0 | 0.392 | 0.062 | -0.392 | havza_kayip |
| Fas | 0.0 | 0.388 | 0.062 | -0.388 | havza_kayip |
| Libya | 0.0 | 0.368 | 0.062 | -0.368 | havza_kayip |
| Kazakistan | 0.0 | 0.302 | 0.062 | -0.302 | havza_kayip |

## Dış aktör — kazanç vekili (A / B / C)

| Aktör | A | B | C |
| --- | ---: | ---: | ---: |
| Merkez finans (vekil) | 9.192 | 16.867 | 5.662 |
| Çin | 7.475 | 11.543 | 5.239 |
| Rusya | 7.108 | 11.113 | 4.93 |
| AB (Balkan vekil) | 6.728 | 10.411 | 4.709 |
| ABD | 4.535 | 7.478 | 3.028 |
| İran | 3.566 | 5.779 | 2.406 |
| BAE | 1.878 | 2.912 | 1.308 |
| İsrail | 1.656 | 2.981 | 1.033 |
| Suudi Arabistan | 1.627 | 2.614 | 1.106 |
| Fransa | 1.124 | 1.838 | 0.756 |
| Mısır | 1.005 | 1.781 | 0.635 |
| Yunanistan | 0.673 | 1.278 | 0.399 |
| Kıbrıs Rum Kesimi (vekil) | 0.127 | 0.245 | 0.074 |
| Ukrayna (vekil) | 0.037 | 0.058 | 0.026 |

## Ülkeler — kayıp endeksi (A / B / C)

| Ülke | A | B | C |
| --- | ---: | ---: | ---: |
| Türkiye | 25.822 | 41.76 | 17.7 |
| Irak | 2.04 | 3.307 | 1.36 |
| Körfez (vekil) | 1.645 | 2.606 | 1.114 |
| Lübnan | 0.778 | 1.52 | 0.441 |
| Suriye | 0.776 | 1.473 | 0.443 |
| Somali | 0.652 | 1.079 | 0.436 |
| Bulgaristan | 0.584 | 0.914 | 0.402 |
| Sırbistan | 0.579 | 0.913 | 0.392 |
| Fas | 0.569 | 0.909 | 0.388 |
| Libya | 0.559 | 0.95 | 0.368 |
| Ukrayna/Karadeniz (vekil) | 0.552 | 0.866 | 0.374 |
| Mısır | 0.505 | 0.891 | 0.316 |
| Kazakistan | 0.461 | 0.775 | 0.302 |
| Özbekistan | 0.427 | 0.724 | 0.278 |
| İran | 0.417 | 0.674 | 0.277 |
| Cezayir | 0.413 | 0.688 | 0.273 |
| Azerbaycan | 0.384 | 0.641 | 0.249 |
| Gürcistan | 0.371 | 0.615 | 0.243 |
| Türkmenistan | 0.343 | 0.57 | 0.227 |
| Ermenistan | 0.31 | 0.503 | 0.204 |
| Bosna-Hersek | 0.306 | 0.49 | 0.208 |
| Kırgızistan | 0.273 | 0.462 | 0.179 |
| Tacikistan | 0.258 | 0.433 | 0.169 |
| Arnavutluk | 0.255 | 0.416 | 0.173 |
| Kuzey Makedonya | 0.252 | 0.409 | 0.169 |
| Tunus | 0.238 | 0.404 | 0.155 |
| İsrail (vekil) | 0.232 | 0.487 | 0.124 |
| Kıbrıs (vekil) | 0.197 | 0.413 | 0.106 |

## Global — üç senaryo özeti

| | A | B | C |
| --- | ---: | ---: | ---: |
| Pasif boşluk (atıl) | 5.566 | 3.695 | 2.823 |
| Araçsallaşma | 1.946 | 3.891 | 1.491 |
| Meşruiyet/temsil zedesi | 2.688 | 3.186 | 1.626 |
| Dış hegemon mimarisi | 3.608 | 3.642 | 2.072 |
| İç dinamik tıkanma | 0.642 | 0.789 | 0.334 |
| Dış açmaz vekili | 8.205 | 10.897 | 4.838 |
| Rant (OD+Levant+Körfez+Kuzey Af.) | 1.044 | 2.21 | 0.578 |
| TR boşalma toplam | 24.952 | 40.166 | 17.172 |

## Levant — A / B / C (makro kapsam)

| | A | B | C |
| --- | ---: | ---: | ---: |
| Net endeks Σ | -1.554 | -2.993 | -0.884 |
| TR boşalma Σ | 1.065 | 2.073 | 0.625 |
| Rant çıkış Σ | 0.073 | 0.182 | 0.036 |
| Dış bağlanma Σ | 0.824 | 1.75 | 0.407 |
| Pasif Σ | 0.421 | 0.337 | 0.182 |

## Orta Doğu (Fırat / Doğu Akdeniz) — A / B / C (makro kapsam)

| | A | B | C |
| --- | ---: | ---: | ---: |
| Net endeks Σ | -3.084 | -5.492 | -1.92 |
| TR boşalma Σ | 5.036 | 8.729 | 3.279 |
| Rant çıkış Σ | 0.424 | 0.928 | 0.229 |
| Dış bağlanma Σ | 2.614 | 4.894 | 1.473 |
| Pasif Σ | 1.126 | 0.785 | 0.55 |

## Körfez — A / B / C (makro kapsam)

| | A | B | C |
| --- | ---: | ---: | ---: |
| Net endeks Σ | -1.645 | -2.606 | -1.114 |
| TR boşalma Σ | 1.869 | 2.911 | 1.316 |
| Rant çıkış Σ | 0.196 | 0.391 | 0.113 |
| Dış bağlanma Σ | 1.095 | 1.869 | 0.649 |
| Pasif Σ | 0.549 | 0.351 | 0.286 |

## Kuzey Afrika — A / B / C (makro kapsam)

| | A | B | C |
| --- | ---: | ---: | ---: |
| Net endeks Σ | -2.11 | -3.478 | -1.407 |
| TR boşalma Σ | 4.371 | 6.808 | 3.076 |
| Rant çıkış Σ | 0.351 | 0.709 | 0.2 |
| Dış bağlanma Σ | 2.315 | 4.126 | 1.375 |
| Pasif Σ | 0.851 | 0.546 | 0.443 |

## Karadeniz — A / B / C (makro kapsam)

| | A | B | C |
| --- | ---: | ---: | ---: |
| Net endeks Σ | -1.227 | -1.925 | -0.832 |
| TR boşalma Σ | 1.832 | 2.853 | 1.289 |
| Rant çıkış Σ | 0.133 | 0.264 | 0.076 |
| Dış bağlanma Σ | 0.984 | 1.68 | 0.583 |
| Pasif Σ | 0.491 | 0.314 | 0.255 |

## Kafkasya — A / B / C (makro kapsam)

| | A | B | C |
| --- | ---: | ---: | ---: |
| Net endeks Σ | -1.065 | -1.759 | -0.696 |
| TR boşalma Σ | 1.927 | 3.001 | 1.357 |
| Rant çıkış Σ | 0.162 | 0.322 | 0.093 |
| Dış bağlanma Σ | 1.19 | 2.071 | 0.71 |
| Pasif Σ | 0.483 | 0.31 | 0.251 |

## Balkan — A / B / C (makro kapsam)

| | A | B | C |
| --- | ---: | ---: | ---: |
| Net endeks Σ | -1.731 | -2.757 | -1.178 |
| TR boşalma Σ | 3.481 | 5.423 | 2.45 |
| Rant çıkış Σ | 0.226 | 0.451 | 0.131 |
| Dış bağlanma Σ | 1.383 | 2.379 | 0.82 |
| Pasif Σ | 0.664 | 0.425 | 0.346 |

## Orta Asya — A / B / C (makro kapsam)

| | A | B | C |
| --- | ---: | ---: | ---: |
| Net endeks Σ | -1.762 | -2.964 | -1.155 |
| TR boşalma Σ | 3.456 | 5.385 | 2.433 |
| Rant çıkış Σ | 0.262 | 0.523 | 0.151 |
| Dış bağlanma Σ | 1.655 | 2.919 | 0.994 |
| Pasif Σ | 0.581 | 0.372 | 0.303 |

## İran (yaricevre vekili) — A / B / C (makro kapsam)

| | A | B | C |
| --- | ---: | ---: | ---: |
| Net endeks Σ | -0.417 | -0.674 | -0.277 |
| TR boşalma Σ | 1.365 | 2.127 | 0.96 |
| Rant çıkış Σ | 0.119 | 0.238 | 0.069 |
| Dış bağlanma Σ | 0.66 | 1.131 | 0.39 |
| Pasif Σ | 0.32 | 0.204 | 0.166 |

## Afrika Boynu / geniş güney — A / B / C (makro kapsam)

| | A | B | C |
| --- | ---: | ---: | ---: |
| Net endeks Σ | -0.652 | -1.079 | -0.436 |
| TR boşalma Σ | 0.55 | 0.856 | 0.387 |
| Rant çıkış Σ | 0.038 | 0.075 | 0.022 |
| Dış bağlanma Σ | 0.342 | 0.619 | 0.207 |
| Pasif Σ | 0.08 | 0.051 | 0.041 |
