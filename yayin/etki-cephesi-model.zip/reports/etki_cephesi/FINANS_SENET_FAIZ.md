# Finans — senet/faiz köprüsü (P2)

Rant tahvil/AB kanalı: **298.3** mn USD/yıl
Faiz vekili (× gerçekleşme finans): **11.7** mn USD
TR finans vekili ek: **0.0019** → kopru son TR net **-1.458**

## İç faiz alacaklı payları (Lm K sütunu)

- **H:** 0.0
- **F:** 0.2009
- **B:** 0.5427
- **D:** 0.2563
