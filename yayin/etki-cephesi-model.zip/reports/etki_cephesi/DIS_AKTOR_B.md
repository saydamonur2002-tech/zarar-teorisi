# Senaryo B — dış aktör kazanç (vekil)

Kaynak: `dis_aktör_pay.json` + `ulkeler_bolge.json` + ikame + merkez sızıntı. `*` Belirsiz M = `merkez_belirsiz.json` eşit pay (fayda Σ'ye eklenmez).

MFIN kenar **16.867** | belirsiz havuz **3.862** | **36** ülke × **0.1073**

| Aktör | Kazanç Σ | Kanal | Matris | İkame | Merkez | Belirsiz M* |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Merkez finans (vekil) | 16.867 | 0.0 | 0.0 | 0.0 | 16.867 | 0.0 |
| Çin | 11.543 | 6.186 | 3.726 | 1.631 | 0.0 | 0.1073 |
| Rusya | 11.113 | 5.808 | 3.3 | 2.005 | 0.0 | 0.1073 |
| AB (Balkan vekil) | 10.411 | 5.206 | 4.296 | 0.909 | 0.0 | 0.1073 |
| ABD | 7.478 | 3.2 | 3.312 | 0.966 | 0.0 | 0.1073 |
| İran | 5.779 | 2.455 | 2.737 | 0.587 | 0.0 | 0.1073 |
| İsrail | 2.981 | 1.402 | 1.134 | 0.445 | 0.0 | 0.1073 |
| BAE | 2.912 | 1.16 | 1.425 | 0.327 | 0.0 | 0.1073 |
| Suudi Arabistan | 2.614 | 1.078 | 1.105 | 0.431 | 0.0 | 0.1073 |
| Fransa | 1.838 | 1.06 | 0.612 | 0.166 | 0.0 | 0.1073 |
| Mısır | 1.781 | 0.952 | 0.563 | 0.266 | 0.0 | 0.1073 |
| Yunanistan | 1.278 | 0.813 | 0.335 | 0.13 | 0.0 | 0.1073 |
| Kıbrıs Rum Kesimi (vekil) | 0.245 | 0.0 | 0.245 | 0.0 | 0.0 | 0.1073 |
| Ukrayna (vekil) | 0.058 | 0.0 | 0.058 | 0.0 | 0.0 | 0.1073 |

## Birleşik (dış kazanç − havza kaybı)

| Aktör | Dış kazanç | Havza kayıp | Belirsiz M* | Net | Durum |
| --- | ---: | ---: | ---: | ---: | --- |
| Merkez finans (vekil) | 16.867 | 0.0 | 0.0 | 16.867 | dis_kazanc |
| Çin | 11.543 | 0.0 | 0.107 | 11.543 | dis_kazanc |
| Rusya | 11.113 | 0.0 | 0.107 | 11.113 | dis_kazanc |
| AB (Balkan vekil) | 10.411 | 0.0 | 0.107 | 10.411 | dis_kazanc |
| ABD | 7.478 | 0.0 | 0.107 | 7.478 | dis_kazanc |
| İran | 5.779 | 0.674 | 0.107 | 5.105 | dis_kazanc |
| BAE | 2.912 | 0.0 | 0.107 | 2.912 | dis_kazanc |
| Suudi Arabistan | 2.614 | 0.0 | 0.107 | 2.614 | dis_kazanc |
| İsrail | 2.981 | 0.487 | 0.107 | 2.494 | dis_kazanc |
| Fransa | 1.838 | 0.0 | 0.107 | 1.838 | dis_kazanc |
| Yunanistan | 1.278 | 0.0 | 0.107 | 1.278 | dis_kazanc |
| Mısır | 1.781 | 0.891 | 0.107 | 0.89 | dis_kazanc |
| Kıbrıs Rum Kesimi (vekil) | 0.245 | 0.413 | 0.107 | -0.168 | havza_kayip |
| Tunus | 0.0 | 0.404 | 0.107 | -0.404 | havza_kayip |
| Kuzey Makedonya | 0.0 | 0.409 | 0.107 | -0.409 | havza_kayip |
| Arnavutluk | 0.0 | 0.416 | 0.107 | -0.416 | havza_kayip |
| Tacikistan | 0.0 | 0.433 | 0.107 | -0.433 | havza_kayip |
| Kırgızistan | 0.0 | 0.462 | 0.107 | -0.462 | havza_kayip |
| Bosna-Hersek | 0.0 | 0.49 | 0.107 | -0.49 | havza_kayip |
| Ermenistan | 0.0 | 0.503 | 0.107 | -0.503 | havza_kayip |
| Türkmenistan | 0.0 | 0.57 | 0.107 | -0.57 | havza_kayip |
| Gürcistan | 0.0 | 0.615 | 0.107 | -0.615 | havza_kayip |
| Azerbaycan | 0.0 | 0.641 | 0.107 | -0.641 | havza_kayip |
| Cezayir | 0.0 | 0.688 | 0.107 | -0.688 | havza_kayip |
| Özbekistan | 0.0 | 0.724 | 0.106 | -0.724 | havza_kayip |
| Kazakistan | 0.0 | 0.775 | 0.107 | -0.775 | havza_kayip |
| Ukrayna (vekil) | 0.058 | 0.866 | 0.107 | -0.808 | havza_kayip |
| Fas | 0.0 | 0.909 | 0.107 | -0.909 | havza_kayip |
| Sırbistan | 0.0 | 0.913 | 0.107 | -0.913 | havza_kayip |
| Bulgaristan | 0.0 | 0.914 | 0.107 | -0.914 | havza_kayip |
