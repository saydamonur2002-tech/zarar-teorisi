# Senaryo B — dış aktör kazanç (vekil)

Kaynak: `dis_aktör_pay.json` + `ulkeler_bolge.json` + ikame + merkez sızıntı. `*` Belirsiz M = `merkez_belirsiz.json` eşit pay (fayda Σ'ye eklenmez).

MFIN kenar **27.997** | belirsiz havuz **3.865** | **36** ülke × **0.1074**

| Aktör | Kazanç Σ | Kanal | Matris | İkame | Merkez | Belirsiz M* |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Merkez finans (vekil) | 27.997 | 0.0 | 0.0 | 0.0 | 27.997 | 0.0 |
| Çin | 11.543 | 6.186 | 3.726 | 1.631 | 0.0 | 0.1074 |
| Rusya | 11.113 | 5.808 | 3.3 | 2.005 | 0.0 | 0.1074 |
| AB (Balkan vekil) | 10.411 | 5.206 | 4.296 | 0.909 | 0.0 | 0.1074 |
| ABD | 7.478 | 3.2 | 3.312 | 0.966 | 0.0 | 0.1074 |
| İran | 5.779 | 2.455 | 2.737 | 0.587 | 0.0 | 0.1074 |
| İsrail | 2.981 | 1.402 | 1.134 | 0.445 | 0.0 | 0.1074 |
| BAE | 2.912 | 1.16 | 1.425 | 0.327 | 0.0 | 0.1074 |
| Suudi Arabistan | 2.614 | 1.078 | 1.105 | 0.431 | 0.0 | 0.1074 |
| Fransa | 1.838 | 1.06 | 0.612 | 0.166 | 0.0 | 0.1074 |
| Mısır | 1.781 | 0.952 | 0.563 | 0.266 | 0.0 | 0.1074 |
| Yunanistan | 1.278 | 0.813 | 0.335 | 0.13 | 0.0 | 0.1074 |
| Kıbrıs Rum Kesimi (vekil) | 0.245 | 0.0 | 0.245 | 0.0 | 0.0 | 0.1074 |
| Ukrayna (vekil) | 0.058 | 0.0 | 0.058 | 0.0 | 0.0 | 0.1074 |

## Birleşik (dış kazanç − havza kaybı)

`—` = bilinmiyor (modellenmedi), sıfır değil. `†` = kısmi kapsam (kazancın yalnız bir kanalı modelli). Net yalnız kazanç ve kayıp ikisi de tam modelliyse yazılır.

| Aktör | Dış kazanç | Havza kayıp | Belirsiz M* | Net | Kapsam | Durum |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| Merkez finans (vekil) | 27.997 | n/a | 0.0 | 27.997 | tam | dis_kazanc |
| Çin | 11.543 | — | 0.107 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| Rusya | 11.113 | — | 0.107 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| AB (Balkan vekil) | 10.411 | — | 0.107 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| ABD | 7.478 | — | 0.107 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| İran | 5.779 | 0.674 | 0.107 | 5.105 | tam | dis_kazanc |
| BAE | 2.912 | — | 0.107 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| Suudi Arabistan | 2.614 | — | 0.107 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| İsrail | 2.981 | 0.487 | 0.107 | 2.494 | tam | dis_kazanc |
| Fransa | 1.838 | — | 0.107 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| Yunanistan | 1.278 | — | 0.107 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| Mısır | 1.781 | 0.891 | 0.107 | 0.89 | tam | dis_kazanc |
| Kıbrıs Rum Kesimi (vekil) | 0.245† | 0.413 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Tunus | 0.0† | 0.404 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Kuzey Makedonya | 0.0† | 0.409 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Arnavutluk | 0.0† | 0.416 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Tacikistan | 0.0† | 0.433 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Kırgızistan | 0.0† | 0.462 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Bosna-Hersek | 0.0† | 0.49 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Ermenistan | 0.0† | 0.503 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Türkmenistan | 0.0† | 0.57 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Gürcistan | 0.0† | 0.615 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Azerbaycan | 0.0 | 0.641 | 0.107 | -0.641 | tam | havza_kayip |
| Cezayir | 0.0† | 0.688 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Özbekistan | 0.0† | 0.724 | 0.106 | bilinmiyor | kazanç kismi | belirsiz |
| Kazakistan | 0.0† | 0.775 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Ukrayna (vekil) | 0.058† | 0.866 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Fas | 0.0† | 0.909 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Sırbistan | 0.0 | 0.913 | 0.107 | -0.913 | tam | havza_kayip |
| Bulgaristan | 0.0† | 0.914 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Libya | 0.0† | 0.95 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Somali | 0.0† | 1.079 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Suriye | 0.0† | 1.473 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Lübnan | 0.0† | 1.52 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Körfez (vekil) | — | 2.606 | 0.107 | bilinmiyor | kazanç yok | belirsiz |
| Irak | 0.0† | 3.307 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Türkiye | 0.0 | 41.76 | 0.0 | -41.76 | tam | havza_kayip |
