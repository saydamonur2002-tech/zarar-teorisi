# Senaryo B — dış aktör kazanç (vekil)

Kaynak: `dis_aktör_pay.json` + `ulkeler_bolge.json` + ikame + merkez sızıntı. `*` Belirsiz M = `merkez_belirsiz.json` eşit pay (fayda Σ'ye eklenmez).

MFIN kenar **27.997** | belirsiz havuz **3.865** | **36** ülke × **0.1074**

| Aktör | Kazanç Σ | Kanal | Matris | İkame | Merkez | Belirsiz M* |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Merkez finans (vekil) | 19.296 | 0.0 | 0.0 | 0.0 | 19.296 | 0.0 |
| Çin | 3.692 | 0.0 | 2.568 | 1.124 | 0.0 | 0.1074 |
| Rusya | 3.656 | 0.0 | 2.274 | 1.382 | 0.0 | 0.1074 |
| AB (Balkan vekil) | 3.587 | 0.0 | 2.961 | 0.626 | 0.0 | 0.1074 |
| ABD | 2.949 | 0.0 | 2.283 | 0.666 | 0.0 | 0.1074 |
| İran | 2.291 | 0.0 | 1.887 | 0.404 | 0.0 | 0.1074 |
| BAE | 1.207 | 0.0 | 0.982 | 0.225 | 0.0 | 0.1074 |
| İsrail | 1.088 | 0.0 | 0.781 | 0.307 | 0.0 | 0.1074 |
| Suudi Arabistan | 1.058 | 0.0 | 0.761 | 0.297 | 0.0 | 0.1074 |
| Mısır | 0.571 | 0.0 | 0.388 | 0.183 | 0.0 | 0.1074 |
| Fransa | 0.537 | 0.0 | 0.422 | 0.115 | 0.0 | 0.1074 |
| Yunanistan | 0.321 | 0.0 | 0.231 | 0.09 | 0.0 | 0.1074 |
| Kıbrıs Rum Kesimi (vekil) | 0.169 | 0.0 | 0.169 | 0.0 | 0.0 | 0.1074 |
| Ukrayna (vekil) | 0.04 | 0.0 | 0.04 | 0.0 | 0.0 | 0.1074 |

## Birleşik (dış kazanç − havza kaybı)

`—` = bilinmiyor (modellenmedi), sıfır değil. `†` = kısmi kapsam (kazancın yalnız bir kanalı modelli). `‡` = kayıp modelde yok; referans aktörlerin (İran, İsrail, Mısır) medyan kayıp/kazanç oranıyla VEKİL (± yarı aralık). Net yalnız kazanç ve kayıp ikisi de tam modelliyse kesin yazılır.

| Aktör | Dış kazanç | Havza kayıp | Belirsiz M* | Net | Kapsam | Durum |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| Merkez finans (vekil) | 19.296 | ≈8.637‡ | 0.0 | ≈10.659‡ (±12.217) | kayıp bilinmiyor | dis_kazanc |
| Çin | 3.692 | ≈1.653‡ | 0.107 | ≈2.039‡ (±2.337) | kayıp bilinmiyor | dis_kazanc |
| Rusya | 3.656 | ≈1.636‡ | 0.107 | ≈2.02‡ (±2.315) | kayıp bilinmiyor | dis_kazanc |
| AB (Balkan vekil) | 3.587 | ≈1.606‡ | 0.107 | ≈1.981‡ (±2.271) | kayıp bilinmiyor | dis_kazanc |
| ABD | 2.949 | ≈1.32‡ | 0.107 | ≈1.629‡ (±1.867) | kayıp bilinmiyor | dis_kazanc |
| İran | 2.291 | 0.674 | 0.107 | 1.617 | tam | dis_kazanc |
| BAE | 1.207 | ≈0.54‡ | 0.107 | ≈0.667‡ (±0.764) | kayıp bilinmiyor | dis_kazanc |
| Suudi Arabistan | 1.058 | ≈0.474‡ | 0.107 | ≈0.584‡ (±0.67) | kayıp bilinmiyor | dis_kazanc |
| İsrail | 1.088 | 0.487 | 0.107 | 0.601 | tam | dis_kazanc |
| Fransa | 0.537 | ≈0.24‡ | 0.107 | ≈0.297‡ (±0.34) | kayıp bilinmiyor | dis_kazanc |
| Yunanistan | 0.321 | ≈0.144‡ | 0.107 | ≈0.177‡ (±0.203) | kayıp bilinmiyor | dis_kazanc |
| Kıbrıs Rum Kesimi (vekil) | 0.169† | 0.413 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Mısır | 0.571 | 0.891 | 0.107 | -0.32 | tam | havza_kayip |
| Tunus | 0.0† | 0.404 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Kuzey Makedonya | 0.0† | 0.409 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Arnavutluk | 0.0† | 0.416 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Tacikistan | 0.0† | 0.433 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Kırgızistan | 0.0† | 0.462 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Bosna-Hersek | 0.0† | 0.49 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Ermenistan | 0.0† | 0.503 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Türkmenistan | 0.0† | 0.57 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Gürcistan | 0.0† | 0.615 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Azerbaycan | 0.0 | 0.641 | 0.107 | -0.641 | tam | havza_kayip |
| Cezayir | 0.0† | 0.688 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Özbekistan | 0.0† | 0.724 | 0.106 | bilinmiyor | kazanç kismi | belirsiz |
| Kazakistan | 0.0† | 0.775 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Ukrayna (vekil) | 0.04† | 0.866 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Fas | 0.0† | 0.909 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Sırbistan | 0.0 | 0.913 | 0.107 | -0.913 | tam | havza_kayip |
| Bulgaristan | 0.0† | 0.914 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Libya | 0.0† | 0.95 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Somali | 0.0† | 1.079 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Suriye | 0.0† | 1.473 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Lübnan | 0.0† | 1.52 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Körfez (vekil) | — | 2.606 | 0.107 | bilinmiyor | kazanç yok | belirsiz |
| Irak | 0.0† | 3.307 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Türkiye | 0.0 | 41.76 | 0.0 | -41.76 | tam | havza_kayip |
