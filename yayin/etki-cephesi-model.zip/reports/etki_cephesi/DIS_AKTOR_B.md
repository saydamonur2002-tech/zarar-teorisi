# Senaryo B — dış aktör kazanç (vekil)

Kaynak: `dis_aktör_pay.json` + `ulkeler_bolge.json` + ikame + merkez sızıntı. `*` Belirsiz M = `merkez_belirsiz.json` eşit pay (fayda Σ'ye eklenmez).

MFIN kenar **27.997** | belirsiz havuz **3.865** | **36** ülke × **0.1074**

| Aktör | Kazanç Σ | Kanal | Matris | İkame | Merkez | Belirsiz M* |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Merkez finans (vekil) | 17.539 | 0.0 | 0.0 | 0.0 | 17.539 | 0.0 |
| AB (Balkan vekil) | 2.691 | 0.0 | 2.691 | 0.0 | 0.0 | 0.1074 |
| Çin | 2.334 | 0.0 | 2.334 | 0.0 | 0.0 | 0.1074 |
| ABD | 2.075 | 0.0 | 2.075 | 0.0 | 0.0 | 0.1074 |
| Rusya | 2.067 | 0.0 | 2.067 | 0.0 | 0.0 | 0.1074 |
| İran | 1.715 | 0.0 | 1.715 | 0.0 | 0.0 | 0.1074 |
| BAE | 0.892 | 0.0 | 0.892 | 0.0 | 0.0 | 0.1074 |
| İsrail | 0.71 | 0.0 | 0.71 | 0.0 | 0.0 | 0.1074 |
| Suudi Arabistan | 0.692 | 0.0 | 0.692 | 0.0 | 0.0 | 0.1074 |
| Fransa | 0.383 | 0.0 | 0.383 | 0.0 | 0.0 | 0.1074 |
| Mısır | 0.353 | 0.0 | 0.353 | 0.0 | 0.0 | 0.1074 |
| Yunanistan | 0.21 | 0.0 | 0.21 | 0.0 | 0.0 | 0.1074 |
| Kıbrıs Rum Kesimi (vekil) | 0.154 | 0.0 | 0.154 | 0.0 | 0.0 | 0.1074 |
| Ukrayna (vekil) | 0.036 | 0.0 | 0.036 | 0.0 | 0.0 | 0.1074 |

## Birleşik (dış kazanç − havza kaybı)

`—` = bilinmiyor (modellenmedi), sıfır değil. `†` = kısmi kapsam (kazancın yalnız bir kanalı modelli). `‡` = kayıp modelde yok; referans aktörlerin (İran, İsrail, Mısır) medyan kayıp/kazanç oranıyla VEKİL (± yarı aralık); Çin ve Rusya için kayıp dış ticaret verisinden (ihracat gelirinin ortak ülke kayıplarına duyarlılığı × referans aktörlerden kalibre φ). Net yalnız kazanç ve kayıp ikisi de tam modelliyse kesin yazılır.

| Aktör | Dış kazanç | Havza kayıp | Belirsiz M* | Net | Kapsam | Durum |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| Merkez finans (vekil) | 17.539 | ≈12.03‡ | 0.0 | ≈5.509‡ (±18.688) | kayıp bilinmiyor | dis_kazanc |
| AB (Balkan vekil) | 2.691 | ≈19.083‡ | 0.107 | ≈-16.392‡ (±15.96) | kayıp bilinmiyor | dis_kazanc |
| Çin | 2.334 | ≈8.576‡ | 0.107 | ≈-6.242‡ (±7.173) | kayıp bilinmiyor | dis_kazanc |
| ABD | 2.075 | ≈2.534‡ | 0.107 | ≈-0.459‡ (±2.119) | kayıp bilinmiyor | dis_kazanc |
| Rusya | 2.067 | ≈7.301‡ | 0.107 | ≈-5.234‡ (±6.106) | kayıp bilinmiyor | dis_kazanc |
| İran | 1.715 | 0.674 | 0.107 | 1.041 | tam | dis_kazanc |
| BAE | 0.892 | ≈5.057‡ | 0.107 | ≈-4.165‡ (±4.23) | kayıp bilinmiyor | dis_kazanc |
| Suudi Arabistan | 0.692 | ≈0.583‡ | 0.107 | ≈0.109‡ (±0.488) | kayıp bilinmiyor | dis_kazanc |
| Fransa | 0.383 | ≈2.254‡ | 0.107 | ≈-1.871‡ (±1.886) | kayıp bilinmiyor | dis_kazanc |
| İsrail | 0.71 | 0.487 | 0.107 | 0.223 | tam | dis_kazanc |
| Yunanistan | 0.21 | ≈1.015‡ | 0.107 | ≈-0.805‡ (±0.849) | kayıp bilinmiyor | dis_kazanc |
| Kıbrıs Rum Kesimi (vekil) | 0.154† | 0.413 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Tunus | 0.0† | 0.404 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Kuzey Makedonya | 0.0† | 0.409 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Arnavutluk | 0.0† | 0.416 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Tacikistan | 0.0† | 0.433 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Kırgızistan | 0.0† | 0.462 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Bosna-Hersek | 0.0† | 0.49 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Ermenistan | 0.0† | 0.503 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Mısır | 0.353 | 0.891 | 0.107 | -0.538 | tam | havza_kayip |
| Türkmenistan | 0.0† | 0.57 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Gürcistan | 0.0† | 0.615 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Azerbaycan | 0.0 | 0.641 | 0.107 | -0.641 | tam | havza_kayip |
| Cezayir | 0.0† | 0.688 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Özbekistan | 0.0† | 0.724 | 0.106 | bilinmiyor | kazanç kismi | belirsiz |
| Kazakistan | 0.0† | 0.775 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Ukrayna (vekil) | 0.036† | 0.866 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Fas | 0.0† | 0.909 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Sırbistan | 0.0 | 0.913 | 0.107 | -0.913 | tam | havza_kayip |
| Bulgaristan | 0.0† | 0.914 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Libya | 0.0† | 0.95 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Somali | 0.0† | 1.079 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Suriye | 0.0† | 1.473 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Lübnan | 0.0† | 1.52 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Körfez (vekil) | — | 2.606 | 0.107 | bilinmiyor | kazanç yok | belirsiz |
| Irak | 0.0† | 3.307 | 0.107 | bilinmiyor | kazanç kismi | belirsiz |
| Türkiye | 0.0 | 41.76 | 0.0 | -41.76 | tam | havza_kayip |
