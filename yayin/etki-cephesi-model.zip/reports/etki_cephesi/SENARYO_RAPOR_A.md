# Senaryo A — ayrıntılı rapor

Üç senaryo (A, B, C) için aynı bölümler ve alanlar. Referans etiketi ayrıcalık değildir.

## 1. Tanım (senaryo parametreleri)

| Alan | Değer |
| --- | ---: |
| Ad | Atıl bağ — pasif tutum |
| Olasılık (kapı iskeleti, gözlem yokken tekdüze) | 0.333 |
| Etki erozyonu çarpanı | 0.35 |
| TR diplomatik esneklik | 0 |
| Merkez sızıntı çarpanı (geçmişten, A=1) | 1 |
| Merkez sızıntı çarpanı (eski, atanmış) | 1 |
| Bağ modu kullanım / atıl / araçsal | 0.22 / 0.5 / 0.28 |

## 2. Projeksiyon (10 yıl vekil)

| Alan | Değer |
| --- | ---: |
| TR yarıçevre boşalma | 24.952 |
| Merkez finans sızıntı Σ | 13.133 |
| MFIN kenar Σ | 9.192 |
| Tüm havza rant Σ | 1.984 |
| Merkez + rant Σ | 15.117 |
| Pasif boşluk Σ | 5.566 |
| Araçsallaşma Σ | 1.946 |
| Temsil zedesi Σ | 2.688 |
| Dış mimari Σ | 3.608 |
| İç dinamik tıkanma | 0.642 |

## 3. Akış ölçümü (USD köprüsü, mn $)

| Alan | Değer |
| --- | ---: |
| MFIN kenar | 11,456.4 |
| Belirsiz merkez | 4,911.8 |
| Merkez toplam | 16,368.3 |
| Rant toplam | 2,472.7 |

## 4. Zarar çözümü (beş adım varsayımı)

| Alan | Değer |
| --- | ---: |
| TR net ham | -25.822 |
| TR net çözüm sonrası | -19.137 |
| TR net farkı | 6.685 |
| TR boşalma ham → sonrası | 24.952 → 21.247 |

## 5. Üretim iç akışı ve finans katmanı

| Alan | Değer |
| --- | ---: |
| Üretim iç akış TR net | -13.49 |
| Üretim: sıfır yılı tahmini | 2067 |
| Finans katmanı TR net | -7.87 |
| Finans: sıfır üstü takvim yılı | 2050 |
| Üretime bağlanma gerçekleşmesi g_u (bağ kullanımı / C) | 0.423 |
| Finans dış koşul gerçekleşmesi g_f (politika / C; < 0: ters çevrilmiş) | 0.737 |
| Finans ters çevrildi (araçsallaşma) | hayır |
| Finans TR net: çevrilmemiş olsaydı (varsayım bandı üstü) | — |
| Finans etiketi | varsayim_carpanli_ham |

## 6. Stok-akış (SFC, tr TL)

| Alan | Değer |
| --- | ---: |
| Matris dönemi / kur | 2026-Q1 / 44.38 |
| H | 0 |
| F | -1.886 |
| B | 0 |
| K | 0 |
| D | 1.886 |
| Kapanış (Σ=0) | evet |
| F.4 stok 2036, baz (mr TL) | 25,339.8 |
| F.4 stok 2036, silme %20 varsayımı | 20,271.8 |

## 7. Gerçeklik kalibrasyonu

| Alan | Değer |
| --- | ---: |
| TR net son (kalibre) | -16.809 |
| GSYH % | 5.025 |
| TR net 10. yıl yolu | -19.368 |
| Yol modu (finans üretimle eşzamanlı mı) | uretimle_es_zamanli |
| Finans kalibre gerçekleşme r_f (tersse harm: tavan yok) | 0.209 |
| Gerçekleşme: zarar / üretim / finans | 0.49 / 0.237 / 0.209 |

## 8. Dış rant parasal akışı

| Alan | Değer |
| --- | ---: |
| Boşluk rantı toplam (vekil) | 7.895 |
| Refah dış toplam (vekil) | 1.984 |
| Refah TR iç toplam (vekil) | 0.905 |
| Boşluk rantı (mn $) | 42,499.9 |
| Refah dış (mn $) | 10,680.1 |

## 9. Uluslararası stok-akış

| Alan | Değer |
| --- | ---: |
| Kapanış tamam | evet |
| Havza net stok (mn $) | 89,101.7 |
| Havza kayıp brüt kenar (mn $) | 216,391.5 |
| Merkez sızıntı (mn $) | 49,820.4 |
| Kanal ikame (mn $) | 65,426.7 |

## 10. Dış aktörlerin kaybın devamlılığı için maliyeti (varsayım)

| Alan | Değer |
| --- | ---: |
| Maliyet katsayısı κ × TR karşı-hamle gücü pol | 0.2 × 0.7 |
| Σ sürdürme maliyeti (TR, MFIN hariç) | 1.982 |
| Σ dış kazanç (TR, MFIN hariç) | 14.14 |
| Maliyet / kazanç | 0.14 |
| Kazançtan maliyet düşülünce Σ dış net | 12.158 |

## 11. Merkez finans (MFIN) ayrı pay (kayıp = referans vekil)

| Alan | Değer |
| --- | ---: |
| MFIN kazancı (sızıntı kenarları, normalize) | 7.825 |
| MFIN kaybı (referans-oran vekil, ±belirsizlik) | ≈3.445 (±6.156) |
| MFIN sürdürme maliyeti | 1.096 |
| MFIN net (kayıp ve maliyet düşülmüş) | 3.284 |
| MFIN payı / boşluk V | 0.308 |

## Ülke ve aktör ayrıntısı

- `ULKE_KAYIP_A.md`, `DIS_AKTOR_A.md`, `AKIS_OLCUM_A.md`, `ZARAR_COZUM_A.md`

## Not

**Yapısal sınır (A, B, C için aynı):** üretim ve finans katmanları senaryoya özgü gerçekleşmeyle kurulur: g_u = bağ kullanımı / C'ninki (üretime bağlama kanalı), g_f = politika gerçekleşmesi / C'ninki (dış koşul: erozyon, diplomatik esneklik). Etkin çarpan = 1 − g (1 − çarpan); C'de g = 1. Çarpanların kendisi (halka düzeltmesi, MFIN, TDS, iç tutma) tüm senaryolarda ortak ve atanmıştır; g türetilmiştir ama doğrusal ölçekleme varsayımdır. Baskın modu araçsal olan senaryoda (B) finans katmanı ters çevrilir (g_f < 0, ayna simetri, güç 1: varsayım; duyarlılık finans raporunda). F.4 stok yolu (bölüm 6) beş adımın kredi itişinden gelir ve senaryodan bağımsızdır; üç sütunda aynı olması senaryo farkı değil model yapısıdır. Finans katmanı kalibre yola bağlıdır (üretimle eşzamanlı yükselir); çarpanları atanmıştır. Olasılık ölçülmemiştir (gözlem yokken tekdüze); bu rapor senaryolar arasında sıra kurmaz.
