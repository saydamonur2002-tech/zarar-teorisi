# Senaryo A — ayrıntılı rapor

Üç senaryo (A, B, C) için aynı bölümler ve alanlar. Referans etiketi ayrıcalık değildir.

## 1. Tanım (senaryo parametreleri)

| Alan | Değer |
| --- | ---: |
| Ad | Atıl bağ — pasif tutum |
| Olasılık (kapı iskeleti, gözlem yokken tekdüze) | 0.333 |
| Etki erozyonu çarpanı | 0.35 |
| TR diplomatik esneklik | 0 |
| Merkez sızıntı çarpanı | 1 |
| Bağ modu kullanım / atıl / araçsal | 0.22 / 0.5 / 0.28 |

## 2. Projeksiyon (10 yıl vekil)

| Alan | Değer |
| --- | ---: |
| TR yarıçevre boşalma | 24.952 |
| Merkez finans sızıntı Σ | 13.133 |
| MFIN kenar Σ | 9.192 |
| Tüm havza rant Σ | 1.984 |
| Merkez + rant Σ | 15.117 |
| Pasif boşluk Σ | 5.566 |
| Araçsallaşma Σ | 1.946 |
| Temsil zedesi Σ | 2.688 |
| Dış mimari Σ | 3.608 |
| İç dinamik tıkanma | 0.642 |

## 3. Akış ölçümü (USD köprüsü, mn $)

| Alan | Değer |
| --- | ---: |
| MFIN kenar | 11,456.4 |
| Belirsiz merkez | 4,911.8 |
| Merkez toplam | 16,368.3 |
| Rant toplam | 2,472.7 |

## 4. Zarar çözümü (beş adım varsayımı)

| Alan | Değer |
| --- | ---: |
| TR net ham | -25.822 |
| TR net çözüm sonrası | -19.137 |
| TR net farkı | 6.685 |
| TR boşalma ham → sonrası | 24.952 → 21.247 |

## 5. Üretim iç akışı ve finans katmanı

| Alan | Değer |
| --- | ---: |
| Üretim iç akış TR net | -6.338 |
| Üretim: sıfır yılı tahmini | 2044 |
| Finans katmanı TR net | -2.253 |
| Finans: sıfır üstü takvim yılı | 2042 |
| Finans etiketi | varsayim_carpanli_ham |

## 6. Stok-akış (SFC, tr TL)

| Alan | Değer |
| --- | ---: |
| Matris dönemi / kur | 2026-Q1 / 44.38 |
| H | 0 |
| F | -1.886 |
| B | 0 |
| K | 0 |
| D | 1.886 |
| Kapanış (Σ=0) | evet |
| F.4 stok 2036, baz (mr TL) | 25,339.8 |
| F.4 stok 2036, silme %20 varsayımı | 20,271.8 |

## 7. Gerçeklik kalibrasyonu

| Alan | Değer |
| --- | ---: |
| TR net son (kalibre) | -16.314 |
| GSYH % | 4.54 |
| TR net 10. yıl yolu | -19.547 |
| Gerçekleşme: zarar / üretim / finans | 0.49 / 0.175 / 0.154 |

## 8. Dış rant parasal akışı

| Alan | Değer |
| --- | ---: |
| Boşluk rantı toplam (vekil) | 7.895 |
| Refah dış toplam (vekil) | 1.984 |
| Refah TR iç toplam (vekil) | 0.905 |
| Boşluk rantı (mn $) | 42,499.9 |
| Refah dış (mn $) | 10,680.1 |

## 9. Uluslararası stok-akış

| Alan | Değer |
| --- | ---: |
| Kapanış tamam | evet |
| Havza net stok (mn $) | 21,947.1 |
| Havza kayıp brüt kenar (mn $) | 216,391.5 |
| Merkez sızıntı (mn $) | 57,179.1 |
| Kanal ikame (mn $) | 125,222.6 |

## Ülke ve aktör ayrıntısı

- `ULKE_KAYIP_A.md`, `DIS_AKTOR_A.md`, `AKIS_OLCUM_A.md`, `ZARAR_COZUM_A.md`

## Not

**Yapısal sınır (A, B, C için aynı):** üretim iç akışı ve finans katmanı A ve B için C tabanından ölçeklenir (`politika_C_bazli`, `merkez_sizinti_C_bazli`). Bu bölümlerde A/B bağımsız modellenmemiştir; fark çarpandan gelir. F.4 stok yolu (bölüm 6) beş adımın kredi itişinden gelir ve senaryodan bağımsızdır; üç sütunda aynı olması senaryo farkı değil model yapısıdır. Olasılık ölçülmemiştir (gözlem yokken tekdüze); bu rapor senaryolar arasında sıra kurmaz.
