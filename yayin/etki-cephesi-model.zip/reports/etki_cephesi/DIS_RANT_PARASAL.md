# Dış rant kanalları — parasal akış (zarar vs refah)

Senaryo **C** · rant modeli **refah** · 1 rant vekil ≈ **5,383.14** mn USD

## Özet (mn USD / yıl vekili)

| | Vekil | USD |
| --- | ---: | ---: |
| Zarar (boşluk rant) | 4.189 | 22,550.0 |
| Refah — dış havuz | 1.12 | 6,029.1 |
| Refah — TR iç | 0.509 | 2,740.0 |
| Fark (boşluk−refah dış) | — | **16,520.9** |
| TR refah iç | 0.509 | 2,740.0 |
| **TR toplam refah kazancı** | — | **19,260.9** |

## Kanal dağılımı — AKIS eşleşmeli

Etiketler `kalibre/rant_kanal_akis_eslesme.json` ile `AKIS_OLCUM.rant_kanal_usd_vekili` anahtarına indirgenir.

| AKIS kanal | AKIS pay | Refah dış pay | Zarar USD | Refah dış USD | Fark |
| --- | ---: | ---: | ---: | ---: | ---: |
| refah_rant | 0.3265 | 0.3265 | 7,254.2 | 1,968.4 | 5,285.8 |
| boru | 0.0690 | 0.0690 | 1,503.7 | 416.3 | 1,087.4 |
| enerji | 0.0510 | 0.0510 | 1,213.9 | 307.3 | 906.6 |
| montaj_ihale | 0.0481 | 0.0481 | 1,154.2 | 290.2 | 864.0 |
| transit | 0.0587 | 0.0587 | 1,081.6 | 353.9 | 727.6 |
| fon_liman | 0.0392 | 0.0392 | 1,020.6 | 236.4 | 784.1 |
| ihale | 0.0378 | 0.0378 | 1,021.9 | 227.9 | 794.0 |
| petro_dolar | 0.0336 | 0.0336 | 884.6 | 202.8 | 681.9 |
| liman | 0.0420 | 0.0420 | 815.1 | 253.5 | 561.6 |
| savunma_tedarik | 0.0354 | 0.0354 | 750.1 | 213.5 | 536.5 |
| AB_fon | 0.0321 | 0.0321 | 768.0 | 193.3 | 574.7 |
| tahvil | 0.0174 | 0.0174 | 780.6 | 105.0 | 675.6 |
| LNG | 0.0222 | 0.0222 | 676.5 | 134.1 | 542.4 |
| maden | 0.0310 | 0.0310 | 590.4 | 187.1 | 403.3 |
| tahıl | 0.0226 | 0.0226 | 549.1 | 136.4 | 412.7 |
| montaj | 0.0259 | 0.0259 | 523.5 | 156.1 | 367.4 |
| transit_rant | 0.0277 | 0.0277 | 482.7 | 166.9 | 315.8 |
| petrol | 0.0251 | 0.0251 | 465.6 | 151.2 | 314.5 |

## Ülke toplam (dış havuz)

- **EU:** refah 1,068.3 · zarar 4,182.3 · fark **3,113.9** mn $
- **CN:** refah 1,059.8 · zarar 3,688.6 · fark **2,628.8** mn $
- **RU:** refah 974.8 · zarar 3,299.0 · fark **2,324.2** mn $
- **US:** refah 952.7 · zarar 3,730.9 · fark **2,778.2** mn $
- **IR:** refah 653.6 · zarar 2,054.0 · fark **1,400.4** mn $
- **AE:** refah 365.5 · zarar 1,470.6 · fark **1,105.1** mn $
- **SA:** refah 240.5 · zarar 897.9 · fark **657.4** mn $
- **IL:** refah 237.8 · zarar 1,217.0 · fark **979.2** mn $
- **FR:** refah 158.1 · zarar 547.1 · fark **388.9** mn $
- **EG:** refah 116.2 · zarar 622.1 · fark **505.9** mn $
- **AZ:** refah 109.8 · zarar 326.9 · fark **217.1** mn $
- **GR:** refah 73.6 · zarar 452.3 · fark **378.7** mn $

## Dış ülkeler — rant kanalından alınan akış (mn USD/yıl vekili)

### Kanal → ülke (refah dış havuz, top)

| Kanal | Refah USD | Zarar USD | Fark | Önde gelen ülkeler |
| --- | ---: | ---: | ---: | --- |
| refah_rant | 1,968.3 | 7,254.3 | 5,286.0 | EU 346, US 319, RU 315, CN 304 |
| boru | 416.3 | 1,503.7 | 1,087.4 | CN 98, RU 93, US 75, IL 56 |
| transit | 353.9 | 1,081.5 | 727.6 | CN 136, IR 70, RU 63, US 55 |
| enerji | 307.3 | 1,213.9 | 906.6 | CN 74, RU 67, EU 58, IR 54 |
| montaj_ihale | 290.2 | 1,154.1 | 863.9 | EU 167, AE 40, CN 37, RU 26 |
| liman | 253.4 | 815.1 | 561.7 | EU 86, IR 35, RU 35, FR 33 |
| fon_liman | 236.5 | 1,020.5 | 784.0 | AE 66, US 51, SA 43, CN 40 |
| ihale | 227.8 | 1,021.9 | 794.1 | US 78, CN 44, IR 42, EU 21 |
| savunma_tedarik | 213.5 | 750.0 | 536.5 | RU 87, US 45, EU 44, AE 16 |
| petro_dolar | 202.8 | 884.6 | 681.8 | AE 66, US 51, SA 43, IR 22 |
| AB_fon | 193.3 | 767.9 | 574.6 | EU 142, CN 24, FR 21, RS 6 |
| maden | 187.1 | 590.4 | 403.3 | CN 112, RU 61, IR 14 |

### Ülke → kanal kırılımı (refah, top 8 ülke)

**EU** — refah **1,068.3** · zarar 4,182.3 mn $
  - refah_rant: refah 345.7 · zarar 1,313.7
  - montaj_ihale: refah 166.7 · zarar 657.8
  - AB_fon: refah 141.7 · zarar 570.1
  - liman: refah 85.9 · zarar 296.3
  - montaj: refah 68.2 · zarar 233.6
**CN** — refah **1,059.8** · zarar 3,688.6 mn $
  - refah_rant: refah 303.9 · zarar 1,048.4
  - transit: refah 136.2 · zarar 421.4
  - maden: refah 112.0 · zarar 359.5
  - boru: refah 97.6 · zarar 339.5
  - enerji: refah 73.5 · zarar 293.0
**RU** — refah **974.8** · zarar 3,299.0 mn $
  - refah_rant: refah 315.1 · zarar 1,066.2
  - transit_rant: refah 106.3 · zarar 305.9
  - boru: refah 92.7 · zarar 302.9
  - savunma_tedarik: refah 86.7 · zarar 312.3
  - enerji: refah 66.7 · zarar 245.6
**US** — refah **952.7** · zarar 3,730.9 mn $
  - refah_rant: refah 319.2 · zarar 1,226.3
  - ihale: refah 78.3 · zarar 328.8
  - boru: refah 74.6 · zarar 287.9
  - petrol_servis: refah 59.5 · zarar 189.2
  - petrol: refah 54.6 · zarar 163.9
**IR** — refah **653.6** · zarar 2,054.0 mn $
  - refah_rant: refah 231.1 · zarar 736.7
  - transit: refah 69.7 · zarar 195.6
  - petrol: refah 58.5 · zarar 183.1
  - enerji: refah 53.8 · zarar 148.1
  - petrol_servis: refah 42.1 · zarar 133.9
**AE** — refah **365.5** · zarar 1,470.6 mn $
  - refah_rant: refah 121.8 · zarar 490.2
  - petro_dolar: refah 65.8 · zarar 287.1
  - fon_liman: refah 65.8 · zarar 287.1
  - enerji: refah 40.1 · zarar 164.0
  - montaj_ihale: refah 40.1 · zarar 164.0
**SA** — refah **240.5** · zarar 897.9 mn $
  - refah_rant: refah 87.8 · zarar 325.6
  - petro_dolar: refah 43.2 · zarar 188.3
  - fon_liman: refah 43.2 · zarar 188.3
  - Süveyş: refah 29.3 · zarar 84.7
  - boru: refah 29.3 · zarar 84.7
**IL** — refah **237.8** · zarar 1,217.0 mn $
  - refah_rant: refah 73.3 · zarar 361.5
  - boru: refah 55.5 · zarar 228.9
  - tahvil: refah 35.6 · zarar 265.1
  - LNG: refah 30.5 · zarar 156.6
  - Süveyş: refah 25.0 · zarar 72.3
