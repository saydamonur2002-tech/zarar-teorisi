# Modül entegrasyonu — gerçeklik kalibre (10 yıl)

## TR net vekil yığını

| Aşama | TR net |
| --- | ---: |
| C + refah (taban) | -17.191 |
| 10y — zarar/üretim/finans (kalibre) | -13.366 |
| + yaşam maliyeti politikası | **-12.671** |
| **Toplam iyileşme** | **4.52** |

## GSYH % (USD orta köprü)

- Taban: **4.784%**
- 10y katmanlar (2036): **3.719%**
- Yaşam maliyeti dahil: **3.526%**

## Modül 1 — dış rant parasal akış

- Zarar (boşluk) USD: **22,550.0** mn/yıl vekili
- Refah dış USD: **6,029.1** mn
- TR refah iç: **2,740.0** mn
- Tasarruf refah vs zarar: **16,520.9** mn

## Modül 2 — yaşam maliyeti

- Hane tasarrufu 10y: **9,500.0** mn USD
- TR net ek iyileşme: **0.695** vekil
