# Senaryo B — ülke bazlı kayıp (10 yıl vekil)

| Ülke | Kayıp endeks | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Türkiye | 41.76 | -41.76 | 0.247 | 0.26 | 0.206 |
| Irak | 3.307 | -3.307 | 0.46 | 0.484 | 0.406 |
| Körfez (vekil) | 2.606 | -2.606 | 0.351 | 0.37 | 0.311 |
| Lübnan | 1.52 | -1.52 | 0.145 | 0.152 | 0.155 |
| Suriye | 1.473 | -1.473 | 0.192 | 0.203 | 0.206 |
| Somali | 1.079 | -1.079 | 0.051 | 0.054 | 0.055 |
| Libya | 0.95 | -0.95 | 0.128 | 0.134 | 0.101 |
| Bulgaristan | 0.914 | -0.914 | 0.14 | 0.148 | 0.098 |
| Sırbistan | 0.913 | -0.913 | 0.164 | 0.172 | 0.126 |
| Fas | 0.909 | -0.909 | 0.114 | 0.12 | 0.101 |
| Mısır | 0.891 | -0.891 | 0.213 | 0.224 | 0.176 |
| Ukrayna/Karadeniz (vekil) | 0.866 | -0.866 | 0.141 | 0.149 | 0.125 |
| Kazakistan | 0.775 | -0.775 | 0.123 | 0.13 | 0.109 |
| Özbekistan | 0.724 | -0.724 | 0.095 | 0.1 | 0.084 |
| Cezayir | 0.688 | -0.688 | 0.088 | 0.093 | 0.07 |
| İran | 0.674 | -0.674 | 0.204 | 0.215 | 0.174 |
| Azerbaycan | 0.641 | -0.641 | 0.142 | 0.149 | 0.125 |
| Gürcistan | 0.615 | -0.615 | 0.095 | 0.1 | 0.084 |
| Türkmenistan | 0.57 | -0.57 | 0.066 | 0.069 | 0.058 |
| Ermenistan | 0.503 | -0.503 | 0.073 | 0.077 | 0.065 |
| Bosna-Hersek | 0.49 | -0.49 | 0.068 | 0.072 | 0.048 |
| İsrail (vekil) | 0.487 | -0.487 | 0.072 | 0.076 | 0.057 |
| Kırgızistan | 0.462 | -0.462 | 0.048 | 0.051 | 0.043 |
| Tacikistan | 0.433 | -0.433 | 0.04 | 0.042 | 0.035 |
| Arnavutluk | 0.416 | -0.416 | 0.061 | 0.064 | 0.042 |
| Kıbrıs (vekil) | 0.413 | -0.413 | 0.061 | 0.065 | 0.049 |
| Kuzey Makedonya | 0.409 | -0.409 | 0.055 | 0.058 | 0.038 |
| Tunus | 0.404 | -0.404 | 0.057 | 0.06 | 0.04 |

## Levant — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Suriye | 1.473 | -1.473 | 0.192 | 0.203 | 0.206 |
| Lübnan | 1.52 | -1.52 | 0.145 | 0.152 | 0.155 |

## Orta Doğu (Fırat / Doğu Akdeniz) — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Irak | 3.307 | -3.307 | 0.46 | 0.484 | 0.406 |
| Kıbrıs (vekil) | 0.413 | -0.413 | 0.061 | 0.065 | 0.049 |
| İsrail (vekil) | 0.487 | -0.487 | 0.072 | 0.076 | 0.057 |
| Mısır | 0.891 | -0.891 | 0.213 | 0.224 | 0.176 |

## Körfez — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Körfez (vekil) | 2.606 | -2.606 | 0.351 | 0.37 | 0.311 |

## Kuzey Afrika — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Libya | 0.95 | -0.95 | 0.128 | 0.134 | 0.101 |
| Mısır | 0.891 | -0.891 | 0.213 | 0.224 | 0.176 |
| Tunus | 0.404 | -0.404 | 0.057 | 0.06 | 0.04 |
| Cezayir | 0.688 | -0.688 | 0.088 | 0.093 | 0.07 |
| Fas | 0.909 | -0.909 | 0.114 | 0.12 | 0.101 |

## Karadeniz — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Ukrayna/Karadeniz (vekil) | 0.866 | -0.866 | 0.141 | 0.149 | 0.125 |
| Sırbistan | 0.913 | -0.913 | 0.164 | 0.172 | 0.126 |

## Kafkasya — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Azerbaycan | 0.641 | -0.641 | 0.142 | 0.149 | 0.125 |
| Gürcistan | 0.615 | -0.615 | 0.095 | 0.1 | 0.084 |
| Ermenistan | 0.503 | -0.503 | 0.073 | 0.077 | 0.065 |

## Balkan — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Sırbistan | 0.913 | -0.913 | 0.164 | 0.172 | 0.126 |
| Bosna-Hersek | 0.49 | -0.49 | 0.068 | 0.072 | 0.048 |
| Arnavutluk | 0.416 | -0.416 | 0.061 | 0.064 | 0.042 |
| Kuzey Makedonya | 0.409 | -0.409 | 0.055 | 0.058 | 0.038 |
| Bulgaristan | 0.914 | -0.914 | 0.14 | 0.148 | 0.098 |

## Orta Asya — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Kazakistan | 0.775 | -0.775 | 0.123 | 0.13 | 0.109 |
| Özbekistan | 0.724 | -0.724 | 0.095 | 0.1 | 0.084 |
| Türkmenistan | 0.57 | -0.57 | 0.066 | 0.069 | 0.058 |
| Kırgızistan | 0.462 | -0.462 | 0.048 | 0.051 | 0.043 |
| Tacikistan | 0.433 | -0.433 | 0.04 | 0.042 | 0.035 |

## İran (yaricevre vekili) — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| İran | 0.674 | -0.674 | 0.204 | 0.215 | 0.174 |

## Afrika Boynu / geniş güney — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Somali | 1.079 | -1.079 | 0.051 | 0.054 | 0.055 |
