# Uzun vade eşikleri ve düzelme aralığı (10 yıl vekil)

Metrik: **TR net birleşik vekil** (negatif = kayıp). Taban senaryo **C**; zarar teorisi çözümü tam olgunlaşınca **7 yıl** vekili (HEKİS tam ölçek referansı).

## Yapısal eşikler (sabit)

| Eşik | TR net vekil | TR boşalma |
| --- | ---: | ---: |
| B — üst kötü (araçsallaşma) | -43.168 | 40.166 |
| A — pasif bağ | -26.471 | 24.952 |
| C — en olası (2026) | -18.015 | 17.172 |
| C + zarar çözümü (anlık tam) | -11.341 | 13.51 |

## Tahmini düzelme aralığı

- **2026 (C):** -18.015
- **2036 orta yol:** -11.341
- **2036 aralık:** -12.008 … -11.341
- **10 yıl iyileşme (orta):** 6.674 vekil birim

## Yıllık koridor

| Yıl | Olgunluk | Alt | Orta | Üst |
| --- | ---: | ---: | ---: | ---: |
| 2026 | 0.0 | -18.015 | -18.015 | -17.014 |
| 2027 | 0.143 | -17.379 | -17.062 | -16.203 |
| 2028 | 0.286 | -16.744 | -16.108 | -15.393 |
| 2029 | 0.429 | -16.108 | -15.155 | -14.583 |
| 2030 | 0.571 | -15.473 | -14.201 | -13.772 |
| 2031 | 0.714 | -14.837 | -13.248 | -12.962 |
| 2032 | 0.857 | -14.201 | -12.294 | -12.151 |
| 2033 | 1.0 | -13.566 | -11.341 | -11.341 |
| 2034 | 1.0 | -12.93 | -11.341 | -11.341 |
| 2035 | 1.0 | -12.294 | -11.341 | -11.341 |
| 2036 | 1.0 | -12.008 | -11.341 | -11.341 |

Görsel: `canvases/uzun-vade-esik-duzelme.canvas.tsx`
