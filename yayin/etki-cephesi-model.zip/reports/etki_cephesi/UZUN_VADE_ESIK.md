# Uzun vade eşikleri ve düzelme aralığı (10 yıl vekil)

Metrik: **TR net birleşik vekil** (negatif = kayıp). Taban senaryo **C**; zarar teorisi çözümü tam olgunlaşınca **7 yıl** vekili (HEKİS tam ölçek referansı).

## Yapısal eşikler (sabit)

| Eşik | TR net vekil | TR boşalma |
| --- | ---: | ---: |
| B — üst kötü (araçsallaşma) | -41.76 | 40.166 |
| A — pasif bağ | -25.822 | 24.952 |
| C — referans (2026) | -17.7 | 17.172 |
| C + zarar çözümü (anlık tam) | -13.113 | 14.622 |

## Tahmini düzelme aralığı

- **2026 (C):** -17.7
- **2036 orta yol:** -13.113
- **2036 aralık:** -13.572 … -13.113
- **10 yıl iyileşme (orta):** 4.587 vekil birim

## Yıllık koridor

| Yıl | Olgunluk | Alt | Orta | Üst |
| --- | ---: | ---: | ---: | ---: |
| 2026 | 0.0 | -17.7 | -17.7 | -17.012 |
| 2027 | 0.143 | -17.263 | -17.045 | -16.455 |
| 2028 | 0.286 | -16.826 | -16.389 | -15.898 |
| 2029 | 0.429 | -16.389 | -15.734 | -15.341 |
| 2030 | 0.571 | -15.953 | -15.079 | -14.784 |
| 2031 | 0.714 | -15.516 | -14.424 | -14.227 |
| 2032 | 0.857 | -15.079 | -13.768 | -13.67 |
| 2033 | 1.0 | -14.642 | -13.113 | -13.113 |
| 2034 | 1.0 | -14.205 | -13.113 | -13.113 |
| 2035 | 1.0 | -13.768 | -13.113 | -13.113 |
| 2036 | 1.0 | -13.572 | -13.113 | -13.113 |

Görsel: `canvases/uzun-vade-esik-duzelme.canvas.tsx`
