# Senaryo A/B/C — modül paketi (P2)

| Senaryo | TR net entegre | Refah dış USD mn | Fark (boşluk−refah) | Stok Σ | Kapanış |
| --- | ---: | ---: | ---: | ---: | --- |
| **A** | -24.917 | 10,680.1 | 31,819.7 | -0.0 | OK |
| **B** | -39.896 | 21,984.7 | 56,469.1 | 0.0 | OK |
| **C** | -17.191 | 6,029.1 | 16,520.9 | 0.0 | OK |

## Olasılık ağırlıklı beklenti

- P(A,B,C): {'A': 0.3333, 'B': 0.3333, 'C': 0.3333}
- Beklenen TR net entegre: **-27.335**
- Beklenen refah dış USD: **12,897.967** mn/yıl
- Beklenen fark (boşluk−refah): **34,936.567** mn

Ana raporlar (`DIS_ULKE_REFAH.json` …) senaryo **C** kopyasıdır.
