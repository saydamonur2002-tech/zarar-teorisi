# Akım ölçümü — USD (2024) ↔ vekil (Senaryo A)

**Çapa:** `birincil_gelir_yatirim_gideri` = **18,841.0** mn USD → model paketi (`merkez_artı_rant` = 15.117) için 1 vekil birim ≈ 1246.3 mn USD (birincil_gelir_yatirim_gideri).

## Gözlemlenebilir finans (mn USD)

| Satır | USD mn |
| --- | ---: |
| birincil_gelir_yatirim_gideri | 18,841 |
| dis_borc_servisi_tds | 89,572 |
| kamu_dis_borc_servisi_tl_cevrilmis | 16,670 |
| hazine_kefalet_koi_yeni_finansman | 9,110 |

## Mal ticareti (mn USD)

- İhracat: **261,925.0**
- İthalat: **344,100.0**
- Net: **-82,175.0**

## Model vekili → USD (aynı çapa)

| Bileşen | Vekil | USD mn (vekili) |
| --- | ---: | ---: |
| MFIN kenar | 9.192 | 11,456.4 |
| Merkez belirsiz havuz | 3.941 | 4,911.8 |
| Merkez toplam | 13.133 | 16,368.3 |
| Rant çıkış (tüm havza) | 1.984 | 2,472.7 |

## USD köprüleri (vekil birimi)

- **bop_merkez_rant:** 1 vekil ≈ **1,246.35** mn USD (usd = vekil × (yatırım geliri gideri / merkez+rant))
- **tum_havza_rant:** 1 vekil ≈ **3,038.87** mn USD (TCMB yatırım geliri × rant-kanal BOP pay vekili (~tahvil+petro+KÖİ))
- **mal_net_ticaret:** 1 vekil ≈ **3,293.32** mn USD (|ihracat−ithalat| ↔ turkiye_yaricevre_bosalma (TİM 2024))

TR net vekil **-25.822** → USD: BoP **32,183.2** · rant **78,469.7** · mal **85,040.1** · orta **59,885.0** mn

## Küresel pay (vekili payda)

- TR dış borç servisi / küresel TDS vekili: **%2.889**
- TR yatırım geliri gideri / küresel vekili: **%0.897**
- TR TDS / BIS cross-border claims vekili: **%0.2421**

## MFIN — havza kenarları (top 25, USD vekili)

| Havza | Vekil | USD mn |
| --- | ---: | ---: |
| Körfez bağlantı hattı | 0.689 | 858.7 |
| Karadeniz çeperi | 0.599 | 746.6 |
| Doğu Akdeniz — KÖİ/kefalet | 0.545 | 679.3 |
| Balkan — Bulgaristan | 0.509 | 634.4 |
| Fırat — Irak merkez | 0.502 | 625.7 |
| Doğu Akdeniz — gaz/LNG | 0.468 | 583.3 |
| Kuzey Afrika — Fas | 0.467 | 582.0 |
| Fırat — KRG | 0.404 | 503.5 |
| Orta Asya — Kazakistan | 0.39 | 486.1 |
| Orta Asya — Özbekistan | 0.364 | 453.7 |
| Balkan — Sırbistan | 0.341 | 425.0 |
| Kuzey Afrika — Mısır (Nil) | 0.335 | 417.5 |
| Kuzey Afrika — Cezayir | 0.279 | 347.7 |
| Balkan — Bosna-Hersek | 0.267 | 332.8 |
| Kuzey Afrika — Libya | 0.261 | 325.3 |
| Balkan — Arnavutluk | 0.26 | 324.0 |
| Kuzey Afrika — Tunus | 0.252 | 314.1 |
| Balkan — Kuzey Makedonya | 0.238 | 296.6 |
| Kafkasya — Azerbaycan | 0.225 | 280.4 |
| Orta Asya — Türkmenistan | 0.219 | 272.9 |
| Orta Asya — Kırgızistan | 0.199 | 248.0 |
| Kafkasya — Gürcistan | 0.184 | 229.3 |
| Orta Asya — Tacikistan | 0.183 | 228.1 |
| İran — Doğu/Orta Asya kapısı | 0.163 | 203.2 |
| Kafkasya — Ermenistan | 0.156 | 194.4 |

## Rant kanalları (USD vekili, top 20)

| Kanal | Rant vekil pay | USD mn |
| --- | ---: | ---: |
| refah_rant | 0.328 | 811.0 |
| boru | 0.0706 | 174.6 |
| transit | 0.0573 | 141.7 |
| enerji | 0.0499 | 123.4 |
| montaj_ihale | 0.0472 | 116.7 |
| liman | 0.0423 | 104.6 |
| fon_liman | 0.0385 | 95.2 |
| ihale | 0.0384 | 95.0 |
| savunma_tedarik | 0.0349 | 86.3 |
| petro_dolar | 0.0329 | 81.4 |
| AB_fon | 0.0313 | 77.4 |
| maden | 0.0302 | 74.7 |
| transit_rant | 0.0272 | 67.3 |
| montaj | 0.0255 | 63.1 |
| petrol | 0.0245 | 60.6 |
| LNG | 0.0243 | 60.1 |
| tahıl | 0.0223 | 55.1 |
| petrol_servis | 0.0212 | 52.4 |
| tahvil | 0.0202 | 49.9 |
| sınır_ticaret | 0.017 | 42.0 |

## Kaynaklar

- TCMB — Balance of Payments Statistics, Yearly Detailed Presentation (2006–2025): birincil gelir / yatırım geliri debit 2024 ≈ 18.841 mn $
- World Bank — DT.TDS.DECT.CD: debt service on external debt, total (TDS), Turkey 2024 ≈ 89.572 mn $
- Hazine ve Maliye — Public Debt Management Report 2025: kamu dış borç servisi 2024 = 547,9 milyar TL (nakit); kefalet/KÖİ yeni finansman 2024 ≈ 9,11 milyar $
- TİM/Ticaret — tr_dis_ticaret_2024.json (mal akışı)
