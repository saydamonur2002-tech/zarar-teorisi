# Senaryo C — dış aktör kazanç (vekil)

Kaynak: `dis_aktör_pay.json` + `ulkeler_bolge.json` + ikame + merkez sızıntı. `*` Belirsiz M = `merkez_belirsiz.json` eşit pay (fayda Σ'ye eklenmez).

MFIN kenar **3.918** | belirsiz havuz **2.239** | **36** ülke × **0.0622**

| Aktör | Kazanç Σ | Kanal | Matris | İkame | Merkez | Belirsiz M* |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Çin | 5.239 | 2.81 | 1.692 | 0.737 | 0.0 | 0.0622 |
| Rusya | 4.93 | 2.583 | 1.46 | 0.887 | 0.0 | 0.0622 |
| AB (Balkan vekil) | 4.709 | 2.364 | 1.95 | 0.395 | 0.0 | 0.0622 |
| Merkez finans (vekil) | 3.918 | 0.0 | 0.0 | 0.0 | 3.918 | 0.0 |
| ABD | 3.028 | 1.281 | 1.341 | 0.406 | 0.0 | 0.0622 |
| İran | 2.406 | 1.01 | 1.139 | 0.257 | 0.0 | 0.0622 |
| BAE | 1.308 | 0.527 | 0.648 | 0.133 | 0.0 | 0.0622 |
| Suudi Arabistan | 1.106 | 0.453 | 0.482 | 0.171 | 0.0 | 0.0622 |
| İsrail | 1.033 | 0.477 | 0.38 | 0.176 | 0.0 | 0.0622 |
| Fransa | 0.756 | 0.439 | 0.252 | 0.065 | 0.0 | 0.0622 |
| Mısır | 0.635 | 0.329 | 0.201 | 0.105 | 0.0 | 0.0622 |
| Yunanistan | 0.399 | 0.246 | 0.101 | 0.052 | 0.0 | 0.0622 |
| Kıbrıs Rum Kesimi (vekil) | 0.074 | 0.0 | 0.074 | 0.0 | 0.0 | 0.0622 |
| Ukrayna (vekil) | 0.026 | 0.0 | 0.026 | 0.0 | 0.0 | 0.0622 |

## Birleşik (dış kazanç − havza kaybı)

`—` = bilinmiyor (modellenmedi), sıfır değil. `†` = kısmi kapsam (kazancın yalnız bir kanalı modelli). Net yalnız kazanç ve kayıp ikisi de tam modelliyse yazılır.

| Aktör | Dış kazanç | Havza kayıp | Belirsiz M* | Net | Kapsam | Durum |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| Çin | 5.239 | — | 0.062 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| Rusya | 4.93 | — | 0.062 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| AB (Balkan vekil) | 4.709 | — | 0.062 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| Merkez finans (vekil) | 3.918 | n/a | 0.0 | 3.918 | tam | dis_kazanc |
| ABD | 3.028 | — | 0.062 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| İran | 2.406 | 0.277 | 0.062 | 2.129 | tam | dis_kazanc |
| BAE | 1.308 | — | 0.062 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| Suudi Arabistan | 1.106 | — | 0.062 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| İsrail | 1.033 | 0.124 | 0.062 | 0.909 | tam | dis_kazanc |
| Fransa | 0.756 | — | 0.062 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| Yunanistan | 0.399 | — | 0.062 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| Mısır | 0.635 | 0.316 | 0.062 | 0.319 | tam | dis_kazanc |
| Kıbrıs Rum Kesimi (vekil) | 0.074† | 0.106 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Tunus | 0.0† | 0.155 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Kuzey Makedonya | 0.0† | 0.169 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Tacikistan | 0.0† | 0.169 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Arnavutluk | 0.0† | 0.173 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Kırgızistan | 0.0† | 0.179 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Ermenistan | 0.0† | 0.204 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Bosna-Hersek | 0.0† | 0.208 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Türkmenistan | 0.0† | 0.227 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Gürcistan | 0.0† | 0.243 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Azerbaycan | 0.0 | 0.249 | 0.062 | -0.249 | tam | havza_kayip |
| Cezayir | 0.0† | 0.273 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Özbekistan | 0.0† | 0.278 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Kazakistan | 0.0† | 0.302 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Ukrayna (vekil) | 0.026† | 0.374 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Libya | 0.0† | 0.368 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Fas | 0.0† | 0.388 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Sırbistan | 0.0 | 0.392 | 0.062 | -0.392 | tam | havza_kayip |
| Bulgaristan | 0.0† | 0.402 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Somali | 0.0† | 0.436 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Lübnan | 0.0† | 0.441 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Suriye | 0.0† | 0.443 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Körfez (vekil) | — | 1.114 | 0.062 | bilinmiyor | kazanç yok | belirsiz |
| Irak | 0.0† | 1.36 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Türkiye | 0.0 | 17.7 | 0.0 | -17.7 | tam | havza_kayip |
