# Senaryo C (referans) — dış aktör kazanç (vekil)

Kaynak: `dis_aktör_pay.json` + `ulkeler_bolge.json` + ikame + merkez sızıntı. `*` Belirsiz M = `merkez_belirsiz.json` eşit pay (fayda Σ'ye eklenmez).

MFIN kenar **5.662** | belirsiz havuz **2.242** | **36** ülke × **0.0623**

| Aktör | Kazanç Σ | Kanal | Matris | İkame | Merkez | Belirsiz M* |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Merkez finans (vekil) | 5.662 | 0.0 | 0.0 | 0.0 | 5.662 | 0.0 |
| Çin | 5.239 | 2.81 | 1.692 | 0.737 | 0.0 | 0.0623 |
| Rusya | 4.93 | 2.583 | 1.46 | 0.887 | 0.0 | 0.0623 |
| AB (Balkan vekil) | 4.709 | 2.364 | 1.95 | 0.395 | 0.0 | 0.0623 |
| ABD | 3.028 | 1.281 | 1.341 | 0.406 | 0.0 | 0.0623 |
| İran | 2.406 | 1.01 | 1.139 | 0.257 | 0.0 | 0.0623 |
| BAE | 1.308 | 0.527 | 0.648 | 0.133 | 0.0 | 0.0623 |
| Suudi Arabistan | 1.106 | 0.453 | 0.482 | 0.171 | 0.0 | 0.0623 |
| İsrail | 1.033 | 0.477 | 0.38 | 0.176 | 0.0 | 0.0623 |
| Fransa | 0.756 | 0.439 | 0.252 | 0.065 | 0.0 | 0.0623 |
| Mısır | 0.635 | 0.329 | 0.201 | 0.105 | 0.0 | 0.0623 |
| Yunanistan | 0.399 | 0.246 | 0.101 | 0.052 | 0.0 | 0.0623 |
| Kıbrıs Rum Kesimi (vekil) | 0.074 | 0.0 | 0.074 | 0.0 | 0.0 | 0.0623 |
| Ukrayna (vekil) | 0.026 | 0.0 | 0.026 | 0.0 | 0.0 | 0.0623 |

## Birleşik (dış kazanç − havza kaybı)

| Aktör | Dış kazanç | Havza kayıp | Belirsiz M* | Net | Durum |
| --- | ---: | ---: | ---: | ---: | --- |
| Merkez finans (vekil) | 5.662 | 0.0 | 0.0 | 5.662 | dis_kazanc |
| Çin | 5.239 | 0.0 | 0.062 | 5.239 | dis_kazanc |
| Rusya | 4.93 | 0.0 | 0.062 | 4.93 | dis_kazanc |
| AB (Balkan vekil) | 4.709 | 0.0 | 0.062 | 4.709 | dis_kazanc |
| ABD | 3.028 | 0.0 | 0.062 | 3.028 | dis_kazanc |
| İran | 2.406 | 0.277 | 0.062 | 2.129 | dis_kazanc |
| BAE | 1.308 | 0.0 | 0.062 | 1.308 | dis_kazanc |
| Suudi Arabistan | 1.106 | 0.0 | 0.062 | 1.106 | dis_kazanc |
| İsrail | 1.033 | 0.124 | 0.062 | 0.909 | dis_kazanc |
| Fransa | 0.756 | 0.0 | 0.062 | 0.756 | dis_kazanc |
| Yunanistan | 0.399 | 0.0 | 0.062 | 0.399 | dis_kazanc |
| Mısır | 0.635 | 0.316 | 0.062 | 0.319 | dis_kazanc |
| Kıbrıs Rum Kesimi (vekil) | 0.074 | 0.106 | 0.062 | -0.032 | nötr |
| Tunus | 0.0 | 0.155 | 0.062 | -0.155 | havza_kayip |
| Kuzey Makedonya | 0.0 | 0.169 | 0.062 | -0.169 | havza_kayip |
| Tacikistan | 0.0 | 0.169 | 0.062 | -0.169 | havza_kayip |
| Arnavutluk | 0.0 | 0.173 | 0.062 | -0.173 | havza_kayip |
| Kırgızistan | 0.0 | 0.179 | 0.062 | -0.179 | havza_kayip |
| Ermenistan | 0.0 | 0.204 | 0.062 | -0.204 | havza_kayip |
| Bosna-Hersek | 0.0 | 0.208 | 0.062 | -0.208 | havza_kayip |
| Türkmenistan | 0.0 | 0.227 | 0.062 | -0.227 | havza_kayip |
| Gürcistan | 0.0 | 0.243 | 0.062 | -0.243 | havza_kayip |
| Azerbaycan | 0.0 | 0.249 | 0.062 | -0.249 | havza_kayip |
| Cezayir | 0.0 | 0.273 | 0.062 | -0.273 | havza_kayip |
| Özbekistan | 0.0 | 0.278 | 0.061 | -0.278 | havza_kayip |
| Kazakistan | 0.0 | 0.302 | 0.062 | -0.302 | havza_kayip |
| Ukrayna (vekil) | 0.026 | 0.374 | 0.062 | -0.348 | havza_kayip |
| Libya | 0.0 | 0.368 | 0.062 | -0.368 | havza_kayip |
| Fas | 0.0 | 0.388 | 0.062 | -0.388 | havza_kayip |
| Sırbistan | 0.0 | 0.392 | 0.062 | -0.392 | havza_kayip |
