# Senaryo C — dış aktör kazanç (vekil)

Kaynak: `dis_aktör_pay.json` + `ulkeler_bolge.json` + ikame + merkez sızıntı. `*` Belirsiz M = `merkez_belirsiz.json` eşit pay (fayda Σ'ye eklenmez).

MFIN kenar **3.918** | belirsiz havuz **2.239** | **36** ülke × **0.0622**

| Aktör | Kazanç Σ | Kanal | Matris | İkame | Merkez | Belirsiz M* |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Merkez finans (vekil) | 3.918 | 0.0 | 0.0 | 0.0 | 3.918 | 0.0 |
| Çin | 2.429 | 0.0 | 1.692 | 0.737 | 0.0 | 0.0622 |
| Rusya | 2.347 | 0.0 | 1.46 | 0.887 | 0.0 | 0.0622 |
| AB (Balkan vekil) | 2.345 | 0.0 | 1.95 | 0.395 | 0.0 | 0.0622 |
| ABD | 1.747 | 0.0 | 1.341 | 0.406 | 0.0 | 0.0622 |
| İran | 1.396 | 0.0 | 1.139 | 0.257 | 0.0 | 0.0622 |
| BAE | 0.781 | 0.0 | 0.648 | 0.133 | 0.0 | 0.0622 |
| Suudi Arabistan | 0.653 | 0.0 | 0.482 | 0.171 | 0.0 | 0.0622 |
| İsrail | 0.556 | 0.0 | 0.38 | 0.176 | 0.0 | 0.0622 |
| Fransa | 0.317 | 0.0 | 0.252 | 0.065 | 0.0 | 0.0622 |
| Mısır | 0.306 | 0.0 | 0.201 | 0.105 | 0.0 | 0.0622 |
| Yunanistan | 0.153 | 0.0 | 0.101 | 0.052 | 0.0 | 0.0622 |
| Kıbrıs Rum Kesimi (vekil) | 0.074 | 0.0 | 0.074 | 0.0 | 0.0 | 0.0622 |
| Ukrayna (vekil) | 0.026 | 0.0 | 0.026 | 0.0 | 0.0 | 0.0622 |

## Birleşik (dış kazanç − havza kaybı)

`—` = bilinmiyor (modellenmedi), sıfır değil. `†` = kısmi kapsam (kazancın yalnız bir kanalı modelli). `‡` = kayıp modelde yok; referans aktörlerin (İran, İsrail, Mısır) medyan kayıp/kazanç oranıyla VEKİL (± yarı aralık); Çin ve Rusya için kayıp dış ticaret verisinden (ihracat gelirinin ortak ülke kayıplarına duyarlılığı × referans aktörlerden kalibre φ). Net yalnız kazanç ve kayıp ikisi de tam modelliyse kesin yazılır.

| Aktör | Dış kazanç | Havza kayıp | Belirsiz M* | Net | Kapsam | Durum |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| Merkez finans (vekil) | 3.918 | ≈0.874‡ | 0.0 | ≈3.044‡ (±1.634) | kayıp bilinmiyor | dis_kazanc |
| Çin | 2.429 | ≈3.171‡ | 0.062 | ≈-0.742‡ (±1.573) | kayıp bilinmiyor | dis_kazanc |
| Rusya | 2.347 | ≈2.781‡ | 0.062 | ≈-0.434‡ (±1.379) | kayıp bilinmiyor | dis_kazanc |
| AB (Balkan vekil) | 2.345 | ≈7.22‡ | 0.062 | ≈-4.875‡ (±3.581) | kayıp bilinmiyor | dis_kazanc |
| ABD | 1.747 | ≈0.949‡ | 0.062 | ≈0.798‡ (±0.471) | kayıp bilinmiyor | dis_kazanc |
| İran | 1.396 | 0.277 | 0.062 | 1.119 | tam | dis_kazanc |
| BAE | 0.781 | ≈1.857‡ | 0.062 | ≈-1.076‡ (±0.921) | kayıp bilinmiyor | dis_kazanc |
| Suudi Arabistan | 0.653 | ≈0.215‡ | 0.062 | ≈0.438‡ (±0.107) | kayıp bilinmiyor | dis_kazanc |
| İsrail | 0.556 | 0.124 | 0.062 | 0.432 | tam | dis_kazanc |
| Fransa | 0.317 | ≈0.853‡ | 0.062 | ≈-0.536‡ (±0.423) | kayıp bilinmiyor | dis_kazanc |
| Yunanistan | 0.153 | ≈0.339‡ | 0.062 | ≈-0.186‡ (±0.168) | kayıp bilinmiyor | dis_kazanc |
| Mısır | 0.306 | 0.316 | 0.062 | -0.01 | tam | nötr |
| Kıbrıs Rum Kesimi (vekil) | 0.074† | 0.106 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Tunus | 0.0† | 0.155 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Kuzey Makedonya | 0.0† | 0.169 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Tacikistan | 0.0† | 0.169 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Arnavutluk | 0.0† | 0.173 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Kırgızistan | 0.0† | 0.179 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Ermenistan | 0.0† | 0.204 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Bosna-Hersek | 0.0† | 0.208 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Türkmenistan | 0.0† | 0.227 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Gürcistan | 0.0† | 0.243 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Azerbaycan | 0.0 | 0.249 | 0.062 | -0.249 | tam | havza_kayip |
| Cezayir | 0.0† | 0.273 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Özbekistan | 0.0† | 0.278 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Kazakistan | 0.0† | 0.302 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Ukrayna (vekil) | 0.026† | 0.374 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Libya | 0.0† | 0.368 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Fas | 0.0† | 0.388 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Sırbistan | 0.0 | 0.392 | 0.062 | -0.392 | tam | havza_kayip |
| Bulgaristan | 0.0† | 0.402 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Somali | 0.0† | 0.436 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Lübnan | 0.0† | 0.441 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Suriye | 0.0† | 0.443 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Körfez (vekil) | — | 1.114 | 0.062 | bilinmiyor | kazanç yok | belirsiz |
| Irak | 0.0† | 1.36 | 0.062 | bilinmiyor | kazanç kismi | belirsiz |
| Türkiye | 0.0 | 17.7 | 0.0 | -17.7 | tam | havza_kayip |
