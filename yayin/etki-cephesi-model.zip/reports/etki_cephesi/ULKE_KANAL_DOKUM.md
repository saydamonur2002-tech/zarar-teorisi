# Ülke × kanal dokümü (P4)

**345** hücre · **37** ülke · **10** kurum

## Top ülke — refah dış USD (kanal hücreleri, tüm senaryolar)

- **EU:** 6,622.6 mn $
- **CN:** 6,550.5 mn $
- **US:** 6,281.3 mn $
- **RU:** 6,122.0 mn $
- **IR:** 4,187.8 mn $
- **AE:** 2,278.2 mn $
- **IL:** 1,790.6 mn $
- **SA:** 1,552.3 mn $
- **FR:** 1,058.0 mn $
- **EG:** 859.1 mn $
- **AZ:** 678.6 mn $
- **GR:** 592.9 mn $
- **RS:** 114.6 mn $

## Kurumlar

- **IMF:** net 0.135 vekil · 565.9 mn $
- **AB kurumları (Komisyon/ECB vekili):** net 0.121 vekil · 538.8 mn $
- **Dünya Bankası:** net 0.113 vekil · 508.3 mn $
- **EBRD (Avrupa İmar ve Kalkınma Bankası):** net 0.094 vekil · 426.5 mn $
- **AIIB (Asya Altyapı Yatırım Bankası):** net 0.093 vekil · 480.9 mn $
- **BIS (Bank for International Settlements):** net 0.09 vekil · 395.1 mn $
- **NATO:** net 0.08 vekil · 348.2 mn $
- **SWIFT / ödeme altyapısı (vekil):** net 0.076 vekil · 366.0 mn $
- **WTO:** net 0.04 vekil · 174.6 mn $
- **Birleşmiş Milletler:** net 0.03 vekil · 129.9 mn $
