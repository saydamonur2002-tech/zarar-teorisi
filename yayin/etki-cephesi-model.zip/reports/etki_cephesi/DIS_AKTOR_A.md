# Senaryo A — dış aktör kazanç (vekil)

Kaynak: `dis_aktör_pay.json` + `ulkeler_bolge.json` + ikame + merkez sızıntı. `*` Belirsiz M = `merkez_belirsiz.json` eşit pay (fayda Σ'ye eklenmez).

MFIN kenar **9.192** | belirsiz havuz **3.941** | **36** ülke × **0.1095**

| Aktör | Kazanç Σ | Kanal | Matris | İkame | Merkez | Belirsiz M* |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Merkez finans (vekil) | 7.825 | 0.0 | 0.0 | 0.0 | 7.825 | 0.0 |
| AB (Balkan vekil) | 2.369 | 0.0 | 2.369 | 0.0 | 0.0 | 0.1095 |
| Çin | 2.054 | 0.0 | 2.054 | 0.0 | 0.0 | 0.1095 |
| Rusya | 1.795 | 0.0 | 1.795 | 0.0 | 0.0 | 0.1095 |
| ABD | 1.71 | 0.0 | 1.71 | 0.0 | 0.0 | 0.1095 |
| İran | 1.438 | 0.0 | 1.438 | 0.0 | 0.0 | 0.1095 |
| BAE | 0.788 | 0.0 | 0.788 | 0.0 | 0.0 | 0.1095 |
| Suudi Arabistan | 0.597 | 0.0 | 0.597 | 0.0 | 0.0 | 0.1095 |
| İsrail | 0.527 | 0.0 | 0.527 | 0.0 | 0.0 | 0.1095 |
| Fransa | 0.319 | 0.0 | 0.319 | 0.0 | 0.0 | 0.1095 |
| Mısır | 0.271 | 0.0 | 0.271 | 0.0 | 0.0 | 0.1095 |
| Yunanistan | 0.148 | 0.0 | 0.148 | 0.0 | 0.0 | 0.1095 |
| Kıbrıs Rum Kesimi (vekil) | 0.108 | 0.0 | 0.108 | 0.0 | 0.0 | 0.1095 |
| Ukrayna (vekil) | 0.032 | 0.0 | 0.032 | 0.0 | 0.0 | 0.1095 |

## Birleşik (dış kazanç − havza kaybı)

`—` = bilinmiyor (modellenmedi), sıfır değil. `†` = kısmi kapsam (kazancın yalnız bir kanalı modelli). `‡` = kayıp modelde yok; referans aktörlerin (İran, İsrail, Mısır) medyan kayıp/kazanç oranıyla VEKİL (± yarı aralık); Çin ve Rusya için kayıp dış ticaret verisinden (ihracat gelirinin ortak ülke kayıplarına duyarlılığı × referans aktörlerden kalibre φ). Net yalnız kazanç ve kayıp ikisi de tam modelliyse kesin yazılır.

| Aktör | Dış kazanç | Havza kayıp | Belirsiz M* | Net | Kapsam | Durum |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| Merkez finans (vekil) | 7.825 | ≈3.445‡ | 0.0 | ≈4.38‡ (±6.156) | kayıp bilinmiyor | dis_kazanc |
| AB (Balkan vekil) | 2.369 | ≈11.211‡ | 0.11 | ≈-8.842‡ (±7.22) | kayıp bilinmiyor | dis_kazanc |
| Çin | 2.054 | ≈4.974‡ | 0.11 | ≈-2.92‡ (±3.204) | kayıp bilinmiyor | dis_kazanc |
| Rusya | 1.795 | ≈4.301‡ | 0.11 | ≈-2.506‡ (±2.77) | kayıp bilinmiyor | dis_kazanc |
| ABD | 1.71 | ≈1.479‡ | 0.11 | ≈0.231‡ (±0.952) | kayıp bilinmiyor | dis_kazanc |
| İran | 1.438 | 0.417 | 0.11 | 1.021 | tam | dis_kazanc |
| BAE | 0.788 | ≈2.927‡ | 0.11 | ≈-2.139‡ (±1.885) | kayıp bilinmiyor | dis_kazanc |
| Suudi Arabistan | 0.597 | ≈0.338‡ | 0.11 | ≈0.259‡ (±0.217) | kayıp bilinmiyor | dis_kazanc |
| Fransa | 0.319 | ≈1.323‡ | 0.11 | ≈-1.004‡ (±0.852) | kayıp bilinmiyor | dis_kazanc |
| İsrail | 0.527 | 0.232 | 0.11 | 0.295 | tam | dis_kazanc |
| Yunanistan | 0.148 | ≈0.558‡ | 0.11 | ≈-0.41‡ (±0.36) | kayıp bilinmiyor | dis_kazanc |
| Kıbrıs Rum Kesimi (vekil) | 0.108† | 0.197 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Mısır | 0.271 | 0.505 | 0.11 | -0.234 | tam | havza_kayip |
| Tunus | 0.0† | 0.238 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Kuzey Makedonya | 0.0† | 0.252 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Arnavutluk | 0.0† | 0.255 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Tacikistan | 0.0† | 0.258 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Kırgızistan | 0.0† | 0.273 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Bosna-Hersek | 0.0† | 0.306 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Ermenistan | 0.0† | 0.31 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Türkmenistan | 0.0† | 0.343 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Gürcistan | 0.0† | 0.371 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Azerbaycan | 0.0 | 0.384 | 0.11 | -0.384 | tam | havza_kayip |
| Cezayir | 0.0† | 0.413 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Özbekistan | 0.0† | 0.427 | 0.108 | bilinmiyor | kazanç kismi | belirsiz |
| Kazakistan | 0.0† | 0.461 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Ukrayna (vekil) | 0.032† | 0.552 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Libya | 0.0† | 0.559 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Fas | 0.0† | 0.569 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Sırbistan | 0.0 | 0.579 | 0.11 | -0.579 | tam | havza_kayip |
| Bulgaristan | 0.0† | 0.584 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Somali | 0.0† | 0.652 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Suriye | 0.0† | 0.776 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Lübnan | 0.0† | 0.778 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Körfez (vekil) | — | 1.645 | 0.11 | bilinmiyor | kazanç yok | belirsiz |
| Irak | 0.0† | 2.04 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Türkiye | 0.0 | 25.822 | 0.0 | -25.822 | tam | havza_kayip |
