# Senaryo A — dış aktör kazanç (vekil)

Kaynak: `dis_aktör_pay.json` + `ulkeler_bolge.json` + ikame + merkez sızıntı. `*` Belirsiz M = `merkez_belirsiz.json` eşit pay (fayda Σ'ye eklenmez).

MFIN kenar **9.192** | belirsiz havuz **3.941** | **36** ülke × **0.1095**

| Aktör | Kazanç Σ | Kanal | Matris | İkame | Merkez | Belirsiz M* |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Merkez finans (vekil) | 8.218 | 0.0 | 0.0 | 0.0 | 8.218 | 0.0 |
| Çin | 3.099 | 0.0 | 2.157 | 0.942 | 0.0 | 0.1095 |
| Rusya | 3.03 | 0.0 | 1.885 | 1.145 | 0.0 | 0.1095 |
| AB (Balkan vekil) | 3.0 | 0.0 | 2.488 | 0.512 | 0.0 | 0.1095 |
| ABD | 2.331 | 0.0 | 1.796 | 0.535 | 0.0 | 0.1095 |
| İran | 1.843 | 0.0 | 1.51 | 0.333 | 0.0 | 0.1095 |
| BAE | 1.005 | 0.0 | 0.827 | 0.178 | 0.0 | 0.1095 |
| Suudi Arabistan | 0.857 | 0.0 | 0.627 | 0.23 | 0.0 | 0.1095 |
| İsrail | 0.791 | 0.0 | 0.553 | 0.238 | 0.0 | 0.1095 |
| Mısır | 0.426 | 0.0 | 0.284 | 0.142 | 0.0 | 0.1095 |
| Fransa | 0.424 | 0.0 | 0.335 | 0.089 | 0.0 | 0.1095 |
| Yunanistan | 0.225 | 0.0 | 0.155 | 0.07 | 0.0 | 0.1095 |
| Kıbrıs Rum Kesimi (vekil) | 0.114 | 0.0 | 0.114 | 0.0 | 0.0 | 0.1095 |
| Ukrayna (vekil) | 0.033 | 0.0 | 0.033 | 0.0 | 0.0 | 0.1095 |

## Birleşik (dış kazanç − havza kaybı)

`—` = bilinmiyor (modellenmedi), sıfır değil. `†` = kısmi kapsam (kazancın yalnız bir kanalı modelli). `‡` = kayıp modelde yok; referans aktörlerin (İran, İsrail, Mısır) medyan kayıp/kazanç oranıyla VEKİL (± yarı aralık); Çin ve Rusya için kayıp dış ticaret verisinden (ihracat gelirinin ortak ülke kayıplarına duyarlılığı × referans aktörlerden kalibre φ). Net yalnız kazanç ve kayıp ikisi de tam modelliyse kesin yazılır.

| Aktör | Dış kazanç | Havza kayıp | Belirsiz M* | Net | Kapsam | Durum |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| Merkez finans (vekil) | 8.218 | ≈2.41‡ | 0.0 | ≈5.808‡ (±3.941) | kayıp bilinmiyor | dis_kazanc |
| Çin | 3.099 | ≈6.125‡ | 0.11 | ≈-3.026‡ (±3.944) | kayıp bilinmiyor | dis_kazanc |
| Rusya | 3.03 | ≈4.301‡ | 0.11 | ≈-1.271‡ (±2.77) | kayıp bilinmiyor | dis_kazanc |
| AB (Balkan vekil) | 3.0 | ≈0.88‡ | 0.11 | ≈2.12‡ (±1.439) | kayıp bilinmiyor | dis_kazanc |
| ABD | 2.331 | ≈0.684‡ | 0.11 | ≈1.647‡ (±1.118) | kayıp bilinmiyor | dis_kazanc |
| İran | 1.843 | 0.417 | 0.11 | 1.426 | tam | dis_kazanc |
| BAE | 1.005 | ≈0.295‡ | 0.11 | ≈0.71‡ (±0.482) | kayıp bilinmiyor | dis_kazanc |
| Suudi Arabistan | 0.857 | ≈0.251‡ | 0.11 | ≈0.606‡ (±0.411) | kayıp bilinmiyor | dis_kazanc |
| İsrail | 0.791 | 0.232 | 0.11 | 0.559 | tam | dis_kazanc |
| Fransa | 0.424 | ≈0.124‡ | 0.11 | ≈0.3‡ (±0.203) | kayıp bilinmiyor | dis_kazanc |
| Yunanistan | 0.225 | ≈0.066‡ | 0.11 | ≈0.159‡ (±0.108) | kayıp bilinmiyor | dis_kazanc |
| Mısır | 0.426 | 0.505 | 0.11 | -0.079 | tam | havza_kayip |
| Kıbrıs Rum Kesimi (vekil) | 0.114† | 0.197 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Tunus | 0.0† | 0.238 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Kuzey Makedonya | 0.0† | 0.252 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Arnavutluk | 0.0† | 0.255 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Tacikistan | 0.0† | 0.258 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Kırgızistan | 0.0† | 0.273 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Bosna-Hersek | 0.0† | 0.306 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Ermenistan | 0.0† | 0.31 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Türkmenistan | 0.0† | 0.343 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Gürcistan | 0.0† | 0.371 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Azerbaycan | 0.0 | 0.384 | 0.11 | -0.384 | tam | havza_kayip |
| Cezayir | 0.0† | 0.413 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Özbekistan | 0.0† | 0.427 | 0.108 | bilinmiyor | kazanç kismi | belirsiz |
| Kazakistan | 0.0† | 0.461 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Ukrayna (vekil) | 0.033† | 0.552 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Libya | 0.0† | 0.559 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Fas | 0.0† | 0.569 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Sırbistan | 0.0 | 0.579 | 0.11 | -0.579 | tam | havza_kayip |
| Bulgaristan | 0.0† | 0.584 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Somali | 0.0† | 0.652 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Suriye | 0.0† | 0.776 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Lübnan | 0.0† | 0.778 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Körfez (vekil) | — | 1.645 | 0.11 | bilinmiyor | kazanç yok | belirsiz |
| Irak | 0.0† | 2.04 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Türkiye | 0.0 | 25.822 | 0.0 | -25.822 | tam | havza_kayip |
