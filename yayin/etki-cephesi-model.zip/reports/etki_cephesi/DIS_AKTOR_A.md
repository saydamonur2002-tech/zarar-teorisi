# Senaryo A — dış aktör kazanç (vekil)

Kaynak: `dis_aktör_pay.json` + `ulkeler_bolge.json` + ikame + merkez sızıntı. `*` Belirsiz M = `merkez_belirsiz.json` eşit pay (fayda Σ'ye eklenmez).

MFIN kenar **9.192** | belirsiz havuz **3.941** | **36** ülke × **0.1095**

| Aktör | Kazanç Σ | Kanal | Matris | İkame | Merkez | Belirsiz M* |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Merkez finans (vekil) | 9.192 | 0.0 | 0.0 | 0.0 | 9.192 | 0.0 |
| Çin | 7.475 | 4.008 | 2.413 | 1.054 | 0.0 | 0.1095 |
| Rusya | 7.108 | 3.719 | 2.108 | 1.281 | 0.0 | 0.1095 |
| AB (Balkan vekil) | 6.728 | 3.372 | 2.783 | 0.573 | 0.0 | 0.1095 |
| ABD | 4.535 | 1.928 | 2.009 | 0.598 | 0.0 | 0.1095 |
| İran | 3.566 | 1.505 | 1.689 | 0.372 | 0.0 | 0.1095 |
| BAE | 1.878 | 0.753 | 0.925 | 0.2 | 0.0 | 0.1095 |
| İsrail | 1.656 | 0.771 | 0.619 | 0.266 | 0.0 | 0.1095 |
| Suudi Arabistan | 1.627 | 0.668 | 0.701 | 0.258 | 0.0 | 0.1095 |
| Fransa | 1.124 | 0.651 | 0.374 | 0.099 | 0.0 | 0.1095 |
| Mısır | 1.005 | 0.528 | 0.318 | 0.159 | 0.0 | 0.1095 |
| Yunanistan | 0.673 | 0.421 | 0.173 | 0.079 | 0.0 | 0.1095 |
| Kıbrıs Rum Kesimi (vekil) | 0.127 | 0.0 | 0.127 | 0.0 | 0.0 | 0.1095 |
| Ukrayna (vekil) | 0.037 | 0.0 | 0.037 | 0.0 | 0.0 | 0.1095 |

## Birleşik (dış kazanç − havza kaybı)

`—` = bilinmiyor (modellenmedi), sıfır değil. `†` = kısmi kapsam (kazancın yalnız bir kanalı modelli). Net yalnız kazanç ve kayıp ikisi de tam modelliyse yazılır.

| Aktör | Dış kazanç | Havza kayıp | Belirsiz M* | Net | Kapsam | Durum |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| Merkez finans (vekil) | 9.192 | n/a | 0.0 | 9.192 | tam | dis_kazanc |
| Çin | 7.475 | — | 0.11 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| Rusya | 7.108 | — | 0.11 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| AB (Balkan vekil) | 6.728 | — | 0.11 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| ABD | 4.535 | — | 0.11 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| İran | 3.566 | 0.417 | 0.11 | 3.149 | tam | dis_kazanc |
| BAE | 1.878 | — | 0.11 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| Suudi Arabistan | 1.627 | — | 0.11 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| İsrail | 1.656 | 0.232 | 0.11 | 1.424 | tam | dis_kazanc |
| Fransa | 1.124 | — | 0.11 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| Yunanistan | 0.673 | — | 0.11 | bilinmiyor | kayıp bilinmiyor | belirsiz |
| Mısır | 1.005 | 0.505 | 0.11 | 0.5 | tam | dis_kazanc |
| Kıbrıs Rum Kesimi (vekil) | 0.127† | 0.197 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Tunus | 0.0† | 0.238 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Kuzey Makedonya | 0.0† | 0.252 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Arnavutluk | 0.0† | 0.255 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Tacikistan | 0.0† | 0.258 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Kırgızistan | 0.0† | 0.273 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Bosna-Hersek | 0.0† | 0.306 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Ermenistan | 0.0† | 0.31 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Türkmenistan | 0.0† | 0.343 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Gürcistan | 0.0† | 0.371 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Azerbaycan | 0.0 | 0.384 | 0.11 | -0.384 | tam | havza_kayip |
| Cezayir | 0.0† | 0.413 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Özbekistan | 0.0† | 0.427 | 0.108 | bilinmiyor | kazanç kismi | belirsiz |
| Kazakistan | 0.0† | 0.461 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Ukrayna (vekil) | 0.037† | 0.552 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Libya | 0.0† | 0.559 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Fas | 0.0† | 0.569 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Sırbistan | 0.0 | 0.579 | 0.11 | -0.579 | tam | havza_kayip |
| Bulgaristan | 0.0† | 0.584 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Somali | 0.0† | 0.652 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Suriye | 0.0† | 0.776 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Lübnan | 0.0† | 0.778 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Körfez (vekil) | — | 1.645 | 0.11 | bilinmiyor | kazanç yok | belirsiz |
| Irak | 0.0† | 2.04 | 0.11 | bilinmiyor | kazanç kismi | belirsiz |
| Türkiye | 0.0 | 25.822 | 0.0 | -25.822 | tam | havza_kayip |
