"""Yaşam maliyeti ucuzlatma — politika katmanı, 10 yıl TR net + GSYH."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
KALIBRE = DATA / "kalibre"
OUT = REPO / "reports" / "etki_cephesi"

if str(REPO / "etki_cephesi") not in sys.path:
    sys.path.insert(0, str(REPO / "etki_cephesi"))
from usd_kopru import tr_net_usd_coklu  # noqa: E402


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _gsyh_usd(capa: dict[str, Any]) -> float:
    return float(capa["gsyh_tl"]) / float(capa["kur_tl_usd"]) / 1_000_000


def hesapla() -> dict[str, Any]:
    ger = _load(OUT / "GERCEKLIK_KALIBRE.json")
    capa = _load(KALIBRE / "gerceklik_capa.json")
    yasam = _load(DATA / "yasam_maliyet_katman.json")
    z10 = _load(OUT / "ZARAR_10Y_GSYH.json") if (OUT / "ZARAR_10Y_GSYH.json").is_file() else {}

    kopruler = ger["usd_kopruleri"]
    gsyh = _gsyh_usd(capa)
    mal_k = float(kopruler["mal_net_ticaret"]["usd_per_vekil_mn"])

    tr_bas = float(ger["tr_net_kalibre_son"])
    if z10.get("yil_10_son"):
        tr_bas = float(z10["yil_10_son"]["tr_net"])

    hane = float(yasam["gsyh_hane_tuketim_payi"])
    duy = float(yasam["tr_net_mal_kopru_duyarlilik"])
    taban_r = float(
        (capa.get("gerceklesme_taban") or {}).get("yasam_maliyet_katman")
        or yasam["gerceklesme_taban"]
    )
    hedef_gsyh = float(
        capa.get("iyilesme_tavan_yuzde_10y_yasam_maliyet") or yasam["iyileme_tavan_gsyh_pay_10y"]
    )
    tam = float(yasam["tam_olgunluk_yil"])

    # Politika: hane tasarrufu GSYH → vekil iyileşme (mal köprüsü)
    tasarruf_usd_hedef = gsyh * hedef_gsyh * hane
    vekil_hedef = tasarruf_usd_hedef / mal_k * duy if mal_k > 0 else 0.0
    otomatik_r = min(1.0, (gsyh * float(yasam["hedef_yasam_maliyeti_dusus_gsyh"]) * hane) / max(vekil_hedef * mal_k, 1.0))
    tavan_usd = float(
        (capa.get("iyilesme_tavan_usd_mn_10y") or {}).get("yasam_maliyet_hane") or tasarruf_usd_hedef
    )
    r_tavan = min(1.0, tavan_usd / max(tasarruf_usd_hedef, 1.0))
    realizasyon = min(1.0, max(taban_r, min(otomatik_r, r_tavan)))

    tr_son = round(tr_bas + vekil_hedef * realizasyon, 3)
    y0 = int(z10.get("horizon", {}).get("bas_yil") or 2027)
    y1 = y0 + int(tam) - 1

    seri: list[dict[str, Any]] = []
    for i, y in enumerate(range(y0, y1 + 1)):
        u = min(1.0, (i + 1) / tam)
        tr_y = round(tr_bas + vekil_hedef * realizasyon * u, 3)
        usd = tr_net_usd_coklu(tr_y, kopruler)
        hane_tas_usd = round(tasarruf_usd_hedef * realizasyon * u, 1)
        seri.append(
            {
                "yil": y,
                "tr_net_katmanli": tr_y,
                "yasam_politika_olgunluk": round(u * realizasyon, 3),
                "hane_tasarruf_usd_mn": hane_tas_usd,
                "gsyh_yuzde_orta": round(usd["geometrik_orta_mn"] / gsyh * 100, 3),
            }
        )

    usd_bas = tr_net_usd_coklu(tr_bas, kopruler)
    usd_son = tr_net_usd_coklu(tr_son, kopruler)

    return {
        "olcum": "yasam_maliyet_politika_katmani",
        "taban_tr_net": tr_bas,
        "taban_kaynak": "ZARAR_10Y_GSYH yil_10_son veya GERCEKLIK_KALIBRE",
        "gerceklesme": round(realizasyon, 4),
        "gerceklesme_tavan_usd_mn": round(tavan_usd, 1),
        "gerceklesme_tavan_oran": round(r_tavan, 4),
        "vekil_hedef_ham": round(vekil_hedef, 3),
        "tr_net_10y_son": tr_son,
        "iyilesme_vekil": round(tr_son - tr_bas, 3),
        "hane_tasarruf_usd_mn_10y": round(tasarruf_usd_hedef * realizasyon, 1),
        "gsyh_pp_hane_tasarruf": round(hedef_gsyh * hane * realizasyon * 100, 3),
        "gsyh_yuzde_orta_bas": usd_bas["geometrik_orta_mn"] / gsyh * 100,
        "gsyh_yuzde_orta_son": round(usd_son["geometrik_orta_mn"] / gsyh * 100, 3),
        "yillik_seri": seri,
        "kaynak": ["yasam_maliyet_katman.json", "GERCEKLIK_KALIBRE.json", "ZARAR_10Y_GSYH.json"],
    }


def _md(d: dict[str, Any]) -> str:
    lines = [
        "# Yaşam maliyeti ucuzlatma — politika katmanı (10 yıl)",
        "",
        f"Gerçekleşme: **{d['gerceklesme']}** · taban TR net **{d['taban_tr_net']}** → "
        f"**{d['tr_net_10y_son']}** (+{d['iyilesme_vekil']} vekil)",
        "",
        f"- Hane tasarrufu (10y, USD): **{d['hane_tasarruf_usd_mn_10y']:,}** mn",
        f"- GSYH hane tasarruf vekili: **{d['gsyh_pp_hane_tasarruf']}** pp (hedef pay × gerçekleşme)",
        f"- GSYH % orta köprü: {d['gsyh_yuzde_orta_bas']:.3f} → **{d['gsyh_yuzde_orta_son']}**",
        "",
        "| Yıl | TR net | Olgunluk | Hane tas. USD mn | GSYH % orta |",
        "| --- | ---: | ---: | ---: | ---: |",
    ]
    for r in d["yillik_seri"]:
        lines.append(
            f"| {r['yil']} | {r['tr_net_katmanli']} | {r['yasam_politika_olgunluk']} | "
            f"{r['hane_tasarruf_usd_mn']:,} | {r['gsyh_yuzde_orta']} |"
        )
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    data = hesapla()
    (OUT / "YASAM_MALIYET_KATMAN.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "YASAM_MALIYET_KATMAN.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'YASAM_MALIYET_KATMAN.md'}")


if __name__ == "__main__":
    main()
