"""P3: 10y anlık görüntüleri ayrı dosyalara yazar."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

OUT = REPO = Path(__file__).resolve().parents[1] / "reports" / "etki_cephesi"


def main() -> None:
    src = OUT / "ULUSLARARASI_STOK_AKIS_10Y.json"
    if not src.is_file():
        raise SystemExit("Önce uluslararasi_stok_akis_10y.py çalıştırın")
    doc = json.loads(src.read_text(encoding="utf-8"))
    yazilan: list[str] = []
    for snap in doc.get("anlik_goruntuler") or []:
        y = int(snap["yil"])
        name = f"ULUSLARARASI_STOK_AKIS_{y}.json"
        payload = {
            "olcum": "uluslararasi_stok_akis_anlik",
            "yil": y,
            "kaynak": "ULUSLARARASI_STOK_AKIS_10Y.json → anlik_goruntuler",
            **snap,
        }
        (OUT / name).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        yazilan.append(name)
    meta = {"olcum": "uluslararasi_snapshot_disa", "dosyalar": yazilan}
    (OUT / "ULUSLARARASI_SNAPSHOT_INDEX.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"Wrote {len(yazilan)} snapshots to {OUT}")


if __name__ == "__main__":
    main()
