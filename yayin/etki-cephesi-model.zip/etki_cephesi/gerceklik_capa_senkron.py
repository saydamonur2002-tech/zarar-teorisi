"""P3: empirik JSON → gerceklik_capa usd_mn çapaları (senkron raporu; isteğe bağlı yazma)."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
EMPIRIK = DATA / "empirik"
KALIBRE = DATA / "kalibre"
OUT = REPO / "reports" / "etki_cephesi"
CAPA = KALIBRE / "gerceklik_capa.json"


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _onerilen_capa(capa: dict[str, Any]) -> dict[str, Any]:
    tic = _load(EMPIRIK / "tr_dis_ticaret_2024.json")
    fin = _load(EMPIRIK / "tr_finans_akisi_2024.json")
    sat = fin.get("akis_satirlari") or {}

    ihr = float(tic.get("toplam_ihracat_usd_mn") or 0)
    ith = float(tic.get("toplam_ithalat_usd_mn") or 0)
    yat = float((sat.get("birincil_gelir_yatirim_gideri") or {}).get("usd_mn") or 0)
    tds = float((sat.get("dis_borc_servisi_tds") or {}).get("usd_mn") or 0)

    usd_mn = dict(capa.get("usd_mn") or {})
    oneri = {
        "ihracat": round(ihr, 0),
        "ithalat": round(ith, 0),
        "net_ticaret": round(ihr - ith, 0),
        "yatirim_geliri_gideri": round(yat, 0),
        "dis_borc_servisi_tds": round(tds, 0),
    }
    fark: dict[str, float] = {}
    for k, v in oneri.items():
        eski = float(usd_mn.get(k) or 0)
        if eski:
            fark[k] = round(v - eski, 1)
    return {"usd_mn_oneri": oneri, "usd_mn_mevcut": usd_mn, "fark_mn": fark}


def calistir(uygula: bool = False) -> dict[str, Any]:
    capa = _load(CAPA)
    on = _onerilen_capa(capa)
    out = {
        "olcum": "gerceklik_capa_empirik_senkron",
        "capa_dosya": str(CAPA.relative_to(REPO)),
        **on,
        "uygulandi": False,
        "kaynak": [
            "empirik/tr_dis_ticaret_2024.json",
            "empirik/tr_finans_akisi_2024.json",
        ],
    }
    if uygula:
        capa["usd_mn"] = {**capa.get("usd_mn", {}), **on["usd_mn_oneri"]}
        capa["senkron_not"] = "P3 empirik senkron — gerceklik_capa_senkron.py --apply"
        CAPA.write_text(json.dumps(capa, ensure_ascii=False, indent=2), encoding="utf-8")
        out["uygulandi"] = True
    return out


def _md(d: dict[str, Any]) -> str:
    lines = [
        "# Gerçeklik çapası — empirik senkron (P3)",
        "",
        "| Alan | Mevcut | Öneri | Fark |",
        "| --- | ---: | ---: | ---: |",
    ]
    for k in d["usd_mn_oneri"]:
        lines.append(
            f"| {k} | {d['usd_mn_mevcut'].get(k, '—')} | {d['usd_mn_oneri'][k]:,} | "
            f"{d['fark_mn'].get(k, 0):,} |"
        )
    lines.extend(["", f"**Dosyaya yazıldı:** {d['uygulandi']}", ""])
    return "\n".join(lines)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true", help="gerceklik_capa.json güncelle")
    args = ap.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    data = calistir(uygula=args.apply)
    (OUT / "GERCEKLIK_CAPA_SENKRON.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "GERCEKLIK_CAPA_SENKRON.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'GERCEKLIK_CAPA_SENKRON.md'}")


if __name__ == "__main__":
    main()
