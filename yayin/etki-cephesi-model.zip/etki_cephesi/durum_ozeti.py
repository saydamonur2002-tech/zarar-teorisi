"""P2+: Zorunlu raporlar ve kapanış özeti."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "etki_cephesi"

ZORUNLU = [
    "PROJEKSIYON.json",
    "GERCEKLIK_KALIBRE.json",
    "DIS_ULKE_REFAH.json",
    "SENARYO_COKLU_P2.json",
    "SENARYO_BEKLENEN_KALIBRE.json",
    "ZARAR_10Y_SENARYO_COKLU.json",
    "GERCEKLIK_CAPA_SENKRON.json",
    "ULUSLARARASI_SNAPSHOT_INDEX.json",
    "ULUSLARARASI_STOK_AKIS.json",
    "ULUSLARARASI_STOK_AKIS_10Y.json",
    "MODUL_KALIBRE.json",
    "SENARYO_UYGULANABILIRLIK.json",
    "DIS_ULKE_REFAH_GENIS.json",
    "FINANS_KATMAN_COKLU.json",
    "ULKE_KANAL_DOKUM.json",
    "ULKE_KANAL_DOKUM_10Y.json",
    "GERCEKLIK_SENARYO_COKLU.json",
    "ZARAR_COZUM_COKLU.json",
    "STOK_AKIS_SIM_COKLU.json",
    "DURUM_OZETI.json",
]


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def ozet() -> dict[str, Any]:
    eksik = [f for f in ZORUNLU if not (OUT / f).is_file()]
    uyg = _load(OUT / "SENARYO_UYGULANABILIRLIK.json") if (OUT / "SENARYO_UYGULANABILIRLIK.json").is_file() else {}
    bek = _load(OUT / "SENARYO_BEKLENEN_KALIBRE.json") if (OUT / "SENARYO_BEKLENEN_KALIBRE.json").is_file() else {}
    ulus = _load(OUT / "ULUSLARARASI_STOK_AKIS.json") if (OUT / "ULUSLARARASI_STOK_AKIS.json").is_file() else {}

    return {
        "olcum": "etki_cephesi_durum_ozeti",
        "tamam": len(eksik) == 0,
        "eksik_dosyalar": eksik,
        "skor_uygulanabilirlik": uyg.get("skor_0_100"),
        "skor_c": uyg.get("skor_senaryo_c"),
        "skor_beklenen": uyg.get("skor_beklenen_ab_c"),
        "stok_kapanis_ok": (ulus.get("kalibrasyon") or {}).get("kapanis_ok"),
        "beklenen_tr_10y": (bek.get("beklenti") or {}).get("beklenen_tr_net_10y_yasam"),
        "komut_tam_zincir": "python etki_cephesi/run_all.py",
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    data = ozet()
    (OUT / "DURUM_OZETI.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = [
        "# Etki cephesi — durum özeti",
        "",
        f"**Tamam:** {'evet' if data['tamam'] else 'hayır — eksik: ' + ', '.join(data['eksik_dosyalar'])}",
        f"- Uygulanabilirlik: **{data.get('skor_uygulanabilirlik')}** (C: {data.get('skor_c')}, beklenen: {data.get('skor_beklenen')})",
        f"- Stok kapanış: **{data.get('stok_kapanis_ok')}**",
        f"- Beklenen TR 10y: **{data.get('beklenen_tr_10y')}** vekil",
        "",
    ]
    (OUT / "DURUM_OZETI.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote {OUT / 'DURUM_OZETI.md'}")


if __name__ == "__main__":
    main()
