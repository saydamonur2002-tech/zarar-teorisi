"""P2: MFIN — projeksiyon kenarı vs uluslararası yapısal stok vs GERCEKLIK köprü."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "etki_cephesi"


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def hesapla() -> dict[str, Any]:
    proj = _load(OUT / "PROJEKSIYON.json")
    ulus = _load(OUT / "ULUSLARARASI_STOK_AKIS.json")
    ger = _load(OUT / "GERCEKLIK_KALIBRE.json")
    akis = _load(OUT / "AKIS_OLCUM.json")

    sen = next(s for s in proj["senaryolar"] if s["id"] == "C")
    mfin_kenar = round(
        sum(
            float(e.get("akis_endeks") or 0)
            for e in (sen.get("akis_kenarlari") or [])
            if e.get("hedef") == "merkez_finans" and e.get("tur") == "sizinti"
        ),
        3,
    )
    stok_mfin = (ulus.get("stok") or {}).get("MFIN") or {}
    mfin_stok = float(stok_mfin.get("net_vekil") or 0.0)
    mfin_defter = float(stok_mfin.get("mfin_defter_vekil") or mfin_stok)
    mfin_duz = float(stok_mfin.get("mfin_yapisal_duzeltme") or 0.0)

    usd_v = float(ger.get("usd_per_vekil_mn") or 0.0)
    mfin_usd = float(stok_mfin.get("net_usd_mn") or 0.0)
    akis_mfin = (akis.get("modelden_usd_vekili") or {}).get("mfin_kenar_usd_mn")

    tol = 2.5
    fark_kenar_stok = round(mfin_kenar - mfin_defter, 3)
    uyum = abs(fark_kenar_stok) <= tol and abs(float(ulus["kalibrasyon"]["stok_net_toplam_vekil"])) < 0.01

    return {
        "olcum": "mfin_tutarlilik",
        "senaryo": "C",
        "projeksiyon_mfin_sizinti_kenar_vekil": mfin_kenar,
        "uluslararasi_mfin_defter_vekil": mfin_defter,
        "uluslararasi_mfin_stok_vekil": mfin_stok,
        "yapisal_duzeltme_vekil": mfin_duz,
        "fark_kenar_minus_defter": fark_kenar_stok,
        "mfin_stok_usd_mn": mfin_usd,
        "akis_mfin_kenar_usd_mn": akis_mfin,
        "stok_kapanis_vekil": ulus["kalibrasyon"]["stok_net_toplam_vekil"],
        "tolerans_vekil": tol,
        "uyum_ok": uyum,
        "not": "Kenar=projeksiyon sızıntı toplamı; defter=DIS_ULKE_REFAH MFIN net; stok=yapısal kapanış sonrası",
    }


def _md(d: dict[str, Any]) -> str:
    ok = "OK" if d["uyum_ok"] else "incele"
    return "\n".join(
        [
            "# MFIN tutarlılık (P2)",
            "",
            f"Projeksiyon MFIN kenar: **{d['projeksiyon_mfin_sizinti_kenar_vekil']}** vekil",
            f"Defter MFIN: **{d['uluslararasi_mfin_defter_vekil']}** → yapısal stok **{d['uluslararasi_mfin_stok_vekil']}** "
            f"(düzeltme {d['yapisal_duzeltme_vekil']})",
            f"Kenar−defter fark: **{d['fark_kenar_minus_defter']}** · Σ stok **{d['stok_kapanis_vekil']}** · **{ok}**",
            "",
        ]
    )


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    data = hesapla()
    (OUT / "MFIN_TUTARLILIK.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "MFIN_TUTARLILIK.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'MFIN_TUTARLILIK.md'}")


if __name__ == "__main__":
    main()
