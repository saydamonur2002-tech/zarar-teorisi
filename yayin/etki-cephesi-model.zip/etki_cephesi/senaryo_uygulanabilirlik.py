"""Senaryo C + refah — uygulanabilirlik değerlendirmesi (kalibre stok-akış üzerinden)."""
from __future__ import annotations

import json
from pathlib import Path
import _olasilik
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _skor_bilesen(
    tr_10: float,
    tr_bas: float,
    gsyh_son: float,
    gsyh_bas: float,
    g_mean: float,
    bop_skor: float,
    kapanis: bool,
) -> tuple[dict[str, float], float]:
    tr_yol_skor = max(0.0, min(1.0, (tr_10 - tr_bas) / 6.0))
    gsyh_skor = max(0.0, min(1.0, (gsyh_bas - gsyh_son) / max(gsyh_bas, 0.01)))
    bilesenler = {
        "katman_gerceklesme_ort": round(g_mean, 3),
        "bop_rant_uyumu": round(bop_skor, 3),
        "tr_10y_iyilesme": round(tr_yol_skor, 3),
        "gsyh_pp_iyilesme": round(gsyh_skor, 3),
        "stok_kapanis": 1.0 if kapanis else 0.35,
    }
    w_partial = {"katman_gerceklesme_ort": 18, "bop_rant_uyumu": 12, "tr_10y_iyilesme": 15, "gsyh_pp_iyilesme": 10, "stok_kapanis": 7}
    partial = sum(bilesenler[k] * w_partial[k] for k in w_partial)
    return bilesenler, partial


def degerlendir(olasilik: dict[str, float] | None = None) -> dict[str, Any]:
    """`olasilik` verilirse senaryo olasılıkları (A/B/C) bu ağırlıklarla yeniden hesaplanır (duyarlılık).

    Varsayılan (None): `_olasilik.vekil()` (kapı gözlemleri; gözlem yokken tekdüze).
    """
    sen_doc = _load(DATA / "senaryolar.json")
    mat = _load(OUT / "ULUSLARARASI_STOK_AKIS.json")
    bek_path = OUT / "SENARYO_BEKLENEN_KALIBRE.json"
    bek = _load(bek_path) if bek_path.is_file() else None
    bolge = _load(OUT / "BOLGE_STOK_AKIS.json")
    modul = _load(OUT / "MODUL_KALIBRE.json")
    ger = _load(OUT / "GERCEKLIK_KALIBRE.json")
    z10 = _load(OUT / "ZARAR_10Y_GSYH.json")

    c = next(s for s in sen_doc["senaryolar"] if s["id"] == "C")
    p_c = _olasilik.vekil_s(c)
    olas_ovr: dict[str, float] | None = None
    if olasilik:
        s_o = sum(float(v) for v in olasilik.values()) or 1.0
        olas_ovr = {str(k): float(v) / s_o for k, v in olasilik.items()}
        p_c = olas_ovr["C"]
        if bek:
            rows = bek.get("senaryolar") or []
            tr_e = round(sum(olas_ovr.get(r["id"], 0.0) * float(r["tr_net_10y_yasam_dahil"]) for r in rows), 3)
            gs_e = round(sum(olas_ovr.get(r["id"], 0.0) * float(r["gsyh_yuzde_orta_10y"]) for r in rows), 3)
            bek = {
                **bek,
                "beklenti": {
                    **(bek.get("beklenti") or {}),
                    "olasilik": {k: round(v, 4) for k, v in olas_ovr.items()},
                    "beklenen_tr_net_10y_yasam": tr_e,
                    "beklenen_gsyh_yuzde_orta_10y": gs_e,
                },
            }
    g = ger.get("gerceklesme_oranlari") or {}
    g_mean = sum(float(v) for v in g.values()) / max(len(g), 1)

    kal = mat["kalibrasyon"]
    kapanis = bool(kal.get("kapanis_ok"))
    pay = float(kal.get("rant_inv_geliri_pay_ham") or 0)
    hedef = float(_load(DATA / "kalibre" / "uluslararasi_stok_akis_capa.json")["rant_inv_geliri_hedef_pay"])
    bop_skor = max(0.0, min(1.0, 1.0 - abs(pay - hedef) / hedef))

    tr_bas = float(modul["tr_net_yigini_10y"]["C_refah_taban"])
    tr_10 = float(modul["tr_net_yigini_10y"]["artı_yasam_maliyet_politikasi"])
    iyilesme = tr_10 - tr_bas
    tr_yol_skor = max(0.0, min(1.0, iyilesme / 6.0))

    gsyh_bas = float(modul["gsyh_yuzde_orta"]["taban"])
    gsyh_son = float(modul["gsyh_yuzde_orta"]["yil_10_yasam_dahil"])
    gsyh_skor = max(0.0, min(1.0, (gsyh_bas - gsyh_son) / max(gsyh_bas, 0.01)))

    tr_bek = float((bek or {}).get("beklenti", {}).get("beklenen_tr_net_10y_yasam") or tr_10)
    gsyh_bek = float((bek or {}).get("beklenti", {}).get("beklenen_gsyh_yuzde_orta_10y") or gsyh_son)
    bek_bil, bek_partial = _skor_bilesen(tr_bek, tr_bas, gsyh_bek, gsyh_bas, g_mean, bop_skor, kapanis)

    direnc = bolge.get("rant_kanali_bosluk_taraftari") or []
    direnc_agir = len([a for a in direnc if (a.get("rant_kanal_bosluk_fark_usd_mn") or 0) > 1000])
    direnc_skor = max(0.0, 1.0 - direnc_agir / 8.0)

    halka = bolge.get("halka_cevre_kazanan") or []
    koalisyon_skor = min(1.0, len(halka) / 4.0)

    bilesenler = {
        "olasilik_senaryo_c": round(p_c, 3),
        "katman_gerceklesme_ort": round(g_mean, 3),
        "bop_rant_uyumu": round(bop_skor, 3),
        "tr_10y_iyilesme": round(tr_yol_skor, 3),
        "gsyh_pp_iyilesme": round(gsyh_skor, 3),
        "direnc_dusuk": round(direnc_skor, 3),
        "halka_cevre_koalisyon": round(koalisyon_skor, 3),
        "stok_kapanis": 1.0 if kapanis else 0.35,
    }

    agirlik = {
        "olasilik_senaryo_c": 18,
        "katman_gerceklesme_ort": 18,
        "bop_rant_uyumu": 12,
        "tr_10y_iyilesme": 15,
        "gsyh_pp_iyilesme": 10,
        "direnc_dusuk": 12,
        "halka_cevre_koalisyon": 8,
        "stok_kapanis": 7,
    }
    skor_c = sum(bilesenler[k] * agirlik[k] for k in agirlik)
    skor_c = round(min(100.0, max(0.0, skor_c)), 1)
    olas_c = bilesenler["olasilik_senaryo_c"]
    skor_bek = round(
        min(
            100.0,
            bek_partial
            + bek_bil["tr_10y_iyilesme"] * 12
            + direnc_skor * 12
            + koalisyon_skor * 8
            + olas_c * 18,
        ),
        1,
    )
    skor = round(0.65 * skor_c + 0.35 * skor_bek, 1) if bek else skor_c

    zcok_path = OUT / "ZARAR_10Y_SENARYO_COKLU.json"
    zcok = _load(zcok_path) if zcok_path.is_file() else None
    skor_senaryo: dict[str, float] = {}
    if zcok:
        olas_norm: dict[str, float] = {}
        for s in sen_doc.get("senaryolar") or []:
            olas_norm[str(s["id"])] = _olasilik.vekil_s(s)
        s_olas = sum(olas_norm.values()) or 1.0
        olas_norm = {k: v / s_olas for k, v in olas_norm.items()}
        if olas_ovr:
            olas_norm = dict(olas_ovr)
        by_z = {x["id"]: x for x in zcok.get("senaryolar") or []}
        for sid in ("A", "B", "C"):
            row = by_z.get(sid)
            if not row:
                continue
            tr_s = float(row.get("yil_10_son") or tr_10)
            gsyh_s = float(row.get("gsyh_yuzde_10_son") or gsyh_son)
            bil_s, part_s = _skor_bilesen(tr_s, tr_bas, gsyh_s, gsyh_bas, g_mean, bop_skor, kapanis)
            skor_s = round(
                min(
                    100.0,
                    part_s
                    + bil_s["tr_10y_iyilesme"] * 12
                    + direnc_skor * 12
                    + koalisyon_skor * 8
                    + olas_norm.get(sid, 0.0) * 18,
                ),
                1,
            )
            skor_senaryo[sid] = skor_s

    iy_c = tr_10 - tr_bas
    iy_bek = tr_bek - tr_bas

    def _yon(v: float) -> str:
        return "iyileşir" if v > 0.05 else ("değişmez" if abs(v) <= 0.05 else "kötüleşir")

    # Özet metni sayılardan türetilir (sabit cümle yok): yön, işaret ve eşik kontrolü burada.
    sayisal = (
        f"C yolunda 10 yılda TR net {tr_bas:+.2f} → {tr_10:+.2f} (Δ {iy_c:+.2f} vekil: {_yon(iy_c)}); "
        f"olasılık ağırlıklı beklenen karışımda Δ {iy_bek:+.2f} ({_yon(iy_bek)}); "
        f"katman gerçekleşme ortalaması {g_mean:.2f}."
    )
    bop_txt = "2024 çapaları içinde tutarlı" if bop_skor >= 0.8 else "2024 çapalarından sapıyor"
    if skor >= 62:
        karar = "uygulanabilir_kosullu"
        ozet = f"Politika yığını ve refah rantı {bop_txt}. {sayisal}"
    elif skor >= 45:
        karar = "kisitli_uygulanabilir"
        ozet = f"Model yön doğru; merkez/rakip direnç ve düşük üretim/finans gerçekleşmesi tempo kısar. {sayisal}"
    else:
        karar = "dusuk_uygulanabilirlik"
        ozet = f"Stok kapanışı veya dış direnç zayıflatır; senaryo analitik senaryo olarak kalmalı. {sayisal}"

    engeller = []
    if g_mean < 0.35:
        engeller.append("Katman gerçekleşme ortalaması düşük (üretim/finans ~0,25–0,35).")
    if direnc_agir >= 5:
        engeller.append("Rant kanalında boşluk senaryosunu tercih eden güçlü dış aktörler (EU, US, CN…).")
    if not kapanis:
        engeller.append("Uluslararası stok net toplamı kapanmıyor — vekil ölçeği abartılı olabilir.")
    if tr_10 > -8:
        engeller.append("TR net hâlâ derin negatif; hedef ‘sıfıra yakın’ değil.")
    if iy_bek <= 0.05:
        engeller.append(
            f"Olasılık ağırlıklı beklenen karışımda TR net başlangıç düzeyinin altında (Δ {iy_bek:+.2f}); iyileşme yok."
        )

    kolaylastirici = []
    if halka:
        kolaylastirici.append(f"Halka çevre entegre kazanan: {', '.join(a['ulke'] for a in halka[:5])}.")
    kolaylastirici.append(f"Refah vs boşluk TR kazancı ~{modul['rant_parasal_ozet']['tasarruf_refah_vs_zarar_usd_mn']:,} mn $/yıl vekili.")
    if float(g.get("zarar_teorisi") or 0) >= 0.65:
        kolaylastirici.append("Zarar teorisi katmanı en yüksek gerçekleşme (≈0,7).")

    return {
        "olcum": "senaryo_c_refah_uygulanabilirlik",
        "skor_0_100": skor,
        "skor_senaryo_c": skor_c,
        "skor_beklenen_ab_c": skor_bek if bek else None,
        "skor_senaryo_ab_c": skor_senaryo or None,
        "karar": karar,
        "ozet": ozet,
        "iyilesme_c_vekil": round(iy_c, 2),
        "iyilesme_beklenen_vekil": round(iy_bek, 2),
        "bilesenler": bilesenler,
        "bilesenler_beklenen": bek_bil if bek else None,
        "agirliklar": agirlik,
        "referans_beklenen": (bek or {}).get("beklenti"),
        "engeller": engeller,
        "kolaylastiricilar": kolaylastirici,
        "referans": {
            "tr_net_10y": tr_10,
            "gsyh_yuzde_10y": gsyh_son,
            "z10_yil": z10.get("horizon", {}).get("bit_yil"),
        },
        "kaynak_raporlar": [
            "ULUSLARARASI_STOK_AKIS.json",
            "BOLGE_STOK_AKIS.json",
            "MODUL_KALIBRE.json",
            "GERCEKLIK_KALIBRE.json",
        ],
    }


def _md(d: dict[str, Any]) -> str:
    lines = [
        "# Senaryo C + refah — uygulanabilirlik",
        "",
        f"**Skor: {d['skor_0_100']}/100** · **{d['karar']}**"
        + (
            f" (C: {d['skor_senaryo_c']}, beklenen A/B/C: {d['skor_beklenen_ab_c']})"
            if d.get("skor_beklenen_ab_c") is not None
            else ""
        ),
        "",
        d["ozet"],
        "",
        "## Bileşenler (0–1)",
        "",
        "| Bileşen | Değer | Ağırlık |",
        "| --- | ---: | ---: |",
    ]
    for k, w in d["agirliklar"].items():
        lines.append(f"| {k} | {d['bilesenler'][k]} | {w} |")
    rb = d.get("referans_beklenen")
    ss = d.get("skor_senaryo_ab_c")
    if rb:
        lines.extend(
            [
                "",
                "## Beklenen (A/B/C olasılık)",
                "",
                f"- TR net 10y (yaşam dahil): **{rb.get('beklenen_tr_net_10y_yasam')}**",
                f"- GSYH % orta: **{rb.get('beklenen_gsyh_yuzde_orta_10y')}**",
                "",
            ]
        )
    if ss:
        lines.extend(
            [
                "## Skor — senaryo başına",
                "",
                "| Senaryo | Skor |",
                "| --- | ---: |",
            ]
        )
        for sid in ("A", "B", "C"):
            if sid in ss:
                lines.append(f"| {sid} | {ss[sid]} |")
        lines.append("")
    lines.extend(["", "## Engeller", ""])
    for e in d["engeller"] or ["—"]:
        lines.append(f"- {e}")
    lines.extend(["", "## Kolaylaştırıcılar", ""])
    for e in d["kolaylastiricilar"]:
        lines.append(f"- {e}")
    lines.extend(
        [
            "",
            f"**10y TR net (kalibre yol):** {d['referans']['tr_net_10y']} vekil · "
            f"GSYH % orta **{d['referans']['gsyh_yuzde_10y']}**",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    if not (OUT / "ULUSLARARASI_STOK_AKIS.json").is_file():
        import subprocess
        import sys

        subprocess.check_call([sys.executable, str(REPO / "etki_cephesi" / "uluslararasi_stok_akis.py")])
    data = degerlendir()
    (OUT / "SENARYO_UYGULANABILIRLIK.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "SENARYO_UYGULANABILIRLIK.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'SENARYO_UYGULANABILIRLIK.md'}")


if __name__ == "__main__":
    main()
