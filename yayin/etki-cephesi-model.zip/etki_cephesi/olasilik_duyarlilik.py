"""C senaryosu olasılığı duyarlılık bandı (0,30–0,80).

Pipeline olasılıkları `_olasilik.vekil()` (kapı gözlemleri; gözlem yokken tekdüze 1/3). Eski el ataması 0,22/0,18/0,60 kaldırıldı.
Bu modül yeni bir olasılık üretmez; sonucun C'nin ağırlığına ne kadar bağlı olduğunu gösterir.
C = c; kalan (1 − c) A:B arasında taban oranla (0,22:0,18) bölünür.
"""
from __future__ import annotations

import json
from pathlib import Path
import _olasilik
from typing import Any

from senaryo_uygulanabilirlik import degerlendir

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"

C_MIN, C_MAX, ADIM = 0.30, 0.80, 0.05
ESIK_KOSULLU = 62.0  # senaryo_uygulanabilirlik.py: skor >= 62 → uygulanabilir_kosullu
ESIK_IYILESME = 0.05  # beklenen karışımda TR net iyileşme eşiği (vekil)


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _olas(c: float, taban: dict[str, float]) -> dict[str, float]:
    ab = taban["A"] + taban["B"]
    return {"A": (1 - c) * taban["A"] / ab, "B": (1 - c) * taban["B"] / ab, "C": c}


def _satir(c: float, taban: dict[str, float], rows: dict[str, Any]) -> dict[str, Any]:
    o = _olas(c, taban)
    d = degerlendir(o)
    rb = d["referans_beklenen"] or {}
    return {
        "p_C": round(c, 3),
        "p_A": round(o["A"], 4),
        "p_B": round(o["B"], 4),
        "beklenen_tr_net_10y_yasam": rb.get("beklenen_tr_net_10y_yasam"),
        "beklenen_tr_net_katman_10y": round(sum(o[k] * float(rows[k]["tr_net_katman_10y"]) for k in o), 3),
        "beklenen_gsyh_yuzde_10y": rb.get("beklenen_gsyh_yuzde_orta_10y"),
        "iyilesme_beklenen_vekil": d["iyilesme_beklenen_vekil"],
        "skor_0_100": d["skor_0_100"],
        "skor_beklenen": d["skor_beklenen_ab_c"],
        "skor_senaryo_c": d["skor_senaryo_c"],
        "karar": d["karar"],
    }


def _gecis(satirlar: list[dict[str, Any]], alan: str, esik: float) -> float | None:
    """İlk (artan c) eşik geçişi: değer eşiğin altından üstüne çıkıyorsa doğrusal enterpolasyonla c."""
    for a, b in zip(satirlar, satirlar[1:]):
        va, vb = float(a[alan]), float(b[alan])
        if (va < esik <= vb) or (va >= esik > vb):
            t = (esik - va) / (vb - va)
            return round(float(a["p_C"]) + t * (float(b["p_C"]) - float(a["p_C"])), 3)
    return None


def _kapi_sonuclari() -> list[dict[str, Any]]:
    """K2 kapısı sonuçlarının (açık sayısı) uygulanabilirlik kararına bağlanması. Tam olasılık, bant kırpması yok."""
    g = _olasilik.hesapla_P()
    out = []
    for r in g["k2_sonuc_tablosu"]:
        o = r["olasilik_tam"]
        d = degerlendir(o)
        out.append({"k_acik": r["k_acik"], "n": r["n"], "P": {k: round(v, 3) for k, v in o.items()}, "skor_0_100": d["skor_0_100"], "karar": d["karar"], "esigi_gecer": d["skor_0_100"] >= ESIK_KOSULLU})
    return out


def hesapla() -> dict[str, Any]:
    sen = _olasilik.vekil()
    bek = _load(OUT / "SENARYO_BEKLENEN_KALIBRE.json")
    rows = {r["id"]: r for r in bek["senaryolar"]}
    n = int(round((C_MAX - C_MIN) / ADIM))
    cs = [round(C_MIN + i * ADIM, 3) for i in range(n + 1)]
    satirlar = [_satir(c, sen, rows) for c in cs]
    taban_c = sen["C"]
    taban = _satir(taban_c, sen, rows)
    ana = _load(OUT / "SENARYO_UYGULANABILIRLIK.json")
    aralik = lambda k: (min(r[k] for r in satirlar), max(r[k] for r in satirlar))  # noqa: E731
    return {
        "olcum": "olasilik_duyarlilik_C",
        "etiket": "olasilik_olculmedi_duyarlilik_bandi",
        "not": (
            "Taban olasılık kapı iskeletinden (`_olasilik.py`); bu rapor yeni olasılık üretmez. C = p, kalan A:B taban oranla "
            f"({sen['A']:.3f}:{sen['B']:.3f}) bölünür."
        ),
        "taban_olasilik": sen,
        "taban_satir_ana_rapor_ile_tutarli": (
            taban["skor_0_100"] == ana["skor_0_100"]
            and abs(taban["beklenen_tr_net_10y_yasam"] - ana["referans_beklenen"]["beklenen_tr_net_10y_yasam"]) < 0.01  # ana rapor 2 hane yuvarlar
        ),
        "taban_satir": taban,
        "satirlar": satirlar,
        "kapi_sonuclari": _kapi_sonuclari(),
        "aralik": {
            "beklenen_tr_net_10y_yasam": aralik("beklenen_tr_net_10y_yasam"),
            "skor_0_100": aralik("skor_0_100"),
        },
        "gecisler": {
            "karar_kosullu_skor_62": _gecis(satirlar, "skor_0_100", ESIK_KOSULLU),
            "beklenen_iyilesme_sifir_ustu": _gecis(satirlar, "iyilesme_beklenen_vekil", ESIK_IYILESME),
        },
        "esikler": {"skor_kosullu": ESIK_KOSULLU, "iyilesme": ESIK_IYILESME},
    }


def _md(d: dict[str, Any]) -> str:
    g = d["gecisler"]
    L = [
        "# C senaryosu olasılığı — duyarlılık bandı",
        "",
        f"**Etiket: {d['etiket']}.** {d['not']}",
        "",
        "| P(C) | P(A) | P(B) | E[TR net 10y, yaşam dahil] | E[GSYH %] | E[iyileşme] | Skor | Karar |",
        "| ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |",
    ]
    for r in d["satirlar"]:
        mark = ""
        L.append(
            f"| {r['p_C']:.2f}{mark} | {r['p_A']:.3f} | {r['p_B']:.3f} | {r['beklenen_tr_net_10y_yasam']} | "
            f"{r['beklenen_gsyh_yuzde_10y']} | {r['iyilesme_beklenen_vekil']:+.2f} | {r['skor_0_100']} | {r['karar']} |"
        )
    L += ["", "## Kapı sonuçları (K2: 3 kontrol noktasından kaçı açık)", "", "| Açık | P(A) | P(B) | P(C) | Skor | Karar | Eşiği geçer |", "| ---: | ---: | ---: | ---: | ---: | --- | --- |"]
    for r in d["kapi_sonuclari"]:
        L.append(f"| {r['k_acik']}/{r['n']} | {r['P']['A']} | {r['P']['B']} | {r['P']['C']} | {r['skor_0_100']} | {r['karar']} | {'evet' if r['esigi_gecer'] else 'hayır'} |")
    tb = d["taban_satir"]
    L += ["", f"Taban (kapı iskeleti, gözlem yok): P(C) = {tb['p_C']:.3f} → skor {tb['skor_0_100']} · {tb['karar']} (bandın dışında, ızgarada değil).", ""]
    lo, hi = d["aralik"]["beklenen_tr_net_10y_yasam"]
    slo, shi = d["aralik"]["skor_0_100"]
    L += [
        "",
        f"- E[TR net 10y] aralığı: **{lo} … {hi}** (P(C) 0,30 → 0,80).",
        f"- Skor aralığı: **{slo} … {shi}**.",
        "- Karar eşiği (skor 62) geçişi: "
        + (f"P(C) ≈ **{g['karar_kosullu_skor_62']}**" if g["karar_kosullu_skor_62"] is not None else "bantta geçiş yok"),
        "- Beklenen karışımda iyileşme (Δ > 0,05) başlangıcı: "
        + (f"P(C) ≈ **{g['beklenen_iyilesme_sifir_ustu']}**" if g["beklenen_iyilesme_sifir_ustu"] is not None else "bantta geçiş yok"),
        f"- Taban satır ana raporla tutarlı: {d['taban_satir_ana_rapor_ile_tutarli']}.",
        "",
    ]
    return "\n".join(L)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    d = hesapla()
    (OUT / "OLASILIK_DUYARLILIK.json").write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "OLASILIK_DUYARLILIK.md").write_text(_md(d), encoding="utf-8")
    print(f"Wrote {OUT / 'OLASILIK_DUYARLILIK.md'}")


if __name__ == "__main__":
    main()
