"""Rakip ikame akışı çift sayılıyor mu? Doğrulama (tanı raporu).

Koddan: `projeksiyon._akislar` her kaynak havza için v = kayip_eff × pay × ikame_carpan hesaplar; AYNI v
  (1) hedef havzanın girişine yazılır (ikame_g[hedef] → bolgesel_net.rakip_ikame_gelen, havza net'ine +),
  (2) aynı kenar listesinden aktörlere dağıtılır (`ikame_kazanc`, kazanç kanalı).
Her ikisi de TR boşalmasından (V) beslenir. Korunum testi: aktör kazançları (V ile sınırlı) + havza girişleri ≤ V olmalıdır.
Bu modül: (a) kenar–giriş–kazanç özdeşliğini, (b) V korunumu aşımını, (c) çift sayımı bir yandan temizleyen iki düzeltme varyantını
(K1: ikame aktör kazancından düş; K2: havza girişini havza net'inden düş) ve etkilerini (sistem toplamı, ölü ağırlık, sınıf değişimi) verir.
Ana modeli DEĞİŞTİRMEZ; hangi tarafın temizleneceği kullanıcı kararıdır.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _sinif(net: float, bant: float) -> str:
    return "kazanan" if net - bant > 0 else ("kaybeden" if net + bant < 0 else "bant_ici")


def dogrula(sid: str, p: dict[str, Any], m: dict[str, Any]) -> dict[str, Any]:
    led = {r["ulke"]: r for r in _load(OUT / f"DIS_ULKE_REFAH_{sid}.json")["ulke_defteri"]}
    hp = _load(DATA / "ulke_havza_pay.json")["bolge_ulke_pay"]
    kenar = sum(float(e["akis_endeks"]) for e in p["akis_kenarlari"] if e["tur"] == "rakip_ikame")
    ig_havza = {b["bolge"]: float(b["rakip_ikame_gelen"]) for b in p["bolgesel_net"]}
    ig = sum(ig_havza.values())
    ikame_aktor = sum(float(d["ikame_kazanc"]) for d in p["dis_aktör_kazanc"])
    v, kaz = float(m["bosluk_V"]), float(m["kazanc"]["toplam"])
    ig_ulke: dict[str, float] = {}
    for b, g in ig_havza.items():
        for u in hp.get(b, []):
            if u["ulke"] != "TR":
                ig_ulke[u["ulke"]] = ig_ulke.get(u["ulke"], 0.0) + float(u["pay"]) * g
    ortak = sorted(c for c in ig_ulke if float(led.get(c, {}).get("ikame_kazanc", 0.0)) > 0)
    net0 = {c: float(r.get("net_maliyetli", r.get("net_refah_entegre")) or 0.0) for c, r in led.items() if c != "TR"}
    bant = {c: float(r.get("net_bandi") or 0.0) for c, r in led.items() if c != "TR"}
    k1 = {c: net0[c] - float(led[c].get("ikame_kazanc", 0.0)) for c in net0}
    k2 = {c: net0[c] - ig_ulke.get(c, 0.0) for c in net0}
    siniflar = {c: (_sinif(net0[c], bant[c]), _sinif(k1[c], bant[c]), _sinif(k2[c], bant[c])) for c in net0}
    degisen = {c: s for c, s in siniflar.items() if len(set(s)) > 1}
    havuz = float(m["kayip"]["toplam"])
    d0 = havuz - kaz
    return {
        "kenar_ikame_toplam": round(kenar, 3),
        "havza_girisi_ig_toplam": round(ig, 3),
        "aktor_ikame_kazanci_toplam": round(ikame_aktor, 3),
        "v": round(v, 3),
        "aktor_kazanci_v_sinirli": round(kaz, 3),
        "kredi_toplam_aktor_arti_havza_girisi": round(kaz + ig, 3),
        "korunum_asimi": round(max(0.0, kaz + ig - v), 3),
        "ayni_ulke_hem_havza_hem_aktor": ortak,
        "ulke_ig": {c: round(v_, 3) for c, v_ in sorted(ig_ulke.items(), key=lambda kv: -kv[1])[:8]},
        "olu_agirlik": round(d0, 3),
        "olu_agirlik_k1_aktor_ikame_dusulurse": round(d0 + ikame_aktor, 3),
        "olu_agirlik_k2_havza_girisi_dusulurse": round(d0 + ig, 3),
        "sistem_net_toplam": {"mevcut": round(sum(net0.values()) + _tr(led), 3), "k1": round(sum(k1.values()) + _tr(led), 3), "k2": round(sum(k2.values()) + _tr(led), 3)},
        "sinif_degisimi_mevcut_k1_k2": {c: list(s) for c, s in sorted(degisen.items())},
    }


def _tr(led: dict[str, Any]) -> float:
    r = led["TR"]
    return float(r.get("net_maliyetli", r.get("net_refah_entegre")) or 0.0)


def calistir() -> dict[str, Any]:
    muh = {s["id"]: s for s in _load(OUT / "KAZANC_KAYIP_MUHASEBE.json")["senaryolar"]}
    proj = {s["id"]: s for s in _load(OUT / "PROJEKSIYON.json")["senaryolar"]}
    sen = {sid: dogrula(sid, proj[sid], muh[sid]) for sid in ("A", "B", "C")}
    d = {"olcum": "ikame_cift_sayim_dogrulama", "etiket": "tani_girdi_degil", "senaryolar": sen,
         "not": "Ana model değiştirilmedi. Aynı v hem havza girişine hem aktör ikame kazancına yazılıyor; korunum (V) aşılıyor. Hangi tarafın düşüleceği karar gerektirir."}
    (OUT / "IKAME_CIFT_SAYIM.json").write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    L = ["# Rakip ikame akışı çift sayımı: doğrulama", "", d["not"], "",
         "| Senaryo | Kenar toplamı | Havza girişi (ig) | Aktör ikame kazancı | V | Aktör kazancı | Aktör + ig | V aşımı |",
         "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |"]
    for sid, s in sen.items():
        L.append(f"| {sid} | {s['kenar_ikame_toplam']} | {s['havza_girisi_ig_toplam']} | {s['aktor_ikame_kazanci_toplam']} | {s['v']} | {s['aktor_kazanci_v_sinirli']} | {s['kredi_toplam_aktor_arti_havza_girisi']} | **{s['korunum_asimi']}** |")
    L += ["", "## Düzeltme varyantlarının etkisi", "", "| Senaryo | Ölü ağırlık | K1: aktör ikame düşülürse | K2: havza girişi düşülürse | Σ net (mevcut / K1 / K2) |", "| --- | ---: | ---: | ---: | --- |"]
    for sid, s in sen.items():
        t = s["sistem_net_toplam"]
        L.append(f"| {sid} | {s['olu_agirlik']} | {s['olu_agirlik_k1_aktor_ikame_dusulurse']} | {s['olu_agirlik_k2_havza_girisi_dusulurse']} | {t['mevcut']} / {t['k1']} / {t['k2']} |")
    L += ["", "## Sınıf değişimi (mevcut → K1 → K2)", ""]
    for sid, s in sen.items():
        ch = s["sinif_degisimi_mevcut_k1_k2"]
        L.append(f"- **{sid}:** " + ("; ".join(f"{c}: {' → '.join(v)}" for c, v in ch.items()) if ch else "değişen yok"))
    L += ["", "Aynı ülkenin hem havza girişi hem aktör ikame kazancı olduğu durumlar: " + "; ".join(f"{sid}: {', '.join(s['ayni_ulke_hem_havza_hem_aktor'])}" for sid, s in sen.items())]
    (OUT / "IKAME_CIFT_SAYIM.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    return d


if __name__ == "__main__":
    calistir()
    print("IKAME_CIFT_SAYIM ok")
