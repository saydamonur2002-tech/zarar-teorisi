"""Rakip ikame akışının çift sayımı: düzeltme sonrası doğrulama (K1 uygulandı).

Sorun (düzeltme öncesi): `projeksiyon` her kaynak havza için v = kayip_eff × pay × ikame_carpan hesaplar; AYNI v hem hedef havzanın girişine
(`rakip_ikame_gelen`, havza net'ine +) hem aktörlere `ikame_kazanc` olarak yazılıyordu. Aktör kazancı + havza girişi V'yi aşıyordu
(A 5,41, B 8,62, C 3,36; bkz. REVIZE_SONUC).
K1 (uygulandı): ikame aktör kazancından düşüldü; kazanç normalizasyonu V'den havza girişini düştükten sonra kalana sığdırılır.
Bu modül düzeltmenin tutarlılığını doğrular: (a) kenar–giriş özdeşliği, (b) aktör kazancı + havza girişi ≤ V, (c) ham ikame dağılımı yalnız tanı,
(d) ölü ağırlık ve sistem toplamı. Tanı raporu: başka modüle girdi olmaz.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "etki_cephesi"


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def dogrula(sid: str, p: dict[str, Any], m: dict[str, Any]) -> dict[str, Any]:
    led = _load(OUT / f"DIS_ULKE_REFAH_{sid}.json")["ulke_defteri"]
    kenar = sum(float(e["akis_endeks"]) for e in p["akis_kenarlari"] if e["tur"] == "rakip_ikame")
    ig = sum(float(b["rakip_ikame_gelen"]) for b in p["bolgesel_net"])
    ikame_aktor = sum(float(d["ikame_kazanc"]) for d in p["dis_aktör_kazanc"])
    ham_ikame = sum(float(d.get("ikame_hesap_ham_havza_girisinde_sayildi", 0.0)) for d in p["dis_aktör_kazanc"])
    v, kaz = float(m["bosluk_V"]), float(m["kazanc"]["toplam"])
    havuz = float(m["kayip"]["toplam"])
    net_toplam = sum(float(r.get("net_maliyetli", r.get("net_refah_entegre")) or 0.0) for r in led)
    return {
        "kenar_ikame_toplam": round(kenar, 3),
        "havza_girisi_ig_toplam": round(ig, 3),
        "aktor_ikame_kazanci_toplam": round(ikame_aktor, 3),
        "ham_ikame_dagilimi_tani": round(ham_ikame, 3),
        "v": round(v, 3),
        "aktor_kazanci_v_sinirli": round(kaz, 3),
        "kredi_toplam_aktor_arti_havza_girisi": round(kaz + ig, 3),
        "korunum_asimi": round(max(0.0, kaz + ig - v), 3),
        "korunum_boslugu": round(v - kaz - ig, 3),
        "normalizasyon_katsayi": m["normalizasyon"]["katsayi"],
        "olu_agirlik": round(havuz - kaz, 3),
        "sistem_net_toplam": round(net_toplam, 3),
    }


def calistir() -> dict[str, Any]:
    muh = {s["id"]: s for s in _load(OUT / "KAZANC_KAYIP_MUHASEBE.json")["senaryolar"]}
    proj = {s["id"]: s for s in _load(OUT / "PROJEKSIYON.json")["senaryolar"]}
    sen = {sid: dogrula(sid, proj[sid], muh[sid]) for sid in ("A", "B", "C")}
    d = {"olcum": "ikame_cift_sayim_dogrulama_k1", "etiket": "tani_girdi_degil", "senaryolar": sen,
         "not": "K1 uygulandı: ikame aktör kazancından düşüldü, havza girişi korundu. Aktör kazancı + havza girişi V'ye sığmalı (korunum aşımı ≈ 0)."}
    (OUT / "IKAME_CIFT_SAYIM.json").write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    L = ["# Rakip ikame çift sayımı: K1 sonrası doğrulama", "", d["not"], "",
         "| Senaryo | Kenar toplamı | Havza girişi (ig) | Aktör ikame kazancı | Ham ikame dağılımı (tanı) | V | Aktör kazancı | Aktör + ig | V aşımı | V boşluğu | Katsayı |",
         "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |"]
    for sid, s in sen.items():
        L.append(f"| {sid} | {s['kenar_ikame_toplam']} | {s['havza_girisi_ig_toplam']} | {s['aktor_ikame_kazanci_toplam']} | {s['ham_ikame_dagilimi_tani']} | {s['v']} | {s['aktor_kazanci_v_sinirli']} | {s['kredi_toplam_aktor_arti_havza_girisi']} | **{s['korunum_asimi']}** | {s['korunum_boslugu']} | {s['normalizasyon_katsayi']} |")
    L += ["", "| Senaryo | Ölü ağırlık | Σ net (tüm aktörler) |", "| --- | ---: | ---: |"]
    for sid, s in sen.items():
        L.append(f"| {sid} | {s['olu_agirlik']} | {s['sistem_net_toplam']} |")
    (OUT / "IKAME_CIFT_SAYIM.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    return d


if __name__ == "__main__":
    calistir()
    print("IKAME_CIFT_SAYIM ok")
