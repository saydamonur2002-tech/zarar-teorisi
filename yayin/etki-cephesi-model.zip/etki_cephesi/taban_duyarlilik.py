"""Gerçekleşme tabanı duyarlılığı: kalibre tabanlar (gerceklik_capa.json → gerceklesme_taban) ölçeklenip tüm zincir yeniden koşulur.

Bağımsız araç (run_all adımı değil): her senaryo repo'nun geçici bir kopyasında run_all'ı kararlı duruma kadar çalıştırır.
Çıktı: data/etki_cephesi/taban_duyarlilik.json. Pipeline değişirse yeniden üretilmelidir (test, taban=1,0 satırını güncel rapora karşı kontrol eder).
Kullanım: python etki_cephesi/taban_duyarlilik.py
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
CAPA_REL = Path("data/etki_cephesi/kalibre/gerceklik_capa.json")
KATMANLAR = ("zarar_teorisi", "uretim_ic_akis", "finans_katman")
ORTAK = [round(0.1 * i, 1) for i in range(0, 11)]
TEK = [0.0, 0.25, 0.5, 0.75]
INCE_ORTAK = [round(0.01 * i, 2) for i in range(71, 80)]  # üç taban birlikte, eşik çevresi
INCE_ZARAR = [0.50, 0.51, 0.513, 0.52, 0.53]  # zarar teorisi tabanı, mutlak değer (eşik çevresi)


def kos(carpan: dict[str, float]) -> dict[str, Any]:
    tmp = Path(tempfile.mkdtemp(prefix="taban_"))
    try:
        r = tmp / "r"
        shutil.copytree(REPO, r, ignore=shutil.ignore_patterns("__pycache__", ".pytest_cache"))
        capa = json.loads((r / CAPA_REL).read_text(encoding="utf-8"))
        capa["gerceklesme_taban"] = {**capa["gerceklesme_taban"], **{k: round(capa["gerceklesme_taban"][k] * v, 6) for k, v in carpan.items()}}
        (r / CAPA_REL).write_text(json.dumps(capa, ensure_ascii=False, indent=2), encoding="utf-8")
        out = r / "reports" / "etki_cephesi"
        for _ in range(8):
            subprocess.run([sys.executable, str(r / "etki_cephesi" / "run_all.py")], cwd=r, capture_output=True, check=True)
            k = json.loads((out / "RUN_ALL_KARARLILIK.json").read_text(encoding="utf-8"))
            if k.get("kararli") and k.get("gecis") == 1:
                break
        g = json.loads((out / "GERCEKLIK_KALIBRE.json").read_text(encoding="utf-8"))
        u = json.loads((out / "SENARYO_UYGULANABILIRLIK.json").read_text(encoding="utf-8"))
        return {
            "taban": capa["gerceklesme_taban"],
            "gerceklesme": g["gerceklesme_oranlari"],
            "tr_net_10y_c": g["tr_net_yol_10_son"],
            "skor": u["skor_0_100"],
            "karar": u["karar"],
        }
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def calistir() -> dict[str, Any]:
    capa0 = json.loads((REPO / CAPA_REL).read_text(encoding="utf-8"))["gerceklesme_taban"]
    isler: list[tuple[str, str | None, float]] = [("ortak", None, c) for c in ORTAK]
    for k in KATMANLAR:
        isler += [("tek", k, c) for c in TEK]
    capa_z = capa0["zarar_teorisi"]
    isler += [("ince_ortak", None, c) for c in INCE_ORTAK]
    isler += [("ince", "zarar_teorisi", t / capa_z) for t in INCE_ZARAR]
    with ThreadPoolExecutor(max_workers=4) as ex:
        sonuc = list(ex.map(lambda j: kos({kk: j[2] for kk in KATMANLAR} if j[0] in ("ortak", "ince_ortak") else {j[1]: j[2]}), isler))
    satirlar = [{"tur": j[0], "katman": j[1], "taban_carpani": j[2], **s} for j, s in zip(isler, sonuc)]
    ortak = [s for s in satirlar if s["tur"] == "ortak"]
    gecis = next((s["taban_carpani"] for s in ortak if s["karar"] == "kisitli_uygulanabilir"), None)
    ince = [s for s in satirlar if s["tur"] == "ince"]
    ortak_ince = sorted((s for s in satirlar if s["tur"] in ("ortak", "ince_ortak")), key=lambda s: s["taban_carpani"])
    o_esik = next((s["taban_carpani"] for s in ortak_ince if s["karar"] == "kisitli_uygulanabilir"), None)
    z_esik = min((s["taban"]["zarar_teorisi"] for s in ince if s["karar"] == "kisitli_uygulanabilir"), default=None)
    d = {
        "olcum": "gerceklesme_taban_duyarlilik", "etiket": "tani_girdi_degil",
        "mevcut_taban": capa0, "taban_carpani_aciklama": "çarpan × mevcut taban; ortak = üç taban birlikte; tek = yalnız bir katman",
        "satirlar": satirlar,
        "ortak_ilk_kisitli_uygulanabilir_carpan": gecis,
        "zarar_tabani_en_kucuk_kisitli_taban_ince_tarama": z_esik,
        "ortak_esik_carpani_ince_tarama": o_esik,
        "ortak_marj": None if o_esik is None else round(1 - o_esik, 4),
        "zarar_tabani_marj": None if z_esik is None else round((capa_z - z_esik) / capa_z, 4),
        "not": "Otomatik gerçekleşme (tavan ÷ beklenen iyileşme) tabana göre max alınır; taban 0 iken yalnız otomatik hesap işler. Tavanlar (zarar 0,08×yatırım geliri vb.) da atanmıştır.",
    }
    (REPO / "data" / "etki_cephesi" / "taban_duyarlilik.json").write_bytes((json.dumps(d, ensure_ascii=False, indent=2) + "\n").replace("\n", "\r\n").encode("utf-8"))
    return d


if __name__ == "__main__":
    calistir()
    print("taban_duyarlilik ok")
