"""İki modül + mevcut kalibre yığını — birleşik 10 yıl raporu."""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "etki_cephesi"


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _run(mod: str) -> None:
    subprocess.check_call([sys.executable, str(REPO / "etki_cephesi" / mod)])


def entegre(pipeline: bool = True) -> dict[str, Any]:
    if pipeline:
        _run("senaryo_gerceklik_kalibre.py")
        _run("zarar_10y_gsyh.py")
    _run("dis_rant_parasal_akisi.py")
    _run("yasam_maliyet_katman.py")
    _run("stok_akis_sim.py")
    _run("bolge_stok_akis.py")
    _run("finans_katman_senaryo_coklu.py")
    _run("senaryo_coklu_p2.py")
    _run("dis_kurum_entegrasyon.py")
    _run("ulke_kanal_dokum.py")
    _run("zarar_10y_senaryo_coklu.py")
    _run("ulke_kanal_dokum_10y.py")
    _run("uluslararasi_stok_akis.py")
    _run("lm_rant_sektor.py")
    _run("finans_senet_faiz_kopru.py")
    _run("mfin_tutarlilik.py")
    _run("uluslararasi_stok_akis_10y.py")
    _run("gerceklik_capa_senkron.py")
    _run("senaryo_beklenen_kalibre.py")
    _run("senaryo_uygulanabilirlik.py")
    _run("uluslararasi_snapshot_disa.py")
    _run("durum_ozeti.py")

    ger = _load(OUT / "GERCEKLIK_KALIBRE.json")
    z10 = _load(OUT / "ZARAR_10Y_GSYH.json")
    rant = _load(OUT / "DIS_RANT_PARASAL.json")
    yasam = _load(OUT / "YASAM_MALIYET_KATMAN.json")
    stok = _load(OUT / "STOK_AKIS_SIM.json") if (OUT / "STOK_AKIS_SIM.json").is_file() else {}

    tr_yol = float(z10["yil_10_son"]["tr_net"])
    tr_final = float(yasam["tr_net_10y_son"])

    out = {
        "olcum": "modul_entegrasyon_kalibre",
        "moduller": ["dis_rant_parasal_akisi", "yasam_maliyet_katman", "stok_akis_sim"],
        "rant_parasal_ozet": rant["ozet"],
        "yasam_maliyet_ozet": {
            "tr_net_son": tr_final,
            "iyilesme_vekil": yasam["iyilesme_vekil"],
            "hane_tasarruf_usd_mn": yasam["hane_tasarruf_usd_mn_10y"],
            "gsyh_yuzde_orta_son": yasam["gsyh_yuzde_orta_son"],
        },
        "tr_net_yigini_10y": {
            "C_refah_taban": z10["taban_C_refah"]["tr_net"],
            "kalibre_10y_zarar_yolu": tr_yol,
            "artı_yasam_maliyet_politikasi": tr_final,
            "toplam_iyilesme_vekil": round(tr_final - float(z10["taban_C_refah"]["tr_net"]), 3),
        },
        "gsyh_yuzde_orta": {
            "taban": z10["taban_C_refah"]["gsyh_yuzde_orta"],
            "yil_10_katmanlar": z10["yil_10_son"]["gsyh_yuzde_orta"],
            "yil_10_yasam_dahil": yasam["gsyh_yuzde_orta_son"],
        },
        "gerceklesme": ger["gerceklesme_oranlari"],
        "usd_kopruleri": ger["usd_kopruleri"],
        "stok_akis_ozet": {
            "entegre_sektor_trilyonTL": (stok.get("entegre_puls") or {}).get("sektor_etkisi_trilyonTL"),
            "lambda": stok.get("lambda_yayilim"),
        },
        "kaynak_raporlar": [
            "GERCEKLIK_KALIBRE.md",
            "ZARAR_10Y_GSYH.md",
            "DIS_RANT_PARASAL.md",
            "YASAM_MALIYET_KATMAN.md",
            "STOK_AKIS_SIM.md",
        ],
    }
    return out


def _md(d: dict[str, Any]) -> str:
    y = d["tr_net_yigini_10y"]
    g = d["gsyh_yuzde_orta"]
    r = d["rant_parasal_ozet"]
    ys = d["yasam_maliyet_ozet"]
    lines = [
        "# Modül entegrasyonu — gerçeklik kalibre (10 yıl)",
        "",
        "## TR net vekil yığını",
        "",
        f"| Aşama | TR net |",
        f"| --- | ---: |",
        f"| C + refah (taban) | {y['C_refah_taban']} |",
        f"| 10y — zarar/üretim/finans (kalibre) | {y['kalibre_10y_zarar_yolu']} |",
        f"| + yaşam maliyeti politikası | **{y['artı_yasam_maliyet_politikasi']}** |",
        f"| **Toplam iyileşme** | **{y['toplam_iyilesme_vekil']}** |",
        "",
        "## GSYH % (USD orta köprü)",
        "",
        f"- Taban: **{g['taban']}%**",
        f"- 10y katmanlar (2036): **{g['yil_10_katmanlar']}%**",
        f"- Yaşam maliyeti dahil: **{g['yil_10_yasam_dahil']}%**",
        "",
        "## Modül 1 — dış rant parasal akış",
        "",
        f"- Zarar (boşluk) USD: **{r['zarar_usd_mn_toplam']:,}** mn/yıl vekili",
        f"- Refah dış USD: **{r['refah_dis_usd_mn_toplam']:,}** mn",
        f"- TR refah iç: **{r['refah_tr_ic_usd_mn']:,}** mn",
        f"- Tasarruf refah vs zarar: **{r['tasarruf_refah_vs_zarar_usd_mn']:,}** mn",
        "",
        "## Modül 2 — yaşam maliyeti",
        "",
        f"- Hane tasarrufu 10y: **{ys['hane_tasarruf_usd_mn']:,}** mn USD",
        f"- TR net ek iyileşme: **{ys['iyilesme_vekil']}** vekil",
        "",
    ]
    return "\n".join(lines)


def main() -> None:
    import argparse

    ap = argparse.ArgumentParser()
    ap.add_argument("--modules-only", action="store_true", help="Mevcut raporlar üzerinde yalnız iki modül")
    args = ap.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    data = entegre(pipeline=not args.modules_only)
    (OUT / "MODUL_KALIBRE.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "MODUL_KALIBRE.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'MODUL_KALIBRE.md'}")


if __name__ == "__main__":
    main()
