"""Kazanç–kayıp muhasebesi: dış aktör kazancı boşluğu (V) aşıyor mu? Ve kapsam (neyin modellenmediği).

Ölçüm raporudur. `projeksiyon.py` eskiden bir korunum özdeşliği tanımlamıyordu; bu rapor özdeşliği yazar ve ölçer:

  Boşluk V = Σ_bölge (TR boşalması) + pasif_k · Σ_bölge (pasif boşluk)     [kazancın dağıtıldığı havuz]
  Kazanç kanalları (aynı V'nin ayrı dağıtım kuralları):
    kanal   = V × dış aktör payı           (dis_aktör_pay.json)
    matris  = V × (kazanç − zarar katsayısı, yalnız > 0)   (ulkeler_bolge.json)
    ikame   = rakip_ikame kenarları        (bölge kaybı × pay × ikame çarpanı)
    merkez  = MFIN sızıntı kenarları       (bölge kaybı × merkez payı × merkez çarpanı)
  Dört kanal AYNI bölge kaybından beslenir ve birbirini dışlamaz → toplam V'yi aşabiliyordu (A %184, B %218, C %170).
  Düzeltme (uygulandı): `kanal` kuralı KALDIRILDI (matris kuralıyla aynı boşluğu ikinci kez dağıtıyordu); kalan üç kanal
  (matris, ikame, merkez) toplamı V'yi aşıyorsa ORANTILI küçültülür (katsayı = V / ham toplam), altındaysa dokunulmaz.
  Kayıp tarafı: TR kaybı + TR dışı ülke kayıpları (bölge net etkisi), ayrı bir nicelik; özdeşlik Σ kazanç ≤ V'dir, Σ kazanç = Σ kayıp DEĞİL.

Çıktı: `KAZANC_KAYIP_MUHASEBE.{json,md}`. Başka modüle girdi olmaz (döngü yok).
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"
# Evren dışı, modelde hiç bulunmayan örnek aktörler (DERLEME; tam liste değil)
EVREN_DISI_ORNEK = ["Katar", "Kuveyt", "Umman", "Ürdün", "Hindistan", "Japonya", "Güney Kore", "Birleşik Krallık", "Almanya (AB yalnız Balkan vekil)", "İtalya"]


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _pasif_k() -> float:
    r = _load(DATA / "refah_rant_model.json")
    return float(r.get("kayip_pasif_ek") or 0.25) if r.get("aktif") else 0.25


def hesapla() -> dict[str, Any]:
    proj = _load(OUT / "PROJEKSIYON.json")
    pk = _pasif_k()
    out_s: list[dict[str, Any]] = []
    for sen in proj["senaryolar"]:
        bos = sum(float(r["bosalma"]) for r in sen["tr_bosalma_detay"])
        pas = sum(float(b.get("pasif_bosluk_dolgu", 0.0)) for b in sen["bolgesel_net"])
        v = bos + pk * pas
        ak = sen["dis_aktör_kazanc"]
        nz = ak[0]["normalizasyon"] if ak else {"bosluk_V": v, "ham_toplam": 0.0, "katsayi": 1.0}
        kanal = sum(d["kanal_kazanc"] for d in ak)
        matris = sum(d["matris_kazanc"] for d in ak)
        ikame = sum(d["ikame_kazanc"] for d in ak)
        merkez = sum(d["merkez_sizinti"] for d in ak)
        toplam_k = kanal + matris + ikame + merkez
        ul = sen["ulke_kayiplari"]
        tr = sum(u["kayip_endeks"] for u in ul if u["ulke"] == "TR")
        diger = sum(u["kayip_endeks"] for u in ul if u["ulke"] != "TR")
        ab = sen["aktör_birlesik"]
        kapsam = {"aktor_sayisi": len(ab)}
        for alan in ("kazanc_kapsam", "kayip_kapsam", "net_kapsam"):
            sayim: dict[str, int] = {}
            for a in ab:
                sayim[a.get(alan, "?")] = sayim.get(a.get(alan, "?"), 0) + 1
            kapsam[alan] = sayim
        out_s.append(
            {
                "id": sen["id"],
                "bosluk_V": round(v, 3),
                "tr_bosalma": round(bos, 3),
                "pasif_k": pk,
                "kazanc": {"kanal": round(kanal, 3), "matris": round(matris, 3), "ikame": round(ikame, 3), "merkez": round(merkez, 3), "toplam": round(toplam_k, 3)},
                "normalizasyon": {"ham_toplam": nz["ham_toplam"], "ham_V_orani": round(nz["ham_toplam"] / v, 3), "katsayi": nz["katsayi"], "kanal_kaldirildi": True},
                "kazanc_V_orani": {
                    "matris": round(matris / v, 3),
                    "ikame": round(ikame / v, 3),
                    "merkez": round(merkez / v, 3),
                    "toplam": round(toplam_k / v, 3),
                },
                "kayip": {"tr": round(tr, 3), "diger": round(diger, 3), "toplam": round(tr + diger, 3)},
                "kazanc_eksi_kayip": round(toplam_k - (tr + diger), 3),
                "kazanc_eksi_V": round(toplam_k - v, 3),
                "kapsam": kapsam,
                "ihlaller": [
                    ("kazanç V'yi aşıyor" if toplam_k > v + 0.01 else None),
                    (f"normalize edildi: ham toplam V'nin %{round(nz['ham_toplam'] / v * 100)}'i, katsayı {nz['katsayi']}" if nz["katsayi"] < 1.0 else None),
                    ("Σ kazanç ≠ Σ kayıp (kayıp bölge net etkisi; özdeşlik Σ kazanç ≤ V)" if abs(toplam_k - (tr + diger)) > 0.05 else None),
                ],
            }
        )
        out_s[-1]["ihlaller"] = [x for x in out_s[-1]["ihlaller"] if x]
    return {
        "olcum": "kazanc_kayip_muhasebe",
        "etiket": "kanal_kaldirildi_normalize",
        "ozdeslik": "Bir boşluğun dağıtımı V'yi (TR boşalması + pasif katkısı) aşmamalı. Eskiden kanal, matris, ikame, merkez aynı V'den beslenir ve dışlamazdı (A %184, B %218, C %170). `kanal` kaldırıldı; kalan üç kanal V'ye normalize edilir.",
        "senaryolar": out_s,
        "evren_disi_ornek": EVREN_DISI_ORNEK,
        "not": "Σ kazanç ≤ V artık sağlanır. Σ kazanç = Σ kayıp sağlanmaz ve hedeflenmedi: kayıp tarafı bölge net etkisidir, kazanç ise TR boşalmasının (V) dağıtımıdır.",
    }


def _md(d: dict[str, Any]) -> str:
    L = ["# Kazanç–kayıp muhasebesi", "", f"**Etiket:** `{d['etiket']}`. {d['ozdeslik']}", ""]
    L += ["## Boşluk V ve kazanç kanalları (kanal kaldırıldı, normalize edildi)", "", "| Senaryo | V (boşluk) | matris | ikame | merkez | Σ kazanç | Σ/V | ham Σ/V (normalizasyondan önce) | katsayı |", "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |"]
    for s in d["senaryolar"]:
        k = s["kazanc"]
        nz = s["normalizasyon"]
        L.append(f"| {s['id']} | {s['bosluk_V']} | {k['matris']} | {k['ikame']} | {k['merkez']} | {k['toplam']} | {s['kazanc_V_orani']['toplam']} | {nz['ham_V_orani']} | {nz['katsayi']} |")
    L += ["", "## Kayıp tarafı ve fark", "", "| Senaryo | TR kayıp | TR dışı kayıp | Σ kayıp | Σ kazanç − Σ kayıp | Σ kazanç − V |", "| --- | ---: | ---: | ---: | ---: | ---: |"]
    for s in d["senaryolar"]:
        y = s["kayip"]
        L.append(f"| {s['id']} | {y['tr']} | {y['diger']} | {y['toplam']} | {s['kazanc_eksi_kayip']} | {s['kazanc_eksi_V']} |")
    L += ["", "## Bulgu", ""]
    for s in d["senaryolar"]:
        L.append(f"- **{s['id']}:** " + "; ".join(s["ihlaller"]) + ".")
    L += ["", "## Kapsam (neyin modellenmediği)", "", "| Senaryo | Aktör | Kazanç tam / kısmi / yok | Kayıp modellendi / bilinmiyor | Net tam / kısmi |", "| --- | ---: | --- | --- | --- |"]
    for s in d["senaryolar"]:
        c = s["kapsam"]
        kz, ky, nt = c["kazanc_kapsam"], c["kayip_kapsam"], c["net_kapsam"]
        L.append(f"| {s['id']} | {c['aktor_sayisi']} | {kz.get('tam', 0)} / {kz.get('kismi', 0)} / {kz.get('yok', 0)} | {ky.get('modellendi', 0)} / {ky.get('bilinmiyor', 0)} | {nt.get('tam', 0)} / {nt.get('kismi', 0)} |")
    L += ["", f"Evren dışı (modelde hiç yok, kazanç/kayıp **bilinmiyor**; derleme, tam liste değil): {', '.join(d['evren_disi_ornek'])}.", "", "## Not", "", d["not"], ""]
    return "\n".join(L)


def main() -> None:
    d = hesapla()
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "KAZANC_KAYIP_MUHASEBE.json").write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "KAZANC_KAYIP_MUHASEBE.md").write_text(_md(d), encoding="utf-8")
    print("KAZANC_KAYIP_MUHASEBE:", [(s["id"], s["kazanc_V_orani"]["toplam"]) for s in d["senaryolar"]])


if __name__ == "__main__":
    main()
