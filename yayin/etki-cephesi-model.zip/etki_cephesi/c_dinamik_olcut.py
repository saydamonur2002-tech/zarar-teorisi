"""C senaryosunun gerçekleşme durumunu ölçen DİNAMİK ölçüt (sıralı Bayes).

Ne yapar: senaryo olasılıklarını (A/B/C) gözlemle her yıl günceller. Gösterge: merkez sızıntı oranı
r_t = (12 ay yatırım geliri gideri) / (12 ay mal ihracatı), EVDS ödemeler dengesi. Modelin kendisi merkez
sızıntıyı bu seriye bağlar (finans_katman: 'birincil_gelir_yatirim_gideri' çapası).

Senaryonun ima ettiği yıllık sürüklenme (karşı-olgusal trende göre): d_s = ln(merkez_sizinti_carpan_s) / T,
T = tam olgunluk (10 yıl). A = 1,0 → 0; B = 1,15; C = 0,9. Bu EŞLEME varsayımdır (senaryolar.json'dan türetilir).

Kurallar (zarar-teorisi üslubu):
  * Ölçüm penceresi baz yıldan sonra başlar (baz 2026 → ilk güncelleme 2027 Aralık verisiyle). Öncesi güncellemez.
  * Eksik gözlem güncellemez: bilinmiyor sıfır değildir.
  * Gösterge senaryoları ayırt edemiyorsa (güç hesabı) bunu söyler; olasılığı oynatmaz ya da ihtiyatlı oynatır.
  * Olasılıklar ölçülmemiştir; bu ölçüt onları DOĞRULAMAZ, ancak ne kadar doğrulanabileceğini gösterir.
"""
from __future__ import annotations

import csv
import json
import math
from pathlib import Path
from typing import Any

import numpy as np

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"
GOZLEM = DATA / "gozlem" / "evds_odeme_dengesi_aylik.csv"

MC_N = 4000
MC_SEED = 0
SPRT_GUVEN = 0.95  # |log LR| esigi = ln(guven / (1 - guven))
UNUTMA = 1.0  # 1,0: unutma yok


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _aylik() -> dict[str, dict[str, float]]:
    d: dict[str, dict[str, float]] = {}
    with GOZLEM.open(encoding="utf-8", newline="") as f:
        for r in csv.DictReader(f):
            try:
                d[r["Donem"]] = {"X": float(r["X_mal_ihracati"]), "YG": float(r["YG_yatirim_geliri_gideri"])}
            except ValueError:
                continue  # eksik gözlem: güncelleme yok
    return d


def _oran12(d: dict[str, dict[str, float]]) -> dict[str, float]:
    ps = sorted(d)
    out: dict[str, float] = {}
    for i in range(11, len(ps)):
        w = ps[i - 11 : i + 1]
        # 12 ardışık ay (boşluksuz) şartı
        y0, m0 = int(w[0][:4]), int(w[0][5:7])
        y1, m1 = int(w[-1][:4]), int(w[-1][5:7])
        if (y1 - y0) * 12 + (m1 - m0) != 11:
            continue
        out[ps[i]] = sum(d[t]["YG"] for t in w) / sum(d[t]["X"] for t in w)
    return out


def _yillik_degisim(r: dict[str, float]) -> dict[int, float]:
    """Aralık→Aralık log değişim (tam yıl, her iki Aralık gözlemi varsa)."""
    g: dict[int, float] = {}
    for t, v in r.items():
        if t.endswith("-12"):
            prev = f"{int(t[:4]) - 1}-12"
            if prev in r:
                g[int(t[:4])] = math.log(v / r[prev])
    return g


def _surukleme(sen: dict[str, Any], olgun: float) -> dict[str, float]:
    return {s["id"]: math.log(float(s["merkez_sizinti_carpan"])) / olgun for s in sen["senaryolar"]}


def _posterior(prior: dict[str, float], obs: list[float], mu: float, sigma: float, drift: dict[str, float], unutma: float = UNUTMA) -> dict[str, float]:
    logp = {k: math.log(v) for k, v in prior.items()}
    for g in obs:
        for k in logp:
            logp[k] = unutma * logp[k] - (g - mu - drift[k]) ** 2 / (2 * sigma * sigma)
    m = max(logp.values())
    w = {k: math.exp(v - m) for k, v in logp.items()}
    s = sum(w.values())
    return {k: w[k] / s for k in w}


def _guc(drift: dict[str, float], sigma: float) -> dict[str, Any]:
    esik = math.log(SPRT_GUVEN / (1 - SPRT_GUVEN))
    out = {}
    for a, b in (("C", "A"), ("C", "B"), ("A", "B")):
        delta = abs(drift[a] - drift[b])
        yil = 2 * sigma * sigma * esik / (delta * delta) if delta > 0 else float("inf")
        out[f"{a}_vs_{b}"] = {"fark_yillik_log": round(delta, 4), "gerekli_yil": round(yil, 0) if yil != float("inf") else None}
    return out


def _monte_carlo(prior: dict[str, float], mu: float, sigma: float, drift: dict[str, float], yil: int) -> dict[str, Any]:
    rng = np.random.default_rng(MC_SEED)
    res = {}
    for truth in ("A", "B", "C"):
        pc = []
        for _ in range(MC_N):
            obs = list(mu + drift[truth] + sigma * rng.standard_normal(yil))
            pc.append(_posterior(prior, obs, mu, sigma, drift)["C"])
        pc = np.array(pc)
        res[truth] = {
            "P_C_ortalama": round(float(pc.mean()), 3),
            "P_C_p10_p90": [round(float(np.quantile(pc, 0.1)), 3), round(float(np.quantile(pc, 0.9)), 3)],
            "P_C_gt_0_8": round(float((pc > 0.8).mean()), 3),
            "P_C_lt_0_4": round(float((pc < 0.4).mean()), 3),
        }
    return res


def hesapla() -> dict[str, Any]:
    sen = _load(DATA / "senaryolar.json")
    capa = _load(DATA / "kalibre" / "gerceklik_capa.json")
    ph = _load(DATA / "finans_katman_kopru.json")
    olgun = float(ph["tam_olgunluk_yil"])
    baz = int(sen["baz_yil"])
    horizon = int(sen["horizon_yil"])
    prior_ham = {s["id"]: float(s["olasilik_vekili"]) for s in sen["senaryolar"]}
    z = sum(prior_ham.values())
    prior = {k: v / z for k, v in prior_ham.items()}
    drift = _surukleme(sen, olgun)

    d = _aylik()
    r = _oran12(d)
    g = _yillik_degisim(r)
    on = [v for y, v in sorted(g.items()) if y <= baz]  # baz yıl ve öncesi: tahmin (güncelleme değil)
    mu = float(np.mean(on))
    sigma = float(np.std(on, ddof=1))
    uygun = {y: v for y, v in g.items() if y > baz}  # ölçüm penceresi
    post = _posterior(prior, [uygun[y] for y in sorted(uygun)], mu, sigma, drift) if uygun else dict(prior)

    son_ay = max(r)
    yil_oran = {y: round(r[f"{y}-12"], 4) for y in sorted({int(t[:4]) for t in r}) if f"{y}-12" in r}
    guc = _guc(drift, sigma)
    min_yil = min(v["gerekli_yil"] for k, v in guc.items() if k.startswith("C_") and v["gerekli_yil"] is not None)
    ayirt = bool(min_yil <= horizon)
    mc = _monte_carlo(prior, mu, sigma, drift, horizon)

    esik = None
    dyp = OUT / "OLASILIK_DUYARLILIK.json"
    if dyp.is_file():
        esik = _load(dyp).get("gecisler", {}).get("karar_kosullu_skor_62")

    # kalibrasyon çapası vs EVDS (aynı seri, yıllık toplam)
    def yillik(y: int) -> float:
        return round(sum(v["YG"] for t, v in d.items() if t.startswith(str(y))), 0)

    capa_deger = float(capa["usd_mn"]["yatirim_geliri_gideri"])
    capa_yil = int(capa["yil"])
    evds_capa_yil = yillik(capa_yil)
    kapilar = [
        {"kapi": "merkez_sizinti_surukleme", "kaynak": "EVDS TP.ODEAYRSUNUM6.Q76 / Q5", "durum": "olculebilir", "ayirt_gucu": "yok" if not ayirt else "var", "not": "Bu raporun göstergesi."},
        {"kapi": "dis_kisit (borç çevirme oranı)", "kaynak": "EVDS bie_oderoll (TP.ODEROLL.K1-K4)", "durum": "veri_var_esleme_yok", "not": "Senaryo başına beklenen değer tanımlı değil: bilinmiyor."},
        {"kapi": "etki_erozyonu (bölge ihracat payı)", "kaynak": "TİM / bolge_havza_ticaret.json (EVDS dışı)", "durum": "kaynak_dis", "not": "Aylık seri depoda yok."},
        {"kapi": "bag_modu_kullanim", "kaynak": "—", "durum": "olculmedi", "not": "Kullanım/atıl/araçsal payı gözlenebilir bir seriye bağlı değil."},
    ]
    return {
        "olcum": "c_dinamik_olcut",
        "etiket": "olasilik_olculmedi_dinamik_olcut",
        "gosterge": "merkez_sizinti_orani = 12a yatırım geliri gideri / 12a mal ihracatı (EVDS ödemeler dengesi)",
        "varsayim": "Senaryo sürüklenmesi d_s = ln(merkez_sizinti_carpan_s)/T (T=%d yıl); karşı-olgusal trend = baz yıl öncesi Ara→Ara ortalaması." % int(olgun),
        "prior": {k: round(v, 4) for k, v in prior.items()},
        "suruklenme_yillik_log": {k: round(v, 4) for k, v in drift.items()},
        "karsi_olgusal": {"mu_yillik_log": round(mu, 4), "sigma_yillik_log": round(sigma, 4), "n_yil": len(on)},
        "olcum_penceresi": {"baz_yil": baz, "ilk_guncelleme": f"{baz + 1}-12 verisi", "uygun_gozlem_sayisi": len(uygun), "son_gozlem_ayi": son_ay},
        "guncelleme_durumu": "yok (olcum_baslamadi: bilinmiyor sifir degildir)" if not uygun else "var",
        "posterior": {k: round(v, 4) for k, v in post.items()},
        "oran_yil_sonu": yil_oran,
        "guc_analizi": {"esik_log_LR": round(math.log(SPRT_GUVEN / (1 - SPRT_GUVEN)), 3), "ciftler": guc, "C_icin_min_gerekli_yil": min_yil, "horizon_yil": horizon, "ayirt_edebilir": ayirt},
        "monte_carlo_horizon": {"n": MC_N, "seed": MC_SEED, "gercek_senaryo_basina_P_C": mc},
        "karar_baglantisi": {
            "karar_esigi_P_C": esik,
            "marj_posterior_eksi_esik": round(post["C"] - esik, 3) if esik is not None else None,
        },
        "kapilar_adaylar": kapilar,
        "capa_uyumsuzluk": {
            "capa_yil": capa_yil,
            "capa_yatirim_geliri_gideri_mn_usd": capa_deger,
            "evds_ayni_yil_mn_usd": evds_capa_yil,
            "evds_bir_onceki_yil_mn_usd": yillik(capa_yil - 1),
            "oran_evds_capa": round(evds_capa_yil / capa_deger, 3),
            "uyumsuz": abs(evds_capa_yil / capa_deger - 1) > 0.05,
        },
        "karsi_olgusal_trend_uyarisi": {
            "oran_2023_sonu": yil_oran.get(2023),
            "oran_2025_sonu": yil_oran.get(2025),
            "artis_carpani": round(yil_oran[2025] / yil_oran[2023], 3) if 2023 in yil_oran and 2025 in yil_oran else None,
            "senaryo_surukleme_iki_yil_maks_abs": round(2 * max(abs(v) for v in drift.values()), 3),
        },
    }


def _md(d: dict[str, Any]) -> str:
    g = d["guc_analizi"]
    mc = d["monte_carlo_horizon"]["gercek_senaryo_basina_P_C"]
    cu = d["capa_uyumsuzluk"]
    ko = d["karsi_olgusal_trend_uyarisi"]
    L = [
        "# C senaryosu: dinamik ölçüt",
        "",
        f"**Etiket: {d['etiket']}.** {d['gosterge']}",
        "",
        f"- Varsayım: {d['varsayim']}",
        f"- Prior (A/B/C): {d['prior']} → **posterior: {d['posterior']}**; güncelleme: {d['guncelleme_durumu']}.",
        f"- Ölçüm penceresi: baz {d['olcum_penceresi']['baz_yil']}, ilk güncelleme {d['olcum_penceresi']['ilk_guncelleme']}; son gözlem ayı {d['olcum_penceresi']['son_gozlem_ayi']}.",
        f"- Karşı-olgusal trend: μ = {d['karsi_olgusal']['mu_yillik_log']:+.3f}/yıl, σ = {d['karsi_olgusal']['sigma_yillik_log']:.3f} (n={d['karsi_olgusal']['n_yil']}).",
        f"- Senaryo sürüklenmesi (yıllık log): {d['suruklenme_yillik_log']}.",
        "",
        "## Güç analizi: bu gösterge C'yi ayırt edebilir mi?",
        "",
        "| Çift | Fark (yıllık log) | SPRT %95 için gerekli yıl |",
        "| --- | ---: | ---: |",
    ]
    for k, v in g["ciftler"].items():
        L.append(f"| {k.replace('_vs_', ' vs ')} | {v['fark_yillik_log']} | {v['gerekli_yil']:,.0f} |")
    L += [
        "",
        f"**Ayırt edebilir (≤ {g['horizon_yil']} yıl): {g['ayirt_edebilir']}.** C için en kısa ayrım {g['C_icin_min_gerekli_yil']:,.0f} yıl.",
        "",
        f"Monte Carlo ({d['monte_carlo_horizon']['n']} koşu, {g['horizon_yil']} yıl, gerçek senaryo → P(C) son):",
        "",
        "| Gerçek senaryo | E[P(C)] | p10–p90 | P(P(C)>0,8) | P(P(C)<0,4) |",
        "| --- | ---: | --- | ---: | ---: |",
    ]
    for t, v in mc.items():
        L.append(f"| {t} | {v['P_C_ortalama']} | {v['P_C_p10_p90'][0]}–{v['P_C_p10_p90'][1]} | {v['P_C_gt_0_8']} | {v['P_C_lt_0_4']} |")
    kb = d["karar_baglantisi"]
    L += [
        "",
        f"- Karar eşiği P(C) ≈ {kb['karar_esigi_P_C']}; posterior − eşik = {kb['marj_posterior_eksi_esik']}.",
        "",
        "## Model uyarıları (gözlemden)",
        "",
        f"- **Karşı-olgusal trend yok:** r(2023 sonu) {ko['oran_2023_sonu']} → r(2025 sonu) {ko['oran_2025_sonu']} (×{ko['artis_carpani']}); senaryoların iki yıllık sürüklenmesi en çok ±{ko['senaryo_surukleme_iki_yil_maks_abs']}. Hiçbir senaryo bu hareketi taşımıyor.",
        f"- **Çapa uyumsuzluğu:** kalibrasyon {cu['capa_yil']} yatırım geliri gideri = {cu['capa_yatirim_geliri_gideri_mn_usd']:,.0f} mn $; EVDS aynı yıl {cu['evds_ayni_yil_mn_usd']:,.0f} (×{cu['oran_evds_capa']}), bir önceki yıl {cu['evds_bir_onceki_yil_mn_usd']:,.0f}. Uyumsuz: {cu['uyumsuz']}.",
        "",
        "## Diğer kapı adayları",
        "",
        "| Kapı | Kaynak | Durum |",
        "| --- | --- | --- |",
    ]
    for k in d["kapilar_adaylar"]:
        L.append(f"| {k['kapi']} | {k['kaynak']} | {k['durum']} |")
    L.append("")
    return "\n".join(L)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    d = hesapla()
    (OUT / "C_DINAMIK_OLCUT.json").write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "C_DINAMIK_OLCUT.md").write_text(_md(d), encoding="utf-8")
    print(f"Wrote {OUT / 'C_DINAMIK_OLCUT.md'}")


if __name__ == "__main__":
    main()
