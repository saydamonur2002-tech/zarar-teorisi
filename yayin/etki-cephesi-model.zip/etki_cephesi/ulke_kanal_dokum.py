"""P4: Ülke × rant kanalı × kurum dokümü (A/B/C + GENIS ülkeler)."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "etki_cephesi"


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def dokum() -> dict[str, Any]:
    genis = _load(OUT / "DIS_ULKE_REFAH_GENIS.json") if (OUT / "DIS_ULKE_REFAH_GENIS.json").is_file() else _load(OUT / "DIS_ULKE_REFAH.json")
    hucre = []
    for sid in ("A", "B", "C"):
        rp = OUT / f"DIS_RANT_PARASAL_{sid}.json"
        if not rp.is_file():
            continue
        rant = _load(rp)
        uk = (rant.get("ulke_rant_kanal") or {}).get("hucre_top120") or []
        for h in uk[:120]:
            hucre.append({**h, "senaryo": sid})
    if not hucre:
        rant = _load(OUT / "DIS_RANT_PARASAL.json")
        for h in (rant.get("ulke_rant_kanal") or {}).get("hucre_top120") or []:
            hucre.append({**h, "senaryo": "C"})

    ulkeler = [
        {
            "ulke": r["ulke"],
            "ad": r.get("ad"),
            "tur": r.get("tur", "devlet_aktor"),
            "rol": r.get("rol"),
            "net_refah_entegre": r.get("net_refah_entegre"),
        }
        for r in genis.get("ulke_defteri") or []
    ]
    kurumlar = genis.get("kurum_defteri") or []

    by_ulke: dict[str, float] = {}
    for h in hucre:
        u = str(h.get("ulke") or "")
        by_ulke[u] = by_ulke.get(u, 0.0) + float(h.get("refah_dis_usd_mn") or 0.0)

    top_ulke_kanal = sorted(by_ulke.items(), key=lambda x: -x[1])[:25]

    return {
        "olcum": "ulke_kanal_kurum_dokum_p4",
        "hucre_sayisi": len(hucre),
        "ulke_sayisi": genis.get("ulke_sayisi") or len(ulkeler),
        "kurum_sayisi": genis.get("kurum_sayisi") or len(kurumlar),
        "top_ulke_refah_dis_usd_mn": [{"ulke": u, "refah_dis_usd_mn": round(v, 1)} for u, v in top_ulke_kanal],
        "kurum_ozet": [
            {"id": k["ulke"], "ad": k["ad"], "net_vekil": k["net_refah_entegre"], "usd_mn": k.get("refah_dis_usd_mn_vekili")}
            for k in kurumlar
        ],
        "hucre_ornek": hucre[:40],
        "kaynak": ["DIS_ULKE_REFAH_GENIS.json", "DIS_RANT_PARASAL_{A,B,C}.json"],
    }


def _md(d: dict[str, Any]) -> str:
    lines = [
        "# Ülke × kanal dokümü (P4)",
        "",
        f"**{d['hucre_sayisi']}** hücre · **{d['ulke_sayisi']}** ülke · **{d['kurum_sayisi']}** kurum",
        "",
        "## Top ülke — refah dış USD (kanal hücreleri, tüm senaryolar)",
        "",
    ]
    for row in d["top_ulke_refah_dis_usd_mn"][:15]:
        lines.append(f"- **{row['ulke']}:** {row['refah_dis_usd_mn']:,} mn $")
    lines.extend(["", "## Kurumlar", ""])
    for k in d["kurum_ozet"]:
        lines.append(f"- **{k['ad']}:** net {k['net_vekil']} vekil · {k.get('usd_mn')} mn $")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    data = dokum()
    (OUT / "ULKE_KANAL_DOKUM.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "ULKE_KANAL_DOKUM.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'ULKE_KANAL_DOKUM.md'}")


if __name__ == "__main__":
    main()
