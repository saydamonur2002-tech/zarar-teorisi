"""P4: Finans katmanı A/B/C + olasılık beklentisi."""
from __future__ import annotations

import json
import sys
from pathlib import Path
import _olasilik
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"

if str(REPO / "etki_cephesi") not in sys.path:
    sys.path.insert(0, str(REPO / "etki_cephesi"))

from finans_katman import _md, hesapla  # noqa: E402


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def calistir(senaryolar: tuple[str, ...] = ("A", "B", "C")) -> dict[str, Any]:
    sen_doc = _load(DATA / "senaryolar.json")
    olas: dict[str, float] = {}
    for s in sen_doc.get("senaryolar") or []:
        olas[str(s["id"])] = _olasilik.vekil_s(s)
    s_olas = sum(olas.values()) or 1.0
    olas = {k: v / s_olas for k, v in olas.items()}

    satirlar: list[dict[str, Any]] = []
    for sid in senaryolar:
        data = hesapla(sid)
        OUT.mkdir(parents=True, exist_ok=True)
        (OUT / f"FINANS_KATMAN_{sid}.json").write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        f = data["finans_katman_tam"]
        satirlar.append(
            {
                "id": sid,
                "olasilik": round(olas.get(sid, 0.0), 4),
                "tr_net_finans": f["tr_net_birlesik_vekil"],
                "merkez_mfin": f["merkez_mfin_kenar_vekili"],
                "finans_geri": f["tr_finans_geri_kazanim_vekili"],
            }
        )
    if "C" in senaryolar:
        (OUT / "FINANS_KATMAN.json").write_text(
            (OUT / "FINANS_KATMAN_C.json").read_text(encoding="utf-8"), encoding="utf-8"
        )
        (OUT / "FINANS_KATMAN.md").write_text(_md(hesapla("C")), encoding="utf-8")

    tr_exp = round(sum(r["olasilik"] * float(r["tr_net_finans"]) for r in satirlar), 3)
    return {
        "olcum": "finans_katman_senaryo_coklu_p4",
        "senaryolar": satirlar,
        "beklenti": {"beklenen_tr_net_finans": tr_exp},
    }


def main() -> None:
    data = calistir()
    (OUT / "FINANS_KATMAN_COKLU.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Wrote {OUT / 'FINANS_KATMAN_COKLU.json'}")


if __name__ == "__main__":
    main()
