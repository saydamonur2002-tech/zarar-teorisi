"""Finans katmanı: MFIN/BoP/TDS vekili + finans halkaları (üretim katmanı üstü)."""
from __future__ import annotations

import json
import subprocess
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
EMPIRIK = DATA / "empirik"
OUT = REPO / "reports" / "etki_cephesi"
PROJ = OUT / "PROJEKSIYON.json"
ZCOZ = OUT / "ZARAR_COZUM_C.json"
URETIM = OUT / "URETIM_IC_AKIS.json"
KOPRU = DATA / "finans_katman_kopru.json"
URETIM_KOPRU = DATA / "uretim_ic_akis_kopru.json"
FIN_HALKALAR = ("para_sizintisi", "dis_kisit", "zarar_aktarimi")


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _halka_toplam(proj: dict[str, Any], sid: str) -> dict[str, float]:
    sen = next(s for s in proj["senaryolar"] if s["id"] == sid)
    tot: dict[str, float] = defaultdict(float)
    for row in sen.get("tr_bosalma_detay") or []:
        for h in row.get("bes_halka") or []:
            tot[str(h["halka"])] += float(h["delta_endeks"])
    return dict(tot)


def _bos_oran(halka: dict[str, float], carpan: dict[str, float]) -> float:
    eski = sum(halka.values())
    yeni = sum(halka.get(k, 0.0) * float(carpan.get(k, 1.0)) for k in halka)
    return yeni / eski if eski > 0 else 1.0


def _mfin_kenar(proj: dict[str, Any], sid: str) -> float:
    sen = next(s for s in proj["senaryolar"] if s["id"] == sid)
    kenar = [
        float(e["akis_endeks"])
        for e in (sen.get("akis_kenarlari") or [])
        if e.get("hedef") == "merkez_finans" and e.get("tur") == "sizinti"
    ]
    return round(sum(kenar), 3)


def _vekil_from_usd(usd_mn: float, cicek_usd: float, merkez_rant: float) -> float:
    if cicek_usd <= 0:
        return 0.0
    return round(usd_mn * merkez_rant / cicek_usd, 3)


def _koridor(y0: int, y1: int, bas: float, hedef: float, tam_yil: float) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for y in range(y0, y1 + 1):
        t = y - y0
        u = min(1.0, t / tam_yil) if tam_yil > 0 else 1.0
        rows.append({"yil": y, "tr_net_orta": round(bas + (hedef - bas) * u, 3), "olgunluk": round(u, 3)})
    return rows


def _senaryo_meta(sid: str) -> dict[str, Any]:
    sen_doc = _load(DATA / "senaryolar.json")
    return next(s for s in sen_doc["senaryolar"] if s["id"] == sid)


def _gerceklesme_f(sid: str, kopru: dict[str, Any]) -> float:
    """Finans katmanı dış koşul gerçekleşmesi g_f = min(1, pol_s / pol_C). C = 1. aktif=false → 1."""
    if not (kopru.get("senaryo_gerceklesme") or {}).get("aktif"):
        return 1.0
    pol_oran, _ = _senaryo_finans_carpanlari({}, sid)
    return max(0.0, min(1.0, pol_oran))


def _senaryo_finans_carpanlari(proj: dict[str, Any], sid: str) -> tuple[float, float]:
    """Politika gerçekleşme (C=1) ve merkez sızıntı göreli (C merkez çarpanı=0.9)."""
    _ = proj
    sen = _senaryo_meta(sid)
    sen_c = _senaryo_meta("C")
    er = float(sen.get("etki_erosyon_carpani") or 0.4)
    flex = float(sen.get("tr_diplomatik_flex") or 0.0)
    pol = max(0.25, min(1.0, 1.05 - er + flex))
    er_c = float(sen_c.get("etki_erosyon_carpani") or 0.22)
    flex_c = float(sen_c.get("tr_diplomatik_flex") or 0.0)
    pol_c = max(0.25, min(1.0, 1.05 - er_c + flex_c))
    pol_oran = pol / pol_c if pol_c > 0 else 1.0
    mer = float(sen.get("merkez_sizinti_carpan") or 1.0)
    mer_c = float(sen_c.get("merkez_sizinti_carpan") or 0.9)
    mer_oran = mer / mer_c if mer_c > 0 else 1.0
    return round(pol_oran, 4), round(mer_oran, 4)


def _sifir_yili(tr_net0: float, tr_net1: float, y0: int, tam_yil: float) -> int | None:
    if tr_net1 >= 0:
        if tr_net1 == tr_net0:
            return y0
        frac = (0.0 - tr_net0) / (tr_net1 - tr_net0)
        return int(round(y0 + tam_yil * max(0.0, min(1.0, frac))))
    if tr_net1 <= tr_net0:
        return None
    slope = (tr_net1 - tr_net0) / tam_yil
    return int(round(y0 + tam_yil + (-tr_net1) / slope))


def _uretim_dosya(sid: str) -> Path:
    p = OUT / f"URETIM_IC_AKIS_{sid}.json"
    return p if p.is_file() else URETIM


def _zcoz_dosya(sid: str) -> Path:
    p = OUT / f"ZARAR_COZUM_{sid}.json"
    return p if p.is_file() else ZCOZ


def _ensure_uretim_sid(sid: str) -> None:
    if _uretim_dosya(sid).is_file():
        return
    subprocess.check_call([sys.executable, str(REPO / "etki_cephesi" / "uretim_ic_akis.py")])


def _baskin_mod(sid: str) -> str:
    bm = _senaryo_meta(sid)["bag_modu"]
    return max(bm, key=lambda k: float(bm[k]))


def _ters_isaret(sid: str, kopru: dict[str, Any]) -> float:
    """Araçsallaşmada finans katmanı ters çevrilir: −guc. Aksi halde +1."""
    cfg = kopru.get("ters_cevirme") or {}
    if cfg.get("aktif") and _baskin_mod(sid) == "aracsal":
        return -float(cfg.get("guc", 1.0))
    return 1.0


def hesapla(senaryo_id: str = "C", isaret_override: float | None = None, band: bool = True) -> dict[str, Any]:
    sid = senaryo_id
    _ensure_uretim_sid(sid)
    proj = _load(PROJ)
    zcoz = _load(_zcoz_dosya(sid))
    uretim_doc = _load(_uretim_dosya(sid))
    kopru = _load(KOPRU)
    u_kopru = _load(URETIM_KOPRU)
    fin = _load(EMPIRIK / "tr_finans_akisi_2024.json")

    u = uretim_doc["uretim_ic_akis_tam"]
    z = zcoz["zarar_cozum_sonrasi"]
    tr_base = float(u["tr_net_birlesik_vekil"])
    bos_u = float(u["turkiye_yaricevre_bosalma"])
    merkez_u = float(u["merkez_finans_sizinti_toplam"])
    havza_u = float(u["tr_havza_kayip"])
    ic_u = float(u["tr_ic_geri_kazanim_vekili"])
    rant_arti_u = float(u["rant_tr_arti_deger_vekili"])

    from uretim_ic_akis import _gerceklesme, etkin_carpan  # noqa: E402

    g_u = _gerceklesme(sid, u_kopru)
    g_f_pozitif = _gerceklesme_f(sid, kopru)
    isaret = _ters_isaret(sid, kopru) if isaret_override is None else float(isaret_override)
    g_f = g_f_pozitif * isaret  # < 0: ters çevrilmiş (araçsallaşma)
    halka = _halka_toplam(proj, sid)
    carpan_u = etkin_carpan(u_kopru["halka_duzeltme_carpan"], g_u)
    oran_uretim = _bos_oran(halka, carpan_u)
    carpan_fin = dict(carpan_u)
    for k, v in etkin_carpan(kopru.get("finans_halka_ek_carpan") or {}, g_f).items():
        carpan_fin[k] = float(carpan_fin.get(k, 1.0)) * float(v)
    oran_fin = _bos_oran(halka, carpan_fin)
    bos_fin = round(bos_u * (oran_fin / oran_uretim) if oran_uretim > 0 else bos_u, 3)

    mfin_z = float(z.get("merkez_mfin_kenar") or _mfin_kenar(proj, sid))
    merkez_z = float(z.get("merkez_finans_sizinti_toplam") or 1.0)
    mfin_u = round(mfin_z * (merkez_u / merkez_z) if merkez_z > 0 else mfin_z, 3)
    mfin_carp = 1.0 - g_f * (1.0 - float(kopru["mfin_kenar_sizinti_carpan"]))
    mfin_fin = round(mfin_u * mfin_carp, 3)
    merkez_fin = round(merkez_u - (mfin_u - mfin_fin), 3)
    kredi_kes = round(merkez_u * float(kopru["kredi_ihtiyaci_sifir_merkez_kesinti"]) * g_f, 3)
    merkez_fin = round(max(0.0, merkez_fin - kredi_kes), 3)

    sen_c = next(s for s in proj["senaryolar"] if s["id"] == sid)
    merkez_rant_c = float(sen_c.get("merkez_artı_rant_cikis_toplam") or 1.0)
    olcek_key = str(kopru.get("empirik_olcek_satir") or fin.get("model_olcek_satir"))
    satir = (fin.get("akis_satirlari") or {}).get(olcek_key) or {}
    cicek = float(satir.get("usd_mn") or 0.0)
    tds = float(((fin.get("akis_satirlari") or {}).get("dis_borc_servisi_tds") or {}).get("usd_mn") or 0.0)

    bop_pay = float(kopru["bop_yatirim_geliri_icde_tutma"]) * g_f
    tds_rah = float(kopru["dis_borc_servisi_rahati_vekili"]) * g_f
    usd_bop_tut = cicek * bop_pay
    usd_tds_rah = tds * tds_rah * 0.002
    vekil_bop = _vekil_from_usd(usd_bop_tut, cicek, merkez_rant_c)
    vekil_tds = _vekil_from_usd(usd_tds_rah, cicek, merkez_rant_c)

    tranch = float(kopru["tr_finans_geri_tranchman"])
    mfin_tr = round((mfin_u - mfin_fin) * tranch, 3)
    merkez_tr = round((merkez_u - merkez_fin) * tranch * 0.85, 3)
    finans_geri_ham = mfin_tr + merkez_tr + (vekil_bop + vekil_tds) * tranch
    finans_geri = round(finans_geri_ham, 3)  # gerçekleşme g_f yukarıda çarpanlara girdi; merkez çarpanı projeksiyonda zaten var

    havza_fin = round(havza_u * (bos_fin / bos_u) if bos_u > 0 else havza_u, 3)
    tr_net_fin = round(-havza_fin + ic_u + rant_arti_u * 0.92 + finans_geri, 3)

    tam = float(kopru.get("tam_olgunluk_yil") or 10)
    y0 = 2026
    tr_z = float(z["tr_net_birlesik_vekil"])
    koridor = _koridor(y0, y0 + 22, tr_base, tr_net_fin, tam)
    sifir = _sifir_yili(tr_base, tr_net_fin, y0, tam)

    tr_c = next(
        a["net_birlesik_vekil"]
        for s in proj["senaryolar"]
        if s["id"] == sid
        for a in s.get("aktör_birlesik") or []
        if a.get("aktor") == "TR"
    )
    katmanlar = [
        {"katman": "C", "tr_net": float(tr_c)},
        {"katman": "C_zarar_cozum", "tr_net": float(z["tr_net_birlesik_vekil"])},
        {"katman": "uretim_ic_akis", "tr_net": tr_base},
        {"katman": "finans_katman", "tr_net": tr_net_fin},
    ]

    return {
        "olcum": "finans_katman_uretim_ustu",
        "etiket": "varsayim_carpanli_ham",
        "uyari": "Isaret donusu atanmis carpanlarla (finans_katman_kopru.json) uretilir; olcum degil, yayinlanan sonuc degil. Kalibre yol ve yayin metni ZARAR_10Y_GSYH / video ile okunmali.",
        "senaryo": sid,
        "taban": kopru.get("taban"),
        "finans_halka_oran_uretim_ustu": round(oran_fin / oran_uretim, 4) if oran_uretim else 1.0,
        "senaryo_gerceklesme": {
            "g_uretim": round(g_u, 4),
            "g_finans": round(g_f, 4),
            "g_finans_pozitif": round(g_f_pozitif, 4),
            "baskin_mod": _baskin_mod(sid),
            "ters_cevrildi": bool(g_f < 0),
            "etiket": (kopru.get("senaryo_gerceklesme") or {}).get("etiket"),
        },
        "ters_cevirme_bandi": _ters_band(sid) if band and g_f < 0 else None,
        "usd_vekili": {
            "yatirim_geliri_gideri_mn": cicek,
            "icde_tutulan_mn": round(usd_bop_tut, 1),
            "tds_rahati_mn": round(usd_tds_rah, 1),
            "vekil_bop": vekil_bop,
            "vekil_tds": vekil_tds,
            "olcek_satir": olcek_key,
        },
        "uretim_ic_akis_taban": {
            "tr_net_birlesik_vekil": tr_base,
            "turkiye_yaricevre_bosalma": bos_u,
            "merkez_finans_sizinti_toplam": merkez_u,
            "merkez_mfin_kenar_vekili": mfin_u,
        },
        "finans_katman_tam": {
            "turkiye_yaricevre_bosalma": bos_fin,
            "merkez_finans_sizinti_toplam": merkez_fin,
            "merkez_mfin_kenar_vekili": mfin_fin,
            "tr_finans_geri_kazanim_vekili": finans_geri,
            "tr_havza_kayip": havza_fin,
            "tr_net_birlesik_vekil": tr_net_fin,
        },
        "fark_tr_net_uretimden": round(tr_net_fin - tr_base, 3),
        "katman_yigini": katmanlar,
        "sifir_nokta": {
            "taban_yil": y0,
            "tam_olgunluk_yil": tam,
            "uretim_sonrasi_net": tr_base,
            "finans_sonrasi_net": tr_net_fin,
            "takvim_yil_sifir_ustu": sifir,
        },
        "yillik_tr_net_orta_finans": koridor[:14],
        "mantik": [
            "Finans halkaları (3)(4)(5): uretim katmanı çarpanının üstüne ek kısalma.",
            "MFIN kenar sızıntısı + merkez; zarar kredi_ihtiyaci=0 → merkez kesinti bonusu.",
            "TCMB yatırım geliri gideri + TDS vekili → vekil, TR finans geri kazanım payı.",
        ],
        "kaynak": [
            f"URETIM_IC_AKIS_{sid}.json",
            "PROJEKSIYON.json",
            f"ZARAR_COZUM_{sid}.json",
            "empirik/tr_finans_akisi_2024.json",
            "finans_katman_kopru.json",
        ],
    }


def _ters_band(sid: str) -> dict[str, Any]:
    """Ters çevirme gücü duyarlılığı (TR net): çevrilmemiş (+1), etkisiz (0), yarım ayna (−0,5), tam ayna (−1)."""
    ad = {"cevrilmemis_pozitif": 1.0, "guc_0.0_etkisiz": 0.0, "guc_0.5": -0.5, "guc_1.0_tam_ayna": -1.0}
    return {k: hesapla(sid, isaret_override=v, band=False)["finans_katman_tam"]["tr_net_birlesik_vekil"] for k, v in ad.items()}


def _md(d: dict[str, Any]) -> str:
    t = d["uretim_ic_akis_taban"]
    f = d["finans_katman_tam"]
    u = d["usd_vekili"]
    s = d["sifir_nokta"]
    lines = [
        "# Finans katmanı (üretim + halka üstü)",
        "",
        "> **Etiket: varsayım çarpanlı ham.** İşaret dönüşü atanmış çarpanlarla üretilir; ölçüm değildir, yayınlanan sonuç değildir.",
        "",
        *(
            [
                f"> **Ters çevrilmiş (araçsallaşma, baskın mod = {d['senaryo_gerceklesme']['baskin_mod']}).** Finans kanalları TR lehine kısalmaz, "
                f"dış çıkar ağının aracına döner (g_f = {d['senaryo_gerceklesme']['g_finans']}). Duyarlılık (TR net): {d['ters_cevirme_bandi']}. Ayna simetri ve güç varsayımdır.",
                "",
            ]
            if d["senaryo_gerceklesme"].get("ters_cevrildi")
            else []
        ),
        "MFIN kenar, merkez sızıntı, finans halkaları (3)(4)(5), "
        f"**{u['olcek_satir']}** ({u['yatirim_geliri_gideri_mn']:,} mn USD) ve TDS vekili.",
        "",
        "## Katman yığını (TR net vekil)",
        "",
        "| Katman | TR net |",
        "| --- | ---: |",
    ]
    for row in d["katman_yigini"]:
        lines.append(f"| {row['katman']} | {row['tr_net']} |")
    lines.extend(
        [
            "",
            "## Üretim → finans",
            "",
            f"| | Üretim tam | + Finans |",
            f"| --- | ---: | ---: |",
            f"| TR net | {t['tr_net_birlesik_vekil']} | **{f['tr_net_birlesik_vekil']}** |",
            f"| Boşalma | {t['turkiye_yaricevre_bosalma']} | {f['turkiye_yaricevre_bosalma']} |",
            f"| Merkez sızıntı | {t['merkez_finans_sizinti_toplam']} | {f['merkez_finans_sizinti_toplam']} |",
            f"| MFIN kenar | {t['merkez_mfin_kenar_vekili']} | {f['merkez_mfin_kenar_vekili']} |",
            f"| Finans geri kazanım | — | {f['tr_finans_geri_kazanim_vekili']} |",
            "",
            f"**Finans katmanı iyileşmesi:** {d['fark_tr_net_uretimden']} vekil",
            "",
            "## USD ↔ vekil",
            "",
            f"- İçde tutulan yatırım geliri vekili: **{u['vekil_bop']}** ({u['icde_tutulan_mn']:,} mn USD)",
            f"- TDS rahatı vekili: **{u['vekil_tds']}**",
            "",
            "## Sıfır noktası",
            "",
            f"- Finans tam olgunluk sonrası net: **{s['finans_sonrasi_net']}**",
            f"- Tahmini takvim yılı (TR net ≥ 0, orta yol): **{s['takvim_yil_sifir_ustu'] or '—'}**",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    data = hesapla()
    (OUT / "FINANS_KATMAN.json").write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (OUT / "FINANS_KATMAN.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'FINANS_KATMAN.md'}")


if __name__ == "__main__":
    main()
