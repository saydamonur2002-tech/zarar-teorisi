"""Havzalar net kaybediyorsa kim kazanıyor? ve TR'nin kayıp hızının bölgeye parasal akış sağlaması (kısa vade, 2027–2029).

A) Kayıp havuzu (TR boşalması + havza kayıpları) ile kazanç kanalları (kanal/matris/ikame/merkez) karşılaştırılır; kazancın hangi grupta
   (merkez, dış rakip güçler, bölge) toplandığı ve ölü ağırlık (havuzun kimseye gitmeyen kısmı) verilir. Net sınıf için bant dikkate alınır.
B) TR'nin yıllık kayıp akışı (ZARAR_10Y yillik_seri, ilk 3 yıl) USD'ye üç köprüyle çevrilir; kazancı toplayanlara oranlanır. Akışın kısa vadede
   SÜRDÜRÜLEBİLİR olup olmadığı bağımsız gözlemle (Dünya Bankası: cari açık, brüt rezerv) karşılaştırılır:
     geçerli_cari_denge: akış gözlenen cari açık ortalamasını aşmıyor; geçerli_rezervle: 3 yıllık aşım brüt rezerv içinde; gecersiz: rezerv yetmez.
   Sınırlar: GSYH 2024'te sabit (büyüme yok), rezerv brüt (net değil), akışın finansmanı için başka kaynak (yeni borç, swap) hesaba katılmadı.
Tanı raporu: başka modüle girdi olmaz (döngü yok).
"""
from __future__ import annotations

import json
import statistics as st
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"
GRUPLAR = {
    "merkez": ("MFIN", "US", "EU", "FR"),
    "dis_rakip_guc": ("CN", "RU"),
}  # kalanı: bölge (İran, İsrail, Körfez, Mısır, Yunanistan, Kıbrıs, Balkan, ...)
KOPRULER = ("bop_merkez_rant", "mal_net_ticaret", "tum_havza_rant")
UFUK = 3


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _grup(iso: str) -> str:
    for g, uyeler in GRUPLAR.items():
        if iso in uyeler:
            return g
    return "bolge"


def kazanan_tablosu() -> dict[str, Any]:
    muh = {s["id"]: s for s in _load(OUT / "KAZANC_KAYIP_MUHASEBE.json")["senaryolar"]}
    proj = {s["id"]: s for s in _load(OUT / "PROJEKSIYON.json")["senaryolar"]}
    out: dict[str, Any] = {}
    for sid in ("A", "B", "C"):
        m, p = muh[sid], proj[sid]
        bn = p["bolgesel_net"]
        led = {r["ulke"]: r for r in _load(OUT / f"DIS_ULKE_REFAH_{sid}.json")["ulke_defteri"]}
        brut: dict[str, float] = {"merkez": 0.0, "dis_rakip_guc": 0.0, "bolge": 0.0}
        net: dict[str, float] = {"merkez": 0.0, "dis_rakip_guc": 0.0, "bolge": 0.0}
        for iso, r in led.items():
            if iso == "TR":
                continue
            g = _grup(iso)
            brut[g] += float(r["dis_toplam_vekili"])
            net[g] += float(r.get("net_maliyetli", r.get("net_refah_entegre")) or 0.0)
        top_defter = sum(brut.values())  # grup payları için (defter, refah rantı dahil)
        top = float(m["kazanc"]["toplam"])  # V ile sınırlı kazanç (muhasebe); ölü ağırlık bununla ölçülür
        kazananlar = sorted(
            (
                (iso, float(r.get("net_maliyetli", r.get("net_refah_entegre")) or 0.0), float(r.get("net_bandi") or 0.0))
                for iso, r in led.items()
                if iso != "TR"
            ),
            key=lambda x: -x[1],
        )
        kayip = m["kayip"]
        out[sid] = {
            "havza_sayisi": len(bn),
            "net_kaybeden_havza": sum(1 for b in bn if b["net_endeks"] < 0),
            "havza_net_toplam": round(sum(b["net_endeks"] for b in bn), 3),
            "tr_boslasma": kayip["tr"],
            "diger_kayip": kayip["diger"],
            "kayip_havuzu": kayip["toplam"],
            "brut_kazanc_toplam": round(top, 3),
            "defter_brut_kazanc_toplam": round(top_defter, 3),
            "olu_agirlik": round(kayip["toplam"] - top, 3),
            "olu_agirlik_orani": round((kayip["toplam"] - top) / kayip["toplam"], 3),
            "kazanc_kanallari": m["kazanc"],
            "grup_brut_kazanc": {g: round(v, 3) for g, v in brut.items()},
            "grup_brut_pay": {g: round(v / top_defter, 3) for g, v in brut.items()},
            "grup_net_maliyetli": {g: round(v, 3) for g, v in net.items()},
            "bant_disi_kazananlar": [iso for iso, n, b in kazananlar if n - b > 0],
            "en_buyuk_brut_alicilar": [
                (iso, round(float(r["dis_toplam_vekili"]), 3))
                for iso, r in sorted(led.items(), key=lambda kv: -float(kv[1]["dis_toplam_vekili"]))
                if iso != "TR"
            ][:6],
        }
    return out


def kisa_vade(tab: dict[str, Any]) -> dict[str, Any]:
    z = {s["id"]: s for s in _load(OUT / "ZARAR_10Y_SENARYO_COKLU.json")["senaryolar"]}
    kop = _load(DATA / "kalibre" / "gerceklik_realizasyon.json")["usd_kopruleri"]
    w = _load(DATA / "gozlem" / "tr_bagimsiz_olcek.json")
    y = w["yillar"]
    gsyh = float(w["TUR"]["gsyh_usd"][y[-1]]) / 1e6
    cari = st.mean(-float(w["TUR"]["cari_denge_gsyh"][k]) for k in y) / 100 * gsyh  # mn $/yıl
    brut_pg = st.mean(float(w["TUR"]["birincil_gelir_odeme_usd"][k]) / float(w["TUR"]["gsyh_usd"][k]) for k in y) * gsyh
    rezerv = float(w["TUR"]["toplam_rezerv_usd"][y[-1]]) / 1e6
    out: dict[str, Any] = {"kapasite_mn_usd": {"cari_acik_ort": round(cari), "brut_birincil_gelir_odemesi_ort": round(brut_pg), "brut_rezerv_son": round(rezerv)}}
    for sid in ("A", "B", "C"):
        seri = z[sid]["yillik_seri"][:UFUK]
        kayip = [-float(r["tr_net"]) for r in seri]
        baslangic = -float(z[sid]["tr_c_refah"])
        hiz = [round(kayip[0] - baslangic, 3)] + [round(kayip[i] - kayip[i - 1], 3) for i in range(1, len(kayip))]
        t = tab[sid]
        alinan = min(1.0, t["brut_kazanc_toplam"] / t["tr_boslasma"])  # TR kaybının kazanç olarak alıcılara ulaşan kısmı
        satirlar = {}
        for k in KOPRULER:
            usd = [v * float(kop[k]["usd_per_vekil_mn"]) for v in kayip]
            asim = [max(0.0, v - cari) for v in usd]
            toplam_asim = sum(asim)
            if toplam_asim == 0:
                karar = "gecerli_cari_denge"
            elif toplam_asim <= rezerv:
                karar = "gecerli_rezervle"
            else:
                karar = "gecersiz"
            satirlar[k] = {
                "akis_mn_usd": [round(v) for v in usd],
                "akis_gsyh_yuzde": [round(v / gsyh * 100, 2) for v in usd],
                "cari_aciga_oran_ilk_yil": round(usd[0] / cari, 2),
                "ucyil_asim_mn_usd": round(toplam_asim),
                "rezerv_orani": round(toplam_asim / rezerv, 2),
                "rezerv_sinirda": bool(0.5 < toplam_asim / rezerv <= 1.0),
                "gecerli_olcek_s": round(cari / max(usd), 3),
                "karar": karar,
                "bolgeye_akis_mn_usd": [round(v * alinan * t["grup_brut_pay"]["bolge"]) for v in usd],
                "merkeze_akis_mn_usd": [round(v * alinan * t["grup_brut_pay"]["merkez"]) for v in usd],
                "dis_rakip_guce_akis_mn_usd": [round(v * alinan * t["grup_brut_pay"]["dis_rakip_guc"]) for v in usd],
                "kimseye_ulasmayan_mn_usd": [round(v * (1 - alinan)) for v in usd],
            }
        out[sid] = {
            "yillar": [r["yil"] for r in seri],
            "tr_kayip_vekil": [round(v, 3) for v in kayip],
            "kayip_hizi_vekil_yil": hiz,
            "alicilara_ulasan_pay": round(alinan, 3),
            "koprular": satirlar,
        }
    return out


def calistir() -> dict[str, Any]:
    tab = kazanan_tablosu()
    kv = kisa_vade(tab)
    d = {
        "olcum": "havza_kazanan_ve_kisa_vade_akis",
        "etiket": "tani_girdi_degil",
        "kazanan_tablosu": tab,
        "kisa_vade": kv,
        "gruplar": {"merkez": list(GRUPLAR["merkez"]), "dis_rakip_guc": list(GRUPLAR["dis_rakip_guc"]), "bolge": "diğer tüm ülkeler/aktörler"},
        "not": "GSYH 2024'te sabit (büyüme yok); rezerv brüt (altın dahil), net rezerv değil; yeni borç/swap ve akışın çok yıllı ivmesi modellenmedi.",
    }
    (OUT / "HAVZA_KAZANAN_KISA_VADE.json").write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    L = ["# Havzalar net kaybediyorsa kim kazanıyor? ve kısa vadeli parasal akış", "", d["not"], "",
         "## 1. Kayıp havuzu ve kim topluyor", "",
         "| Senaryo | Net kaybeden havza | Σ havza net | TR kaybı | Diğer kayıp | Havuz | Kazanç (V ile sınırlı) | Ölü ağırlık | Oran |",
         "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |"]
    for sid, t in tab.items():
        L.append(f"| {sid} | {t['net_kaybeden_havza']}/{t['havza_sayisi']} | {t['havza_net_toplam']:+.2f} | {t['tr_boslasma']:.2f} | {t['diger_kayip']:.2f} | {t['kayip_havuzu']:.2f} | {t['brut_kazanc_toplam']:.2f} | {t['olu_agirlik']:.2f} | %{t['olu_agirlik_orani']*100:.0f} |")
    L += ["", "| Senaryo | Merkez (MFİN, ABD, AB, Fransa) brüt / net | Dış rakip güçler (Çin, Rusya) brüt / net | Bölge brüt / net | Bant dışı kazananlar |", "| --- | --- | --- | --- | --- |"]
    for sid, t in tab.items():
        g, n, p = t["grup_brut_kazanc"], t["grup_net_maliyetli"], t["grup_brut_pay"]
        L.append(f"| {sid} | {g['merkez']:.2f} (%{p['merkez']*100:.0f}) / {n['merkez']:+.2f} | {g['dis_rakip_guc']:.2f} (%{p['dis_rakip_guc']*100:.0f}) / {n['dis_rakip_guc']:+.2f} | {g['bolge']:.2f} (%{p['bolge']*100:.0f}) / {n['bolge']:+.2f} | {', '.join(t['bant_disi_kazananlar']) or '—'} |")
    L += ["", "## 2. Kısa vade (2027–2029): TR kayıp hızı → bölgeye parasal akış", "",
          f"Kapasite (mn $/yıl, 2024 GSYH sabit): cari açık ort. {kv['kapasite_mn_usd']['cari_acik_ort']:,}; brüt birincil gelir ödemesi ort. {kv['kapasite_mn_usd']['brut_birincil_gelir_odemesi_ort']:,}; brüt rezerv {kv['kapasite_mn_usd']['brut_rezerv_son']:,}.", ""]
    for sid in ("A", "B", "C"):
        s = kv[sid]
        L += [f"### Senaryo {sid}: kayıp {s['tr_kayip_vekil']} vekil (hız {s['kayip_hizi_vekil_yil']}/yıl); alıcılara ulaşan pay %{s['alicilara_ulasan_pay']*100:.0f}", "",
              "| Köprü | Akış mn $ (3 yıl) | % GSYH | Cari açığa oran (yıl 1) | 3 yıl aşım | Rezerve oran | Geçerli ölçek s | Karar | Bölgeye akış | Merkeze | Dış rakip güçlere |",
              "| --- | --- | --- | ---: | ---: | ---: | ---: | --- | --- | --- | --- |"]
        for k, r in s["koprular"].items():
            L.append(f"| {k} | {r['akis_mn_usd']} | {r['akis_gsyh_yuzde']} | {r['cari_aciga_oran_ilk_yil']} | {r['ucyil_asim_mn_usd']:,} | {r['rezerv_orani']} | {r['gecerli_olcek_s']} | {r['karar']}{' (rezerv sınırda)' if r['rezerv_sinirda'] else ''} | {r['bolgeye_akis_mn_usd']} | {r['merkeze_akis_mn_usd']} | {r['dis_rakip_guce_akis_mn_usd']} |")
        L.append("")
    (OUT / "HAVZA_KAZANAN_KISA_VADE.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    return d


if __name__ == "__main__":
    calistir()
    print("HAVZA_KAZANAN_KISA_VADE ok")
