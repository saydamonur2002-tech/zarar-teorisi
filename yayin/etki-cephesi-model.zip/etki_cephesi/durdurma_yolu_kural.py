"""Durdurmanın nasıl gerçekleşeceği: kural bazlı yol (aktör bazlı değil).

Kurallar (data/etki_cephesi/durdurma_kurallari.json):
  R1 Ayrışma: TR boşalması beş halkaya bölünür (C'deki halka ağırlıkları w_h).
  R2 Hız: halka h için s_h(t+1) = s_h(t) + min(1, a · m · g_h) · (1 − s_h(t)) · kapı_h(t); g_h ilgili katmanın kalibre gerçekleşme oranı
          (zarar_teorisi 0,665; uretim_ic_akis 0,2375; finans_katman 0,2193; koordinasyon ve dış kısıt için üç katmanın ortalaması, atanmış).
  R3 Sıra kapısı: üretim ve finans halkaları, zarar-aktarım halkası eşik θ_z'ye ulaşınca açılır (θ_z kalibre yolun faz sınırından türetilir).
  R4 Dış kısıt kapısı: kendi katmanı olmayan ekzojen halka, diğer halkaların ağırlıklı durma ortalaması 0,5'e ulaşınca açılır (atanmış).
  R5 Finansman: yıllık TR kayıp akışı (boşalma dışı sabit kayıp + boşalma × (1 − d_t)) üç USD köprüsüyle cari açık ve brüt rezervle karşılaştırılır;
          kümülatif aşım rezervi aşarsa rezerv tükenir (yıl raporlanır). Cari açık ve rezerv 2024 düzeyinde sabit (büyüme, yeni borç yok).
a: hız sabiti, kalibre C yolunun 10. yıl durdurma oranına uydurulur (m = 1 modelin mevcut yolunu yeniden üretir). m: politika hız çarpanı.
Tanı raporu: başka modüle girdi olmaz.
"""
from __future__ import annotations

import json
import statistics as st
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"
KOPRULER = ("bop_merkez_rant", "mal_net_ticaret", "tum_havza_rant")
HALKALAR = ("zarar_aktarimi", "uretim_bagimlilik", "para_sizintisi", "koordinasyon_kopuk", "dis_kisit")


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _girdiler() -> dict[str, Any]:
    cfg = _load(DATA / "durdurma_kurallari.json")
    ref = cfg["referans_senaryo"]
    proj = next(s for s in _load(OUT / "PROJEKSIYON.json")["senaryolar"] if s["id"] == ref)
    toplam: dict[str, float] = {h: 0.0 for h in HALKALAR}
    for b in proj["tr_bosalma_detay"]:
        for h in b["bes_halka"]:
            toplam[h["halka"]] += float(h["delta_endeks"])
    top = sum(toplam.values())
    w = {h: toplam[h] / top for h in HALKALAR}
    real = _load(DATA / "kalibre" / "gerceklik_realizasyon.json")["gerceklesme_oranlari"]
    g_ort = st.mean(float(real[k]) for k in ("zarar_teorisi", "uretim_ic_akis", "finans_katman"))
    g = {}
    for h, kat in cfg["halka_katman"].items():
        g[h] = g_ort if kat in (None, "ortalama_uc_katman") else float(real[kat])
    z = next(s for s in _load(OUT / "ZARAR_10Y_SENARYO_COKLU.json")["senaryolar"] if s["id"] == ref)
    seri = z["yillik_seri"]
    baslangic = float(z["tr_c_refah"])
    d_cal = [1.0 - float(r["tr_net"]) / baslangic for r in seri]
    faz_siniri = next(i for i, r in enumerate(seri) if r["faz"] != "zarar")  # ilk 'uretim+finans' yılının indeksi
    tr = next(a for a in proj["aktör_birlesik"] if a["aktor"] == "TR")
    bosalma = float(proj["turkiye_yaricevre_bosalma"])
    kop = _load(DATA / "kalibre" / "gerceklik_realizasyon.json")["usd_kopruleri"]
    wb = _load(DATA / "gozlem" / "tr_bagimsiz_olcek.json")
    y = wb["yillar"]
    gsyh = float(wb["TUR"]["gsyh_usd"][y[-1]]) / 1e6
    cari = sum(-float(wb["TUR"]["cari_denge_gsyh"][k]) for k in y) / len(y) / 100 * gsyh
    rezerv = float(wb["TUR"]["toplam_rezerv_usd"][y[-1]]) / 1e6
    refah_ic = sum(float(b["refah_rant_tr_ic"]) for b in proj["bolgesel_net"])
    return {
        "cfg": cfg, "w": w, "g": g, "yillar": [r["yil"] for r in seri], "d_cal": d_cal, "faz_siniri": faz_siniri,
        "bosalma": bosalma, "sabit_kayip": float(tr["havza_kayip"]) - bosalma, "refah_ic": refah_ic,
        "kop": {k: float(kop[k]["usd_per_vekil_mn"]) for k in KOPRULER}, "cari": cari, "rezerv": rezerv,
    }


def simule(G: dict[str, Any], a: float, m: float, sira: bool, n: int, theta_z: float | None, time_gate: int | None = None) -> dict[str, Any]:
    w, g = G["w"], G["g"]
    esik_x = float(G["cfg"]["kapi_kurallari"]["dis_kisit_kurali"]["esik"])
    s = {h: 0.0 for h in HALKALAR}
    d_yol, s_yol = [], []
    acilis: dict[str, int | None] = {"uretim_bagimlilik": None, "para_sizintisi": None, "dis_kisit": None}
    for t in range(1, n + 1):
        onceki = dict(s)
        for h in HALKALAR:
            kapi = 1.0
            if h in ("uretim_bagimlilik", "para_sizintisi") and sira:
                kapi = 1.0 if ((t - 1 >= time_gate) if time_gate is not None else onceki["zarar_aktarimi"] >= (theta_z or 0.0)) else 0.0
            if h == "dis_kisit":
                diger = sum(w[k] * onceki[k] for k in HALKALAR if k != "dis_kisit") / (1.0 - w["dis_kisit"])
                kapi = 1.0 if diger >= esik_x else 0.0
            if kapi and h in acilis and acilis[h] is None:
                acilis[h] = t
            s[h] = onceki[h] + min(1.0, a * m * g[h]) * (1.0 - onceki[h]) * kapi  # adım en çok 1: halka bir yılda tümüyle durabilir, aşmaz
        d_yol.append(sum(w[h] * s[h] for h in HALKALAR))
        s_yol.append(dict(s))
    return {"d": d_yol, "s": s_yol, "acilis_yili": acilis}


def simule_321(G: dict[str, Any], a: float, m: float, n: int) -> dict[str, Any]:
    """Kullanıcının 3↔2↔1 ⇒ 4↓ ⇒ 5↓ mimarisi (Drive: Zarar Teorisi Tek Çekirdek Dört Düğüm): 1, 2, 3 halkaları kendi hızlarıyla ilerler;
    zarar aktarımı (4) yalnız ORTAK ilerlemeyle azalır (geometrik ortalama J = (s1·s2·s3)^(1/3): biri sıfırsa 4 hiç azalmaz, 'tek başına yetmez');
    dış kısıt (5) 4 yarıya inince açılır ('4 küçüldükçe 5 gevşer')."""
    w, g = G["w"], G["g"]
    esik5 = 0.5
    s = {h: 0.0 for h in HALKALAR}
    d_yol, s_yol = [], []
    for t in range(1, n + 1):
        o = dict(s)
        for h in ("uretim_bagimlilik", "koordinasyon_kopuk", "para_sizintisi"):
            s[h] = o[h] + min(1.0, a * m * g[h]) * (1.0 - o[h])
        j = (o["uretim_bagimlilik"] * o["koordinasyon_kopuk"] * o["para_sizintisi"]) ** (1.0 / 3.0)
        s["zarar_aktarimi"] = o["zarar_aktarimi"] + min(1.0, a * m * g["zarar_aktarimi"]) * (1.0 - o["zarar_aktarimi"]) * j
        kapi5 = 1.0 if o["zarar_aktarimi"] >= esik5 else 0.0
        s["dis_kisit"] = o["dis_kisit"] + min(1.0, a * m * g["dis_kisit"]) * (1.0 - o["dis_kisit"]) * kapi5
        d_yol.append(sum(w[h] * s[h] for h in HALKALAR))
        s_yol.append(dict(s))
    return {"d": d_yol, "s": s_yol}


def kalibre_321(G: dict[str, Any]) -> dict[str, Any]:
    n = len(G["d_cal"])
    hedef = G["d_cal"][-1]
    lo, hi = 1e-6, 50.0
    for _ in range(100):
        mid = (lo + hi) / 2
        if simule_321(G, mid, 1.0, n)["d"][-1] < hedef:
            lo = mid
        else:
            hi = mid
    a = (lo + hi) / 2
    r = simule_321(G, a, 1.0, n)
    rmse = (sum((x - y) ** 2 for x, y in zip(r["d"], G["d_cal"])) / n) ** 0.5
    return {"a": a, "rmse": rmse, "ref_d": r["d"], "ulasilabilir": simule_321(G, hi, 1.0, n)["d"][-1] >= hedef - 1e-4}


def kalibre(G: dict[str, Any]) -> dict[str, Any]:
    n = len(G["d_cal"])
    hedef = G["d_cal"][-1]
    ts = G["faz_siniri"]
    lo, hi = 1e-6, 5.0
    for _ in range(80):
        mid = (lo + hi) / 2
        if simule(G, mid, 1.0, True, n, None, time_gate=ts)["d"][-1] < hedef:
            lo = mid
        else:
            hi = mid
    a = (lo + hi) / 2
    ref = simule(G, a, 1.0, True, n, None, time_gate=ts)
    theta = ref["s"][ts - 1]["zarar_aktarimi"]  # faz sınırında (ts. yıl başında) zarar-aktarım halkası durma oranı
    rmse = (sum((x - y) ** 2 for x, y in zip(ref["d"], G["d_cal"])) / n) ** 0.5
    return {"a": a, "theta_z": theta, "rmse": rmse, "ref_d": ref["d"]}


def akis(G: dict[str, Any], d_yol: list[float]) -> dict[str, Any]:
    out = {}
    for k in KOPRULER:
        usd = [(G["sabit_kayip"] + G["bosalma"] * (1.0 - d)) * G["kop"][k] for d in d_yol]
        kum, tukenme = 0.0, None
        for i, v in enumerate(usd):
            kum += max(0.0, v - G["cari"])
            if tukenme is None and kum > G["rezerv"]:
                tukenme = G["yillar"][i]
        ilk_sigar = next((G["yillar"][i] for i, v in enumerate(usd) if v <= G["cari"]), None)
        out[k] = {
            "akis_mn_usd": [round(v) for v in usd],
            "cari_aciga_oran": [round(v / G["cari"], 2) for v in usd],
            "kumulatif_asim_mn_usd": round(kum),
            "rezerv_orani": round(kum / G["rezerv"], 2),
            "rezerv_tukenme_yili": tukenme,
            "akis_cariye_siger_ilk_yil": ilk_sigar,
        }
    return out


def hiz_carpani_ara_321(G: dict[str, Any], kal: dict[str, Any], n: int, ust: float) -> dict[str, float | None]:
    sonuc: dict[str, float | None] = {}
    for k in KOPRULER:
        def tukenir(m: float) -> bool:
            return akis(G, simule_321(G, kal["a"], m, n)["d"])[k]["rezerv_tukenme_yili"] is not None

        if not tukenir(1.0):
            sonuc[k] = 1.0
            continue
        if tukenir(ust):
            sonuc[k] = None
            continue
        lo, hi = 1.0, ust
        for _ in range(40):
            mid = (lo + hi) / 2
            lo, hi = (mid, hi) if tukenir(mid) else (lo, mid)
        sonuc[k] = round(hi, 2)
    return sonuc


def hiz_carpani_ara(G: dict[str, Any], kal: dict[str, Any], n: int, sira: bool, ust: float) -> dict[str, float | None]:
    """Rezerv 10 yıl boyunca tükenmesin diye gereken en küçük hız çarpanı m* (köprü başına, ikili arama)."""
    sonuc: dict[str, float | None] = {}
    for k in KOPRULER:
        def tukenir(m: float) -> bool:
            d = simule(G, kal["a"], m, sira, n, kal["theta_z"])["d"]
            return akis(G, d)[k]["rezerv_tukenme_yili"] is not None

        if not tukenir(1.0):
            sonuc[k] = 1.0
            continue
        if tukenir(ust):
            sonuc[k] = None
            continue
        lo, hi = 1.0, ust
        for _ in range(40):
            mid = (lo + hi) / 2
            lo, hi = (mid, hi) if tukenir(mid) else (lo, mid)
        sonuc[k] = round(hi, 2)
    return sonuc


SIRALAR = {
    # Drive "Geçiş Koridoru" (6 aşama): 1-2 zarar haritası/ayrıştırma (ölçüm: 2 ve 4'ün işi), 3 koşullu tampon (4), 4 yerli tedarik (1), 5 mekânsal bağlantı (3), 6 döviz kazancı fonu (5).
    # Aynı belgenin "3-2-1 sıra değil, eşzamanlı döngüdür" ilkesine AYKIRI: ardışık ve 1, 3'ten önce.
    "koridor_aykiri": (("koordinasyon_kopuk", "zarar_aktarimi"), ("uretim_bagimlilik",), ("para_sizintisi",), ("dis_kisit",)),
    "eszamanli": (tuple(HALKALAR),),
}


def simule_asamali(G: dict[str, Any], a: float, m: float, n: int, asamalar: tuple, kota: float) -> dict[str, Any]:
    """Aşamalı açılış: aşama i, aşama i-1'in tüm halkaları `kota` durma oranına varınca açılır (önceki yıl sonu değeriyle). Tek aşama = eş zamanlı."""
    w, g = G["w"], G["g"]
    s = {h: 0.0 for h in HALKALAR}
    d_yol, s_yol = [], []
    acilis = {h: None for h in HALKALAR}
    for t in range(1, n + 1):
        o = dict(s)
        for i, grp in enumerate(asamalar):
            kapi = 1.0 if i == 0 or min(o[h] for h in asamalar[i - 1]) >= kota else 0.0
            for h in grp:
                s[h] = o[h] + min(1.0, a * m * g[h]) * (1.0 - o[h]) * kapi
                if kapi and acilis[h] is None:
                    acilis[h] = t
        d_yol.append(sum(w[h] * s[h] for h in HALKALAR))
        s_yol.append(dict(s))
    return {"d": d_yol, "s": s_yol, "acilis_yili": acilis}


def kalibre_asamali(G: dict[str, Any], asamalar: tuple, kota: float) -> dict[str, Any]:
    n = len(G["d_cal"])
    hedef = G["d_cal"][-1]
    lo, hi = 1e-6, 50.0
    for _ in range(100):
        mid = (lo + hi) / 2
        if simule_asamali(G, mid, 1.0, n, asamalar, kota)["d"][-1] < hedef:
            lo = mid
        else:
            hi = mid
    a = (lo + hi) / 2
    r = simule_asamali(G, a, 1.0, n, asamalar, kota)
    rmse = (sum((x - y) ** 2 for x, y in zip(r["d"], G["d_cal"])) / n) ** 0.5
    return {"a": a, "rmse": rmse, "ref_d": r["d"]}


def siralar_blogu(G: dict[str, Any]) -> dict[str, Any]:
    n = len(G["d_cal"])
    blok: dict[str, Any] = {}
    for ad, asamalar, kota in (("koridor_aykiri_kota025", SIRALAR["koridor_aykiri"], 0.25), ("koridor_aykiri_kota050", SIRALAR["koridor_aykiri"], 0.5), ("eszamanli", SIRALAR["eszamanli"], 0.0)):
        k = kalibre_asamali(G, asamalar, kota)
        var = {}
        for vad, m in (("kalibre", 1.0), ("hiz_x2", 2.0), ("hiz_x3", 3.0), ("hiz_x5", 5.0)):
            r = simule_asamali(G, k["a"], m, n, asamalar, kota)
            var[vad] = {"hiz_carpani": m, "d_son": round(r["d"][-1], 4), "halka_durma_son_yil": {h: round(r["s"][-1][h], 3) for h in HALKALAR},
                        "halka_acilis_yili": {h: (G["yillar"][y - 1] if y else None) for h, y in r["acilis_yili"].items()},
                        "rezerv_tukenme_yili": {kp: v["rezerv_tukenme_yili"] for kp, v in akis(G, r["d"]).items()}}
        blok[ad] = {"asamalar": [list(x) for x in asamalar], "kota": kota, "a": round(k["a"], 5), "rmse_d": round(k["rmse"], 5), "varyantlar": var}
    return blok


def calistir() -> dict[str, Any]:
    G = _girdiler()
    n = len(G["d_cal"])
    kal = kalibre(G)
    cfg = G["cfg"]
    varyantlar = {}
    for ad, v in cfg["varyantlar"].items():
        r = simule(G, kal["a"], float(v["hiz_carpani"]), bool(v["sira_kurali"]), n, kal["theta_z"])
        d = r["d"]
        eşik_yil = {str(e): next((G["yillar"][i] for i, x in enumerate(d) if x >= e), None) for e in (0.25, 0.5, 0.75)}
        tr_net = [round(G["refah_ic"] * (1.0 - x) - (G["sabit_kayip"] + G["bosalma"] * (1.0 - x)), 3) for x in d]
        varyantlar[ad] = {
            "parametre": v,
            "d_yol": [round(x, 4) for x in d],
            "halka_durma_son_yil": {h: round(r["s"][-1][h], 3) for h in HALKALAR},
            "halka_acilis_yili": {h: (G["yillar"][y - 1] if y else None) for h, y in r["acilis_yili"].items()},
            "esik_yili": eşik_yil,
            "tr_net_yol": tr_net,
            "finansman": akis(G, d),
        }
    mstar = hiz_carpani_ara(G, kal, n, True, float(cfg["m_arama_ust"]))
    # Kullanıcının 3↔2↔1 ⇒ 4 ⇒ 5 mimarisi (Drive): aynı kalibrasyon hedefi, farklı kural yapısı
    k321 = kalibre_321(G)
    mimari = {"kalibrasyon": {"a": round(k321["a"], 5), "rmse_d": round(k321["rmse"], 5), "d_kural_yolu": [round(x, 4) for x in k321["ref_d"]]}, "varyantlar": {}}
    for ad, m in (("kalibre", 1.0), ("hiz_x2", 2.0), ("hiz_x3", 3.0), ("hiz_x5", 5.0)):
        r = simule_321(G, k321["a"], m, n)
        dd = r["d"]
        mimari["varyantlar"][ad] = {
            "hiz_carpani": m,
            "d_yol": [round(x, 4) for x in dd],
            "halka_durma_son_yil": {h: round(r["s"][-1][h], 3) for h in HALKALAR},
            "esik_yili": {str(e): next((G["yillar"][i] for i, x in enumerate(dd) if x >= e), None) for e in (0.25, 0.5, 0.75)},
            "finansman": akis(G, dd),
        }
    mimari["gereken_hiz_carpani_rezerv_tukenmesin"] = hiz_carpani_ara_321(G, k321, n, float(cfg["m_arama_ust"]))
    d = {
        "olcum": "durdurma_yolu_kural_bazli",
        "etiket": "tani_girdi_degil",
        "kurallar": cfg,
        "halka_agirliklari": {h: round(G["w"][h], 3) for h in HALKALAR},
        "halka_hizlari_g": {h: round(G["g"][h], 4) for h in HALKALAR},
        "kalibrasyon": {"a": round(kal["a"], 5), "theta_z": round(kal["theta_z"], 4), "rmse_d": round(kal["rmse"], 5), "d_kalibre_yol": [round(x, 4) for x in G["d_cal"]], "d_kural_yolu": [round(x, 4) for x in kal["ref_d"]], "yillar": G["yillar"], "faz_siniri_yili": G["yillar"][G["faz_siniri"]]},
        "varyantlar": varyantlar,
        "gereken_hiz_carpani_rezerv_tukenmesin": mstar,
        "mimari_321": mimari,
        "mimari_siralar": siralar_blogu(G),
        "kapasite_mn_usd": {"cari_acik_ort": round(G["cari"]), "brut_rezerv": round(G["rezerv"])},
        "not": "Kurallar mekanizma düzeyinde (halka/katman/kapı), aktör düzeyinde değil. Eşleştirmeler ve kapı eşikleri atanmış; hız sabiti kalibre C yoluna uydurulmuş. Cari açık ve rezerv sabit (büyüme, yeni borç yok); rezerv brüt.",
    }
    (OUT / "DURDURMA_YOLU_KURAL.json").write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    L = ["# Durdurmanın gerçekleşme yolu (kural bazlı)", "", d["not"], "",
         f"Kalibrasyon: a = {d['kalibrasyon']['a']}, θ_z = {d['kalibrasyon']['theta_z']}, kalibre yola RMSE (d) = {d['kalibrasyon']['rmse_d']}. Faz sınırı: {d['kalibrasyon']['faz_siniri_yili']}.", "",
         "Halka ağırlıkları (C): " + ", ".join(f"{h} {v}" for h, v in d["halka_agirliklari"].items()) + ".",
         "Halka hızları g: " + ", ".join(f"{h} {v}" for h, v in d["halka_hizlari_g"].items()) + ".", "",
         "| Yıl | " + " | ".join(str(y) for y in G["yillar"]) + " |", "| --- | " + " | ".join("---:" for _ in G["yillar"]) + " |",
         "| d (kalibre C yolu) | " + " | ".join(f"{x:.3f}" for x in G["d_cal"]) + " |",
         "| d (kural, m=1) | " + " | ".join(f"{x:.3f}" for x in kal["ref_d"]) + " |", ""]
    for ad, v in varyantlar.items():
        L += [f"## {ad} (m = {v['parametre']['hiz_carpani']}, sıra kuralı: {v['parametre']['sira_kurali']})", "",
              "d yolu: " + ", ".join(f"{x:.3f}" for x in v["d_yol"]),
              f"d ≥ 0,25 / 0,5 / 0,75 yılı: {v['esik_yili']['0.25']} / {v['esik_yili']['0.5']} / {v['esik_yili']['0.75']}; halka açılış yılları: {v['halka_acilis_yili']}; son yıl halka durma oranları: {v['halka_durma_son_yil']}",
              f"TR net yolu: " + ", ".join(f"{x:+.2f}" for x in v["tr_net_yol"]), "",
              "| Köprü | Akış / cari açık (yıl 1 → 10) | Akış cariye sığar (ilk yıl) | 10 yıl aşım | Rezerv oranı | Rezerv tükenme yılı |", "| --- | --- | --- | ---: | ---: | --- |"]
        for k, f in v["finansman"].items():
            L.append(f"| {k} | {f['cari_aciga_oran'][0]} → {f['cari_aciga_oran'][-1]} | {f['akis_cariye_siger_ilk_yil'] or '—'} | {f['kumulatif_asim_mn_usd']:,} | {f['rezerv_orani']} | {f['rezerv_tukenme_yili'] or '—'} |")
        L.append("")
    L += ["## Rezerv 10 yıl boyunca tükenmesin diye gereken hız çarpanı m* (kalibre sıra kuralıyla)", "", ", ".join(f"{k}: {v if v is not None else 'ulaşılamaz'}" for k, v in mstar.items())]
    L += ["", "## Alternatif kural yapısı: kullanıcının 3↔2↔1 ⇒ 4 ⇒ 5 mimarisi", "",
          "Halkalar 1 (üretim), 2 (koordinasyon), 3 (para sızıntısı) kendi hızlarında ilerler; 4 (zarar aktarımı) yalnız ortak ilerlemeyle (geometrik ortalama) azalır, 5 (dış kısıt) 4 yarıya inince açılır.",
          f"Kalibrasyon: a = {mimari['kalibrasyon']['a']}, kalibre yola RMSE (d) = {mimari['kalibrasyon']['rmse_d']} (faz sıralı yapı: {d['kalibrasyon']['rmse_d']}).", "",
          "| Yıl | " + " | ".join(str(y) for y in G["yillar"]) + " |", "| --- | " + " | ".join("---:" for _ in G["yillar"]) + " |",
          "| d (kalibre C yolu) | " + " | ".join(f"{x:.3f}" for x in G["d_cal"]) + " |",
          "| d (3↔2↔1, m=1) | " + " | ".join(f"{x:.3f}" for x in mimari["kalibrasyon"]["d_kural_yolu"]) + " |", ""]
    for ad, v in mimari["varyantlar"].items():
        L += [f"### 3↔2↔1 {ad} (m = {v['hiz_carpani']})", "", "d yolu: " + ", ".join(f"{x:.3f}" for x in v["d_yol"]),
              f"d ≥ 0,25 / 0,5 / 0,75 yılı: {v['esik_yili']['0.25']} / {v['esik_yili']['0.5']} / {v['esik_yili']['0.75']}; son yıl halka durma oranları: {v['halka_durma_son_yil']}",
              "Rezerv tükenme yılı (BoP / mal / rant): " + " / ".join(str(v["finansman"][k]["rezerv_tukenme_yili"] or "—") for k in KOPRULER), ""]
    L += ["3↔2↔1 mimarisiyle rezerv tükenmesin diye gereken m*: " + ", ".join(f"{k}: {v if v is not None else 'ulaşılamaz'}" for k, v in mimari["gereken_hiz_carpani_rezerv_tukenmesin"].items())]
    L += ["", "## Drive'daki aykırı sıralama: Geçiş Koridoru (ardışık) ve eş zamanlı karşılaştırma", "",
          "Belge 3-2-1'in 'bir reform sırası değil, eşzamanlı kapalı döngü' olduğunu söyler; ama Geçiş Koridoru ardışıktır: önce ölçüm ve koşullu tampon (2 ve 4), sonra yerli tedarik (1), sonra mekânsal bağlantı (3), en sonda döviz fonu (5). Bu hem eş zamanlılık ilkesine hem de 'üçü tek başına yapılırsa işlemez' uyarısına aykırı.", "",
          "| Yapı | Kota | a | RMSE (d) | son yıl durma oranları (m=1) | rezerv tükenme yılı (BoP / mal / rant), m=1 → m=5 |", "| --- | ---: | ---: | ---: | --- | --- |"]
    for ad, v in d["mimari_siralar"].items():
        k1, k5 = v["varyantlar"]["kalibre"], v["varyantlar"]["hiz_x5"]
        r1 = " / ".join(str(k1["rezerv_tukenme_yili"][k] or "—") for k in KOPRULER)
        r5 = " / ".join(str(k5["rezerv_tukenme_yili"][k] or "—") for k in KOPRULER)
        L.append(f"| {ad} | {v['kota']} | {v['a']} | {v['rmse_d']} | {k1['halka_durma_son_yil']} | {r1} → {r5} |")
    (OUT / "DURDURMA_YOLU_KURAL.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    return d


if __name__ == "__main__":
    calistir()
    print("DURDURMA_YOLU_KURAL ok")
