"""Etki cephesi tam zincir + P2 (A/B/C, 10y uluslararası)."""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
ETKI = REPO / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"
KALIBRE = REPO / "data" / "etki_cephesi" / "kalibre"
MAKS_GECIS = 5


def _run(name: str) -> None:
    parts = name.split()
    subprocess.check_call([sys.executable, str(ETKI / parts[0]), *parts[1:]])


def _ozet() -> str:
    """Üretilmiş raporlar + kalibre verisi özeti (satır sonu ve kararlılık dosyası hariç)."""
    h = hashlib.sha256()
    for d in (OUT, KALIBRE):
        for f in sorted(d.rglob("*")):
            if f.is_file() and f.name != "RUN_ALL_KARARLILIK.json":
                h.update(f.name.encode())
                h.update(f.read_bytes().replace(b"\r\n", b"\n"))
    return h.hexdigest()[:16]


def main() -> None:
    capa_apply = "--capa-apply" in sys.argv
    steps: list[str] = []
    if capa_apply:
        steps.append("gerceklik_capa_senkron.py --apply")
    steps.extend(
        [
        "kalibrasyon.py",
        "projeksiyon.py",
        "akis_olcum.py",
        "zarar_cozum_entegrasyon.py",
        "refah_dis_entegrasyon.py",
        "uretim_ic_akis.py",
        "finans_katman_senaryo_coklu.py",
        "senaryo_gerceklik_kalibre.py --skip-pipeline",
        "zarar_10y_gsyh.py",
        "modul_entegrasyon_kalibre.py --modules-only",
        "olasilik_duyarlilik.py",
        "c_dinamik_olcut.py",
        "olasilik_kapilar.py",
        "uzun_vade_esik.py",
        "senaryo_rapor.py",
        "gecmis_projeksiyon.py",
        ]
    )
    # Pipeline kendi çıktısını girdi okur (kalibre/ ve raporlar). Kararlı duruma kadar geç;
    # tek geçiş eski raporları okuyup ara durum bırakabilir.
    onceki = _ozet()
    kararli = False
    gecis = 0
    for gecis in range(1, MAKS_GECIS + 1):
        for s in steps:
            print(f"=== [geçiş {gecis}] {s} ===")
            _run(s)
        simdi = _ozet()
        if simdi == onceki:
            kararli = True
            break
        onceki = simdi
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "RUN_ALL_KARARLILIK.json").write_text(
        json.dumps({"gecis": gecis, "kararli": kararli, "ozet": onceki}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"Kararlı durum: {kararli} (geçiş {gecis})")


if __name__ == "__main__":
    main()
