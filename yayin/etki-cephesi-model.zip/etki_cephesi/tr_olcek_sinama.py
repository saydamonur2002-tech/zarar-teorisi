"""TR kaybının ölçeğini bağımsız gözlemle sına ve ölçek belirsizliğinin dış aktör sınıflarına yayılımını ölç.

Neden: Çin/Rusya/AB/BAE... kayıpları (ticaret çekimi) TR'nin gelir kaybına (L_TR) doğrusal bağlı; L_TR'nin USD ölçeği modelde üç farklı köprüyle
(BoP 2.589, rant 5.383, mal ticareti 4.785 mn $/vekil) 2 katı aşan farkla çevriliyor ve bağımsız bir gözlemle hiç karşılaştırılmamıştı.
Bağımsız gözlem (Dünya Bankası WDI, `gozlem/tr_bagimsiz_olcek.json`): brüt/net birincil gelir ödemesi, cari açık (kaynak aktarımı), kişi başı büyümenin
üst-orta gelir grubuna göre farkı. Bunlar GÖZLENEBİLİR sınırlardır; karşı-olgusal (refah rejimi) kaybın gözlenemeyen kısmını sınamazlar.
Yayılım: L_TR × s için (s ızgarası) φ yeniden kalibre edilir ve dış-veri aktörlerinin sınıfı yeniden hesaplanır. Tanı raporu: başka modüle girdi olmaz.
"""
from __future__ import annotations

import json
import math
import statistics as st
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"
OLCEK_IZGARA = (1.0, 0.7, 0.5, 0.35, 0.25, 0.1)
KOPRULER = ("bop_merkez_rant", "mal_net_ticaret", "tum_havza_rant")


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def gozlem() -> dict[str, Any]:
    d = _load(DATA / "gozlem" / "tr_bagimsiz_olcek.json")
    y = d["yillar"]
    T, U = d["TUR"], d["UMC"]
    gsyh = {k: T["gsyh_usd"][k] / 1e6 for k in y}  # mn $
    odeme = {k: T["birincil_gelir_odeme_usd"][k] / 1e6 for k in y}
    tahsil = {k: T["birincil_gelir_tahsilat_usd"][k] / 1e6 for k in y}
    brut = [odeme[k] / gsyh[k] * 100 for k in y]
    net = [(odeme[k] - tahsil[k]) / gsyh[k] * 100 for k in y]
    cari = [-T["cari_denge_gsyh"][k] for k in y]
    fark = [T["gsyh_kisibasi_buyume"][k] - U["gsyh_kisibasi_buyume"][k] for k in y]
    son = y[-1]
    return {
        "yillar": [y[0], son],
        "gsyh_son_mn_usd": round(gsyh[son], 1),
        "brut_birincil_gelir_odemesi_gsyh_yuzde": {"ort": round(st.mean(brut), 2), "maks": round(max(brut), 2), "son": round(brut[-1], 2)},
        "net_birincil_gelir_odemesi_gsyh_yuzde": {"ort": round(st.mean(net), 2), "maks": round(max(net), 2), "son": round(net[-1], 2)},
        "cari_acik_gsyh_yuzde": {"ort": round(st.mean(cari), 2), "maks": round(max(cari), 2), "son": round(cari[-1], 2)},
        "kisi_basi_buyume_farki_tr_eksi_umc_pp": {"ort": round(st.mean(fark), 2), "min": round(min(fark), 2), "maks": round(max(fark), 2)},
    }


def model_kayip(gs: float) -> dict[str, Any]:
    proj = {s["id"]: s for s in _load(OUT / "PROJEKSIYON.json")["senaryolar"]}
    kop = _load(DATA / "kalibre" / "gerceklik_realizasyon.json")["usd_kopruleri"]
    out = {}
    for sid in ("A", "B", "C"):
        tr = next(a for a in proj[sid]["aktör_birlesik"] if a["aktor"] == "TR")
        L = float(tr["havza_kayip"])
        row = {"vekil": L}
        for k in KOPRULER:
            usd = L * float(kop[k]["usd_per_vekil_mn"])
            row[k] = {"usd_mn": round(usd), "gsyh_yuzde": round(usd / gs * 100, 2)}
        out[sid] = row
    return out


def olcek_araliklari(model: dict[str, Any], gz: dict[str, Any]) -> dict[str, Any]:
    """Her gözlemlenebilir sınır için, model TR kaybı o sınıra eşit olsun diye gereken ölçek s = sınır / model (köprüler arası min–maks)."""
    sinirlar = {
        "brut_birincil_gelir_odemesi_ort": gz["brut_birincil_gelir_odemesi_gsyh_yuzde"]["ort"],
        "net_birincil_gelir_odemesi_ort": gz["net_birincil_gelir_odemesi_gsyh_yuzde"]["ort"],
        "cari_acik_ort": gz["cari_acik_gsyh_yuzde"]["ort"],
    }
    out: dict[str, Any] = {}
    for sid, row in model.items():
        out[sid] = {}
        for ad, sinir in sinirlar.items():
            degerler = [sinir / row[k]["gsyh_yuzde"] for k in KOPRULER]
            out[sid][ad] = {"s_min": round(min(degerler), 3), "s_maks": round(max(degerler), 3)}
    return out


def _sinif(net: float, bant: float) -> str:
    return "kazanan" if net - bant > 0 else ("kaybeden" if net + bant < 0 else "bant_ici")


def yayilim() -> dict[str, Any]:
    dv = _load(DATA / "gozlem" / "dis_ticaret_gsyh_2023.json")
    G, X = dv["gsyh_mn_usd"], dv["ihracat_mn_usd"]
    esik = dv["hub_kurali"]["esik_ihracat_gsyh"]

    def cekim(i: str, L: dict[str, float]) -> float:
        return sum(x / G[j] * L.get(j, 0.0) for j, x in X[i].items() if j != i and G.get(j) and not (esik and x / G[j] > esik))

    out: dict[str, Any] = {}
    for sid in ("A", "B", "C"):
        proj = {s["id"]: s for s in _load(OUT / "PROJEKSIYON.json")["senaryolar"]}[sid]
        ab = {a["aktor"]: a for a in proj["aktör_birlesik"]}
        led = {r["ulke"]: r for r in _load(OUT / f"DIS_ULKE_REFAH_{sid}.json")["ulke_defteri"]}
        L0 = {k: float(a["havza_kayip"]) for k, a in ab.items() if a.get("kayip_kapsam") == "modellendi"}
        satirlar = []
        for s in OLCEK_IZGARA:
            L = dict(L0)
            L["TR"] = L0["TR"] * s
            phi = sorted(L[i] / g for i in dv["kalibrasyon_aktorleri"] if i in L and L[i] > 0 and (g := cekim(i, L)) > 0)
            akt = {}
            for i in dv["dis_veri_aktorleri"]:
                r = led[i]
                g = cekim(i, L)
                kay, kb = g * phi[len(phi) // 2], g * (phi[-1] - phi[0]) / 2
                net = float(r["dis_toplam_vekili"]) - kay - float(r["surdurme_maliyeti"])
                bant = math.sqrt(float(r["net_bandi_kayip_haric"]) ** 2 + kb**2 + float(r["maliyet_belirsizligi"]) ** 2)
                akt[i] = {"net": round(net, 3), "bant": round(bant, 3), "sinif": _sinif(net, bant)}
            # sistem toplamı: dış-veri aktörleri ve TR yeniden hesaplanır, diğerleri (MFIN, Balkan, bölge) defterden aynen
            def _net(r: dict[str, Any]) -> float:
                return float(r.get("net_maliyetli", r.get("net_refah_entegre")) or 0.0)

            diger = sum(_net(r) for k, r in led.items() if k != "TR" and k not in akt)
            tr_net = _net(led["TR"]) + (1.0 - s) * L0["TR"]
            sistem = diger + tr_net + sum(a["net"] for a in akt.values())
            satirlar.append({"s": s, "phi": [round(p, 3) for p in phi], "aktorler": akt, "tr_net": round(tr_net, 3), "sistem_net_toplam": round(sistem, 3)})
        # TR hariç sistem etkisi: s=1'de ledger ile birebir olmalı (iç tutarlılık)
        out[sid] = satirlar
    return out


def calistir() -> dict[str, Any]:
    gz = gozlem()
    model = model_kayip(gz["gsyh_son_mn_usd"])
    ar = olcek_araliklari(model, gz)
    yy = yayilim()
    # sınıf kararlılığı: s ızgarasının tamamında aynı sınıfı koruyan aktörler
    kararli: dict[str, dict[str, bool]] = {}
    for sid, satirlar in yy.items():
        kararli[sid] = {i: len({r["aktorler"][i]["sinif"] for r in satirlar}) == 1 for i in satirlar[0]["aktorler"]}
    d = {
        "olcum": "tr_kayip_olcek_sinamasi",
        "etiket": "tani_girdi_degil",
        "gozlem": gz,
        "model_tr_kaybi": model,
        "gereken_olcek": ar,
        "yayilim": yy,
        "sinif_kararli_tum_olceklerde": kararli,
        "olcek_izgara": list(OLCEK_IZGARA),
        "not": "Gözlemlenebilir sınırlar karşı-olgusal kaybın gözlenemeyen kısmını sınamaz; yalnız ölçeğin üst sınırını verir.",
    }
    (OUT / "TR_OLCEK_SINAMA.json").write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    L = ["# TR kaybının ölçek sınaması (bağımsız gözlem)", "", d["not"], "",
         "## 1. Bağımsız gözlem (WDI, %d–%s)" % (int(gz["yillar"][0]), gz["yillar"][1]), "",
         "| Gösterge | Ort | Maks | Son |", "| --- | ---: | ---: | ---: |"]
    for k, ad in (("brut_birincil_gelir_odemesi_gsyh_yuzde", "Brüt birincil gelir ödemesi (% GSYH)"), ("net_birincil_gelir_odemesi_gsyh_yuzde", "Net birincil gelir ödemesi (% GSYH)"), ("cari_acik_gsyh_yuzde", "Cari açık (% GSYH)")):
        L.append(f"| {ad} | {gz[k]['ort']} | {gz[k]['maks']} | {gz[k]['son']} |")
    f = gz["kisi_basi_buyume_farki_tr_eksi_umc_pp"]
    L += [f"| Kişi başı büyüme, TR − üst-orta gelir grubu (pp/yıl) | {f['ort']} | {f['maks']} | min {f['min']} |", "",
          "## 2. Model TR kaybı (yıllık, % GSYH) ve üç USD köprüsü", "",
          "| Senaryo | Vekil | BoP köprüsü | Mal ticareti köprüsü | Rant köprüsü |", "| --- | ---: | ---: | ---: | ---: |"]
    for sid, r in model.items():
        L.append(f"| {sid} | {r['vekil']} | {r['bop_merkez_rant']['usd_mn']:,} mn $ (%{r['bop_merkez_rant']['gsyh_yuzde']}) | {r['mal_net_ticaret']['usd_mn']:,} (%{r['mal_net_ticaret']['gsyh_yuzde']}) | {r['tum_havza_rant']['usd_mn']:,} (%{r['tum_havza_rant']['gsyh_yuzde']}) |")
    L += ["", "## 3. Gözlemlenebilir sınıra inmek için gereken ölçek s (model TR kaybı × s = sınır; üç köprü arası aralık)", "",
          "| Senaryo | Brüt birincil gelir ödemesi | Net birincil gelir ödemesi | Cari açık |", "| --- | --- | --- | --- |"]
    for sid, r in ar.items():
        L.append(f"| {sid} | {r['brut_birincil_gelir_odemesi_ort']['s_min']} – {r['brut_birincil_gelir_odemesi_ort']['s_maks']} | {r['net_birincil_gelir_odemesi_ort']['s_min']} – {r['net_birincil_gelir_odemesi_ort']['s_maks']} | {r['cari_acik_ort']['s_min']} – {r['cari_acik_ort']['s_maks']} |")
    L += ["", "## 4. TR kaybı ölçeği s ile dış aktör sınıfları (φ her s'de yeniden kalibre)", ""]
    for sid, satirlar in yy.items():
        aktler = list(satirlar[0]["aktorler"])
        L += [f"### Senaryo {sid}", "", "| s | φ (min/med/maks) | TR net | Σ sistem | " + " | ".join(aktler) + " |", "| ---: | --- | ---: | ---: | " + " | ".join("---" for _ in aktler) + " |"]
        for r in satirlar:
            L.append(f"| {r['s']} | {r['phi'][0]}/{r['phi'][len(r['phi'])//2]}/{r['phi'][-1]} | {r['tr_net']:+.2f} | {r['sistem_net_toplam']:+.2f} | " + " | ".join(f"{r['aktorler'][i]['net']:+.2f} ({r['aktorler'][i]['sinif']})" for i in aktler) + " |")
        L.append("- Tüm ölçeklerde sınıfı değişmeyenler: " + ", ".join(i for i, v in kararli[sid].items() if v))
        L.append("")
    (OUT / "TR_OLCEK_SINAMA.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    return d


if __name__ == "__main__":
    calistir()
    print("TR_OLCEK_SINAMA ok")
