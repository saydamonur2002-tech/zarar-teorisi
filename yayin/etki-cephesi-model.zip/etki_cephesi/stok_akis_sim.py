"""Stok-akış (SFC) simülasyonu — etki cephesi kalibre akışları × zarar-teorisi L/G."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import numpy as np

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
KALIBRE = DATA / "kalibre"
OUT = REPO / "reports" / "etki_cephesi"
ZARAR_DIR = REPO / "_incoming" / "zarar-teorisi-main"

SEC = ["H", "F", "B", "K", "D"]
IDX = {s: i for i, s in enumerate(SEC)}

if str(ZARAR_DIR) not in sys.path:
    sys.path.insert(0, str(ZARAR_DIR))
from akis_model import simulate  # noqa: E402
from _kur import kur_matris_donemi  # noqa: E402


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _nested(doc: dict[str, Any], path: str) -> Any:
    cur: Any = doc
    for part in path.split("."):
        cur = cur[part]
    return cur


def _usd_mn_to_x(usd_mn: float, kur: float) -> float:
    """akis_model.simulate girdisi: bin TL (×1000 TL); 1e9 bin TL = 1 trilyon TL."""
    return usd_mn * kur * 1000.0


def _matrices(donem: str = "2026-Q1") -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    L = np.loadtxt(ZARAR_DIR / f"L_v2_{donem}.csv", delimiter=",", skiprows=1, usecols=range(1, 6))
    G = np.loadtxt(ZARAR_DIR / f"G_v2_{donem}.csv", delimiter=",", skiprows=1, usecols=range(1, 6))
    oz = _load(ZARAR_DIR / "akis_model_ozeti.json")
    nfp_t = oz["nfp_2026Q1_trilyonTL"]
    nfp = np.array([float(nfp_t[s]) * 1e9 for s in SEC])
    return L, G, nfp


def _shock_vec(
    usd_mn: float,
    kur: float,
    sektor: str,
    tur: str,
    pay: float = 1.0,
    gerceklesme: float = 1.0,
) -> np.ndarray:
    x = np.zeros(5)
    mag = _usd_mn_to_x(usd_mn, kur) * pay * gerceklesme
    if tur == "zarar":
        mag = -abs(mag)
    else:
        mag = abs(mag)
    x[IDX[sektor]] = mag
    return x


def _impact_dict(v: np.ndarray) -> dict[str, float]:
    return {s: round(float(v[i]) / 1e9, 3) for i, s in enumerate(SEC)}


def _stok_f4_yolu(yillar: list[int], oran: float, stok0: float, itis: float, ust_sinir: float) -> list[dict[str, Any]]:
    """F.4 stok yolu. `oran` bir VARSAYIM senaryosudur (silinen payı), ölçüm değil.

    Önceki sürüm `stok_silim_tavan` (0,2582: hazneler arası brüt çift düzeyinin ÜST SINIRI, F.4 stokuna ait
    değil) gerçekleşmiş silinme gibi uyguluyordu. Burada baz yol sabittir (silinen ölçülmedi); tavan yalnız
    `oran <= ust_sinir` tutarlılık kontrolüdür.
    """
    rows = []
    for i, y in enumerate(yillar):
        u = min(1.0, (i + 1) / len(yillar))
        sil = stok0 * oran * u
        rows.append(
            {
                "yil": y,
                "stok_f4_milyar": round(stok0 - sil, 1),
                "silinen_kumulatif_milyar": round(sil, 1),
                "yeni_itis_milyar": itis,
                "etiket": "varsayim" if oran > 0 else "olculmedi_sabit",
                "oran_varsayim": oran,
                "ust_sinir_icinde": oran <= ust_sinir,
            }
        )
    return rows


def calistir(senaryo_id: str = "C") -> dict[str, Any]:
    sid = senaryo_id
    kopru = _load(DATA / "stok_akis_kopru.json")
    capa = _load(KALIBRE / "gerceklik_capa.json")
    sim_cfg = kopru.get("simulate") or {}
    lam_cfg = sim_cfg.get("lambda") or {}
    lam = float(lam_cfg.get("varsayilan", 0.5))
    lam_bant = [float(v) for v in (lam_cfg.get("bant") or [0.25, 0.5, 0.75])]
    kappa = float(sim_cfg["kappa"])
    kur, kur_kaynak = kur_matris_donemi(ZARAR_DIR, str(kopru.get("matris_donem") or "2026-Q1"), float(capa["kur_tl_usd"]))

    modul = _load(OUT / "MODUL_KALIBRE.json") if (OUT / "MODUL_KALIBRE.json").is_file() else {}
    dis_path = OUT / f"DIS_RANT_PARASAL_{sid}.json"
    if not dis_path.is_file():
        dis_path = OUT / "DIS_RANT_PARASAL.json"
    dis = _load(dis_path) if dis_path.is_file() else {}
    yasam = _load(OUT / "YASAM_MALIYET_KATMAN.json") if (OUT / "YASAM_MALIYET_KATMAN.json").is_file() else {}
    ger_path = OUT / f"GERCEKLIK_KALIBRE_{sid}.json"
    if not ger_path.is_file() and sid == "C":
        ger_path = OUT / "GERCEKLIK_KALIBRE.json"
    ger = _load(ger_path) if ger_path.is_file() else {}

    sen_doc = _load(DATA / "senaryolar.json")
    sen = next((s for s in sen_doc.get("senaryolar") or [] if s.get("id") == sid), None)
    er = float((sen or {}).get("etki_erosyon_carpani") or 0.22)
    flex = float((sen or {}).get("tr_diplomatik_flex") or 0.0)
    pol = max(0.25, min(1.0, 1.05 - er + flex))
    docs = {
        "MODUL_KALIBRE.json": modul,
        "DIS_RANT_PARASAL.json": dis,
        "YASAM_MALIYET_KATMAN.json": yasam,
        "GERCEKLIK_KALIBRE.json": ger,
    }
    r_z = float(ger.get("gerceklesme_oranlari", {}).get("zarar_teorisi") or 0.7)
    r_y = float(yasam.get("gerceklesme") or 0.28)

    L, G, nfp = _matrices(str(kopru.get("matris_donem") or "2026-Q1"))

    pulslar: list[dict[str, Any]] = []
    x_kapali = np.zeros(5)  # SFC'ye giren darbeler (zarar/kâr; L-G ile yayılır)
    x_transfer = np.zeros(5)  # transferler: doğrudan NFP'ye yazılır, yayılmaz, toplamı sıfır
    x_dissal = np.zeros(5)  # karşı bacağı tanımsız; SFC kimliğine girmez
    x_eski_cift = np.zeros(5)  # yalnız kıyas: eski çift muamele (zarar F + D 'kâr')
    kapsam_disi_usd = 0.0
    for ad, spec in (kopru.get("akis_kaynaklari") or {}).items():
        rapor = str(spec["rapor"])
        doc = docs.get(rapor) or _load(OUT / rapor)
        usd = float(_nested(doc, spec["alan"]))
        g = float(spec.get("gerceklesme", 1.0))
        if spec.get("gerceklesme_kaynak"):
            src, fld = spec["gerceklesme_kaynak"].split(" → ")
            gdoc = docs.get(src.strip()) or _load(OUT / src.strip())
            if "gerceklesme_oranlari" in fld:
                key = fld.split(".")[-1]
                g = float(gdoc.get("gerceklesme_oranlari", {}).get(key) or r_z)
            else:
                g = float(gdoc.get(fld.strip()) or r_y)
        pay = float(spec.get("pay") or 1.0)
        if spec.get("mod") == "transfer":
            # F -A, D +A: toplam sıfır; L ile yayılmaz (kayıp değil, devir).
            xt = np.zeros(5)
            a_x = abs(_usd_mn_to_x(usd, kur) * pay * g)
            xt[IDX[spec["odeyen"]]] -= a_x
            xt[IDX[spec["alan_sektor"]]] += a_x
            x_transfer += xt
            x_eski_cift += _shock_vec(usd, kur, spec["sektor_baslangic"], "zarar", pay=float(spec.get("eski_pay", pay)), gerceklesme=g)
            kapsam_disi_usd += usd * (1.0 - pay) * g
            pulslar.append(
                {
                    "id": ad,
                    "usd_mn_girdi": round(usd * pay * g, 1),
                    "sektor_baslangic": spec["odeyen"],
                    "tur": "transfer",
                    "gerceklesme": g,
                    "sfc_dahil": True,
                    "x_trilyonTL": round(float(xt.sum()) / 1e9, 3),
                    "x_sektor_trilyonTL": _impact_dict(xt),
                    "sektor_etkisi_trilyonTL": _impact_dict(xt),
                }
            )
            continue
        x = _shock_vec(usd, kur, spec["sektor_baslangic"], spec["tur"], pay=pay, gerceklesme=g)
        if spec.get("devre_disi"):
            x_eski_cift += x
            pulslar.append(
                {
                    "id": ad,
                    "usd_mn_girdi": round(usd * pay * g, 1),
                    "sektor_baslangic": spec["sektor_baslangic"],
                    "tur": spec["tur"],
                    "gerceklesme": g,
                    "sfc_dahil": False,
                    "devre_disi": True,
                    "x_trilyonTL": round(float(x[IDX[spec["sektor_baslangic"]]]) / 1e9, 3),
                    "sektor_etkisi_trilyonTL": _impact_dict(simulate(L, G, nfp, x, lam=lam, kappa=kappa)),
                }
            )
            continue
        imp = simulate(L, G, nfp, x, lam=lam, kappa=kappa)
        dissal = bool(spec.get("dissal"))
        pulslar.append(
            {
                "id": ad,
                "usd_mn_girdi": round(usd * pay * g, 1),
                "sektor_baslangic": spec["sektor_baslangic"],
                "tur": spec["tur"],
                "gerceklesme": g,
                "sfc_dahil": not dissal,
                "x_trilyonTL": round(float(x[IDX[spec["sektor_baslangic"]]]) / 1e9, 3),
                "sektor_etkisi_trilyonTL": _impact_dict(imp),
            }
        )
        if dissal:
            x_dissal += x
        else:
            x_kapali += x

    imp_entegre = simulate(L, G, nfp, x_kapali, lam=lam, kappa=kappa) + x_transfer
    imp_eski = simulate(L, G, nfp, x_kapali + x_dissal + x_eski_cift, lam=lam, kappa=kappa)
    imp_eski_cift = simulate(L, G, nfp, x_eski_cift, lam=lam, kappa=kappa)
    x_kapali_top = float(x_kapali.sum() + x_transfer.sum()) / 1e9
    tol = 1e-3
    kapanis = {
        "x_kapali_toplam_trilyonTL": round(x_kapali_top, 3),
        "entegre_etki_toplam_trilyonTL": round(float(imp_entegre.sum()) / 1e9, 3),
        "acik_fark_trilyonTL": round(x_kapali_top, 3),
        "kapanis_ok": abs(x_kapali_top) <= tol,
        "not": (
            "Sıfır toplam kimliği (Σ NFP = 0) için SFC'ye giren darbelerin toplamı 0 olmalı. Fark ilan edilir, "
            "gizlenmez. Dış rant transfer olarak yazılır (F −A, D +A); tutarın geri kalanı kapsam dışıdır."
        ),
    }

    lambda_bandi = {
        str(lb): _impact_dict(simulate(L, G, nfp, x_kapali, lam=lb, kappa=kappa)) for lb in lam_bant
    }

    yillar = [int(r["yil"]) for r in yasam.get("yillik_seri") or []]
    if not yillar:
        yillar = list(range(2027, 2037))
    bes = kopru.get("bes_adim_stok") or {}
    stok0 = float(bes.get("stok_bas_milyar") or 25339.8)
    ust = float(bes.get("stok_silim_ust_sinir") or 0.2582)
    itis = float(bes.get("kredi_itis_milyar_yillik") or 0.0)
    oran = float(bes.get("silinen_oran_varsayilan", 0.0))
    stok_yolu = _stok_f4_yolu(yillar, oran, stok0, itis, ust)
    stok_bandi = {
        str(o): _stok_f4_yolu(yillar, float(o), stok0, itis, ust)[-1]
        for o in (bes.get("silinen_oran_senaryo") or [0.0, 0.1, 0.2])
    }

    yillik: list[dict[str, Any]] = []
    x_kum = np.zeros(5)  # dışsal (karşı bacaksız) kümülatif girdi: yalnız kıyas
    seri = yasam.get("yillik_seri") or []
    for i, y in enumerate(yillar):
        x_y = np.zeros(5)
        if seri and i < len(seri):
            h_usd = float(seri[i].get("hane_tasarruf_usd_mn") or 0)
            x_y += _shock_vec(h_usd, kur, "H", "kar", gerceklesme=1.0)
        if i == len(yillar) - 1:
            tas = float(
                (dis.get("ozet") or {}).get("tasarruf_refah_vs_zarar_usd_mn")
                or modul.get("rant_parasal_ozet", {}).get("tasarruf_refah_vs_zarar_usd_mn")
                or 0
            )
            x_y += _shock_vec(tas, kur, "F", "kar", gerceklesme=r_z * pol)
        x_kum += x_y
        imp_y = simulate(L, G, nfp, x_kum, lam=lam, kappa=kappa)
        yillik.append(
            {
                "yil": y,
                "stok_f4": stok_yolu[i] if i < len(stok_yolu) else None,
                "kumulatif_sektor_etkisi_trilyonTL": _impact_dict(np.zeros(5)),
                "kumulatif_dissal_dahil_eski_trilyonTL": _impact_dict(imp_y),
                "dissal_kumulatif_x_trilyonTL": round(float(x_kum.sum()) / 1e9, 3),
            }
        )

    return {
        "olcum": "stok_akis_simulasyon",
        "senaryo_id": sid,
        "senaryo_politika_carpan": round(pol, 3),
        "matris_donem": kopru.get("matris_donem"),
        "lambda_yayilim": lam,
        "lambda_etiket": "senaryo_parametresi (tanimlanamadi; zarar-teorisi OKU.txt). Bant altta.",
        "lambda_bandi_sektor_etkisi_trilyonTL": lambda_bandi,
        "kappa": kappa,
        "kur_tl_usd": kur,
        "kur_kaynak": kur_kaynak,
        "nfp_2026Q1_trilyonTL": _load(ZARAR_DIR / "akis_model_ozeti.json")["nfp_2026Q1_trilyonTL"],
        "pulslar": pulslar,
        "entegre_puls": {
            "x_trilyonTL_sektor": {s: round(float(x_kapali[i] + x_transfer[i]) / 1e9, 3) for i, s in enumerate(SEC)},
            "transfer_trilyonTL_sektor": {s: round(float(x_transfer[i]) / 1e9, 3) for i, s in enumerate(SEC)},
            "sektor_etkisi_trilyonTL": _impact_dict(imp_entegre),
            "kapanis": kapanis,
        },
        "cift_muamele": {
            "duzeltildi": True,
            "aciklama": (
                "Eski: F 'zararı' L ile yayılıp D'ye kayıp yazılıyordu (kayıp ≠ transfer) ve ayrıca 'D kârı' G ile "
                "yerli sektörlere dağıtılıyordu (D'de kalmıyordu). Yeni: dış rant F→D transferi, doğrudan NFP, toplam sıfır."
            ),
            "kapsam_disi_rant_usd_mn": round(kapsam_disi_usd, 1),
            "kapsam_disi_not": "Rant tutarının transfer payı dışında kalanı; pay %100 ise 0.",
            "eski_sektor_etkisi_trilyonTL": _impact_dict(imp_eski_cift),
            "yeni_sektor_etkisi_trilyonTL": _impact_dict(x_transfer),
        },
        "dissal_enjeksiyon": {
            "x_toplam_trilyonTL": round(float(x_dissal.sum()) / 1e9, 3),
            "pulslar": [p["id"] for p in pulslar if not p["sfc_dahil"] and not p.get("devre_disi")],
            "not": "Karşı bacağı tanımsız 'refah/tasarruf' girdileri. SFC'ye girmez: sıfır toplam kimliğini bozar.",
            "eski_davranis_sektor_etkisi_trilyonTL": _impact_dict(imp_eski),
            "eski_davranis_not": "Yalnız kıyas: dışsal girdiler dahil edilince tüm sektörler artıya geçer (para yaratımı).",
        },
        "yillik_stok_akis": yillik,
        "stok_f4_bandi_son_yil": stok_bandi,
        "bes_adim_kisit": bes,
        "kaynak": [
            "stok_akis_kopru.json",
            "MODUL_KALIBRE.json",
            "L_v2_2026-Q1.csv",
            "G_v2_2026-Q1.csv",
            "akis_model.simulate",
        ],
    }


def _md(d: dict[str, Any]) -> str:
    e = d["entegre_puls"]["sektor_etkisi_trilyonTL"]
    k = d["entegre_puls"]["kapanis"]
    lines = [
        "# Stok-akış simülasyonu (SFC × etki cephesi) — revize",
        "",
        f"Matris **{d['matris_donem']}** · λ={d['lambda_yayilim']} (**senaryo**, tanımsız) · κ={d['kappa']} · "
        f"kur **{d['kur_tl_usd']}** ({d['kur_kaynak']})",
        "",
        "## Entegre sektör etkisi (trilyon TL) — yalnız SFC'ye giren darbeler",
        "",
        "| Sektör | Δ (trilyon TL) |",
        "| --- | ---: |",
    ]
    for s in SEC:
        lines.append(f"| {s} | {e[s]:,.3f} |")
    lines.extend(
        [
            "",
            f"**Kapanış:** Σ darbe = {k['x_kapali_toplam_trilyonTL']} tr TL → "
            f"{'OK' if k['kapanis_ok'] else 'AÇIK FARK (ilan edildi)'}. {k['not']}",
            "",
            f"**Dış rant (F→D transfer):** " + ", ".join(
                f"{s}={d['cift_muamele']['yeni_sektor_etkisi_trilyonTL'][s]}" for s in SEC
            ) + f"; eski çift muamele: " + ", ".join(
                f"{s}={d['cift_muamele']['eski_sektor_etkisi_trilyonTL'][s]}" for s in SEC
            ) + f". Kapsam dışı rant: {d['cift_muamele']['kapsam_disi_rant_usd_mn']:,} mn USD.",
            "",
            f"**Dışsal enjeksiyon (SFC dışı):** {d['dissal_enjeksiyon']['x_toplam_trilyonTL']} tr TL. "
            f"{d['dissal_enjeksiyon']['not']}",
            "",
            "## λ bandı (sektör etkisi, tr TL)",
            "",
        ]
    )
    for lb, v in d["lambda_bandi_sektor_etkisi_trilyonTL"].items():
        lines.append(f"- λ={lb}: " + ", ".join(f"{s}={v[s]}" for s in SEC))
    lines.extend(["", "## Akış pulsları", ""])
    for p in d["pulslar"]:
        lines.append(
            f"- **{p['id']}** ({p['tur']}, {p['sektor_baslangic']}, "
            f"{'SFC' if p['sfc_dahil'] else ('devre dışı' if p.get('devre_disi') else 'dışsal')}): "
            f"{p['usd_mn_girdi']:,} mn USD → D dağılımı "
            f"H={p['sektor_etkisi_trilyonTL']['H']}, F={p['sektor_etkisi_trilyonTL']['F']}, "
            f"D={p['sektor_etkisi_trilyonTL']['D']}"
        )
    lines.extend(["", "## F.4 stok yolu — silinen ölçülmedi; oranlar varsayım bandıdır", ""])
    for row in d["yillik_stok_akis"]:
        st = row.get("stok_f4") or {}
        lines.append(f"- **{row['yil']}:** F.4 stok **{st.get('stok_f4_milyar', '—')}** milyar TL ({st.get('etiket')})")
    lines.extend(["", "Son yıl bandı:"])
    for o, r in d["stok_f4_bandi_son_yil"].items():
        lines.append(f"- silinen oran {o} (varsayım, ≤ üst sınır: {r['ust_sinir_icinde']}): {r['stok_f4_milyar']} milyar TL")
    lines.append("")
    return "\n".join(lines)


def calistir_coklu(senaryolar: tuple[str, ...] = ("A", "B", "C")) -> dict[str, Any]:
    OUT.mkdir(parents=True, exist_ok=True)
    satirlar: list[dict[str, Any]] = []
    for sid in senaryolar:
        data = calistir(sid)
        (OUT / f"STOK_AKIS_SIM_{sid}.json").write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        e = data["entegre_puls"]["sektor_etkisi_trilyonTL"]
        satirlar.append(
            {
                "id": sid,
                "politika_carpan": data.get("senaryo_politika_carpan"),
                "gerceklesme_zarar": data.get("pulslar", [{}])[0].get("gerceklesme") if data.get("pulslar") else None,
                "entegre_D_trilyonTL": e.get("D"),
                "entegre_F_trilyonTL": e.get("F"),
                "entegre_H_trilyonTL": e.get("H"),
            }
        )
    coklu = {"olcum": "stok_akis_sim_coklu", "senaryolar": satirlar}
    (OUT / "STOK_AKIS_SIM_COKLU.json").write_text(json.dumps(coklu, ensure_ascii=False, indent=2), encoding="utf-8")
    if "C" in senaryolar:
        c_data = _load(OUT / "STOK_AKIS_SIM_C.json") if (OUT / "STOK_AKIS_SIM_C.json").is_file() else calistir("C")
        (OUT / "STOK_AKIS_SIM.json").write_text(json.dumps(c_data, ensure_ascii=False, indent=2), encoding="utf-8")
        (OUT / "STOK_AKIS_SIM.md").write_text(_md(c_data), encoding="utf-8")
    return coklu


def main() -> None:
    calistir_coklu()
    print(f"Wrote {OUT / 'STOK_AKIS_SIM.md'} + STOK_AKIS_SIM_COKLU.json")


if __name__ == "__main__":
    main()
