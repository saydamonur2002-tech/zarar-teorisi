"""P3: A/B/C için 10y TR net yolu (senaryo kalibre yigin)."""
from __future__ import annotations

import json
import sys
from pathlib import Path
import _olasilik
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
KALIBRE = DATA / "kalibre"
OUT = REPO / "reports" / "etki_cephesi"

if str(REPO / "etki_cephesi") not in sys.path:
    sys.path.insert(0, str(REPO / "etki_cephesi"))

from senaryo_gerceklik_kalibre import kalibre_yigin_refah  # noqa: E402
from usd_kopru import tr_net_usd_coklu  # noqa: E402


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def hesapla(senaryolar: tuple[str, ...] = ("A", "B", "C")) -> dict[str, Any]:
    capa = _load(KALIBRE / "gerceklik_capa.json")
    proj = _load(OUT / "PROJEKSIYON.json")
    akis = _load(OUT / "AKIS_OLCUM.json")
    fin = _load(OUT / "FINANS_KATMAN.json")
    sen_doc = _load(DATA / "senaryolar.json")
    gsyh = float(_load(OUT / "GERCEKLIK_KALIBRE.json").get("gsyh_usd_mn") or 0)

    olas: dict[str, float] = {}
    for s in sen_doc.get("senaryolar") or []:
        olas[str(s["id"])] = _olasilik.vekil_s(s)
    s_olas = sum(olas.values()) or 1.0
    olas = {k: v / s_olas for k, v in olas.items()}

    paketler: list[dict[str, Any]] = []
    for sid in senaryolar:
        path = OUT / f"DIS_ULKE_REFAH_{sid}.json"
        if not path.is_file() and sid == "C":
            path = OUT / "DIS_ULKE_REFAH.json"
        refah = _load(path) if path.is_file() else None
        sen = next(s for s in sen_doc["senaryolar"] if s["id"] == sid)
        y = kalibre_yigin_refah(proj, refah, fin, capa, akis, senaryo=sen)
        kp = y["usd_kopruleri"]
        seri: list[dict[str, Any]] = []
        for row in y["yol_koridor"][:10]:
            tr = float(row["tr_net"])
            usd = tr_net_usd_coklu(tr, kp)
            seri.append(
                {
                    "yil": row["yil"],
                    "faz": row.get("faz"),
                    "tr_net": tr,
                    "gsyh_yuzde_orta": round(usd["geometrik_orta_mn"] / gsyh * 100, 3) if gsyh else None,
                }
            )
        paketler.append(
            {
                "id": sid,
                "olasilik": round(olas.get(sid, 0.0), 4),
                "tr_c_refah": y["tr_c_refah"],
                "yil_10_son": y["tr_net_yol_10_son"],
                "sifir_nokta": y["sifir_nokta_takvim"],
                "senaryo_pol_carpan": y.get("senaryo_pol_carpan"),
                "yillik_seri": seri,
            }
        )

    tr_exp = round(sum(p["olasilik"] * float(p["yil_10_son"]) for p in paketler), 3)
    return {
        "olcum": "zarar_10y_senaryo_coklu_p3",
        "senaryolar": paketler,
        "beklenti": {"beklenen_tr_net_yil_10": tr_exp},
        "kaynak": ["kalibre_yigin_refah + senaryo erosyon", "DIS_ULKE_REFAH_{A,B,C}.json"],
    }


def _md(d: dict[str, Any]) -> str:
    lines = [
        "# 10 yıl TR net — senaryo A/B/C (P3)",
        "",
        "| Senaryo | P | Taban | 10y son | Sıfır yıl |",
        "| --- | ---: | ---: | ---: | ---: |",
    ]
    for p in d["senaryolar"]:
        lines.append(
            f"| **{p['id']}** | {p['olasilik']} | {p['tr_c_refah']} | {p['yil_10_son']} | {p.get('sifir_nokta') or '—'} |"
        )
    lines.extend(["", f"**Beklenen 10y son:** {d['beklenti']['beklenen_tr_net_yil_10']} vekil", ""])
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    data = hesapla()
    (OUT / "ZARAR_10Y_SENARYO_COKLU.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "ZARAR_10Y_SENARYO_COKLU.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'ZARAR_10Y_SENARYO_COKLU.md'}")


if __name__ == "__main__":
    main()
