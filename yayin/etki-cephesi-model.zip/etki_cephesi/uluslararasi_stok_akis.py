"""Uluslararası stok-akış matrisi — Senaryo C, gerçeklik kalibre."""
from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
KALIBRE = DATA / "kalibre"
OUT = REPO / "reports" / "etki_cephesi"


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _defter_row(defter: dict[str, Any], iso: str) -> dict[str, Any]:
    for row in defter.get("ulke_defteri") or []:
        if row.get("ulke") == iso:
            return row
    return {}


def _balkan_eu_ayir(
    defter: dict[str, Any],
    stok_ham: dict[str, float],
    capa: dict[str, Any],
) -> dict[str, Any]:
    balkan = list(capa.get("balkan_aktörler") or [])
    pay = float(capa.get("eu_satir_balkan_kanal_pay") or 0.68)
    eu = _defter_row(defter, "EU")
    eu_net = float(stok_ham.get("EU") or 0.0)
    balkan_ind = sum(float(stok_ham.get(b) or 0.0) for b in balkan if b in stok_ham)
    eu_aktar = (
        float(eu.get("kanal_kazanc") or 0.0)
        + float(eu.get("ikame_kazanc") or 0.0)
        + float(eu.get("refah_rant") or 0.0)
    ) * pay
    eu_merkez = round(eu_net - eu_aktar, 3)
    balkan_grup = round(balkan_ind + eu_aktar, 3)
    return {
        "balkan_aktörler": balkan,
        "eu_satir_ham_vekil": round(eu_net, 3),
        "eu_merkez_vekil": eu_merkez,
        "balkan_grup_toplam_vekil": balkan_grup,
        "balkan_bireysel_toplam_vekil": round(balkan_ind, 3),
        "eu_den_balkana_aktarilan_vekil": round(eu_aktar, 3),
        "balkan_bireysel": {b: round(float(stok_ham.get(b) or 0.0), 3) for b in balkan if b in stok_ham},
    }


def _havza_akis_net(
    kenarlar: list[dict[str, Any]],
    meta_havza: str,
) -> tuple[float, float, float]:
    giris = cikis = 0.0
    for e in kenarlar:
        if e.get("tur") == "mfin_havza_denge":
            continue
        if e.get("hedef") == meta_havza:
            giris += float(e["vekil"])
        if e.get("kaynak") == meta_havza:
            cikis += float(e["vekil"])
    return giris, cikis, giris - cikis


def _yapisal_mfin_havza_kapanis(
    stok_ham: dict[str, float],
    stok: dict[str, dict[str, float]],
    kenarlar: list[dict[str, Any]],
    tol: float,
    usd_rant: float,
    capa: dict[str, Any],
) -> tuple[float, dict[str, Any]]:
    """HAVZA = clearing (stok = giriş−çıkış); MFIN = −Σ(diğer stoklar + HAVZA)."""
    meta_havza = str(capa.get("havza_meta_aktör") or "HAVZA")
    kenarlar[:] = [e for e in kenarlar if e.get("tur") != "mfin_havza_denge"]

    stok_ham.pop(meta_havza, None)
    stok.pop(meta_havza, None)

    onceki_net = sum(stok_ham.values())
    mfin_defter = float(stok_ham.get("MFIN") or 0.0)

    havza_g, havza_c, havza_stok = _havza_akis_net(kenarlar, meta_havza)
    sum_diger = sum(v for k, v in stok_ham.items() if k != "MFIN")
    mfin_stok = round(-(sum_diger + havza_stok), 4)
    duzeltme = round(mfin_stok - mfin_defter, 4)

    stok_ham["MFIN"] = mfin_stok
    stok_ham[meta_havza] = round(havza_stok, 4)
    stok["MFIN"] = {
        **(stok.get("MFIN") or {}),
        "net_vekil": mfin_stok,
        "net_usd_mn": round(mfin_stok * usd_rant, 1),
        "mfin_defter_vekil": round(mfin_defter, 3),
        "mfin_yapisal_duzeltme": duzeltme,
    }
    stok[meta_havza] = {
        "net_vekil": round(havza_stok, 3),
        "net_usd_mn": round(havza_stok * usd_rant, 1),
        "tur": "clearing_meta",
        "giris_vekil": round(havza_g, 3),
        "cikis_vekil": round(havza_c, 3),
        "not": "Defter satırı değil; akış neti = stok",
    }

    if abs(duzeltme) > 1e-9:
        if duzeltme > 0:
            kenarlar.append(
                {
                    "kaynak": "HAVZA",
                    "hedef": "MFIN",
                    "tur": "mfin_havza_denge",
                    "vekil": round(abs(duzeltme), 3),
                    "usd_mn": round(abs(duzeltme) * usd_rant, 1),
                    "not": "Yapısal kapanış — MFIN rezidü havuzu",
                }
            )
        else:
            kenarlar.append(
                {
                    "kaynak": "MFIN",
                    "hedef": "HAVZA",
                    "tur": "mfin_havza_denge",
                    "vekil": round(abs(duzeltme), 3),
                    "usd_mn": round(abs(duzeltme) * usd_rant, 1),
                    "not": "Yapısal kapanış — MFIN rezidü havuzu",
                }
            )

    net_yeni = sum(stok_ham.values())
    meta: dict[str, Any] = {
        "uygulandi": True,
        "yapisal_kural": capa.get("mfin_havza_yapisal_kural"),
        "onceki_net_toplam_vekil": round(onceki_net, 3),
        "sonraki_net_toplam_vekil": round(net_yeni, 3),
        "denge_vekil": duzeltme,
        "mfin_defter_vekil": round(mfin_defter, 3),
        "mfin_stok_vekil": mfin_stok,
        "havza_giris_vekil": round(havza_g, 3),
        "havza_cikis_vekil": round(havza_c, 3),
        "havza_stok_vekil": round(havza_stok, 3),
        "kapanis_ok": abs(net_yeni) <= tol,
    }
    return net_yeni, meta


def matris_olustur(
    defter: dict[str, Any] | None = None,
    rant: dict[str, Any] | None = None,
    ger: dict[str, Any] | None = None,
) -> dict[str, Any]:
    capa = _load(KALIBRE / "uluslararasi_stok_akis_capa.json")
    if defter is None:
        genis = OUT / "DIS_ULKE_REFAH_GENIS.json"
        defter = _load(genis if genis.is_file() else OUT / "DIS_ULKE_REFAH.json")
    rant = rant or _load(OUT / "DIS_RANT_PARASAL.json")
    ger = ger or _load(OUT / "GERCEKLIK_KALIBRE.json")

    usd_rant = float(rant.get("usd_per_vekil_rant_mn") or 5383.14)
    inv = float(capa["cicekler_usd_mn"]["yatirim_geliri_gideri"])
    refah_dis_usd = float(rant["ozet"]["refah_dis_usd_mn_toplam"])
    hedef_pay = float(capa["rant_inv_geliri_hedef_pay"])
    tavan_pay = float(capa["rant_inv_geliri_tavan_pay"])

    olcek_rant = 1.0
    pay = refah_dis_usd / inv if inv > 0 else 0.0
    if pay > tavan_pay and capa.get("kalibre_otomatik_olcek"):
        olcek_rant = tavan_pay / pay
    elif pay > hedef_pay * 1.15 and capa.get("kalibre_otomatik_olcek"):
        olcek_rant = hedef_pay / pay

    aktorler: list[str] = []
    stok_ham: dict[str, float] = {}
    stok: dict[str, dict[str, float]] = {}

    for row in defter.get("ulke_defteri") or []:
        iso = str(row["ulke"])
        aktorler.append(iso)
        nv = float(row.get("net_refah_entegre") or 0.0)
        stok_ham[iso] = nv
        olcek = olcek_rant if iso not in ("TR", "MFIN", "HAVZA") else 1.0
        stok[iso] = {
            "net_vekil": round(nv, 3),
            "net_usd_mn": round(nv * usd_rant * olcek, 1),
        }

    kenarlar: list[dict[str, Any]] = []

    for row in defter.get("ulke_defteri") or []:
        iso = str(row["ulke"])
        if iso == "TR":
            hk = float(row.get("havza_kayip") or 0.0)
            if hk > 0:
                kenarlar.append(
                    {
                        "kaynak": "TR",
                        "hedef": "HAVZA",
                        "tur": "havza_kayip",
                        "vekil": round(hk, 3),
                        "usd_mn": round(hk * usd_rant, 1),
                    }
                )
            ric = float(row.get("refah_rant") or 0.0)
            if ric > 0:
                kenarlar.append(
                    {
                        "kaynak": "HAVZA",
                        "hedef": "TR",
                        "tur": "refah_tr_ic",
                        "vekil": round(ric, 3),
                        "usd_mn": round(ric * usd_rant, 1),
                    }
                )
            continue
        rr = float(row.get("refah_rant") or 0.0) * olcek_rant
        if rr > 0:
            kenarlar.append(
                {
                    "kaynak": "HAVZA",
                    "hedef": iso,
                    "tur": "refah_rant_dis",
                    "vekil": round(rr, 3),
                    "usd_mn": round(rr * usd_rant, 1),
                }
            )
        kk = float(row.get("kanal_kazanc") or 0.0) + float(row.get("ikame_kazanc") or 0.0)
        if kk > 0:
            kenarlar.append(
                {
                    "kaynak": "HAVZA",
                    "hedef": iso,
                    "tur": "kanal_ikame",
                    "vekil": round(kk, 3),
                    "usd_mn": round(kk * usd_rant, 1),
                }
            )
        ms = float(row.get("merkez_sizinti") or 0.0) + float(row.get("merkez_belirsiz") or 0.0)
        if ms > 0:
            kenarlar.append(
                {
                    "kaynak": "HAVZA",
                    "hedef": iso,
                    "tur": "merkez_sizinti",
                    "vekil": round(ms, 3),
                    "usd_mn": round(ms * usd_rant, 1),
                }
            )
        hk = float(row.get("havza_kayip") or 0.0)
        if hk > 0:
            kenarlar.append(
                {
                    "kaynak": iso,
                    "hedef": "HAVZA",
                    "tur": "havza_kayip",
                    "vekil": round(hk, 3),
                    "usd_mn": round(hk * usd_rant, 1),
                }
            )

    meta_b = defter.get("balkan_eu_defter") or {}
    if meta_b.get("uygulandi"):
        for b, vekil in (meta_b.get("balkan_dagilim_vekil") or {}).items():
            v = float(vekil or 0.0)
            if v > 1e-6:
                kenarlar.append(
                    {
                        "kaynak": "EU",
                        "hedef": str(b),
                        "tur": "balkan_eu_aktarim",
                        "vekil": round(v, 3),
                        "usd_mn": round(v * usd_rant, 1),
                        "not": "Defter EU→Balkan aktarımı (matris kenarı)",
                    }
                )

    balkan_ayrim = _balkan_eu_ayir(defter, stok_ham, capa)

    tol = float(capa["stok_kapanis_tolerans_vekil"])
    mfin_denge_meta: dict[str, Any] = {"uygulandi": False}
    net_toplam = sum(stok_ham.values())

    if capa.get("mfin_havza_denge_aktif"):
        net_toplam, mfin_denge_meta = _yapisal_mfin_havza_kapanis(
            stok_ham, stok, kenarlar, tol, usd_rant, capa
        )
        kapanis_ok = bool(mfin_denge_meta.get("kapanis_ok"))
    else:
        kapanis_ok = abs(net_toplam) <= tol

    if not kapanis_ok and capa.get("kalibre_otomatik_olcek"):
        faktor = 1.0 - min(0.12, max(0.0, abs(net_toplam) - tol) / (abs(net_toplam) + 1e-6))
        for iso in list(stok.keys()):
            if iso in ("TR", "MFIN"):
                continue
            if stok_ham.get(iso, 0) > 0:
                stok_ham[iso] *= faktor
                stok[iso]["net_vekil"] = round(stok_ham[iso], 3)
                stok[iso]["net_usd_mn"] = round(stok_ham[iso] * usd_rant, 1)
                stok[iso]["kalibre_olcek"] = round(faktor, 4)
        net_toplam = sum(stok_ham.values())
        if capa.get("mfin_havza_denge_aktif"):
            net_toplam, mfin_denge_meta = _yapisal_mfin_havza_kapanis(
                stok_ham, stok, kenarlar, tol, usd_rant, capa
            )
        kapanis_ok = abs(net_toplam) <= tol * 1.2

    hucre = (rant.get("ulke_rant_kanal") or {}).get("hucre_top120") or []
    kanal_usd_top = sum(float(h.get("refah_dis_usd_mn") or 0) for h in hucre) * olcek_rant

    meta_havza = str(capa.get("havza_meta_aktör") or "HAVZA")
    havza_brut_g, havza_brut_c, _ = _havza_akis_net(
        [e for e in kenarlar if e.get("tur") != "mfin_havza_denge"], meta_havza
    )
    havza_kayip_brut = sum(
        float(e["usd_mn"]) for e in kenarlar if e.get("tur") == "havza_kayip"
    )
    havza_stok_usd = float((stok.get(meta_havza) or {}).get("net_usd_mn") or 0.0)

    tur_top: dict[str, float] = defaultdict(float)
    for k in kenarlar:
        tur_top[k["tur"]] += float(k["usd_mn"])
    if "havza_kayip" in tur_top:
        tur_top["havza_kayip_brut_kenar"] = tur_top.pop("havza_kayip")
        tur_top["havza_net_stok"] = havza_stok_usd

    tr_net_k = float(ger.get("tr_net_kalibre_son") or -9.7)

    return {
        "olcum": "uluslararasi_stok_akis_matrisi",
        "senaryo": defter.get("senaryo", "C"),
        "rant_modeli": defter.get("rant_modeli"),
        "kalibrasyon": {
            "rant_inv_geliri_pay_ham": round(pay, 4),
            "hedef_pay": hedef_pay,
            "olcek_rant_dis": round(olcek_rant, 4),
            "refah_dis_usd_kalibre_mn": round(refah_dis_usd * olcek_rant, 1),
            "stok_net_toplam_vekil": round(net_toplam, 3),
            "kapanis_tolerans_vekil": tol,
            "kapanis_ok": kapanis_ok,
            "mfin_havza_denge": mfin_denge_meta,
            "tr_net_kalibre_vekil": tr_net_k,
            "tr_net_gsyh_yuzde_orta": ger.get("gsyh_yuzde_son"),
        },
        "balkan_eu_ayrım": balkan_ayrim,
        "aktörler": aktorler,
        "stok": stok,
        "akis_kenarlari": kenarlar,
        "havza_rapor": {
            "meta_aktör": meta_havza,
            "giris_vekil": round(havza_brut_g, 3),
            "cikis_vekil": round(havza_brut_c, 3),
            "stok_vekil": round(havza_brut_g - havza_brut_c, 3),
            "kayip_kenar_brut_usd_mn": round(havza_kayip_brut, 1),
            "not": "Brüt havza_kayip kenar USD stokla toplanmaz; stok = giriş−çıkış neti",
        },
        "akis_tur_toplam_usd_mn": dict(sorted(tur_top.items(), key=lambda x: -x[1])),
        "kanal_rant_usd_kontrol_mn": round(kanal_usd_top, 1),
        "kaynak": [
            "DIS_ULKE_REFAH.json",
            "DIS_RANT_PARASAL.json",
            "GERCEKLIK_KALIBRE.json",
            "kalibre/uluslararasi_stok_akis_capa.json",
        ],
    }


def _md(d: dict[str, Any]) -> str:
    k = d["kalibrasyon"]
    b = d.get("balkan_eu_ayrım") or {}
    m = k.get("mfin_havza_denge") or {}
    lines = [
        "# Uluslararası stok-akış matrisi (kalibre)",
        "",
        f"Senaryo **{d['senaryo']}** · {d['rant_modeli']} · rant/inv geliri payı "
        f"**{k['rant_inv_geliri_pay_ham']:.3f}** → ölçek **{k['olcek_rant_dis']}**",
        "",
        f"- Refah dış (kalibre): **{k['refah_dis_usd_kalibre_mn']:,}** mn $",
        f"- Stok kapanış (Σ net vekil): **{k['stok_net_toplam_vekil']}** · "
        f"{'**OK**' if k['kapanis_ok'] else 'zayıf'}",
    ]
    h = d.get("havza_rapor") or {}
    if h:
        lines.append(
            f"- **HAVZA (clearing):** giriş **{h.get('giris_vekil')}** · çıkış **{h.get('cikis_vekil')}** · "
            f"stok **{h.get('stok_vekil')}** vekil (brüt kayıp kenar USD: {h.get('kayip_kenar_brut_usd_mn'):,} mn — stokla toplanmaz)"
        )
    if m.get("uygulandi"):
        lines.append(
            f"- **MFIN yapısal:** defter **{m.get('mfin_defter_vekil')}** → stok **{m.get('mfin_stok_vekil')}** "
            f"(Σ net **{m.get('sonraki_net_toplam_vekil')}**)"
        )
    lines.extend(
        [
            "",
            "## Balkan / EU ayrımı",
            "",
            f"- EU satır (ham): **{b.get('eu_satir_ham_vekil')}** vekil → **EU merkez (Balkan hariç): {b.get('eu_merkez_vekil')}**",
            f"- Balkan grup toplam: **{b.get('balkan_grup_toplam_vekil')}** vekil "
            f"(bireysel {b.get('balkan_bireysel_toplam_vekil')} + EU'dan aktarım {b.get('eu_den_balkana_aktarilan_vekil')})",
            "",
        ]
    )
    for iso, val in (b.get("balkan_bireysel") or {}).items():
        lines.append(f"  - **{iso}:** {val} vekil")
    lines.extend(["", "## Akış türleri (mn USD/yıl vekili)", ""])
    for tur, val in d["akis_tur_toplam_usd_mn"].items():
        lines.append(f"- **{tur}:** {val:,}")
    lines.extend(["", "## Stok (seçili)", ""])
    for iso in ("TR", "MFIN", "HAVZA", "IMF", "WB", "EUINST", "EU", "IR", "CN", "RS", "BA", "BG"):
        if iso in d["stok"]:
            s = d["stok"][iso]
            lines.append(f"- **{iso}:** {s['net_vekil']} vekil · {s['net_usd_mn']:,} mn $")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    data = matris_olustur()
    (OUT / "ULUSLARARASI_STOK_AKIS.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "ULUSLARARASI_STOK_AKIS.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'ULUSLARARASI_STOK_AKIS.md'}")


if __name__ == "__main__":
    main()
