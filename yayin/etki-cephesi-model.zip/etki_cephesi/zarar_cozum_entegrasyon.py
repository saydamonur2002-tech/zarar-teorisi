"""Zarar teorisi (GitHub) çözüm varsayımı + etki cephesi referans senaryosu."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"
ZARAR_DIR = REPO / "_incoming" / "zarar-teorisi-main"


def _load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _senaryo(doc: dict[str, Any], sid: str) -> dict[str, Any]:
    for s in doc.get("senaryolar") or []:
        if s.get("id") == sid:
            return s
    raise KeyError(sid)


def _tr_birlesik(sen: dict[str, Any]) -> dict[str, Any] | None:
    for a in sen.get("aktör_birlesik") or []:
        if a.get("aktor") == "TR":
            return a
    return None


def _uygula(sen: dict[str, Any], kopru: dict[str, Any]) -> dict[str, Any]:
    c = kopru["etki_cephesi_carpanlari"]
    ic = float(c["ic_dongu_kazanim"])
    fin = float(c["finans_halka_agirlik_payi"])
    d_m = float(c["merkez_sizinti_duyarlilik"])
    d_b = float(c["bosalma_duyarlilik"])
    d_r = float(c["rant_duyarlilik"])
    tr_g = float(c["tr_ic_geri_kazanim_payi"])

    bos = float(sen["turkiye_yaricevre_bosalma"])
    merkez = float(sen["merkez_finans_sizinti_toplam"])
    rant = float(sen["tum_havza_rant_cikis_toplam"])
    mfin = float(sen.get("merkez_mfin_kenar_toplam") or 0.0)
    merkez_rant = float(sen["merkez_artı_rant_cikis_toplam"])

    merkez_y = round(merkez * (1.0 - ic * d_m), 3)
    mfin_y = round(mfin * (1.0 - ic * d_m * 0.92), 3)
    bos_y = round(bos * (1.0 - ic * fin * d_b), 3)
    rant_y = round(rant * (1.0 - ic * d_r), 3)
    mr_y = round(merkez_y + rant_y, 3)

    tr_row = _tr_birlesik(sen) or {}
    havza_k = float(tr_row.get("havza_kayip") or 0.0)
    ic_geri = round(bos * ic * tr_g, 3)
    havza_y = round(havza_k * (1.0 - ic * d_b * 0.85), 3)
    tr_net_y = round(-havza_y + ic_geri, 3)

    return {
        "senaryo_etki_cephesi": sen["id"],
        "cozum_varsayimi": kopru.get("cozum_varsayimi"),
        "github": kopru.get("github"),
        "bes_adim": kopru.get("bes_adim_kanit"),
        "ham": {
            "turkiye_yaricevre_bosalma": bos,
            "merkez_finans_sizinti_toplam": merkez,
            "merkez_mfin_kenar": mfin,
            "tum_havza_rant_cikis_toplam": rant,
            "merkez_artı_rant_cikis_toplam": merkez_rant,
            "tr_havza_kayip": havza_k,
            "tr_net_birlesik_vekil": float(tr_row.get("net_birlesik_vekil") or 0.0),
        },
        "zarar_cozum_sonrasi": {
            "turkiye_yaricevre_bosalma": bos_y,
            "merkez_finans_sizinti_toplam": merkez_y,
            "merkez_mfin_kenar": mfin_y,
            "tum_havza_rant_cikis_toplam": rant_y,
            "merkez_artı_rant_cikis_toplam": mr_y,
            "tr_ic_geri_kazanim_vekili": ic_geri,
            "tr_havza_kayip": havza_y,
            "tr_net_birlesik_vekil": tr_net_y,
        },
        "fark": {
            "bosalma": round(bos_y - bos, 3),
            "merkez": round(merkez_y - merkez, 3),
            "tr_net": round(tr_net_y - float(tr_row.get("net_birlesik_vekil") or 0.0), 3),
        },
        "formul_not": (
            f"ic_dongu={ic:.4f}; merkez×(1−ic×{d_m}); "
            f"boşalma×(1−ic×fin×{d_b}); rant×(1−ic×{d_r}); "
            f"TR iç geri +{tr_g}×ic×boşalma, havza×(1−ic×{d_b}×0.85)"
        ),
    }


def _md(res: dict[str, Any]) -> str:
    h = res["ham"]
    z = res["zarar_cozum_sonrasi"]
    f = res["fark"]
    gh = res["github"]
    ba = res["bes_adim"]
    sid = res["senaryo_etki_cephesi"]
    lines = [
        "# Zarar teorisi × etki cephesi (çözüm varsayımı)",
        "",
        f"**GitHub:** [{gh['repo']}]({gh['repo']}) (`{gh['on_kayit']}`) — beş adım koşusu **{ba['kosu']}**, "
        f"kredi ihtiyacı **{ba['kredi_ihtiyaci_milyar']}**, tavan **{ba['eski_tavan']}→{ba['yeni_tavan']}**.",
        "",
        f"**Etki cephesi taban:** Senaryo **{sid}**.",
        "",
        f"*{res['formul_not']}*",
        "",
        f"| Gösterge | {sid} (ham) | {sid} + zarar çözümü | Δ |",
        "| --- | ---: | ---: | ---: |",
        f"| TR boşalma | {h['turkiye_yaricevre_bosalma']} | {z['turkiye_yaricevre_bosalma']} | {f['bosalma']} |",
        f"| Merkez sızıntı | {h['merkez_finans_sizinti_toplam']} | {z['merkez_finans_sizinti_toplam']} | {f['merkez']} |",
        f"| MFIN kenar | {h['merkez_mfin_kenar']} | {z['merkez_mfin_kenar']} | {round(z['merkez_mfin_kenar']-h['merkez_mfin_kenar'],3)} |",
        f"| Rant Σ | {h['tum_havza_rant_cikis_toplam']} | {z['tum_havza_rant_cikis_toplam']} | {round(z['tum_havza_rant_cikis_toplam']-h['tum_havza_rant_cikis_toplam'],3)} |",
        f"| Merkez+rant | {h['merkez_artı_rant_cikis_toplam']} | {z['merkez_artı_rant_cikis_toplam']} | "
        f"{round(z['merkez_artı_rant_cikis_toplam']-h['merkez_artı_rant_cikis_toplam'],3)} |",
        f"| TR havza kaybı | {h['tr_havza_kayip']} | {z['tr_havza_kayip']} | {round(z['tr_havza_kayip']-h['tr_havza_kayip'],3)} |",
        f"| TR iç geri kazanım (vekili) | — | {z['tr_ic_geri_kazanim_vekili']} | — |",
        f"| TR net birleşik vekil | {h['tr_net_birlesik_vekil']} | {z['tr_net_birlesik_vekil']} | {f['tr_net']} |",
        "",
        "## Yorum",
        "",
        "- **Zarar teorisi** tarafında çözüm = stok eşleşme tavanı genişler, **yeni kredi itişi 0** (adım 3).",
        "- **Etki cephesi** tarafında bu, finans/rant sızıntısını kısar ve TR'ye **iç döngü geri kazanım** satırı ekler; "
        "dış aktörler hâlâ kazanır ama **MFIN/CN payı görece düşer**.",
        "- Bu birleşik koşu **kanıt A/B değil**; SFC beş adım etiketi `temiz` + kullanıcı varsayımı.",
        "",
    ]
    return "\n".join(lines)


def calistir(senaryolar: tuple[str, ...] = ("A", "B", "C")) -> dict[str, Any]:
    kopru = _load(DATA / "zarar_teorisi_kopru.json")
    proj = _load(OUT / "PROJEKSIYON.json")
    bes_path = ZARAR_DIR / "bes_adim_sonuc.json"
    bes_canli: dict[str, Any] | None = None
    if bes_path.is_file():
        bes = _load(bes_path)
        bes_canli = {
            "adim3_kredi_ihtiyaci": (bes.get("adimlar") or {}).get("3", {}).get("kredi_ihtiyaci"),
            "adim1_yeni_tavan": (bes.get("adimlar") or {}).get("1", {}).get("yeni_tavan"),
            "kosu": bes.get("kosu"),
        }

    OUT.mkdir(parents=True, exist_ok=True)
    satirlar: list[dict[str, Any]] = []
    for sid in senaryolar:
        sen = _senaryo(proj, sid)
        res = _uygula(sen, kopru)
        if bes_canli:
            res["bes_adim_canli"] = bes_canli
        path = OUT / f"ZARAR_COZUM_{sid}.json"
        path.write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
        z = res["zarar_cozum_sonrasi"]
        satirlar.append(
            {
                "id": sid,
                "tr_net_ham": float(res["ham"]["tr_net_birlesik_vekil"]),
                "tr_net_zarar_cozum": float(z["tr_net_birlesik_vekil"]),
            }
        )

    for sid in senaryolar:  # her senaryo için aynı md (C ayrıcalığı yok)
        (OUT / f"ZARAR_COZUM_{sid}.md").write_text(_md(_load(OUT / f"ZARAR_COZUM_{sid}.json")), encoding="utf-8")

    coklu = {
        "olcum": "zarar_cozum_senaryo_coklu",
        "senaryolar": satirlar,
        "referans": "C",
    }
    (OUT / "ZARAR_COZUM_COKLU.json").write_text(
        json.dumps(coklu, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return coklu


def main() -> None:
    calistir()
    print(f"Wrote {OUT / 'ZARAR_COZUM_COKLU.json'}")


if __name__ == "__main__":
    main()
