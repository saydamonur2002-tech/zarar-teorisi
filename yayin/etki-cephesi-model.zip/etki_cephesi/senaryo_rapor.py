"""Senaryo raporları: A, B, C için AYNI bölümler, AYNI alanlar (referans senaryo ayrıcalığı yok).

Çıktı: `SENARYO_RAPOR_{A,B,C}.md` (aynı iskelet) ve `SENARYO_KARSILASTIRMA.md` (yan yana).
Girdi: senaryo başına JSON'lar (PROJEKSIYON, AKIS_OLCUM_{s}, ZARAR_COZUM_{s}, URETIM_IC_AKIS_{s}, FINANS_KATMAN_{s},
STOK_AKIS_SIM_{s}, GERCEKLIK_KALIBRE_{s}, DIS_RANT_PARASAL_{s}, ULUSLARARASI_STOK_AKIS_{s}) + `_olasilik.vekil()`.
Eksik alan "—" yazılır: bilinmiyor sıfır değildir. Bu rapor başka modüle girdi olmaz (döngü yok).

Yapısal asimetri notu (rapor sonunda da yazılı): üretim/finans katmanları A ve B için C tabanlı ölçeklenir
(`politika_C_bazli`, `merkez_sizinti_C_bazli`); yani A/B bu katmanlarda bağımsız modellenmiş değildir.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import _olasilik

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"
SENARYOLAR = ("A", "B", "C")


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8")) if p.is_file() else {}


def _g(d: Any, yol: str) -> Any:
    for k in yol.split("."):
        if isinstance(d, dict) and k in d:
            d = d[k]
        else:
            return None
    return d


def _f(v: Any) -> str:
    if v is None:
        return "—"
    if isinstance(v, bool):
        return "evet" if v else "hayır"
    if isinstance(v, float):
        return f"{v:,.3f}".rstrip("0").rstrip(".") if abs(v) < 1e4 else f"{v:,.1f}"
    return str(v)


def _satirlar(sid: str) -> list[tuple[str, list[tuple[str, Any]]]]:
    sen_doc = _load(DATA / "senaryolar.json")
    sen = next(s for s in sen_doc["senaryolar"] if s["id"] == sid)
    proj = _load(OUT / "PROJEKSIYON.json")
    p = next((s for s in proj.get("senaryolar", []) if s["id"] == sid), {})
    akis = _load(OUT / f"AKIS_OLCUM_{sid}.json")
    zc = _load(OUT / f"ZARAR_COZUM_{sid}.json")
    ui = _load(OUT / f"URETIM_IC_AKIS_{sid}.json")
    fk = _load(OUT / f"FINANS_KATMAN_{sid}.json")
    ss = _load(OUT / f"STOK_AKIS_SIM_{sid}.json")
    gk = _load(OUT / f"GERCEKLIK_KALIBRE_{sid}.json")
    dr = _load(OUT / f"DIS_RANT_PARASAL_{sid}.json")
    us = _load(OUT / f"ULUSLARARASI_STOK_AKIS_{sid}.json")
    bm = sen.get("bag_modu", {})
    ent = ss.get("entegre_puls", {})
    sek = ent.get("sektor_etkisi_trilyonTL", {})
    return [
        ("1. Tanım (senaryo parametreleri)", [
            ("Ad", sen.get("ad")),
            ("Olasılık (kapı iskeleti, gözlem yokken tekdüze)", round(_olasilik.vekil()[sid], 4)),
            ("Etki erozyonu çarpanı", sen.get("etki_erosyon_carpani")),
            ("TR diplomatik esneklik", sen.get("tr_diplomatik_flex")),
            ("Merkez sızıntı çarpanı", sen.get("merkez_sizinti_carpan")),
            ("Bağ modu kullanım / atıl / araçsal", f"{bm.get('kullanim')} / {bm.get('atil')} / {bm.get('aracsal')}"),
        ]),
        ("2. Projeksiyon (10 yıl vekil)", [
            ("TR yarıçevre boşalma", p.get("turkiye_yaricevre_bosalma")),
            ("Merkez finans sızıntı Σ", p.get("merkez_finans_sizinti_toplam")),
            ("MFIN kenar Σ", p.get("merkez_mfin_kenar_toplam")),
            ("Tüm havza rant Σ", p.get("tum_havza_rant_cikis_toplam")),
            ("Merkez + rant Σ", p.get("merkez_artı_rant_cikis_toplam")),
            ("Pasif boşluk Σ", p.get("pasif_bosluk_toplam")),
            ("Araçsallaşma Σ", p.get("aracsallasma_toplam")),
            ("Temsil zedesi Σ", p.get("mesruiyet_temsil_zedesi_toplam")),
            ("Dış mimari Σ", p.get("dis_hegemon_mimari_toplam")),
            ("İç dinamik tıkanma", p.get("ic_dinamik_tikanma")),
        ]),
        ("3. Akış ölçümü (USD köprüsü, mn $)", [
            ("MFIN kenar", _g(akis, "modelden_usd_vekili.mfin_kenar_usd_mn")),
            ("Belirsiz merkez", _g(akis, "modelden_usd_vekili.merkez_belirsiz_usd_mn")),
            ("Merkez toplam", _g(akis, "modelden_usd_vekili.merkez_toplam_usd_mn")),
            ("Rant toplam", _g(akis, "modelden_usd_vekili.rant_toplam_usd_mn")),
        ]),
        ("4. Zarar çözümü (beş adım varsayımı)", [
            ("TR net ham", _g(zc, "ham.tr_net_birlesik_vekil")),
            ("TR net çözüm sonrası", _g(zc, "zarar_cozum_sonrasi.tr_net_birlesik_vekil")),
            ("TR net farkı", _g(zc, "fark.tr_net")),
            ("TR boşalma ham → sonrası", f"{_f(_g(zc, 'ham.turkiye_yaricevre_bosalma'))} → {_f(_g(zc, 'zarar_cozum_sonrasi.turkiye_yaricevre_bosalma'))}"),
        ]),
        ("5. Üretim iç akışı ve finans katmanı", [
            ("Üretim iç akış TR net", _g(ui, "uretim_ic_akis_tam.tr_net_birlesik_vekil")),
            ("Üretim: sıfır yılı tahmini", _g(ui, "sifir_nokta_tahmini.takvim_yil_sifir_veya_ustu")),
            ("Finans katmanı TR net", _g(fk, "finans_katman_tam.tr_net_birlesik_vekil")),
            ("Finans: sıfır üstü takvim yılı", _g(fk, "sifir_nokta.takvim_yil_sifir_ustu")),
            ("Finans etiketi", fk.get("etiket")),
        ]),
        ("6. Stok-akış (SFC, tr TL)", [
            ("Matris dönemi / kur", f"{_f(ss.get('matris_donem'))} / {_f(ss.get('kur_tl_usd'))}"),
            ("H", sek.get("H")), ("F", sek.get("F")), ("B", sek.get("B")), ("K", sek.get("K")), ("D", sek.get("D")),
            ("Kapanış (Σ=0)", _g(ent, "kapanis.kapanis_ok")),
            ("F.4 stok 2036, baz (mr TL)", (ss.get("stok_f4_bandi_son_yil", {}).get("0.0") or {}).get("stok_f4_milyar")),
            ("F.4 stok 2036, silme %20 varsayımı", (ss.get("stok_f4_bandi_son_yil", {}).get("0.2") or {}).get("stok_f4_milyar")),
        ]),
        ("7. Gerçeklik kalibrasyonu", [
            ("TR net son (kalibre)", gk.get("tr_net_kalibre_son")),
            ("GSYH %", gk.get("gsyh_yuzde_son")),
            ("TR net 10. yıl yolu", gk.get("tr_net_yol_10_son")),
            ("Gerçekleşme: zarar / üretim / finans", " / ".join(_f(_g(gk, f"gerceklesme_oranlari.{k}")) for k in ("zarar_teorisi", "uretim_ic_akis", "finans_katman"))),
        ]),
        ("8. Dış rant parasal akışı", [
            ("Boşluk rantı toplam (vekil)", _g(dr, "ozet.zarar_bosluk_toplam_vekil")),
            ("Refah dış toplam (vekil)", _g(dr, "ozet.refah_dis_toplam_vekil")),
            ("Refah TR iç toplam (vekil)", _g(dr, "ozet.refah_tr_ic_toplam_vekil")),
            ("Boşluk rantı (mn $)", _g(dr, "ozet.zarar_usd_mn_toplam")),
            ("Refah dış (mn $)", _g(dr, "ozet.refah_dis_usd_mn_toplam")),
        ]),
        ("9. Uluslararası stok-akış", [
            ("Kapanış tamam", _g(us, "kalibrasyon.kapanis_ok")),
            ("Havza net stok (mn $)", _g(us, "akis_tur_toplam_usd_mn.havza_net_stok")),
            ("Havza kayıp brüt kenar (mn $)", _g(us, "akis_tur_toplam_usd_mn.havza_kayip_brut_kenar")),
            ("Merkez sızıntı (mn $)", _g(us, "akis_tur_toplam_usd_mn.merkez_sizinti")),
            ("Kanal ikame (mn $)", _g(us, "akis_tur_toplam_usd_mn.kanal_ikame")),
        ]),
    ]


NOT = (
    "**Yapısal sınır (A, B, C için aynı):** üretim iç akışı ve finans katmanı A ve B için C tabanından ölçeklenir "
    "(`politika_C_bazli`, `merkez_sizinti_C_bazli`). Bu bölümlerde A/B bağımsız modellenmemiştir; fark çarpandan gelir. "
    "F.4 stok yolu (bölüm 6) beş adımın kredi itişinden gelir ve senaryodan bağımsızdır; üç sütunda aynı olması senaryo farkı değil model yapısıdır. "
    "Olasılık ölçülmemiştir (gözlem yokken tekdüze); bu rapor senaryolar arasında sıra kurmaz."
)


def _md(sid: str) -> str:
    L = [f"# Senaryo {sid} — ayrıntılı rapor", "", "Üç senaryo (A, B, C) için aynı bölümler ve alanlar. Referans etiketi ayrıcalık değildir.", ""]
    for baslik, rows in _satirlar(sid):
        L += [f"## {baslik}", "", "| Alan | Değer |", "| --- | ---: |"]
        L += [f"| {a} | {_f(v)} |" for a, v in rows]
        L.append("")
    L += ["## Ülke ve aktör ayrıntısı", "", f"- `ULKE_KAYIP_{sid}.md`, `DIS_AKTOR_{sid}.md`, `AKIS_OLCUM_{sid}.md`, `ZARAR_COZUM_{sid}.md`", "", "## Not", "", NOT, ""]
    return "\n".join(L)


def _karsilastirma() -> str:
    tum = {s: _satirlar(s) for s in SENARYOLAR}
    L = ["# Senaryo karşılaştırması (A | B | C)", "", "Aynı alanlar, aynı sıra. Her sütun ilgili `SENARYO_RAPOR_{X}.md` ile birebir.", ""]
    for i, (baslik, rows) in enumerate(tum["A"]):
        L += [f"## {baslik}", "", "| Alan | A | B | C |", "| --- | ---: | ---: | ---: |"]
        for j, (alan, _) in enumerate(rows):
            L.append(f"| {alan} | " + " | ".join(_f(tum[s][i][1][j][1]) for s in SENARYOLAR) + " |")
        L.append("")
    L += ["## Not", "", NOT, ""]
    return "\n".join(L)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    for sid in SENARYOLAR:
        (OUT / f"SENARYO_RAPOR_{sid}.md").write_text(_md(sid), encoding="utf-8")
    (OUT / "SENARYO_KARSILASTIRMA.md").write_text(_karsilastirma(), encoding="utf-8")
    print(f"Wrote SENARYO_RAPOR_{{A,B,C}}.md + SENARYO_KARSILASTIRMA.md")


if __name__ == "__main__":
    main()
