"""Göreceli konum, direnç alternatifi (seçenek 1) ve gerçek-kayıp kırılma oranı (seçenek 2). Tanı raporu: başka modüle girdi olmaz (döngü yok).

1) Göreceli konum: "herkes batarken en geç batan" kazanan sayılabilir mi? Mutlak sınıf (net ± bant) ile göreceli sıra ayrı verilir.
   Göreceli kazanan = mutlak net < 0 (bant dışı kaybeden DEĞİL ayrımı yapılmaz) ama kaybeden aktörlerin medyanından, ortak bantla,
   ayırt edilebilir derecede iyi olan aktör. Bant kısmi-kapsam proxy'si olduğundan ayırt edilebilirlik zayıftır; bunu raporda belirtir.
   Yerel iç elit katmanı modelde YOK (aktörler ülke düzeyinde): elit sorusu burada ölçülmez, yalnız ülke düzeyindeki sınırı verilir.
2) Seçenek 1 (alternatif direnç): rant kaybı − net kazanç > 1000 mn $. Ana skor değişmez; alternatif yalnız burada raporlanır.
3) Seçenek 2: kaybı modelde olmayan kazananlar için net'i sıfıra getiren kayıp/kazanç oranı r0 = 1 − maliyet/kazanç ve referans oranlarla karşılaştırma.
"""
from __future__ import annotations

import json
import statistics as st
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "etki_cephesi"
ESIK_DIRENC_USD = 1000.0
AGIRLIK_DIRENC = 12.0  # senaryo_uygulanabilirlik ile aynı; skor = 0,65 skor_c + 0,35 skor_bek, ikisinde de direnç x12 -> skora 12 x delta


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def goreceli(sid: str) -> dict[str, Any]:
    d = _load(OUT / f"DIS_ULKE_REFAH_{sid}.json")
    rows = [r for r in d["ulke_defteri"] if r["ulke"] not in ("TR", "MFIN")]
    net = {r["ulke"]: float(r.get("net_maliyetli", r.get("net_refah_entegre")) or 0.0) for r in rows}
    # Kısmi kapsamlı aktörlerde bant ölçülmedi: bolge_stok_akis ile aynı vekil (tam kapsamlıların kayıp-hariç bant medyanı).
    tam = sorted(
        float(r.get("net_bandi_kayip_haric") or 0.0)
        for r in d["ulke_defteri"]
        if r.get("bant_kapsami") == "tam" and r["ulke"] not in ("TR", "MFIN") and float(r.get("net_bandi_kayip_haric") or 0.0) > 0
    )
    vekil = tam[len(tam) // 2] if tam else 0.0
    bant = {
        r["ulke"]: max(float(r.get("net_bandi") or 0.0), vekil) if r.get("bant_kapsami") == "kismi" else float(r.get("net_bandi") or 0.0)
        for r in rows
    }
    kaybeden = sorted([u for u in net if net[u] < 0], key=lambda u: -net[u])
    med = st.median(net[u] for u in kaybeden) if kaybeden else 0.0
    bmed = st.median(bant[u] for u in kaybeden) if kaybeden else 0.0
    sira = []
    for u in kaybeden:
        fark = net[u] - med
        ortak = (bant[u] ** 2 + bmed**2) ** 0.5
        sira.append(
            {
                "ulke": u,
                "net": round(net[u], 3),
                "kayip_medyanina_gore": round(fark, 3),
                "ortak_bant": round(ortak, 3),
                "ayirt_edilebilir_iyi": bool(fark - ortak > 0),
                "mutlak_sinif": "kaybeden" if net[u] + bant[u] < 0 else "bant_ici",
            }
        )
    mf = next(r for r in d["ulke_defteri"] if r["ulke"] == "MFIN")
    toplam_kayip = sum(net[u] for u in kaybeden)
    kazanan_toplam = sum(v for v in net.values() if v > 0)
    return {
        "id": sid,
        "kaybeden_sayisi": len(kaybeden),
        "kaybeden_medyan_net": round(med, 3),
        "en_gec_batan": sira[:5],
        "en_cok_batan": list(reversed(sira[-3:])),
        "ayirt_edilebilir_goreceli_kazanan": [x["ulke"] for x in sira if x["ayirt_edilebilir_iyi"]],
        "mutlak_kaybeden_bant_disi": [x["ulke"] for x in sira if x["mutlak_sinif"] == "kaybeden"],
        "kaybeden_net_toplam": round(toplam_kayip, 3),
        "diger_kazanan_net_toplam": round(kazanan_toplam, 3),
        "mfin_net": round(float(mf.get("net_maliyetli") or 0.0), 3),
        "mfin_net_kaybeden_toplaminin_kati": round(float(mf.get("net_maliyetli") or 0.0) / abs(toplam_kayip), 3) if toplam_kayip else None,
    }


def direnc_alternatif() -> dict[str, Any]:
    b = _load(OUT / "BOLGE_STOK_AKIS.json")
    usd_per = None
    satir = []
    for a in b["aktorler"]:
        if a["ulke"] == "TR":
            continue
        fark = a.get("rant_kanal_bosluk_fark_usd_mn")
        if fark is None or fark <= 0:
            continue
        net_usd = float(a.get("net_refah_entegre_usd_mn") or 0.0)
        satir.append(
            {
                "ulke": a["ulke"],
                "rant_kaybi_usd_mn": fark,
                "net_kazanc_usd_mn": net_usd,
                "ana_tanim_direnc": bool(fark > ESIK_DIRENC_USD),
                "alternatif_direnc": bool(fark - max(net_usd, 0.0) > ESIK_DIRENC_USD),
            }
        )
    ana = sum(1 for s in satir if s["ana_tanim_direnc"])
    alt = sum(1 for s in satir if s["alternatif_direnc"])
    sk_ana, sk_alt = max(0.0, 1 - ana / 8.0), max(0.0, 1 - alt / 8.0)
    u = _load(OUT / "SENARYO_UYGULANABILIRLIK.json")
    return {
        "satirlar": sorted(satir, key=lambda s: -s["rant_kaybi_usd_mn"]),
        "ana_direnc_sayisi": ana,
        "alternatif_direnc_sayisi": alt,
        "direnc_skor_ana": round(sk_ana, 3),
        "direnc_skor_alternatif": round(sk_alt, 3),
        "skor_ana": u["skor_0_100"],
        "skor_alternatif": round(u["skor_0_100"] + AGIRLIK_DIRENC * (sk_alt - sk_ana), 1),
        "not": "Alternatif yalnız tanı: net kazancı yüksek aktör rant kaybını telafi ettiği için direnç sayılmaz. Ana skor değişmedi.",
    }


def kirilma_orani() -> dict[str, Any]:
    out = {}
    bs = _load(OUT / "BANT_SINAMA.json")
    ssen = bs["senaryolar"] if isinstance(bs["senaryolar"], list) else list(bs["senaryolar"].values())
    for sid in ("A", "B", "C"):
        d = _load(OUT / f"DIS_ULKE_REFAH_{sid}.json")
        sen = next(s for s in ssen if s["id"] == sid)
        ref = sen.get("kayip_orani_referans_aktorler") or {}
        satir = {}
        for r in d["ulke_defteri"]:
            iso = r["ulke"]
            if iso not in ("CN", "RU", "US", "EU"):
                continue
            g = float(r.get("net_refah_entegre") or 0.0) + float(r.get("havza_kayip") or 0.0)
            c = float(r.get("surdurme_maliyeti") or 0.0)
            if g <= 0:
                continue
            r0 = 1.0 - c / g
            r_bant = 1.0 - (c + float(r.get("net_bandi") or 0.0)) / g
            satir[iso] = {
                "kazanc": round(g, 3),
                "maliyet": round(c, 3),
                "r_net_sifir": round(r0, 3),
                "r_bant_dis_kazanan_sinir": round(r_bant, 3),
                "uygulanan_referans_oran": round(float(r.get("havza_kayip_referans") or 0.0) / g, 3),
            }
        out[sid] = {"referans_oranlar": ref, "aktorler": satir}
    return out


BUYUK = ("TR", "MFIN", "CN", "RU", "US", "EU", "AE", "SA", "FR", "GR", "IR", "IL", "EG")
OLAY_PAYI = 0.02  # "ortalığı karıştıran" düşük olasılıklı olay için kullanıcı varsayımı (tanımsız olay; yalnız etki üst sınırı)


def sistem_tani() -> dict[str, Any]:
    """Kayıplar doğruysa iki açıklama ayrışsın diye: (a) sistem toplamı negatif mi (kilitlenme/ölü ağırlık), (b) tüm büyük aktörlerin
    birlikte daha iyi olduğu bir senaryo var mı (varsa kimse oraya geçmiyor = koordinasyon/kilit; yoksa kayıp yapısal çıkar çatışması).
    Ayrım yalnız ölçülür; 'yönetim becerisiz' ancak bir aktörün kendi seçimiyle daha iyi bir sonuca ulaşabildiği durumda söylenebilir ve bu modelde seçim yok."""
    net: dict[str, dict[str, float]] = {}
    for sid in ("A", "B", "C"):
        d = _load(OUT / f"DIS_ULKE_REFAH_{sid}.json")
        net[sid] = {r["ulke"]: float(r.get("net_maliyetli", r.get("net_refah_entegre")) or 0.0) for r in d["ulke_defteri"]}
    toplam = {sid: round(sum(v.values()), 3) for sid, v in net.items()}
    pozitif = {sid: round(sum(x for x in v.values() if x > 0), 3) for sid, v in net.items()}
    negatif = {sid: round(sum(x for x in v.values() if x < 0), 3) for sid, v in net.items()}
    buyuk = {sid: {u: round(net[sid][u], 3) for u in BUYUK if u in net[sid]} for sid in net}
    en_iyi = {u: max(net, key=lambda sid: net[sid][u]) for u in BUYUK if all(u in net[sid] for sid in net)}
    baskin = [
        sid for sid in net
        if all(net[sid][u] >= max(net[x][u] for x in net) - 1e-9 for u in BUYUK if all(u in net[x] for x in net))
    ]
    tr = [net[sid]["TR"] for sid in net]
    return {
        "sistem_net_toplam": toplam,
        "pozitif_net_toplam": pozitif,
        "negatif_net_toplam": negatif,
        "buyuk_aktor_net": buyuk,
        "aktor_en_iyi_senaryo": en_iyi,
        "tum_buyuk_aktorlerin_ortak_en_iyi_senaryosu": baskin,
        "olay_payi": OLAY_PAYI,
        "olay_etkisi_tr_net_ust_sinir": round(OLAY_PAYI * (max(tr) - min(tr)), 3),
        "not": "Net toplamı kapalı sistemde sıfır olmaz: kazançlar V'den, kayıplar vekil ve maliyet ayrı kaynaktan; toplam, ölü ağırlık/dışlanan kaybın işareti.",
    }


def calistir() -> dict[str, Any]:
    d = {
        "olcum": "goreceli_konum_direnc_alternatif_kirilma",
        "etiket": "tani_girdi_degil",
        "goreceli": {s: goreceli(s) for s in ("A", "B", "C")},
        "sistem_tani": sistem_tani(),
        "direnc_alternatif_C": direnc_alternatif(),
        "kirilma_orani": kirilma_orani(),
        "not": "Yerel iç elit katmanı modelde yok; ülke düzeyi. Elit sorusu ölçülmez, ancak mutlak/göreceli ayrımı ülke düzeyinde verilir.",
    }
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "GORECELI_KONUM.json").write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    L = ["# Göreceli konum, direnç alternatifi ve kırılma oranı", "", d["not"], ""]
    L.append("## 1. Göreceli konum: herkes batarken en geç batan")
    for s in ("A", "B", "C"):
        g = d["goreceli"][s]
        L += [
            "",
            f"### Senaryo {s}",
            f"- Net kaybeden aktör: {g['kaybeden_sayisi']} · kaybeden medyan net {g['kaybeden_medyan_net']:+.3f}",
            f"- Σ kaybeden net {g['kaybeden_net_toplam']:+.2f} · Σ diğer kazanan net {g['diger_kazanan_net_toplam']:+.2f} · MFIN net {g['mfin_net']:+.2f} (kaybedenlerin |toplamının| {g['mfin_net_kaybeden_toplaminin_kati']} katı)",
            f"- Mutlak olarak bant dışı kaybeden: {', '.join(g['mutlak_kaybeden_bant_disi']) or '—'}",
            f"- Göreceli kazanan (kayıp medyanından ayırt edilebilir iyi): {', '.join(g['ayirt_edilebilir_goreceli_kazanan']) or 'yok (ayırt edilemiyor)'}",
            "",
            "| En geç batan | Net | Medyana göre | Ortak bant | Ayırt edilebilir | Mutlak sınıf |",
            "| --- | ---: | ---: | ---: | --- | --- |",
        ]
        for x in g["en_gec_batan"]:
            L.append(f"| {x['ulke']} | {x['net']:+.3f} | {x['kayip_medyanina_gore']:+.3f} | {x['ortak_bant']:.3f} | {'evet' if x['ayirt_edilebilir_iyi'] else 'hayır'} | {x['mutlak_sinif']} |")
        L.append("- En çok batan: " + ", ".join(f"{x['ulke']} {x['net']:+.2f}" for x in g["en_cok_batan"]))
    a = d["direnc_alternatif_C"]
    L += ["", "## 2. Seçenek 1: alternatif direnç (rant kaybı − net kazanç)", "",
          f"Ana tanım {a['ana_direnc_sayisi']} aktör (bileşen {a['direnc_skor_ana']}), alternatif {a['alternatif_direnc_sayisi']} aktör (bileşen {a['direnc_skor_alternatif']}). Skor {a['skor_ana']} → {a['skor_alternatif']} (yalnız tanı).", "",
          "| Aktör | Rant kaybı mn $ | Net kazanç mn $ | Ana | Alternatif |", "| --- | ---: | ---: | --- | --- |"]
    for s in a["satirlar"]:
        L.append(f"| {s['ulke']} | {s['rant_kaybi_usd_mn']:,.0f} | {s['net_kazanc_usd_mn']:,.0f} | {'evet' if s['ana_tanim_direnc'] else '—'} | {'evet' if s['alternatif_direnc'] else '—'} |")
    L += ["", "## 3. Seçenek 2: gerçek kayıp için kırılma oranı", "",
          "Kayıp/kazanç oranı r. r_net_sıfır: net 0'a ininceye kadar katlanılabilir oran; r_bant: kazanan sınıfını koruyan üst oran. Referans oranlar Mısır/İran/İsrail kayıplarından.", "",
          "| Senaryo | Aktör | Kazanç | Maliyet | r_net_sıfır | r_bant | Uygulanan oran |", "| --- | --- | ---: | ---: | ---: | ---: | ---: |"]
    for sid, v in d["kirilma_orani"].items():
        for iso, x in v["aktorler"].items():
            L.append(f"| {sid} | {iso} | {x['kazanc']:.2f} | {x['maliyet']:.2f} | {x['r_net_sifir']:.2f} | {x['r_bant_dis_kazanan_sinir']:.2f} | {x['uygulanan_referans_oran']:.2f} |")
    st_ = d["sistem_tani"]
    L += ["", "## 4. Kayıplar doğruysa: sistem kilidi mi, aktör becerisizliği mi?", "",
          "| Senaryo | Σ net (tüm aktörler) | Σ pozitif | Σ negatif |", "| --- | ---: | ---: | ---: |"]
    for sid in ("A", "B", "C"):
        L.append(f"| {sid} | {st_['sistem_net_toplam'][sid]:+.2f} | {st_['pozitif_net_toplam'][sid]:+.2f} | {st_['negatif_net_toplam'][sid]:+.2f} |")
    L += ["", "Büyük aktörlerin net'i (maliyetli, kayıp vekilli):", "", "| Aktör | A | B | C | En iyi |", "| --- | ---: | ---: | ---: | --- |"]
    for u, en in st_["aktor_en_iyi_senaryo"].items():
        L.append(f"| {u} | {st_['buyuk_aktor_net']['A'][u]:+.2f} | {st_['buyuk_aktor_net']['B'][u]:+.2f} | {st_['buyuk_aktor_net']['C'][u]:+.2f} | {en} |")
    ort = st_["tum_buyuk_aktorlerin_ortak_en_iyi_senaryosu"]
    L += ["", f"Tüm büyük aktörlerin birlikte en iyi olduğu senaryo: {', '.join(ort) if ort else 'yok'}.",
          f"%{int(st_['olay_payi']*100)} olasılıklı, tanımsız bir olayın TR net'i üzerindeki etkisi en fazla ≈ {st_['olay_etkisi_tr_net_ust_sinir']:+.2f} (olay en kötü senaryoya çevirse bile).", "", st_["not"]]
    (OUT / "GORECELI_KONUM.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    return d


if __name__ == "__main__":
    calistir()
    print("GORECELI_KONUM ok")
