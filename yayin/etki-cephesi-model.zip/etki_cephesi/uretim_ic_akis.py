"""Üretime bağlı iç akış + halka düzeltmesi + rant artı değeri (C+zarar üstü)."""
from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"
PROJ = OUT / "PROJEKSIYON.json"
ZCOZ = OUT / "ZARAR_COZUM_C.json"
KOPRU = DATA / "uretim_ic_akis_kopru.json"


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _halka_toplam(proj: dict[str, Any], sid: str) -> dict[str, float]:
    sen = next(s for s in proj["senaryolar"] if s["id"] == sid)
    tot: dict[str, float] = defaultdict(float)
    for row in sen.get("tr_bosalma_detay") or []:
        for h in row.get("bes_halka") or []:
            tot[str(h["halka"])] += float(h["delta_endeks"])
    return dict(tot)


def _bosalma_oran(proj: dict[str, Any], sid: str, carpan: dict[str, float]) -> float:
    raw = _halka_toplam(proj, sid)
    eski = sum(raw.values())
    yeni = sum(raw.get(k, 0.0) * float(carpan.get(k, 1.0)) for k in raw)
    if eski <= 0:
        return 1.0
    return yeni / eski


def _koridor_sifir(y0: int, y1: int, bas: float, hedef: float, tam_yil: float) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for y in range(y0, y1 + 1):
        t = y - y0
        u = min(1.0, t / tam_yil) if tam_yil > 0 else 1.0
        orta = bas + (hedef - bas) * u
        rows.append({"yil": y, "tr_net_orta": round(orta, 3), "olgunluk": round(u, 3)})
    return rows


def _sifir_yili_extrap(tr_net0: float, tr_net1: float, y0: int, tam_yil: float) -> int | None:
    if tr_net1 >= 0:
        return y0 + int(round(tam_yil * (0 - tr_net0) / (tr_net1 - tr_net0))) if tr_net1 != tr_net0 else y0
    if tr_net1 <= tr_net0:
        return None
    slope = (tr_net1 - tr_net0) / tam_yil
    return int(round(y0 + tam_yil + (-tr_net1) / slope))


def hesapla(senaryo_id: str = "C") -> dict[str, Any]:
    proj = _load(PROJ)
    sid = senaryo_id
    zpath = OUT / f"ZARAR_COZUM_{sid}.json"
    if not zpath.is_file():
        zpath = ZCOZ
    zcoz = _load(zpath) if zpath.is_file() else {}
    kopru = _load(KOPRU)

    z = zcoz.get("zarar_cozum_sonrasi") or {}
    bos0 = float(z.get("turkiye_yaricevre_bosalma") or 0.0)
    rant0 = float(z.get("tum_havza_rant_cikis_toplam") or 0.0)
    merkez0 = float(z.get("merkez_finans_sizinti_toplam") or 0.0)
    havza0 = float(z.get("tr_havza_kayip") or 0.0)
    tr_net0 = float(z.get("tr_net_birlesik_vekil") or 0.0)
    ic_geri0 = float(z.get("tr_ic_geri_kazanim_vekili") or 0.0)

    carpan = kopru["halka_duzeltme_carpan"]
    oran = _bosalma_oran(proj, sid, carpan)
    halka_raw = _halka_toplam(proj, sid)

    bos1 = round(bos0 * oran, 3)
    rant_pay = float(kopru["rant_tr_arti_deger_payi"])
    rant_cikis1 = round(rant0 * (1.0 - rant_pay * 0.85), 3)
    rant_tr_arti = round(rant0 * rant_pay, 3)
    merkez1 = round(merkez0 * (0.55 + 0.45 * oran), 3)

    u_es = float(kopru["uretim_akis_eslesme"])
    gsyh_d = float(kopru["gsyh_ic_talep_uretim_kopukluk_duzeltme"])
    havza1 = round(havza0 * oran * (1.0 - u_es * 0.55), 3)
    ic_uretim = round(bos0 * u_es * 0.16, 3)
    ic_gsyh = round(bos0 * gsyh_d * 0.12, 3)
    ic_geri1 = round(ic_geri0 + ic_uretim + ic_gsyh, 3)

    tr_net1 = round(-havza1 + ic_geri1 + rant_tr_arti * 0.92, 3)

    tam = float(kopru.get("tam_olgunluk_yil") or 12)
    y0 = 2026
    koridor = _koridor_sifir(y0, y0 + 25, tr_net0, tr_net1, tam)
    sifir = _sifir_yili_extrap(tr_net0, tr_net1, y0, tam)

    return {
        "olcum": "uretim_ic_akis_ve_halka_duzeltme",
        "taban": kopru.get("taban"),
        "senaryo_etki_cephesi": sid,
        "halka_toplam_ham": {k: round(v, 3) for k, v in halka_raw.items()},
        "halka_toplam_ham_C": {k: round(v, 3) for k, v in halka_raw.items()},
        "bosalma_oran_halka_duzeltme": round(oran, 4),
        "C_zarar_cozum": {
            "turkiye_yaricevre_bosalma": bos0,
            "tr_net_birlesik_vekil": tr_net0,
            "tum_havza_rant_cikis_toplam": rant0,
            "merkez_finans_sizinti_toplam": merkez0,
        },
        "uretim_ic_akis_tam": {
            "turkiye_yaricevre_bosalma": bos1,
            "tum_havza_rant_cikis_toplam": rant_cikis1,
            "rant_tr_arti_deger_vekili": rant_tr_arti,
            "merkez_finans_sizinti_toplam": merkez1,
            "tr_havza_kayip": havza1,
            "tr_ic_geri_kazanim_vekili": ic_geri1,
            "tr_net_birlesik_vekil": tr_net1,
        },
        "fark_tr_net": round(tr_net1 - tr_net0, 3),
        "mantik": [
            "Beş halka: finans/dış kısıt/zarar aktarımı deltasını düşür; üretim bağımlılığı kanalını üretime bağlı akışla kapat.",
            "Rant: disari_cikis yerine rant_tr_arti_deger_payi TR artı değer satırı.",
            "GSYH vekili: iç talep–üretim kopukluğu düzeltmesi ic_gsyh; uretim_akis_eslesme ic_uretim.",
        ],
        "sifir_nokta_tahmini": {
            "tr_net_hedef_tam_olgunluk": tr_net1,
            "tam_olgunluk_yil_vekili": tam,
            "takvim_yil_sifir_veya_ustu": sifir,
            "not": (
                "Tam olgunlukta net hâlâ negatifse sıfır yılı, aynı eğimin devamı varsayımıdır."
                if tr_net1 < 0
                else "Tam olgunlukta net ≥ 0."
            ),
        },
        "yillik_tr_net_orta": koridor[:15],
        "kaynak": ["PROJEKSIYON.json", f"ZARAR_COZUM_{sid}.json", "uretim_ic_akis_kopru.json"],
    }


def _md(d: dict[str, Any]) -> str:
    z = d["C_zarar_cozum"]
    u = d["uretim_ic_akis_tam"]
    s = d["sifir_nokta_tahmini"]
    lines = [
        "# Üretime bağlı akış — halka düzeltmesi + rant artı değer",
        "",
        "Taban: **C + zarar-teorisi**; üst katman: çevre halkalarının üretime bağlanması, "
        "GSYH’deki iç-talep/üretim kopukluğu vekili, rantın TR artı değeri.",
        "",
        "## Halka toplamı (C ham delta)",
        "",
    ]
    for k, v in d["halka_toplam_ham_C"].items():
        lines.append(f"- `{k}`: {v}")
    lines.extend(
        [
            "",
            f"**Boşalma oranı (düzeltme sonrası):** {d['bosalma_oran_halka_duzeltme']}",
            "",
            "| | C+zarar | + üretim/iç akış |",
            "| --- | ---: | ---: |",
            f"| TR net vekil | {z['tr_net_birlesik_vekil']} | **{u['tr_net_birlesik_vekil']}** |",
            f"| TR boşalma | {z['turkiye_yaricevre_bosalma']} | {u['turkiye_yaricevre_bosalma']} |",
            f"| Rant çıkış | {z['tum_havza_rant_cikis_toplam']} | {u['tum_havza_rant_cikis_toplam']} |",
            f"| Rant TR artı | — | {u['rant_tr_arti_deger_vekili']} |",
            f"| Merkez sızıntı | {z['merkez_finans_sizinti_toplam']} | {u['merkez_finans_sizinti_toplam']} |",
            "",
            f"**TR net iyileşme:** {d['fark_tr_net']} vekil",
            "",
            "## Sıfır noktası (TR net ≥ 0)",
            "",
            f"- Tam olgunluk vekili: **{s['tam_olgunluk_yil_vekili']} yıl**",
            f"- Tam katman sonrası net: **{s['tr_net_hedef_tam_olgunluk']}**",
            f"- Tahmini takvim yılı (orta yol): **{s['takvim_yil_sifir_veya_ustu'] or '—'}**",
            f"- {s['not']}",
            "",
        ]
    )
    return "\n".join(lines)


def calistir(senaryolar: tuple[str, ...] = ("A", "B", "C")) -> dict[str, Any]:
    OUT.mkdir(parents=True, exist_ok=True)
    satirlar: list[dict[str, Any]] = []
    for sid in senaryolar:
        data = hesapla(sid)
        (OUT / f"URETIM_IC_AKIS_{sid}.json").write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        u = data["uretim_ic_akis_tam"]
        satirlar.append({"id": sid, "tr_net_uretim": float(u["tr_net_birlesik_vekil"])})
    if "C" in senaryolar:
        c_data = hesapla("C")
        (OUT / "URETIM_IC_AKIS.json").write_text(
            json.dumps(c_data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        (OUT / "URETIM_IC_AKIS.md").write_text(_md(c_data), encoding="utf-8")
    return {"olcum": "uretim_ic_akis_coklu", "senaryolar": satirlar}


def main() -> None:
    calistir()
    print(f"Wrote {OUT / 'URETIM_IC_AKIS.md'}")


if __name__ == "__main__":
    main()
