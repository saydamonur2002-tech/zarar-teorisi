"""10 yıl vekil: senaryo eşikleri + zarar çözümü düzelme koridoru."""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "etki_cephesi"
PROJ = OUT / "PROJEKSIYON.json"
ZCOZ = OUT / "ZARAR_COZUM_C.json"


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _tr_net(proj: dict[str, Any], sid: str) -> float:
    sen = next(s for s in proj["senaryolar"] if s["id"] == sid)
    for a in sen.get("aktör_birlesik") or []:
        if a.get("aktor") == "TR":
            return float(a["net_birlesik_vekil"])
    return -float(sen["turkiye_yaricevre_bosalma"])


def _bosalma(proj: dict[str, Any], sid: str) -> float:
    sen = next(s for s in proj["senaryolar"] if s["id"] == sid)
    return float(sen["turkiye_yaricevre_bosalma"])


def _koridor(
    y0: int,
    y1: int,
    c_net: float,
    cz_net: float,
    a_net: float,
    tam_yil: float = 7.0,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for y in range(y0, y1 + 1):
        t = y - y0
        u = min(1.0, t / tam_yil)
        u_yavas = min(1.0, t / (tam_yil * 1.35))
        u_hizli = min(1.0, t / (tam_yil * 0.85))
        orta = c_net + (cz_net - c_net) * u
        alt = c_net + (cz_net - c_net) * u_yavas * 0.9
        ust = c_net + (a_net - c_net) * (1.0 - u) * 0.25
        if ust < orta:
            ust = orta + abs(c_net - cz_net) * 0.15 * (1.0 - u)
        rows.append(
            {
                "yil": y,
                "tr_net_orta": round(orta, 3),
                "tr_net_alt": round(min(alt, orta), 3),
                "tr_net_ust": round(max(ust, orta), 3),
                "cozum_olgunluk": round(u, 3),
            }
        )
    return rows


def hesapla() -> dict[str, Any]:
    proj = _load(PROJ)
    zcoz = _load(ZCOZ) if ZCOZ.is_file() else {}
    ham = zcoz.get("ham") or {}
    coz = zcoz.get("zarar_cozum_sonrasi") or {}

    b_net = _tr_net(proj, "B")
    a_net = _tr_net(proj, "A")
    c_net = float(coz.get("tr_net_birlesik_vekil") or _tr_net(proj, "C"))
    cz_net = float(coz.get("tr_net_birlesik_vekil") or c_net)
    if zcoz:
        c_net = float(ham.get("tr_net_birlesik_vekil") or c_net)
        cz_net = float(coz.get("tr_net_birlesik_vekil"))

    y0 = 2026
    y1 = 2036
    koridor = _koridor(y0, y1, c_net, cz_net, a_net)

    esikler = {
        "tr_net_birlesik_vekil": {
            "B_ust_kotu": round(b_net, 3),
            "A_pasif": round(a_net, 3),
            "C_referans": round(c_net, 3),
            "C_zarar_cozum_aninda": round(cz_net, 3),
            "not": "Negatif = TR kaybı. Üst eşik = B (araçsallaşma); alt hedef = C+zarar teorisi.",
        },
        "turkiye_bosalma": {
            "B": round(_bosalma(proj, "B"), 3),
            "A": round(_bosalma(proj, "A"), 3),
            "C": round(_bosalma(proj, "C"), 3),
            "C_zarar_cozum": round(float(coz.get("turkiye_yaricevre_bosalma") or _bosalma(proj, "C")), 3),
        },
    }

    son = koridor[-1]
    duzeltme = {
        "metrik": "TR net birleşik vekil",
        "2036_orta": son["tr_net_orta"],
        "2036_aralik": [son["tr_net_alt"], son["tr_net_ust"]],
        "2026_C": c_net,
        "2036_hedef_taban": cz_net,
        "iyilesme_2026_2036_orta": round(son["tr_net_orta"] - c_net, 3),
        "tam_cozum_yil_vekili": 7,
    }

    return {
        "olcum": "uzun_vade_esik_ve_duzeltme_koridoru",
        "horizon_yil": y1 - y0,
        "referans_senaryo": proj.get("referans_senaryo", "C"),
        "zarar_teorisi_cozum": zcoz.get("cozum_varsayimi", True),
        "esikler": esikler,
        "duzelme_ozeti": duzeltme,
        "yillik_koridor": koridor,
        "kaynak": ["PROJEKSIYON.json", "ZARAR_COZUM_C.json"],
    }


def _md(d: dict[str, Any]) -> str:
    e = d["esikler"]["tr_net_birlesik_vekil"]
    b = d["esikler"]["turkiye_bosalma"]
    u = d["duzelme_ozeti"]
    lines = [
        "# Uzun vade eşikleri ve düzelme aralığı (10 yıl vekil)",
        "",
        "Metrik: **TR net birleşik vekil** (negatif = kayıp). Taban senaryo **C**; "
        "zarar teorisi çözümü tam olgunlaşınca **7 yıl** vekili (HEKİS tam ölçek referansı).",
        "",
        "## Yapısal eşikler (sabit)",
        "",
        "| Eşik | TR net vekil | TR boşalma |",
        "| --- | ---: | ---: |",
        f"| B — üst kötü (araçsallaşma) | {e['B_ust_kotu']} | {b['B']} |",
        f"| A — pasif bağ | {e['A_pasif']} | {b['A']} |",
        f"| C — referans (2026) | {e['C_referans']} | {b['C']} |",
        f"| C + zarar çözümü (anlık tam) | {e['C_zarar_cozum_aninda']} | {b['C_zarar_cozum']} |",
        "",
        "## Tahmini düzelme aralığı",
        "",
        f"- **2026 (C):** {u['2026_C']}",
        f"- **2036 orta yol:** {u['2036_orta']}",
        f"- **2036 aralık:** {u['2036_aralik'][0]} … {u['2036_aralik'][1]}",
        f"- **10 yıl iyileşme (orta):** {u['iyilesme_2026_2036_orta']} vekil birim",
        "",
        "## Yıllık koridor",
        "",
        "| Yıl | Olgunluk | Alt | Orta | Üst |",
        "| --- | ---: | ---: | ---: | ---: |",
    ]
    for row in d["yillik_koridor"]:
        lines.append(
            f"| {row['yil']} | {row['cozum_olgunluk']} | {row['tr_net_alt']} | "
            f"{row['tr_net_orta']} | {row['tr_net_ust']} |"
        )
    lines.extend(
        [
            "",
            "Görsel: `canvases/uzun-vade-esik-duzelme.canvas.tsx`",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    data = hesapla()
    (OUT / "UZUN_VADE_ESIK.json").write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (OUT / "UZUN_VADE_ESIK.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'UZUN_VADE_ESIK.md'}")


if __name__ == "__main__":
    main()
