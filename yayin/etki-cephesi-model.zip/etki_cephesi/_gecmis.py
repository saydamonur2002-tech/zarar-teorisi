"""Geçmişten türetilen senaryo büyüklükleri (SAF: yalnız gözlem CSV'leri + tam_olgunluk_yil).

Fikir: senaryolar geçmişin rejimleridir. Merkez sızıntı oranı r = yatırım geliri gideri / mal ihracatı'nın
kayan 5 yıllık log-eğimleri (2015–2025) geçmişin kalıcı sürüklenme dağılımını verir:
  A (pasif, bağ atıl)          = medyan eğim   (tipik geçmiş devam eder)
  B (araçsallaşma)             = üst çeyrek eğim (q75, sızıntı artar)
  C (katmanlı oyun, kullanım)  = alt çeyrek eğim (q25, sızıntı azalır)
`merkez_sizinti_carpan_s = exp((d_s − d_A) · T)` (A = 1, `tam_olgunluk_yil` T). Atanmış 1,0 / 1,15 / 0,9 yerine.

Sınır: n = 7 kayan pencere, örtüşüyor (etkin bağımsız gözlem ~2). Çeyrekler gürültülüdür; sonuç geçmişin
dalgalanmasını yansıtır, öngörü değildir. Senaryo anlatısının geçmişte karşılığı olmayan parametreleri
(etki erozyonu, diplomatik esneklik, bağ modu, halka çarpanları) buradan türetilemez; atanmış kalır.
"""
from __future__ import annotations

import csv
import json
import math
from functools import lru_cache
from pathlib import Path
from typing import Any

import numpy as np

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
GOZLEM = DATA / "gozlem" / "evds_odeme_dengesi_aylik.csv"
CEVIRME = DATA / "gozlem" / "evds_borc_cevirme_aylik.csv"
PENCERE = 5
ESIK_ACIK = 100.0


def _csv(p: Path) -> list[dict[str, str]]:
    with p.open(encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


@lru_cache(maxsize=1)
def yillik_r() -> dict[int, float]:
    d: dict[str, tuple[float, float]] = {}
    for r in _csv(GOZLEM):
        try:
            d[r["Donem"]] = (float(r["X_mal_ihracati"]), float(r["YG_yatirim_geliri_gideri"]))
        except ValueError:
            continue
    out: dict[int, float] = {}
    for y in sorted({int(t[:4]) for t in d}):
        ay = [f"{y}-{m:02d}" for m in range(1, 13)]
        if all(a in d for a in ay):
            out[y] = sum(d[a][1] for a in ay) / sum(d[a][0] for a in ay)
    return out


@lru_cache(maxsize=1)
def egimler() -> dict[int, float]:
    """Kayan 5 yıllık log-eğim; anahtar = pencerenin son yılı."""
    r = yillik_r()
    ys = sorted(r)
    lr = [math.log(r[y]) for y in ys]
    return {ys[i + PENCERE - 1]: float(np.polyfit(np.arange(PENCERE), lr[i : i + PENCERE], 1)[0]) for i in range(len(ys) - PENCERE + 1)}


def ceyrekler() -> tuple[float, float, float]:
    v = np.array(list(egimler().values()))
    q = np.quantile(v, [0.25, 0.5, 0.75])
    return float(q[0]), float(q[1]), float(q[2])


def suruklenme() -> dict[str, float]:
    """Senaryo yıllık log sürüklenmesi (mutlak): A medyan, B q75, C q25."""
    q25, q50, q75 = ceyrekler()
    return {"A": q50, "B": q75, "C": q25}


def sigma_yillik() -> float:
    r = yillik_r()
    ys = sorted(r)
    ch = np.diff([math.log(r[y]) for y in ys])
    return float(np.std(ch, ddof=1))


def tam_olgunluk() -> float:
    return float(json.loads((DATA / "finans_katman_kopru.json").read_text(encoding="utf-8"))["tam_olgunluk_yil"])


def merkez_carpan() -> dict[str, float]:
    d = suruklenme()
    t = tam_olgunluk()
    return {s: float(math.exp((d[s] - d["A"]) * t)) for s in ("A", "B", "C")}


def rejim(egim: float) -> str:
    q25, _, q75 = ceyrekler()
    return "C" if egim <= q25 else ("B" if egim >= q75 else "A")


@lru_cache(maxsize=1)
def acik_yil() -> dict[int, bool]:
    """Takvim yılı ortalaması: borç çevirme K1 ve K2 ≥ %100 mü?"""
    d: dict[str, tuple[float, float]] = {}
    for r in _csv(CEVIRME):
        try:
            d[r["Donem"]] = (float(r["K1_bankalar"]), float(r["K2_diger_sektorler"]))
        except ValueError:
            continue
    out: dict[int, bool] = {}
    for y in sorted({int(t[:4]) for t in d}):
        ay = [f"{y}-{m:02d}" for m in range(1, 13)]
        if all(a in d for a in ay):
            out[y] = bool(np.mean([d[a][0] for a in ay]) >= ESIK_ACIK and np.mean([d[a][1] for a in ay]) >= ESIK_ACIK)
    return out


def k2_olabilirlik() -> dict[str, Any]:
    """P(dış finansman açık | rejim) geçmişteki koşullu sıklıktan (Laplace). Kayan pencere sonu yılı etiketlenir."""
    ay = acik_yil()
    sayim = {s: [0, 0] for s in ("A", "B", "C")}
    for y, e in egimler().items():
        if y in ay:
            s = rejim(e)
            sayim[s][1] += 1
            sayim[s][0] += int(ay[y])
    p = {s: (a + 1) / (n + 2) for s, (a, n) in sayim.items()}
    taban = sum(ay.values()) / len(ay)
    return {"p": p, "sayim_acik_toplam": sayim, "taban_oran": taban}
