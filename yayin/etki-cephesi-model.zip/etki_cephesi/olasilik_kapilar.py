"""P(C) kapı raporu: `_olasilik.hesapla_P()` çıktısını yazar. Saf hesap `_olasilik.py`'dedir (rapor okumaz).

Karar eşiğiyle bağlantı (skor 62, P(C) ≈ 0,56) `olasilik_duyarlilik.py` raporunda: kapı sonuçlarının her biri için
uygulanabilirlik kararı orada hesaplanır.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import _olasilik

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "etki_cephesi"


def _md(d: dict[str, Any]) -> str:
    L = ["# P(C) — kapılarla yeniden kurulum", "", f"**Etiket:** `{d['etiket']}`", ""]
    L.append(f"- Prior: tekdüze {d['prior']} (eski el ataması {d['eski_el_atamasi']} dayanaksızdı).")
    L.append(f"- Bugünkü P: **{d['bugunku_P']}**. {d['bugunku_durum']}")
    L += ["", "## Kapılar", "", "| Kapı | Kaynak | Olabilirlik | Durum |", "| --- | --- | --- | --- |"]
    for k in d["kapilar"]:
        L.append(f"| {k['kapi']} | {k['kaynak']} | {k['olabilirlik']} | {k['durum']} |")
    t = d["k2_tarihce"]
    L += ["", "## K2 dış kısıt", "", f"- Tarihçe: 12 aylık ort. çevirme ≥ %100 olan pencerelerin payı **{t['taban_acik_pay']}** ({t['n_pencere']} pencere). Bu A için taban oran p0.", f"- Son: {t['son']}", f"- Olabilirlik **geçmişten**: P(açık | rejim) = {t['rejim_kosullu']['p']}, geçmiş sayım (açık, toplam) = {t['rejim_kosullu']['sayim_acik_toplam']}. Rejim = kayan 5 yıllık eğimin çeyreği (C ≤ q25, B ≥ q75, A arası). n = 7 örtüşen pencere (etkin ~2 bağımsız): çok zayıf. λ = {_olasilik.LAMBDA} (λ=1: kapı bilgi taşımaz).", "", "| Açık sayısı (3 kontrol noktasından) | P(A) | P(B) | P(C) |", "| ---: | ---: | ---: | ---: |"]
    for r in d["k2_sonuc_tablosu"]:
        L.append(f"| {r['k_acik']}/{r['n']} | {r['P']['A']} | {r['P']['B']} | {r['P']['C']} |")
    L += ["", "### λ duyarlılığı (geçmişe ağırlık; P(C): hiç açık yok → hepsi açık)", "", "| λ | tekdüze prior | eski el ataması prior |", "| ---: | --- | --- |"]
    for r in d["k2_duyarlilik"]:
        L.append(f"| {r['lambda']} | {r['tekduze']['k=0']} → {r['tekduze']['k=n']} | {r['eski_el_atamasi']['k=0']} → {r['eski_el_atamasi']['k=n']} |")
    L += ["", "## Karar bağlantısı", "", "Kapı sonuçlarının uygulanabilirlik kararına çevrilmesi `OLASILIK_DUYARLILIK.md` içinde ('Kapı sonuçları').", "", "## Ne denmez", "", "- 'P(C) = 1/3' bir ölçüm değildir; bilgi yokluğudur. Ölçüm 2027-12'den itibaren başlar.", "- K2 olabilirliği 7 örtüşen geçmiş pencereden gelir; çok gürültülü. λ tablosu geçmişe verilen ağırlığın etkisini gösterir.", "- K3 ve K4 veri gelene kadar olasılığa girmez; sıfır değil, bilinmiyor.", ""]
    return "\n".join(L)


def main() -> None:
    d = _olasilik.hesapla_P()
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "OLASILIK_KAPILAR.json").write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "OLASILIK_KAPILAR.md").write_text(_md(d), encoding="utf-8")
    print("OLASILIK_KAPILAR:", d["bugunku_P"], "| en iyi tek kapi P(C) =", d["en_iyi_tek_kapi_P_C"])


if __name__ == "__main__":
    main()
