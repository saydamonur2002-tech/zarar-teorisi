"""Rant kanal etiketlerini AKIS_OLCUM rant_kanal anahtarlarına eşler."""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
ESLESME = REPO / "data" / "etki_cephesi" / "kalibre" / "rant_kanal_akis_eslesme.json"


@lru_cache(maxsize=1)
def load_eslesme() -> dict[str, Any]:
    return json.loads(ESLESME.read_text(encoding="utf-8"))


def akis_kanal_etiket(tag: str) -> str:
    doc = load_eslesme()
    tab = doc.get("etiket_akis_kanal") or {}
    return str(tab.get(tag) or doc.get("varsayilan_akis_kanal") or tag)


def normalize_tags(tags: list[str]) -> list[str]:
    return [akis_kanal_etiket(str(t)) for t in tags if t]
