"""Matris dönemine uygun USD/TRY.

SFC matrisi (L_v2, G_v2, NFP) hangi dönemdeyse USD→TL çevirisi o dönemin kuruyla yapılır.
Kaynak: zarar-teorisi akis_model_ozeti.json -> dis_borc_artisi.stok_milyar_USD.<dönem>.USDTRY
(EVDS TP.DK.USD.A çeyrek sonu). Bulunamazsa yedek (gerceklik_capa 2024 ortalaması) döner ve etiketlenir.
"""
from __future__ import annotations

import json
from pathlib import Path


def kur_matris_donemi(zarar_dir: Path, donem: str, yedek: float) -> tuple[float, str]:
    try:
        oz = json.loads((zarar_dir / "akis_model_ozeti.json").read_text(encoding="utf-8"))
        v = float(oz["dis_borc_artisi"]["stok_milyar_USD"][str(donem)]["USDTRY"])
        return v, f"akis_model_ozeti.dis_borc_artisi.{donem}.USDTRY"
    except (OSError, KeyError, TypeError, ValueError):
        return float(yedek), "yedek:gerceklik_capa(2024 ortalama) — matris dönemiyle uyumsuz"
