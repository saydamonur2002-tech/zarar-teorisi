"""Etki çeperi — bölünmüş havza + yerel dış bağlanma + rant çıkışı."""
from __future__ import annotations

import json
from pathlib import Path

import _gecmis
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
KALIBRE = DATA / "kalibre"
OUT = REPO / "reports" / "etki_cephesi"


def _data_path(name: str) -> Path:
    k = KALIBRE / name
    if k.is_file():
        return k
    return DATA / name


def _makro_sirasi(doc: dict[str, Any] | None) -> list[tuple[str, str]]:
    if doc and doc.get("makrolar"):
        return [(m["id"], m["ad"]) for m in doc["makrolar"]]
    return [
        ("levant", "Levant"),
        ("orta_dogu", "Orta Doğu"),
        ("korfez", "Körfez"),
        ("kuzey_afrika", "Kuzey Afrika"),
        ("karadeniz", "Karadeniz"),
        ("kafkasya", "Kafkasya"),
        ("balkan", "Balkan"),
        ("ortasya", "Orta Asya"),
        ("iran", "İran"),
        ("afrika", "Afrika"),
    ]


def _makro_ozet(bolge_net: list[dict[str, Any]], makro_sira: list[str]) -> list[dict[str, Any]]:
    buckets: dict[str, dict[str, Any]] = {}

    def _b(m: str) -> dict[str, Any]:
        return buckets.setdefault(
            m,
            {
                "makro": m,
                "net_toplam": 0.0,
                "tr_bosalma_toplam": 0.0,
                "rant_cikis_toplam": 0.0,
                "dis_baglama_toplam": 0.0,
                "pasif_toplam": 0.0,
                "aracsal_toplam": 0.0,
                "temsil_toplam": 0.0,
                "ikame_toplam": 0.0,
                "tampon_sok_toplam": 0.0,
                "havza_sayisi": 0,
            },
        )

    for b in bolge_net:
        m = b.get("makro") or "diger"
        o = _b(m)
        o["net_toplam"] += float(b.get("net_endeks", 0.0))
        o["tr_bosalma_toplam"] += float(b.get("tr_bosalma", 0.0))
        o["rant_cikis_toplam"] += float(b.get("rant_kanal_cikis_kar", 0.0))
        o["dis_baglama_toplam"] += float(b.get("yerel_dis_baglama_zarar", 0.0))
        o["pasif_toplam"] += float(b.get("pasif_bosluk_dolgu", 0.0))
        o["aracsal_toplam"] += float(b.get("aracsallasma_zarar", 0.0))
        o["temsil_toplam"] += float(b.get("mesruiyet_temsil_zedesi", 0.0))
        o["ikame_toplam"] += float(b.get("rakip_ikame_gelen", 0.0))
        o["tampon_sok_toplam"] += float(b.get("tampon_koridor_sok", 0.0))
        o["havza_sayisi"] += 1

    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    for mid in makro_sira:
        if mid not in buckets:
            continue
        seen.add(mid)
        row = buckets[mid]
        out.append({k: (round(v, 3) if isinstance(v, float) else v) for k, v in row.items()})
    for mid, row in sorted(buckets.items()):
        if mid in seen:
            continue
        out.append({k: (round(v, 3) if isinstance(v, float) else v) for k, v in row.items()})
    return out


def _makro_ulke_gruplari(
    bolgeler: list[dict[str, Any]],
    ulke_doc: dict[str, Any],
    makro_sira: list[tuple[str, str]],
) -> list[tuple[str, tuple[str, ...]]]:
    pay_map = ulke_doc.get("bolge_ulke_pay") or {}
    labels = {m[0]: m[1] for m in makro_sira}
    by_makro: dict[str, list[str]] = {m[0]: [] for m in makro_sira}

    def _append(m: str, iso: str) -> None:
        if not iso or iso == "TR":
            return
        lst = by_makro.setdefault(m, [])
        if iso not in lst:
            lst.append(iso)

    for b in bolgeler:
        m = b.get("makro") or ""
        bid = b["id"]
        rows = pay_map.get(bid)
        if rows:
            for row in rows:
                _append(m, row["ulke"])
        else:
            u = b.get("ulke", "")
            if u and u != "MIX":
                _append(m, u)

    out: list[tuple[str, tuple[str, ...]]] = []
    for mid, ad in makro_sira:
        isos = tuple(by_makro.get(mid, []))
        if isos:
            out.append((f"{ad} — ülkeler / vekiller", isos))
    return out


def _md_makro_havza_detay(sen: dict[str, Any], makro_id: str, baslik: str) -> list[str]:
    rows = [b for b in sen.get("bolgesel_net", []) if b.get("makro") == makro_id]
    if not rows:
        return []
    lines = [f"### {baslik}", ""]
    for b in rows:
        ch = ", ".join(b.get("rant_kanallar") or []) or "—"
        lines.append(
            f"- **{b['ad']}:** net {b['net_endeks']} | boşalma {b['tr_bosalma']} | "
            f"ikame {b['rakip_ikame_gelen']} | sok {b['tampon_koridor_sok']} | "
            f"dış bağ. {b['yerel_dis_baglama_zarar']} | rant {b['rant_kanal_cikis_kar']} ({ch})"
        )
    lines.append("")
    return lines


def _load(name: str) -> dict[str, Any]:
    return json.loads(_data_path(name).read_text(encoding="utf-8"))


def _bolge_bosalma(
    bolge: dict,
    kanallar: list[dict],
    rol_carpan: dict[str, dict[str, float]],
    ozel: dict[str, dict[str, float]],
    erozyon: float,
    flex: float,
) -> tuple[float, list[dict]]:
    rol = bolge.get("rol", "koridor")
    rc = rol_carpan.get(rol, {})
    oz = ozel.get(bolge["id"], {})
    vek = bolge["etki_vekili_2026"]
    detay = []
    toplam = 0.0
    for k in kanallar:
        kid = k["id"]
        w = k["agirlik"] * rc.get(kid, 1.0) * oz.get(kid, 1.0)
        delta = vek * w * erozyon * (1.0 + flex)
        toplam += delta
        detay.append({"halka": kid, "delta_endeks": round(delta, 3)})
    return round(toplam, 3), detay


def _enigma_carp(bolge: dict, enigma_levant: float) -> float:
    if bolge.get("makro_ceper") == "levant" or bolge.get("makro") == "levant":
        return enigma_levant
    return 1.0


def _bag_modu_etkiler(
    bolge: dict,
    bag_row: dict[str, Any],
    bag_modu: dict[str, float],
    enigma_levant: float,
    dominion_doc: dict[str, Any],
) -> dict[str, float]:
    """kullanim | atil | aracsal — metin: pasif tutum + araçsallaşma ayrı."""
    enigma = float(bag_row.get("donmus_enigma", 1.0)) * _enigma_carp(bolge, enigma_levant)
    bv = float(bag_row.get("bag_vekili", 5.0)) / 10.0
    ev = float(bolge.get("etki_vekili_2026", 4.0)) / 10.0
    base = bv * ev * enigma
    pasif_k = float(dominion_doc.get("pasif_bosluk_dolgu_katsayi", 0.85))
    arac_k = float(dominion_doc.get("aracsallasma_katsayi", 0.72))
    mim_k = float(dominion_doc.get("dis_mimari_katsayi", 0.48))
    rol = bolge.get("rol", "koridor")
    mes = float((dominion_doc.get("mesruiyet_hassasiyet_rol") or {}).get(rol, 0.9))

    atil = float(bag_modu.get("atil", 0.4))
    arac = float(bag_modu.get("aracsal", 0.3))
    kull = float(bag_modu.get("kullanim", 0.3))

    pasif = round(base * atil * pasif_k * 3.8, 3)
    aracsal = round(base * arac * arac_k * 2.8, 3)
    temsil = round((pasif * 0.32 + aracsal * 0.58) * mes, 3)
    mimari = round((pasif + aracsal) * mim_k, 3)
    telafi = round(-base * kull * 0.95, 3)
    return {
        "pasif_bosluk_dolgu": pasif,
        "aracsallasma_zarar": aracsal,
        "mesruiyet_temsil_zedesi": temsil,
        "dis_hegemon_mimari": mimari,
        "kullanim_telafi": telafi,
        "bag_kullanim_pay": kull,
    }


def _ceper_govde_acigi(
    bolgeler: list[dict],
    bag_doc: dict[str, Any],
    kullanim_pay: float,
) -> tuple[float, float]:
    govde_k = float(bag_doc.get("govde_tasima_kapasitesi", 0.42))
    cevher = ("levant", "korfez", "kafkasya", "karadeniz", "ortasya", "kuzey_afrika", "iran")
    pot = 0.0
    bags = bag_doc.get("bolge_bag") or {}
    for b in bolgeler:
        if b.get("makro_ceper") not in cevher:
            continue
        br = bags.get(b["id"], {})
        pot += (float(br.get("bag_vekili", 0)) / 10.0) * (
            float(b.get("etki_vekili_2026", 0)) / 10.0
        )
    pot = round(pot, 3)
    tasima = round(govde_k * kullanim_pay, 3)
    acik = round(pot * (1.0 - tasima), 3) if pot > 0 else 0.0
    return pot, acik


def _yerel_dis_rant(
    bid: str,
    bosalma: float,
    ikame_gelen: float,
    pasif_dolgu: float,
    aracsal: float,
    yerel_doc: dict[str, Any],
    sen_id: str,
    refah_doc: dict[str, Any] | None = None,
    kullanim_telafi: float = 0.0,
) -> tuple[float, float, list[str], dict[str, float]]:
    dis = (yerel_doc.get("dis_baglama") or {}).get(bid, {})
    rant = (yerel_doc.get("rant_kanal") or {}).get(bid, {})
    dc = float((yerel_doc.get("senaryo_dis_baglama_carpan") or {}).get(sen_id, 1.0))
    rc = float((yerel_doc.get("senaryo_rant_cikis_carpan") or {}).get(sen_id, 1.0))
    lk = float(dis.get("yerel_katsayi", 0.3))
    ic = float(dis.get("ikame_ceza", 0.3))
    dis_z = (bosalma * lk + ikame_gelen * ic + pasif_dolgu * 0.42 + aracsal * 0.55) * dc
    yog = float(rant.get("yogunluk", 0.0))
    cik = float(rant.get("disari_cikis", 0.0))
    bosluk_rant = (bosalma * yog * cik + pasif_dolgu * 0.32 + aracsal * 0.28) * rc
    refah_extra = {"refah_rant_tr_ic": 0.0, "refah_rant_dis_havuz": 0.0, "bosluk_rant_karsiligi": round(bosluk_rant, 3)}
    if refah_doc and refah_doc.get("aktif"):
        w = refah_doc.get("agirliklar") or {}
        hv = {**(refah_doc.get("varsayilan_havza") or {}), **(refah_doc.get("havza") or {}).get(bid, {})}
        ref_yog = float(hv.get("refah_yogunluk", yog))
        tr_ic = float(hv.get("tr_ic_refah_pay", 0.24))
        dis_pay = float(hv.get("dis_refah_paylasim", cik))
        taban = (
            bosalma * float(w.get("uretim_kapasitesi", 0.42))
            + ikame_gelen * float(w.get("rakip_ikame_refah", 0.33))
            + max(0.0, kullanim_telafi) * float(w.get("bag_kullanim_refah", 0.25))
        )
        refah_brut = taban * ref_yog * rc
        refah_extra["refah_rant_tr_ic"] = round(refah_brut * tr_ic, 3)
        refah_extra["refah_rant_dis_havuz"] = round(refah_brut * dis_pay, 3)
        rant_kar = round(refah_brut, 3)
        kanallar = list(rant.get("kanallar") or []) + ["refah_rant"]
    else:
        rant_kar = round(bosluk_rant, 3)
        kanallar = list(rant.get("kanallar") or [])
    return round(dis_z, 3), rant_kar, kanallar, refah_extra


def _bolgesel_dagilim(
    kayiplar: dict[str, float],
    bag_etki_by_id: dict[str, dict[str, float]],
    bolgeler: list[dict],
    akis_doc: dict[str, Any],
    yerel_doc: dict[str, Any],
    ikame_carpan: float,
    merkez_carpan: float,
    sen_id: str,
    refah_doc: dict[str, Any] | None = None,
) -> tuple[list[dict[str, Any]], float, float, float, float, float, float, list[dict[str, Any]]]:
    mat = akis_doc.get("tr_zayiflayinca") or {}
    rol_cokus = akis_doc.get("tampon_cokus_rol_carpan") or {}
    rol_by_id = {b["id"]: b.get("rol", "koridor") for b in bolgeler}
    makro_by_id = {b["id"]: b.get("makro", "") for b in bolgeler}
    adlar = {b["id"]: b["ad"] for b in bolgeler}

    merkez_toplam = 0.0
    tampon_z: dict[str, float] = {b["id"]: 0.0 for b in bolgeler}
    ikame_g: dict[str, float] = {b["id"]: 0.0 for b in bolgeler}
    merkez_kaynak: dict[str, float] = {}
    kenarlar: list[dict[str, Any]] = []

    pasif_by_id = {k: v.get("pasif_bosluk_dolgu", 0.0) for k, v in bag_etki_by_id.items()}
    pasif_merkez_k = 0.06 if refah_doc and refah_doc.get("aktif") else 0.38
    pasif_kayip_k = 0.08 if refah_doc and refah_doc.get("aktif") else 0.25
    merkez_toplam += sum(pasif_by_id.values()) * pasif_merkez_k
    merkez_toplam += sum(v.get("dis_hegemon_mimari", 0.0) for v in bag_etki_by_id.values())

    for kaynak, kayip in kayiplar.items():
        row = mat.get(kaynak, {})
        m_pay = row.get("merkez_finans", 0.0)
        t_pay = row.get("tampon_cokus", 0.0)
        rol = rol_by_id.get(kaynak, "koridor")
        kayip_eff = kayip + pasif_by_id.get(kaynak, 0.0) * pasif_kayip_k
        m_akis = kayip_eff * m_pay * merkez_carpan
        merkez_toplam += m_akis
        merkez_kaynak[kaynak] = round(m_akis, 3)
        t_akis = kayip_eff * t_pay * rol_cokus.get(rol, 0.5)
        tampon_z[kaynak] = tampon_z.get(kaynak, 0.0) + t_akis
        kenarlar.append(
            {
                "kaynak": kaynak,
                "hedef": "merkez_finans",
                "kaynak_ad": adlar.get(kaynak, kaynak),
                "hedef_ad": "Merkez (finans vekil)",
                "akis_endeks": round(m_akis, 3),
                "tur": "sizinti",
            }
        )
        for hedef, pay in (row.get("rakip_yaricevre") or {}).items():
            v = kayip_eff * pay * ikame_carpan
            ikame_g[hedef] = ikame_g.get(hedef, 0.0) + v
            kenarlar.append(
                {
                    "kaynak": kaynak,
                    "hedef": hedef,
                    "kaynak_ad": adlar.get(kaynak, kaynak),
                    "hedef_ad": adlar.get(hedef, hedef),
                    "akis_endeks": round(v, 3),
                    "tur": "rakip_ikame",
                }
            )

    orta_dogu_rant_cikis = 0.0
    orta_dogu_dis_baglama = 0.0
    pasif_toplam = 0.0
    arac_toplam = 0.0
    mimari_toplam = 0.0
    temsil_toplam = 0.0
    bolge_satir: list[dict[str, Any]] = []

    for b in bolgeler:
        bid = b["id"]
        bosalma = kayiplar.get(bid, 0.0)
        be = bag_etki_by_id.get(bid, {})
        pasif = be.get("pasif_bosluk_dolgu", 0.0)
        arac = be.get("aracsallasma_zarar", 0.0)
        temsil = be.get("mesruiyet_temsil_zedesi", 0.0)
        mimari = be.get("dis_hegemon_mimari", 0.0)
        telafi = be.get("kullanim_telafi", 0.0)
        pasif_toplam += pasif
        arac_toplam += arac
        mimari_toplam += mimari
        temsil_toplam += temsil
        tz = round(tampon_z.get(bid, 0.0), 3)
        ig = round(ikame_g.get(bid, 0.0), 3)
        ms = round(merkez_kaynak.get(bid, 0.0), 3)
        dis_z, rant_kar, rant_kanallar, refah_x = _yerel_dis_rant(
            bid, bosalma, ig, pasif, arac, yerel_doc, sen_id, refah_doc, telafi
        )
        refah_dis = float(refah_x.get("refah_rant_dis_havuz") or 0.0)
        refah_tr_ic = float(refah_x.get("refah_rant_tr_ic") or 0.0)
        rant_cikis = refah_dis if refah_doc and refah_doc.get("aktif") else rant_kar
        net = round(ig - tz - dis_z - rant_cikis - temsil + telafi + refah_tr_ic, 3)
        durum = "fayda" if net > 0.05 else ("zarar" if net < -0.05 else "nötr")
        mak = makro_by_id.get(bid, "")
        if mak in ("orta_dogu", "levant", "korfez", "kuzey_afrika"):
            orta_dogu_rant_cikis += rant_cikis
            orta_dogu_dis_baglama += dis_z
        bolge_satir.append(
            {
                "bolge": bid,
                "ad": b["ad"],
                "makro": b.get("makro"),
                "makro_ceper": b.get("makro_ceper"),
                "rol": b.get("rol"),
                "tr_bosalma": bosalma,
                "pasif_bosluk_dolgu": pasif,
                "aracsallasma_zarar": arac,
                "mesruiyet_temsil_zedesi": temsil,
                "dis_hegemon_mimari": mimari,
                "kullanim_telafi": telafi,
                "merkeze_sizinti": ms,
                "tampon_koridor_sok": tz,
                "rakip_ikame_gelen": ig,
                "yerel_dis_baglama_zarar": dis_z,
                "rant_kanal_cikis_kar": round(rant_cikis, 3),
                "refah_rant_vekili": round(rant_kar, 3),
                "refah_rant_tr_ic": refah_tr_ic,
                "refah_rant_dis_havuz": refah_dis,
                "bosluk_rant_karsiligi": refah_x.get("bosluk_rant_karsiligi", 0.0),
                "rant_kanallar": rant_kanallar,
                "net_endeks": net,
                "durum": durum,
            }
        )
    bolge_satir.sort(key=lambda x: -x["net_endeks"])
    kenarlar.sort(key=lambda x: -x["akis_endeks"])
    return (
        bolge_satir,
        round(merkez_toplam, 3),
        round(orta_dogu_rant_cikis, 3),
        round(orta_dogu_dis_baglama, 3),
        round(pasif_toplam, 3),
        round(arac_toplam, 3),
        round(mimari_toplam, 3),
        round(temsil_toplam, 3),
        kenarlar,
    )


def _mermaid(kenarlar: list[dict], min_v: float = 0.18) -> str:
    lines = ["```mermaid", "flowchart LR"]
    seen: set[str] = set()
    for e in kenarlar:
        if e["akis_endeks"] < min_v:
            continue
        s = e["kaynak"][:8]
        t = "MFIN" if e["hedef"] == "merkez_finans" else e["hedef"][:8]
        if s not in seen:
            lines.append(f'  {s}["{e["kaynak_ad"][:24]}"]')
            seen.add(s)
        if t == "MFIN":
            if "MFIN" not in seen:
                lines.append('  MFIN["Merkez finans"]')
                seen.add("MFIN")
        elif t not in seen:
            lines.append(f'  {t}["{e["hedef_ad"][:24]}"]')
            seen.add(t)
        lab = "sız" if e["tur"] == "sizinti" else "ikm"
        lines.append(f'  {s} -->|{e["akis_endeks"]} {lab}| {t}')
    lines.append("```")
    return "\n".join(lines)


_BOLGE_VERI_LEGACY: dict[str, str] = {
    "irak_bagdat": "irak",
    "irak_krg": "irak",
    "dogu_akdeniz_gaz": "dogu_akdeniz",
    "dogu_akdeniz_kefalet": "dogu_akdeniz",
}


def _bolge_veri_anahtar(bid: str, tablo: dict[str, Any]) -> str:
    if bid in tablo:
        return bid
    leg = _BOLGE_VERI_LEGACY.get(bid, "")
    if leg and leg in tablo:
        return leg
    return bid


def _dis_aktör_kazanc(
    kayiplar: dict[str, float],
    bag_etki_by_id: dict[str, dict[str, float]],
    kenarlar: list[dict[str, Any]],
    dis_doc: dict[str, Any],
    ub_doc: dict[str, Any],
    ulke_by_bolge: dict[str, str] | None = None,
    refah_doc: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """TR boşalması + ikame akışı → dış aktör kazanç vekili (ülke havza netinden bağımsız kanal)."""
    dis_pay = dis_doc.get("bolge_pay") or {}
    ub_rows = ub_doc.get("bolge_ulkeler") or {}
    names_ub = ub_doc.get("ulkeler") or {}
    names = {
        **names_ub,
        "MFIN": "Merkez finans (vekil)",
        "EU": names_ub.get("EU", "AB (vekil)"),
    }

    acc: dict[str, dict[str, float]] = {}

    def _touch(iso: str) -> dict[str, float]:
        return acc.setdefault(
            iso,
            {
                "kanal_kazanc": 0.0,
                "matris_kazanc": 0.0,
                "ikame_kazanc": 0.0,
                "ikame_hesap_ham": 0.0,
                "merkez_sizinti": 0.0,
                "kanal_alt": 0.0,
            },
        )

    def _host(bid: str) -> str:
        return (ulke_by_bolge or {}).get(bid, "")

    def _skip_kanal(bid: str, actor: str) -> bool:
        host = _host(bid)
        if host and actor == host:
            return True
        if bid.startswith("iran_") and actor == "IR":
            return True
        return False

    pasif_k = float((refah_doc or {}).get("kayip_pasif_ek") or 0.25) if refah_doc and refah_doc.get("aktif") else 0.25
    bosluk_v = 0.0
    for bid, kayip in kayiplar.items():
        pasif = float(bag_etki_by_id.get(bid, {}).get("pasif_bosluk_dolgu", 0.0))
        vakum = float(kayip) + pasif * pasif_k
        bosluk_v += vakum
        # `kanal` dağıtım kuralı (V × aktör payı) KALDIRILDI: matris kuralıyla aynı boşluğu ikinci kez dağıtıyordu.
        # Yalnız TANI için hesaplanır (kazanca girmez): dağıtım kuralı belirsizliği = |kanal − matris| (sınıf bandında kullanılır).
        pkey = _bolge_veri_anahtar(bid, dis_pay)
        for actor, pay in (dis_pay.get(pkey) or {}).items():
            if actor == "TR" or _skip_kanal(bid, actor):
                continue
            _touch(actor)["kanal_alt"] += vakum * float(pay)
        ukey = _bolge_veri_anahtar(bid, ub_rows)
        for row in ub_rows.get(ukey) or []:
            iso = row["iso"]
            if iso == "TR" or _skip_kanal(bid, iso):
                continue
            delta = float(row["kazanc_katsayi"]) - float(row["zarar_katsayi"])
            if delta <= 0:
                continue
            _touch(iso)["matris_kazanc"] += vakum * delta

    for e in kenarlar:
        if e.get("tur") != "rakip_ikame":
            continue
        dest = e["hedef"]
        flow = float(e["akis_endeks"])
        pkey = _bolge_veri_anahtar(dest, dis_pay)
        pay_row = dis_pay.get(pkey) or {}
        non_tr = sum(float(p) for a, p in pay_row.items() if a != "TR")
        if non_tr <= 0:
            continue
        for actor, pay in pay_row.items():
            if actor == "TR" or _skip_kanal(dest, actor):
                continue
            # K1 (çift sayım düzeltmesi): rakip ikame akışı havza net'inde (rakip_ikame_gelen) zaten kredilendi; aynı v'yi aktör kazancına
            # ayrıca yazmak V'yi iki kez dağıtırdı (bkz. IKAME_CIFT_SAYIM). Ham dağılım yalnız tanı için tutulur, kazanca girmez.
            _touch(actor)["ikame_hesap_ham"] += flow * (float(pay) / non_tr)

    for e in kenarlar:
        if e.get("tur") == "sizinti":
            _touch("MFIN")["merkez_sizinti"] += float(e["akis_endeks"])

    # Normalizasyon: kalan üç kanalın (matris, ikame, merkez) toplamı boşluk V'yi aşamaz. Aşıyorsa orantılı küçültülür; V altındaysa dokunulmaz.
    ham_toplam = sum(v["matris_kazanc"] + v["ikame_kazanc"] + v["merkez_sizinti"] for v in acc.values())
    # Korunum: aktör kazançları + havza girişleri (rakip ikame) birlikte V'yi aşamaz; kazançlar V'den havza girişi düşüldükten sonra kalana sığdırılır.
    havza_girisi = sum(float(e["akis_endeks"]) for e in kenarlar if e.get("tur") == "rakip_ikame")
    katsayi = min(1.0, max(0.0, bosluk_v - havza_girisi) / ham_toplam) if ham_toplam > 0 else 1.0
    out: list[dict[str, Any]] = []
    for iso, v in acc.items():
        kanal = 0.0  # kaldırıldı
        matris = round(v["matris_kazanc"] * katsayi, 3)
        ikame = round(v["ikame_kazanc"] * katsayi, 3)
        merkez = round(v["merkez_sizinti"] * katsayi, 3)
        toplam = round(kanal + matris + ikame + merkez, 3)
        if toplam < 0.02 and iso != "MFIN":
            continue
        out.append(
            {
                "aktor": iso,
                "ad": names.get(iso, iso),
                "kanal_kazanc": kanal,
                "matris_kazanc": matris,
                "ikame_kazanc": ikame,
                "ikame_hesap_ham_havza_girisinde_sayildi": round(v["ikame_hesap_ham"], 3),
                "merkez_sizinti": merkez,
                "fayda_endeks": toplam,
                "kanal_alternatif_kazanc": round(v["kanal_alt"] * katsayi, 3),
                "normalizasyon": {"bosluk_V": round(bosluk_v, 3), "ham_toplam": round(ham_toplam, 3), "havza_girisi_dusuldu": round(havza_girisi, 3), "katsayi": round(katsayi, 4), "kanal_kaldirildi": True, "ikame_aktor_kazancindan_dusuldu": True},
            }
        )
    out.sort(key=lambda x: -x["fayda_endeks"])
    return out


def _merkez_belirsiz_dagit(
    sen_row: dict[str, Any],
    belirsiz_doc: dict[str, Any],
    ulke_names: dict[str, str],
    dis_aktörler: list[str],
) -> dict[str, float]:
    """MFIN kenar toplamı kalır; kalan merkez havuz evren ülkelerine eşit belirsiz pay."""
    merkez_toplam = float(sen_row.get("merkez_finans_sizinti_toplam", 0.0))
    kenarlar = sen_row.get("akis_kenarlari") or []
    mfin_kenar = round(
        sum(float(e["akis_endeks"]) for e in kenarlar if e.get("tur") == "sizinti"),
        3,
    )
    belirsiz_havuz = round(max(0.0, merkez_toplam - mfin_kenar), 3)
    haric = set(belirsiz_doc.get("haric") or ["TR", "MFIN"])
    evren: set[str] = set(ulke_names.keys()) | set(dis_aktörler)
    evren |= set(belirsiz_doc.get("evren_ek") or [])
    evren -= haric
    evren.discard("TR")
    evren.discard("MFIN")
    if not evren:
        sen_row["merkez_mfin_kenar_toplam"] = mfin_kenar
        sen_row["merkez_belirsiz_havuz"] = belirsiz_havuz
        sen_row["merkez_belirsiz_ulke_sayisi"] = 0
        return {}
    pay = round(belirsiz_havuz / len(evren), 4)
    dagitim = {iso: pay for iso in sorted(evren)}
    # yuvarlama farkını son ülkeye
    fark = round(belirsiz_havuz - pay * len(evren), 3)
    if fark and dagitim:
        last = sorted(evren)[-1]
        dagitim[last] = round(dagitim[last] + fark, 3)

    for u in sen_row.get("ulke_kayiplari") or []:
        iso = u["ulke"]
        u["merkez_belirsiz_vekil"] = dagitim.get(iso, 0.0)

    for d in sen_row.get("dis_aktör_kazanc") or []:
        iso = d["aktor"]
        if iso == "MFIN":
            d["merkez_belirsiz_vekil"] = 0.0
            d["merkez_toplam_vekil"] = round(
                float(d.get("merkez_sizinti", 0.0)) + belirsiz_havuz, 3
            )
            continue
        d["merkez_belirsiz_vekil"] = dagitim.get(iso, 0.0)
        d["merkez_toplam_vekil"] = round(float(d.get("merkez_sizinti", 0.0)), 3)

    sen_row["merkez_mfin_kenar_toplam"] = mfin_kenar
    sen_row["merkez_belirsiz_havuz"] = belirsiz_havuz
    sen_row["merkez_belirsiz_ulke_sayisi"] = len(evren)
    sen_row["merkez_belirsiz_pay_esit"] = pay
    return dagitim


REFERANS_ORAN = ("IR", "IL", "EG")  # kayıp/kazanç referansı: kaybı ve kazancı tam modellenmiş, bölünmesiz aktörler


def _kapsam(dis_doc: dict[str, Any], ub_doc: dict[str, Any]) -> dict[str, set[str]]:
    """Hangi aktörün hangi kazanç kanalında MODELLENDİĞİ. Modellenmemiş ≠ sıfır kazanç (bilinmiyor)."""
    kanal: set[str] = set()
    for row in (dis_doc.get("bolge_pay") or {}).values():
        kanal |= set(row)
    matris = {r["iso"] for rows in (ub_doc.get("bolge_ulkeler") or {}).values() for r in rows}
    return {"kanal": kanal, "matris": matris}


def _kapsam_alanlari(iso: str, kayip_var: bool, kapsam: dict[str, set[str]] | None) -> dict[str, Any]:
    if kapsam is None:
        return {}
    if iso == "MFIN":
        # Merkez finans vekili: kazancı açık kenarlardan (sızıntı) ölçülür; kaybı modelde YOK → diğer kaybı bilinmeyen aktörler gibi
        # referans-oran vekilinin konusu (önceden "tanımsız" idi ve kayıp 0 sayılıyordu).
        return {"kayip_kapsam": "bilinmiyor", "kazanc_kapsam": "tam", "net_kapsam": "kismi"}
    if iso == "TR":
        return {"kayip_kapsam": "modellendi", "kazanc_kapsam": "ozel (TR payı rant defterinde)", "net_kapsam": "tam"}
    k = iso in kapsam["kanal"]
    m = iso in kapsam["matris"]
    kazanc = "tam" if (k and m) else ("kismi" if (k or m) else "yok")
    kayip = "modellendi" if kayip_var else "bilinmiyor"
    net = "tam" if (kazanc == "tam" and kayip == "modellendi") else "kismi"
    return {
        "kayip_kapsam": kayip,
        "kazanc_kapsam": kazanc,
        "kazanc_kanallari": {"ikame": k, "matris": m},
        "net_kapsam": net,
    }


def _surdurme_alanlari(iso: str, dis_k: float, pol: float) -> dict[str, Any]:
    """Dış aktörün kaybın devamlılığı için katlandığı maliyet: kappa · pol_s · kazanç (TR, MFIN muaf)."""
    cfg = _surdurme_cfg()
    if not cfg.get("aktif") or iso in cfg.get("muaf", []) or dis_k <= 0:
        return {}
    oran = float(cfg["kappa"]) * pol
    lo, hi = cfg["kappa_bant"]
    return {
        "surdurme_maliyeti": round(oran * dis_k, 3),
        "surdurme_maliyet_belirsizligi": round((hi - lo) / 2 * pol * dis_k, 3),
        "surdurme_maliyet_orani": round(oran, 4),
    }


def _dis_veri() -> dict[str, Any]:
    return json.loads((DATA / "gozlem" / "dis_ticaret_gsyh_2023.json").read_text(encoding="utf-8"))


def _hublar(iso: str, dv: dict[str, Any]) -> list[str]:
    """Transit/yeniden ihracat merkezi: tek kaynağın ihracatı ortağın GSYH'sinin eşik payını aşıyorsa yurt içi talep değildir."""
    esik = dv.get("hub_kurali", {}).get("esik_ihracat_gsyh")
    if not esik:
        return []
    gsyh = dv["gsyh_mn_usd"]
    return sorted(j for j, x in dv["ihracat_mn_usd"].get(iso, {}).items() if j != iso and gsyh.get(j) and x / gsyh[j] > esik)


def _cekim(iso: str, kayip: dict[str, float], dv: dict[str, Any], hub_kurali: bool = True) -> float:
    """İhracat geliri kaybı (vekil birim): Σ_j (ihracat_ij / GSYH_j) · L_j. Ortak ülke j'nin gelir kaybı, ithalat payı kadar i'nin ihracatını düşürür.
    hub_kurali: transit merkezi sayılan ortakların katkısı sıfırlanır (bkz. _hublar)."""
    gsyh = dv["gsyh_mn_usd"]
    hub = set(_hublar(iso, dv)) if hub_kurali else set()
    return sum(x / gsyh[j] * kayip.get(j, 0.0) for j, x in dv["ihracat_mn_usd"].get(iso, {}).items() if j != iso and j not in hub and gsyh.get(j))


def _dis_veri_kayip(by_iso: dict[str, dict[str, Any]], kayip_var: set[str]) -> dict[str, dict[str, float]]:
    """Çin/Rusya kaybı dış ticaret verisinden: çekim tahmini × φ. φ, kaybı modelli referans aktörlerde (İran, İsrail, Mısır)
    modelin kaybının çekim tahminine oranı (ticaret dışı kanallar dahil); min/medyan/maks aralığı kayıp belirsizliğini verir."""
    dv = _dis_veri()
    kayip = {k: float(v["havza_kayip"]) for k, v in by_iso.items() if k in kayip_var}
    phi = sorted(
        kayip[i] / g
        for i in dv["kalibrasyon_aktorleri"]
        if i in kayip and kayip[i] > 0 and (g := _cekim(i, kayip, dv)) > 0
    )
    if not phi:
        return {}
    out: dict[str, dict[str, float]] = {}
    for i in dv["dis_veri_aktorleri"]:
        g = _cekim(i, kayip, dv)
        out[i] = {"cekim": g, "cekim_hubsuz_kural": _cekim(i, kayip, dv, hub_kurali=False), "hublar": _hublar(i, dv), "phi_min": phi[0], "phi_med": phi[len(phi) // 2], "phi_maks": phi[-1]}
    return out


def _surdurme_cfg() -> dict[str, Any]:
    return json.loads((DATA / "surdurme_maliyeti.json").read_text(encoding="utf-8"))


def _aktör_birlesik(
    ulke_kayiplari: list[dict[str, Any]],
    dis_kazanc: list[dict[str, Any]],
    ulke_names: dict[str, str],
    kapsam: dict[str, set[str]] | None = None,
    pol: float = 1.0,
) -> list[dict[str, Any]]:
    by_iso: dict[str, dict[str, Any]] = {}
    for u in ulke_kayiplari:
        iso = u["ulke"]
        by_iso[iso] = {
            "aktor": iso,
            "ad": u["ad"],
            "havza_kayip": u.get("kayip_endeks", 0.0),
            "havza_net": u.get("net_endeks", 0.0),
            "dis_kazanc_vekili": 0.0,
            "kanal_kazanc": 0.0,
            "ikame_kazanc": 0.0,
            "merkez_sizinti": 0.0,
            "merkez_belirsiz_vekil": float(u.get("merkez_belirsiz_vekil", 0.0)),
        }
    for d in dis_kazanc:
        iso = d["aktor"]
        row = by_iso.setdefault(
            iso,
            {
                "aktor": iso,
                "ad": d["ad"],
                "havza_kayip": 0.0,
                "havza_net": 0.0,
                "dis_kazanc_vekili": 0.0,
                "kanal_kazanc": 0.0,
                "ikame_kazanc": 0.0,
                "merkez_sizinti": 0.0,
                "merkez_belirsiz_vekil": 0.0,
            },
        )
        row["dis_kazanc_vekili"] = d["fayda_endeks"]
        row["kanal_kazanc"] = d.get("kanal_kazanc", 0.0)
        row["ikame_kazanc"] = d.get("ikame_kazanc", 0.0)
        row["merkez_sizinti"] = d.get("merkez_sizinti", 0.0)
        row["merkez_belirsiz_vekil"] = d.get("merkez_belirsiz_vekil", 0.0)
        row["ad"] = d["ad"] or row["ad"]

    for u in ulke_kayiplari:
        iso = u["ulke"]
        row = by_iso.setdefault(
            iso,
            {
                "aktor": iso,
                "ad": u["ad"],
                "havza_kayip": 0.0,
                "havza_net": 0.0,
                "dis_kazanc_vekili": 0.0,
                "kanal_kazanc": 0.0,
                "ikame_kazanc": 0.0,
                "merkez_sizinti": 0.0,
                "merkez_belirsiz_vekil": 0.0,
            },
        )
        bel = float(u.get("merkez_belirsiz_vekil", 0.0))
        if bel > 0:
            row["merkez_belirsiz_vekil"] = bel

    out: list[dict[str, Any]] = []
    kayip_var = {u["ulke"] for u in ulke_kayiplari}
    # Referans kayıp/kazanç oranı: kaybı VE kazancı tam modellenmiş, AB bölünmesinden bağımsız aktörler (İran, İsrail, Mısır).
    # Kaybı modelde OLMAYAN aktörlere bu oranla bir kayıp VEKİLİ atanır (sıfır yazmak "bilinmiyor"u sıfır sayardı).
    _ref_oran: list[float] = []
    for iso_, row_ in by_iso.items():
        if iso_ in REFERANS_ORAN and iso_ in kayip_var and float(row_["dis_kazanc_vekili"]) > 0:
            _ref_oran.append(float(row_["havza_kayip"]) / float(row_["dis_kazanc_vekili"]))
    _ref_oran.sort()
    r_min = _ref_oran[0] if _ref_oran else 0.0
    r_med = _ref_oran[len(_ref_oran) // 2] if _ref_oran else 0.0
    r_max = _ref_oran[-1] if _ref_oran else 0.0
    kapsam_aktor = {iso_ for iso_ in by_iso if kapsam is not None and iso_ not in kayip_var and iso_ != "TR"}
    dis_veri = _dis_veri_kayip(by_iso, kayip_var) if kapsam is not None else {}
    for iso, row in by_iso.items():
        dis_k = round(float(row["dis_kazanc_vekili"]), 3)
        havza_k = round(float(row["havza_kayip"]), 3)
        net_birlesik = round(dis_k - havza_k, 3)
        if iso in kapsam_aktor and dis_k > 0 and iso in dis_veri:
            # Dış veriden kayıp: oran, ledger'ın kullandığı kayip_referans_orani alanına AKTÖRE ÖZGÜ yazılır (kayıp = oran × kazanç)
            dvr = dis_veri[iso]
            k_min, k_med, k_max = (dvr["cekim"] * dvr[a] for a in ("phi_min", "phi_med", "phi_maks"))
            kayip_alanlari = {
                "havza_kayip_referans": round(k_med, 3),
                "kayip_referans_belirsizlik": round((k_max - k_min) / 2, 3),
                "net_birlesik_referansli": round(dis_k - k_med, 3),
                "kayip_referans_orani": {"min": round(k_min / dis_k, 3), "medyan": round(k_med / dis_k, 3), "maks": round(k_max / dis_k, 3)},
                "kayip_yontemi": "dis_veri_cekim",
                "kayip_dis_veri": {"cekim_tahmini": round(dvr["cekim"], 3), "cekim_hub_kuralsiz": round(dvr["cekim_hubsuz_kural"], 3), "hublar": dvr["hublar"], "phi": {"min": round(dvr["phi_min"], 3), "medyan": round(dvr["phi_med"], 3), "maks": round(dvr["phi_maks"], 3)}},
            }
        elif iso in kapsam_aktor and dis_k > 0:
            kayip_alanlari = {
                "havza_kayip_referans": round(r_med * dis_k, 3),
                "kayip_referans_belirsizlik": round((r_max - r_min) / 2 * dis_k, 3),
                "net_birlesik_referansli": round(dis_k - r_med * dis_k, 3),
                "kayip_referans_orani": {"min": round(r_min, 3), "medyan": round(r_med, 3), "maks": round(r_max, 3)},
                "kayip_yontemi": "referans_oran",
            }
        else:
            kayip_alanlari = {}
        out.append(
            {
                **row,
                **_kapsam_alanlari(iso, iso in kayip_var, kapsam),
                **_surdurme_alanlari(iso, dis_k, pol),
                **kayip_alanlari,
                "dis_kazanc_vekili": dis_k,
                "havza_kayip": havza_k,
                "merkez_belirsiz_vekil": round(float(row.get("merkez_belirsiz_vekil", 0.0)), 3),
                "net_birlesik_vekil": net_birlesik,
                "durum": (
                    "dis_kazanc"
                    if dis_k > havza_k + 0.05
                    else ("havza_kayip" if havza_k > dis_k + 0.05 else "nötr")
                ),
            }
        )
    for row in out:
        if "surdurme_maliyeti" in row:
            taban = row.get("net_birlesik_referansli", row["net_birlesik_vekil"])
            row["net_birlesik_maliyetli"] = round(taban - row["surdurme_maliyeti"], 3)
    out.sort(key=lambda x: -x["dis_kazanc_vekili"])
    return out


def _ulke_kayiplari(
    bolge_net: list[dict[str, Any]],
    ulke_doc: dict[str, Any],
    tr_net_zarar: float,
    ulke_by_bolge: dict[str, str] | None = None,
) -> list[dict[str, Any]]:
    pay_map = ulke_doc.get("bolge_ulke_pay") or {}
    names = ulke_doc.get("ulkeler") or {}
    acc: dict[str, dict[str, float]] = {}

    def _add(iso: str, key: str, val: float) -> None:
        acc.setdefault(iso, {})
        acc[iso][key] = acc[iso].get(key, 0.0) + val

    def _pay_rows(bid: str) -> list[dict[str, Any]]:
        rows = pay_map.get(bid)
        if rows:
            return rows
        iso = (ulke_by_bolge or {}).get(bid, "")
        if iso and iso not in ("MIX", "TR"):
            return [{"ulke": iso, "pay": 1.0}]
        return []

    for b in bolge_net:
        bid = b["bolge"]
        for row in _pay_rows(bid):
            iso = row["ulke"]
            p = float(row["pay"])
            _add(iso, "net_endeks", b["net_endeks"] * p)
            _add(iso, "pasif_bosluk", b["pasif_bosluk_dolgu"] * p)
            _add(iso, "aracsallasma", b["aracsallasma_zarar"] * p)
            _add(iso, "temsil_zedesi", b["mesruiyet_temsil_zedesi"] * p)
            _add(iso, "dis_mimari", b["dis_hegemon_mimari"] * p)

    _add("TR", "net_endeks", tr_net_zarar)
    _add("TR", "dominion_bosalma", abs(tr_net_zarar))

    out: list[dict[str, Any]] = []
    for iso, v in acc.items():
        net = round(v.get("net_endeks", 0.0), 3)
        kayip = round(max(0.0, -net), 3)
        fayda = round(max(0.0, net), 3)
        durum = "kayip" if kayip > 0.05 else ("fayda" if fayda > 0.05 else "nötr")
        out.append(
            {
                "ulke": iso,
                "ad": names.get(iso, iso),
                "net_endeks": net,
                "kayip_endeks": kayip,
                "fayda_endeks": fayda,
                "pasif_bosluk": round(v.get("pasif_bosluk", 0.0), 3),
                "aracsallasma": round(v.get("aracsallasma", 0.0), 3),
                "temsil_zedesi": round(v.get("temsil_zedesi", 0.0), 3),
                "dis_mimari": round(v.get("dis_mimari", 0.0), 3),
                "dominion_bosalma": round(v.get("dominion_bosalma", 0.0), 3),
                "durum": durum,
            }
        )
    out.sort(key=lambda x: -x["kayip_endeks"])
    return out


def run() -> dict[str, Any]:
    bolgeler_doc = _load("bolgeler.json")
    kanallar_doc = _load("kanallar.json")
    senaryolar_doc = _load("senaryolar.json")
    akis_doc = _load("bolge_akis.json")
    yerel_doc = _load("yerel_rant_kanal.json")
    dominion_doc = _load("dominion_bag.json")
    ulke_doc = _load("ulke_havza_pay.json")
    dis_doc = _load("dis_aktör_pay.json")
    ub_doc = _load("ulkeler_bolge.json")
    belirsiz_doc = _load("merkez_belirsiz.json")
    refah_path = DATA / "refah_rant_model.json"
    refah_doc = json.loads(refah_path.read_text(encoding="utf-8")) if refah_path.is_file() else None
    makro_doc = _load("makro_kapsam.json")
    makro_sira_pairs = _makro_sirasi(makro_doc)
    makro_sira_ids = [m[0] for m in makro_sira_pairs]

    kanallar = kanallar_doc["kanallar"]
    rol_carpan = kanallar_doc["rol_kanal_carpan"]
    ozel = kanallar_doc.get("bolge_ozel_carpan") or {}
    bolgeler = bolgeler_doc["bolgeler"]
    adlar = {b["id"]: b["ad"] for b in bolgeler}
    ulke_by_bolge = {b["id"]: b.get("ulke", "") for b in bolgeler}
    ikame = float(akis_doc.get("yaricevre_rakip_ikame_carpan", 0.55))

    kalibre_kullanildi = (KALIBRE / "bolgeler.json").is_file()
    referans = str(senaryolar_doc.get("referans_senaryo") or "C")
    sonuc: dict[str, Any] = {
        "olcum": "arti_deger_havza_dominion_10y",
        "referans_senaryo": referans,
        "kalibre_2024_ticaret": kalibre_kullanildi,
        "rant_modeli": "refah" if refah_doc and refah_doc.get("aktif") else "bosluk",
        "kaynak_tez": "data/etki_cephesi/KAYNAK_TEZ.md",
        "kaynak_konum": "data/etki_cephesi/KAYNAK_KONUM_ORTA_DOGU.md",
        "kanit_seviyesi": "C-D",
        "not": (
            "Bağ modu: kullanım / atıl / araçsallaşma. Net = ikame − sok − dış bağlanma − rant − temsil zedesi + kullanım telafisi. "
            "Dış sonuç TR merkezli değil; dis_hegemon_acmaz vekil."
        ),
        "horizon_yil": senaryolar_doc["horizon_yil"],
        "referans_olcum_not": senaryolar_doc.get("referans_olcum_not"),
        "makro_kapsam": makro_sira_pairs,
        "senaryolar": [],
    }

    for sen in senaryolar_doc["senaryolar"]:
        sid = sen["id"]
        ero = sen["etki_erosyon_carpani"]
        flex = sen["tr_diplomatik_flex"]
        merkez_c = float(_gecmis.merkez_carpan()[sid])  # geçmişten türetilmiş (A=1)
        bag_modu = sen.get("bag_modu") or {"kullanim": 0.3, "atil": 0.4, "aracsal": 0.3}
        kullanim = float(bag_modu.get("kullanim", 0.3))
        enigma_l = float(sen.get("enigma_carpan_levant", 1.0))
        bags = dominion_doc.get("bolge_bag") or {}
        cevher_pot, cevher_acik = _ceper_govde_acigi(bolgeler, dominion_doc, kullanim)
        kayiplar: dict[str, float] = {}
        bag_etki_by_id: dict[str, dict[str, float]] = {}
        tr_bosalma_satir = []

        for b in bolgeler:
            bid = b["id"]
            kayip, detay = _bolge_bosalma(b, kanallar, rol_carpan, ozel, ero, flex)
            kayip = round(kayip * _enigma_carp(b, enigma_l), 3)
            kayiplar[bid] = kayip
            bag_etki_by_id[bid] = _bag_modu_etkiler(
                b, bags.get(bid, {}), bag_modu, enigma_l, dominion_doc
            )
            tr_bosalma_satir.append(
                {"bolge": bid, "ad": b["ad"], "makro": b.get("makro"), "bosalma": kayip, "bes_halka": detay}
            )

        toplam = round(sum(kayiplar.values()), 3)
        (
            bolge_net,
            merkez,
            od_rant,
            od_dis,
            pasif_top,
            arac_top,
            mimari_top,
            temsil_top,
            kenarlar,
        ) = _bolgesel_dagilim(
            kayiplar, bag_etki_by_id, bolgeler, akis_doc, yerel_doc, ikame, merkez_c, sid, refah_doc
        )
        tum_rant = round(sum(b["rant_kanal_cikis_kar"] for b in bolge_net), 3)
        tum_dis = round(sum(b["yerel_dis_baglama_zarar"] for b in bolge_net), 3)
        merkez_toplam_rant_dahil = round(merkez + tum_rant, 3)
        tie_n = len(bolgeler)
        esz_ceza = float(dominion_doc.get("eszamanli_bag_ceza", 0.08))
        ic_tikanma = round(cevher_acik * tie_n * esz_ceza * (temsil_top / max(tie_n, 1)), 3)
        dis_acmaz = round(mimari_top + merkez * 0.35, 3)

        sonuc["senaryolar"].append(
            {
                "id": sid,
                "ad": sen["ad"],
                "aciklama": sen["aciklama"],
                "bag_modu": bag_modu,
                "ceper_potansiyel": cevher_pot,
                "ceper_govde_acigi": cevher_acik,
                "pasif_bosluk_toplam": pasif_top,
                "aracsallasma_toplam": arac_top,
                "dis_hegemon_mimari_toplam": mimari_top,
                "mesruiyet_temsil_zedesi_toplam": temsil_top,
                "ic_dinamik_tikanma": ic_tikanma,
                "dis_hegemon_acmaz_vekili": dis_acmaz,
                "turkiye_yaricevre_bosalma": toplam,
                "turkiye_net_zarar_endeks": -toplam,
                "merkez_finans_sizinti_toplam": merkez,
                "orta_dogu_rant_kanal_cikis_kar": od_rant,
                "orta_dogu_yerel_dis_baglama_zarar": od_dis,
                "tum_havza_rant_cikis_toplam": tum_rant,
                "tum_havza_dis_baglama_toplam": tum_dis,
                "merkez_artı_rant_cikis_toplam": merkez_toplam_rant_dahil,
                "tr_bosalma_detay": tr_bosalma_satir,
                "bolgesel_net": bolge_net,
                "makro_ozet": _makro_ozet(bolge_net, makro_sira_ids),
                "ulke_kayiplari": _ulke_kayiplari(
                    bolge_net, ulke_doc, -toplam, ulke_by_bolge
                ),
                "akis_kenarlari": kenarlar,
            }
        )
        dis_k = _dis_aktör_kazanc(
            kayiplar, bag_etki_by_id, kenarlar, dis_doc, ub_doc, ulke_by_bolge, refah_doc
        )
        sen_row = sonuc["senaryolar"][-1]
        sen_row["dis_aktör_kazanc"] = dis_k
        ulke_names = {**(ulke_doc.get("ulkeler") or {}), **(ub_doc.get("ulkeler") or {})}
        _merkez_belirsiz_dagit(
            sen_row,
            belirsiz_doc,
            ulke_names,
            list(dis_doc.get("aktörler") or []),
        )
        sen_row["aktör_birlesik"] = _aktör_birlesik(
            sen_row["ulke_kayiplari"],
            sen_row["dis_aktör_kazanc"],
            ulke_names,
            _kapsam(dis_doc, ub_doc),
            max(0.25, min(1.0, 1.05 - float(ero) + float(flex))),  # TR karşı-hamle gücü (pol_s)
        )

    sonuc["_adlar"] = adlar
    sonuc["_makro_sira"] = makro_sira_pairs
    sonuc["_ulke_gruplari"] = _makro_ulke_gruplari(bolgeler, ulke_doc, makro_sira_pairs)
    return sonuc


def _md(payload: dict[str, Any]) -> str:
    lines = [
        "# Artı değer — dominion bağı + bölünmüş çeper",
        "",
        f"**Ölçüm:** `{payload['olcum']}` | **Kanıt:** {payload['kanit_seviyesi']}",
        f"**Konum tezi:** `{payload.get('kaynak_konum', '')}`",
        "",
        payload["not"],
        "",
        "Atıl bağ → pasif boşluk. Araçsallaşma → dar çıkar ağı + meşruiyet/temsil zedesi. "
        "Kullanım → kısmi telafi (katmanlı oyun inşası vekili).",
        "",
    ]
    if payload.get("referans_olcum_not"):
        lines.append(f"*{payload['referans_olcum_not']}*")
        lines.append("")

    sira = sorted(payload["senaryolar"], key=lambda s: s["id"])  # A, B, C: sıra ayrıcalık değildir
    lines.extend(
        [
            "## Senaryo özeti (aynı alanlar)",
            "",
            "| Senaryo | TR boşalma | Merkez+rant Σ | MFIN kenar | Rant Σ |",
            "| --- | ---: | ---: | ---: | ---: |",
        ]
    )
    for sen in sira:
        lines.append(
            f"| {sen['id']} | {sen['turkiye_yaricevre_bosalma']} | {sen['merkez_artı_rant_cikis_toplam']} | "
            f"{sen.get('merkez_mfin_kenar_toplam', '—')} | {sen['tum_havza_rant_cikis_toplam']} |"
        )
    lines.extend(["", "Her senaryo için aynı ayrıntı: `SENARYO_RAPOR_{A,B,C}.md`, `SENARYO_KARSILASTIRMA.md`.", ""])
    for sen in sira:
        tag = ""
        lines.append(f"## Senaryo {sen['id']}: {sen['ad']}{tag}")
        lines.append("")
        lines.append(sen["aciklama"])
        lines.append("")
        bm = sen.get("bag_modu", {})
        lines.append(
            f"**Bağ modu (kullanım/atıl/araçsal):** {bm.get('kullanim')}/{bm.get('atil')}/{bm.get('aracsal')} | "
            f"**Çeper / gövde açığı:** {sen['ceper_potansiyel']} / {sen['ceper_govde_acigi']}"
        )
        lines.append(
            f"**Pasif boşluk:** {sen['pasif_bosluk_toplam']} | **Araçsallaşma:** {sen['aracsallasma_toplam']} | "
            f"**Temsil zedesi:** {sen['mesruiyet_temsil_zedesi_toplam']} | **Dış mimari:** {sen['dis_hegemon_mimari_toplam']}"
        )
        lines.append(
            f"**İç dinamik tıkanma:** {sen['ic_dinamik_tikanma']} | "
            f"**Dış hegemon açmaz (vekil):** {sen['dis_hegemon_acmaz_vekili']}"
        )
        lines.append(
            f"**TR boşalma:** {sen['turkiye_yaricevre_bosalma']} | "
            f"**Rant (OD+Levant+Körfez+Kuzey Af. alt küme):** {sen['orta_dogu_rant_kanal_cikis_kar']} | "
            f"**Tüm havza rant Σ:** {sen.get('tum_havza_rant_cikis_toplam', '—')}"
        )
        lines.append(
            f"**Dış bağlanma (alt küme / tüm Σ):** {sen['orta_dogu_yerel_dis_baglama_zarar']} / "
            f"{sen.get('tum_havza_dis_baglama_toplam', '—')} | "
            f"**Merkez sızıntı + rant Σ:** {sen['merkez_artı_rant_cikis_toplam']}"
        )
        lines.append(
            f"**MFIN kenar / belirsiz havuz / evren:** "
            f"{sen.get('merkez_mfin_kenar_toplam', '—')} / "
            f"{sen.get('merkez_belirsiz_havuz', '—')} / "
            f"{sen.get('merkez_belirsiz_ulke_sayisi', '—')} ülke × "
            f"{sen.get('merkez_belirsiz_pay_esit', '—')}"
        )
        lines.append("")
        lines.append("### Alt havza tablosu")
        lines.append("")
        lines.append(
            "| Bölge | Çeper | Atıl | Araçsal | Temsil z. | Dış mimari | Net |"
        )
        lines.append("| --- | --- | ---: | ---: | ---: | ---: | ---: |")
        for b in sen["bolgesel_net"]:
            lines.append(
                f"| {b['ad']} | {b.get('makro_ceper', '')} | {b['pasif_bosluk_dolgu']} | "
                f"{b['aracsallasma_zarar']} | {b['mesruiyet_temsil_zedesi']} | "
                f"{b['dis_hegemon_mimari']} | {b['net_endeks']} |"
            )
        lines.append("")
        lines.append("### Makro özet (tüm bölgeler, aynı kapsam)")
        lines.append("")
        lines.append(
            "| Makro | Havza | Net Σ | Boşalma Σ | Rant Σ | Dış bağ. Σ | Pasif Σ |"
        )
        lines.append("| --- | ---: | ---: | ---: | ---: | ---: | ---: |")
        for mo in sen.get("makro_ozet", []):
            mid = mo["makro"]
            ad = next((a for i, a in payload.get("makro_kapsam", []) if i == mid), mid)
            lines.append(
                f"| {ad} | {mo['havza_sayisi']} | {mo['net_toplam']} | {mo['tr_bosalma_toplam']} | "
                f"{mo['rant_cikis_toplam']} | {mo['dis_baglama_toplam']} | {mo['pasif_toplam']} |"
            )
        lines.append("")
        makro_pairs = payload.get("makro_kapsam") or _makro_sirasi(None)
        for mid, mad in makro_pairs:
            lines.extend(_md_makro_havza_detay(sen, mid, f"{mad} — havza detayı"))
        lines.append("### Rant kanalları (tüm havzalar)")
        lines.append("")
        for b in sen["bolgesel_net"]:
            if not b.get("rant_kanallar"):
                continue
            ch = ", ".join(b["rant_kanallar"])
            lines.append(
                f"- **{b['ad']}** ({b.get('makro', '')}): {ch} → {b['rant_kanal_cikis_kar']}"
            )
        lines.append("")
        lines.append("### Akış şeması (≥ 0,18)")
        lines.append("")
        lines.append(_mermaid(sen["akis_kenarlari"]))
        lines.append("")
        lines.append("### Ülke bazlı kayıp / fayda (10 yıl vekil)")
        lines.append("")
        lines.append(
            "| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil | Durum |"
        )
        lines.append("| --- | ---: | ---: | ---: | ---: | ---: | --- |")
        for u in sen.get("ulke_kayiplari", []):
            lines.append(
                f"| {u['ad']} | {u['kayip_endeks']} | {u['net_endeks']} | "
                f"{u['pasif_bosluk']} | {u['aracsallasma']} | {u['temsil_zedesi']} | {u['durum']} |"
            )
        lines.append("")
        lines.append("### Dış aktör kazanç (TR boşalması + ikame + merkez; vekil)")
        lines.append("")
        lines.append(
            "| Aktör | Kazanç Σ | Kanal | Matris | İkame | Merkez sız. | Belirsiz M* |"
        )
        lines.append("| --- | ---: | ---: | ---: | ---: | ---: | ---: |")
        for d in sen.get("dis_aktör_kazanc", []):
            lines.append(
                f"| {d['ad']} | {d['fayda_endeks']} | {d['kanal_kazanc']} | "
                f"{d['matris_kazanc']} | {d['ikame_kazanc']} | {d['merkez_sizinti']} | "
                f"{d.get('merkez_belirsiz_vekil', 0.0)} |"
            )
        lines.append("")
        lines.append("### Aktör birleşik (havza kaybı vs dış kazanç vekili)")
        lines.append("")
        lines.append(
            "| Aktör | Dış kazanç | Havza kayıp | Belirsiz M* | Net birleşik | Kapsam |"
        )
        lines.append("| --- | ---: | ---: | ---: | ---: | --- |")
        for a in sen.get("aktör_birlesik", [])[:25]:
            kaz, kay, net, kap = _gos_birlesik(a)
            lines.append(
                f"| {a['ad']} | {kaz} | {kay} | "
                f"{a.get('merkez_belirsiz_vekil', 0.0)} | {net} | {kap} |"
            )
        lines.append("")

    lines.append("## Dış aktör — kazanç vekili (A / B / C)")
    lines.append("")
    by_d: dict[str, dict[str, float]] = {}
    dnames: dict[str, str] = {}
    for sen in payload["senaryolar"]:
        sid = sen["id"]
        for d in sen.get("dis_aktör_kazanc", []):
            dnames[d["aktor"]] = d["ad"]
            by_d.setdefault(d["aktor"], {})[sid] = d["fayda_endeks"]
    lines.append("| Aktör | A | B | C |")
    lines.append("| --- | ---: | ---: | ---: |")
    for iso, nets in sorted(by_d.items(), key=lambda x: -(x[1].get("A", 0))):
        lines.append(
            f"| {dnames.get(iso, iso)} | {nets.get('A', '—')} | "
            f"{nets.get('B', '—')} | {nets.get('C', '—')} |"
        )
    lines.append("")

    lines.append("## Ülkeler — kayıp endeksi (A / B / C)")
    lines.append("")
    by_u: dict[str, dict[str, float]] = {}
    unames: dict[str, str] = {}
    for sen in payload["senaryolar"]:
        sid = sen["id"]
        for u in sen.get("ulke_kayiplari", []):
            unames[u["ulke"]] = u["ad"]
            by_u.setdefault(u["ulke"], {})[sid] = u["kayip_endeks"]
    lines.append("| Ülke | A | B | C |")
    lines.append("| --- | ---: | ---: | ---: |")
    for iso, nets in sorted(by_u.items(), key=lambda x: -(x[1].get("A", 0))):
        lines.append(
            f"| {unames.get(iso, iso)} | {nets.get('A', '—')} | "
            f"{nets.get('B', '—')} | {nets.get('C', '—')} |"
        )
    lines.append("")

    lines.append("## Global — üç senaryo özeti")
    lines.append("")
    lines.append("| | A | B | C |")
    lines.append("| --- | ---: | ---: | ---: |")
    keys = [
        ("Pasif boşluk (atıl)", "pasif_bosluk_toplam"),
        ("Araçsallaşma", "aracsallasma_toplam"),
        ("Meşruiyet/temsil zedesi", "mesruiyet_temsil_zedesi_toplam"),
        ("Dış hegemon mimarisi", "dis_hegemon_mimari_toplam"),
        ("İç dinamik tıkanma", "ic_dinamik_tikanma"),
        ("Dış açmaz vekili", "dis_hegemon_acmaz_vekili"),
        ("Rant (OD+Levant+Körfez+Kuzey Af.)", "orta_dogu_rant_kanal_cikis_kar"),
        ("TR boşalma toplam", "turkiye_yaricevre_bosalma"),
    ]
    for label, key in keys:
        row = [label]
        for sid in ("A", "B", "C"):
            v = next((s[key] for s in payload["senaryolar"] if s["id"] == sid), "—")
            row.append(str(v))
        lines.append("| " + " | ".join(row) + " |")
    lines.append("")

    makro_pairs = payload.get("makro_kapsam") or _makro_sirasi(None)
    makro_metrik = [
        ("Net endeks Σ", "net_toplam"),
        ("TR boşalma Σ", "tr_bosalma_toplam"),
        ("Rant çıkış Σ", "rant_cikis_toplam"),
        ("Dış bağlanma Σ", "dis_baglama_toplam"),
        ("Pasif Σ", "pasif_toplam"),
    ]
    for mid, mad in makro_pairs:
        lines.append(f"## {mad} — A / B / C (makro kapsam)")
        lines.append("")
        lines.append("| | A | B | C |")
        lines.append("| --- | ---: | ---: | ---: |")
        for label, field in makro_metrik:
            row = [label]
            for sid in ("A", "B", "C"):
                sen = next((s for s in payload["senaryolar"] if s["id"] == sid), None)
                if not sen:
                    row.append("—")
                    continue
                mo = next((x for x in sen.get("makro_ozet", []) if x["makro"] == mid), None)
                row.append(str(mo[field] if mo else "—"))
            lines.append("| " + " | ".join(row) + " |")
        lines.append("")
    return "\n".join(lines)


def _gos_birlesik(a: dict[str, Any]) -> tuple[str, str, str, str]:
    """(dış kazanç, havza kayıp, net, kapsam) metni. Bilinmeyen sıfır yazılmaz: '—'; kısmi '†'."""
    kz = a.get("kazanc_kapsam", "tam")
    ky = a.get("kayip_kapsam", "modellendi")
    kaz = "—" if kz == "yok" else (f"{a['dis_kazanc_vekili']}†" if kz == "kismi" else str(a["dis_kazanc_vekili"]))
    kay = "—" if ky == "bilinmiyor" else ("n/a" if ky == "tanimsiz" else str(a["havza_kayip"]))
    net_k = a.get("net_kapsam", "tam")
    net = str(a["net_birlesik_vekil"]) if net_k in ("tam", "tanimsiz") else "bilinmiyor"
    if "net_birlesik_referansli" in a:
        kay = f"≈{a['havza_kayip_referans']}‡"
        net = f"≈{a['net_birlesik_referansli']}‡ (±{a['kayip_referans_belirsizlik']})"
    kap = []
    if kz in ("kismi", "yok"):
        kap.append(f"kazanç {kz}")
    if ky == "bilinmiyor":
        kap.append("kayıp bilinmiyor")
    return kaz, kay, net, (", ".join(kap) or "tam")


def _senaryo_yan_raporlari(
    sen: dict[str, Any],
    sid: str,
    ulke_gruplari: list[tuple[str, list[str]]],
    referans: bool,
) -> None:
    baslik_etiket = sid
    if sen.get("ulke_kayiplari"):
        ua = [f"# Senaryo {baslik_etiket} — ülke bazlı kayıp (10 yıl vekil)", ""]
        ua.append("| Ülke | Kayıp endeks | Net | Pasif | Araçsal | Temsil |")
        ua.append("| --- | ---: | ---: | ---: | ---: | ---: |")
        for u in sen["ulke_kayiplari"]:
            ua.append(
                f"| {u['ad']} | {u['kayip_endeks']} | {u['net_endeks']} | "
                f"{u['pasif_bosluk']} | {u['aracsallasma']} | {u['temsil_zedesi']} |"
            )
        ua.append("")
        for baslik, kodlar in ulke_gruplari:
            ua.append(f"## {baslik}")
            ua.append("")
            ua.append("| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |")
            ua.append("| --- | ---: | ---: | ---: | ---: | ---: |")
            by_iso = {u["ulke"]: u for u in sen["ulke_kayiplari"]}
            for iso in kodlar:
                u = by_iso.get(iso)
                if not u:
                    continue
                ua.append(
                    f"| {u['ad']} | {u['kayip_endeks']} | {u['net_endeks']} | "
                    f"{u['pasif_bosluk']} | {u['aracsallasma']} | {u['temsil_zedesi']} |"
                )
            ua.append("")
        (OUT / f"ULKE_KAYIP_{sid}.md").write_text("\n".join(ua), encoding="utf-8")
    if sen.get("dis_aktör_kazanc"):
        da = [
            f"# Senaryo {baslik_etiket} — dış aktör kazanç (vekil)",
            "",
            "Kaynak: `dis_aktör_pay.json` + `ulkeler_bolge.json` + ikame + merkez sızıntı. "
            "`*` Belirsiz M = `merkez_belirsiz.json` eşit pay (fayda Σ'ye eklenmez).",
            "",
            f"MFIN kenar **{sen.get('merkez_mfin_kenar_toplam', '—')}** | "
            f"belirsiz havuz **{sen.get('merkez_belirsiz_havuz', '—')}** | "
            f"**{sen.get('merkez_belirsiz_ulke_sayisi', '—')}** ülke × "
            f"**{sen.get('merkez_belirsiz_pay_esit', '—')}**",
            "",
            "| Aktör | Kazanç Σ | Kanal | Matris | İkame | Merkez | Belirsiz M* |",
            "| --- | ---: | ---: | ---: | ---: | ---: | ---: |",
        ]
        for d in sen["dis_aktör_kazanc"]:
            da.append(
                f"| {d['ad']} | {d['fayda_endeks']} | {d['kanal_kazanc']} | "
                f"{d['matris_kazanc']} | {d['ikame_kazanc']} | {d['merkez_sizinti']} | "
                f"{d.get('merkez_belirsiz_vekil', 0.0)} |"
            )
        da.append("")
        da.append("## Birleşik (dış kazanç − havza kaybı)")
        da.append("")
        da.append("`—` = bilinmiyor (modellenmedi), sıfır değil. `†` = kısmi kapsam (kazancın yalnız bir kanalı modelli). `‡` = kayıp modelde yok; referans aktörlerin (İran, İsrail, Mısır) medyan kayıp/kazanç oranıyla VEKİL (± yarı aralık); Çin ve Rusya için kayıp dış ticaret verisinden (ihracat gelirinin ortak ülke kayıplarına duyarlılığı × referans aktörlerden kalibre φ). Net yalnız kazanç ve kayıp ikisi de tam modelliyse kesin yazılır.")
        da.append("")
        da.append("| Aktör | Dış kazanç | Havza kayıp | Belirsiz M* | Net | Kapsam | Durum |")
        da.append("| --- | ---: | ---: | ---: | ---: | --- | --- |")
        for a in sorted(
            sen.get("aktör_birlesik", []),
            key=lambda x: -x["net_birlesik_vekil"],
        ):
            kaz, kay, net, kap = _gos_birlesik(a)
            da.append(
                f"| {a['ad']} | {kaz} | {kay} | "
                f"{a.get('merkez_belirsiz_vekil', 0.0)} | {net} | {kap} | "
                f"{a['durum'] if net != 'bilinmiyor' else 'belirsiz'} |"
            )
        da.append("")
        (OUT / f"DIS_AKTOR_{sid}.md").write_text("\n".join(da), encoding="utf-8")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    payload = run()
    adlar = payload.pop("_adlar", {})
    ulke_gruplari = payload.pop("_ulke_gruplari", [])
    payload.pop("_makro_sira", None)
    clean = {k: v for k, v in payload.items() if not k.startswith("_")}
    (OUT / "PROJEKSIYON.json").write_text(json.dumps(clean, ensure_ascii=False, indent=2), encoding="utf-8")
    payload["_adlar"] = adlar
    (OUT / "PROJEKSIYON.md").write_text(_md(payload), encoding="utf-8")
    referans = str(clean.get("referans_senaryo") or "C")
    for sid in ("A", "B", "C"):
        sen = next((s for s in clean.get("senaryolar", []) if s["id"] == sid), None)
        if sen:
            _senaryo_yan_raporlari(sen, sid, ulke_gruplari, referans=(sid == referans))
    print(f"Wrote {OUT / 'PROJEKSIYON.md'} (referans: {referans})")


if __name__ == "__main__":
    main()
