"""Ölü ağırlığı gerçek yıkım ve ölçüm boşluğu diye ayır.

Ölü ağırlık D = kayıp havuzu (TR kaybı + diğer kayıp) − V ile sınırlı kazanç. Üç ayrı kaynak:
  (a) V içi dağıtılmayan: V − kazanç − havza girişi (K1 sonrası ≈ 0). Alıcısı olan ama atanmayan kısım → ÖLÇÜM BOŞLUĞU (kesin).
  (b) TR'nin boşalma dışı kaybı (pasif boşluk, araçsallaşma, temsil zedesi, mimari): model gereği alıcısı yok → GERÇEK YIKIM.
  (c) Havza kaybı ('diger'): gross bileşenlere (bolgesel_net) oranlanır; V'nin pasif payı (0,08 × pasif) düşülür:
        - tampon/koridor şoku, mesruiyet temsil zedesi, kullanım telafi maliyeti: alıcısı olmayan zarar → GERÇEK YIKIM.
        - rant kanalı çıkışı: defterde alıcısı belli (dış havuz) ama V ile sınırlı kazanca girmiyor → ÖLÇÜM BOŞLUĞU (alıcı belli).
        - yerel dış bağlama zararı: dış bağlayıcı aktörlere gidiyor olabilir ama rota modellenmedi → BELİRSİZ (alıcı muhtemel).
Sınıflama doğal-tür varsayımıdır (ölçülmüş değil); bu yüzden belirsiz kova ayrıca verilir ve iki uç aralık hesaplanır.
Ek tanı: ham kazanç V'yi aştıysa (normalizasyon) D'nin ham kazançla değeri. (Rakip ikame çift sayımı K1 ile giderildi: bkz. ikame_cift_sayim.py.)
Tanı raporu: başka modüle girdi olmaz (döngü yok).
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"
YIKIM_TURLERI = ("tampon_koridor_sok", "mesruiyet_temsil_zedesi", "kullanim_telafi")  # alıcısız zarar
ALICI_BELLI = ("rant_kanal_cikis_kar",)
BELIRSIZ = ("yerel_dis_baglama_zarar",)


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def dis_baglama_tasinabilirlik(p: dict[str, Any]) -> dict[str, Any]:
    """Dış bağlama zararı ülke bazında USD'ye çevrilir (BoP ve rant köprüsü) ve ülkenin brüt birincil gelir ödemesiyle sınırlanır:
    ülke, gelir ödemesinden fazlasını bu kanaldan dışarı aktaramaz. Verisi olmayan ülkeler sınırlanmaz.
    f = Σ min(zarar_c, ödeme_c) / Σ zarar_c: belirsiz kovanın gelir ödemesiyle taşınabilecek en çok payı (üst sınır, alıcı kanıtı değil)."""
    hp = _load(DATA / "ulke_havza_pay.json")["bolge_ulke_pay"]
    odeme = _load(DATA / "gozlem" / "bolge_birincil_gelir_odemesi.json")["ulke_odeme_mn_usd"]
    kop = _load(DATA / "kalibre" / "gerceklik_realizasyon.json")["usd_kopruleri"]
    dz: dict[str, float] = {}
    for b in p["bolgesel_net"]:
        for u in hp.get(b["bolge"], []):
            if u["ulke"] != "TR":
                dz[u["ulke"]] = dz.get(u["ulke"], 0.0) + float(u["pay"]) * float(b["yerel_dis_baglama_zarar"])
    out = {}
    for ad, k in (("bop_koprusu", "bop_merkez_rant"), ("rant_koprusu", "tum_havza_rant")):
        usd = float(kop[k]["usd_per_vekil_mn"])
        tasinabilir = sum(min(v * usd, odeme[c]["usd_mn"]) if c in odeme else v * usd for c, v in dz.items())
        toplam = sum(v * usd for v in dz.values())
        out[ad] = round(tasinabilir / toplam, 3)
    out["sinirlanan_ulkeler"] = sorted(c for c, v in dz.items() if c in odeme and v * float(kop["tum_havza_rant"]["usd_per_vekil_mn"]) > odeme[c]["usd_mn"])
    out["verisiz_ulkeler"] = sorted(c for c in dz if c not in odeme)
    return out


def ayristir(sid: str, m: dict[str, Any], p: dict[str, Any]) -> dict[str, Any]:
    bn = p["bolgesel_net"]
    brut = {k: sum(abs(float(b[k])) for b in bn) for k in YIKIM_TURLERI + ALICI_BELLI + BELIRSIZ}
    top_brut = sum(brut.values())
    kayip, kazanc = m["kayip"], m["kazanc"]
    havuz, kaz = float(kayip["toplam"]), float(kazanc["toplam"])
    d = havuz - kaz
    v = float(m["bosluk_V"])
    # K1 sonrası V; aktör kazancı + havza girişi (rakip ikame, havza net'inde iç kazanç olarak düşülmüş) arasında paylaşılır.
    # Dağıtılmayan = V − kazanç − havza girişi (≈ 0). 'diger' havza girişi düşülmüş net olduğundan, ölü ağırlıkta geri eklenir (D = havuz − kazanç).
    ig = sum(float(b["rakip_ikame_gelen"]) for b in bn)
    v_ici = v - kaz - ig
    tr_disi = float(kayip["tr"]) - float(m["tr_bosalma"])
    pasif_pay = v - float(m["tr_bosalma"])
    diger_eff = float(kayip["diger"]) - pasif_pay + ig
    pay = {k: v_ / top_brut for k, v_ in brut.items()}
    yikim_diger = diger_eff * sum(pay[k] for k in YIKIM_TURLERI)
    alici_belli = diger_eff * sum(pay[k] for k in ALICI_BELLI)
    belirsiz = diger_eff * sum(pay[k] for k in BELIRSIZ)
    yikim = tr_disi + yikim_diger
    bosluk = v_ici + alici_belli
    ham = float(m["normalizasyon"]["ham_toplam"])
    kap = dis_baglama_tasinabilirlik(p)
    f_max = max(kap["bop_koprusu"], kap["rant_koprusu"])
    return {
        "dis_baglama_gelir_odemesi_siniri": kap,
        "gercek_yikim_aralik_kapasite_sinirli": [round(yikim + belirsiz * (1 - f_max), 3), round(yikim + belirsiz, 3)],
        "olcum_boslugu_aralik_kapasite_sinirli": [round(bosluk, 3), round(bosluk + belirsiz * f_max, 3)],
        "gercek_yikim_pay_aralik_kapasite_sinirli": [round((yikim + belirsiz * (1 - f_max)) / d, 3), round((yikim + belirsiz) / d, 3)],
        "olcum_boslugu_pay_aralik_kapasite_sinirli": [round(bosluk / d, 3), round((bosluk + belirsiz * f_max) / d, 3)],
        "olu_agirlik": round(d, 3),
        "kayip_havuzu": round(havuz, 3),
        "kazanc_v_sinirli": round(kaz, 3),
        "bilesenler": {
            "v_ici_dagitilmayan": round(v_ici, 3),
            "tr_bosalma_disi_kayip": round(tr_disi, 3),
            "havza_alicisiz_zarar": round(yikim_diger, 3),
            "havza_alicisi_belli_rant_cikisi": round(alici_belli, 3),
            "havza_dis_baglama_belirsiz": round(belirsiz, 3),
            "v_pasif_pay_dusuldu": round(pasif_pay, 3),
            "havza_girisi_geri_eklendi": round(ig, 3),
        },
        "gercek_yikim_alt": round(yikim, 3),
        "olcum_boslugu_alt": round(bosluk, 3),
        "belirsiz": round(belirsiz, 3),
        "gercek_yikim_aralik": [round(yikim, 3), round(yikim + belirsiz, 3)],
        "olcum_boslugu_aralik": [round(bosluk, 3), round(bosluk + belirsiz, 3)],
        "gercek_yikim_pay_aralik": [round(yikim / d, 3), round((yikim + belirsiz) / d, 3)],
        "olcum_boslugu_pay_aralik": [round(bosluk / d, 3), round((bosluk + belirsiz) / d, 3)],
        "ham_kazanc_toplam": round(ham, 3),
        "olu_agirlik_ham_kazanc": round(havuz - ham, 3),
        "normalizasyon_katsayi": m["normalizasyon"]["katsayi"],
        "brut_bilesen_paylari": {k: round(v_, 3) for k, v_ in pay.items()},
    }


def calistir() -> dict[str, Any]:
    muh = {s["id"]: s for s in _load(OUT / "KAZANC_KAYIP_MUHASEBE.json")["senaryolar"]}
    proj = {s["id"]: s for s in _load(OUT / "PROJEKSIYON.json")["senaryolar"]}
    sen = {sid: ayristir(sid, muh[sid], proj[sid]) for sid in ("A", "B", "C")}
    d = {
        "olcum": "olu_agirlik_ayrisma",
        "etiket": "tani_girdi_degil",
        "senaryolar": sen,
        "not": "Sınıflama bileşen türüne göre (alıcısız zarar / alıcısı belli rant / dış bağlama belirsiz); dış bağlama kovası alt ve üst uçları verir. Ölçülmüş bir ayrım değil.",
    }
    (OUT / "OLU_AGIRLIK_AYRISMA.json").write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    L = ["# Ölü ağırlık: gerçek yıkım ve ölçüm boşluğu", "", d["not"], "",
         "| Senaryo | Ölü ağırlık | Gerçek yıkım (alt) | Ölçüm boşluğu (alt) | Belirsiz (dış bağlama) | Yıkım payı aralığı | Ölçüm boşluğu payı aralığı |",
         "| --- | ---: | ---: | ---: | ---: | --- | --- |"]
    for sid, s in sen.items():
        a, b = s["gercek_yikim_pay_aralik"], s["olcum_boslugu_pay_aralik"]
        L.append(f"| {sid} | {s['olu_agirlik']:.2f} | {s['gercek_yikim_alt']:.2f} | {s['olcum_boslugu_alt']:.2f} | {s['belirsiz']:.2f} | %{a[0]*100:.0f} – %{a[1]*100:.0f} | %{b[0]*100:.0f} – %{b[1]*100:.0f} |")
    L += ["", "## Dış bağlama kovasının gelir ödemesi kapasitesiyle daraltılması", "",
          "Ülkenin brüt birincil gelir ödemesinden (WDI) fazlası bu kanaldan aktarılamaz; bu yalnız üst sınırdır (kanıt değil).", "",
          "| Senaryo | Taşınabilir pay f (BoP / rant köprüsü) | Sınırlanan ülkeler | Gerçek yıkım payı | Ölçüm boşluğu payı |", "| --- | --- | --- | --- | --- |"]
    for sid, s in sen.items():
        k, a, b = s["dis_baglama_gelir_odemesi_siniri"], s["gercek_yikim_pay_aralik_kapasite_sinirli"], s["olcum_boslugu_pay_aralik_kapasite_sinirli"]
        L.append(f"| {sid} | {k['bop_koprusu']} / {k['rant_koprusu']} | {', '.join(k['sinirlanan_ulkeler']) or '—'} (verisiz: {', '.join(k['verisiz_ulkeler']) or '—'}) | %{a[0]*100:.0f} – %{a[1]*100:.0f} | %{b[0]*100:.0f} – %{b[1]*100:.0f} |")
    L += ["", "## Bileşenler", "", "| Senaryo | V içi dağıtılmayan | TR boşalma dışı kayıp | Havza alıcısız zarar | Havza rant çıkışı (alıcı belli) | Havza dış bağlama (belirsiz) |", "| --- | ---: | ---: | ---: | ---: | ---: |"]
    for sid, s in sen.items():
        c = s["bilesenler"]
        L.append(f"| {sid} | {c['v_ici_dagitilmayan']:.2f} | {c['tr_bosalma_disi_kayip']:.2f} | {c['havza_alicisiz_zarar']:.2f} | {c['havza_alicisi_belli_rant_cikisi']:.2f} | {c['havza_dis_baglama_belirsiz']:.2f} |")
    L += ["", "## Duyarlılık: kazancın nasıl sayıldığı ölü ağırlığı değiştirir", "", "| Senaryo | D (V sınırlı) | D (ham kazanç, V sınırı yok) | Normalizasyon katsayısı |", "| --- | ---: | ---: | ---: |"]
    for sid, s in sen.items():
        L.append(f"| {sid} | {s['olu_agirlik']:.2f} | {s['olu_agirlik_ham_kazanc']:.2f} | {s['normalizasyon_katsayi']} |")
    (OUT / "OLU_AGIRLIK_AYRISMA.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    return d


if __name__ == "__main__":
    calistir()
    print("OLU_AGIRLIK_AYRISMA ok")
