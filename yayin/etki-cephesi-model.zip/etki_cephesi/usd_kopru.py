"""Çoklu USD köprüleri: merkez+rant (BoP), tum_havza_rant, mal net ticaret."""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
KALIBRE = DATA / "kalibre"
KOPRU_CFG = KALIBRE / "usd_kopruleri.json"
EMPIRIK = DATA / "empirik" / "tr_finans_akisi_2024.json"


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _vekil_usd(vekil: float, usd_cicek: float, vekil_toplam: float) -> float:
    if vekil_toplam <= 0:
        return 0.0
    return round(vekil * (usd_cicek / vekil_toplam), 1)


def hesapla(
    *,
    cicek_usd_mn: float,
    merkez_rant_vekil: float,
    rant_top_vekil: float,
    bosalma_vekil: float,
    net_ticaret_usd_mn: float,
    cfg: dict[str, Any] | None = None,
) -> dict[str, Any]:
    cfg = cfg or _load(KOPRU_CFG)
    bir = cfg["birincil"]
    rant_cfg = cfg["tum_havza_rant"]
    mal_cfg = cfg["mal_yapisal_kayip"]

    bop_k = cicek_usd_mn / merkez_rant_vekil if merkez_rant_vekil > 0 else 0.0
    rant_usd_cicek = cicek_usd_mn * float(rant_cfg.get("birincil_gelir_carpan", 0.32))
    rant_k = rant_usd_cicek / rant_top_vekil if rant_top_vekil > 0 else bop_k
    mal_usd = abs(float(net_ticaret_usd_mn))
    mal_k = mal_usd / bosalma_vekil if bosalma_vekil > 0 else bop_k

    kopruler = {
        "bop_merkez_rant": {
            "cicek_satir": bir["cicek_satir"],
            "cicek_usd_mn": cicek_usd_mn,
            "vekil_payda": bir["vekil_payda"],
            "vekil_payda_deger": merkez_rant_vekil,
            "usd_per_vekil_mn": round(bop_k, 2),
            "not": "usd = vekil × (yatırım geliri gideri / merkez+rant)",
        },
        "tum_havza_rant": {
            "usd_cicek_mn": round(rant_usd_cicek, 1),
            "vekil_payda": rant_cfg["vekil_payda"],
            "vekil_payda_deger": rant_top_vekil,
            "usd_per_vekil_mn": round(rant_k, 2),
            "not": rant_cfg.get("not"),
        },
        "mal_net_ticaret": {
            "usd_cicek_mn": mal_usd,
            "vekil_payda": mal_cfg["vekil_payda"],
            "vekil_payda_deger": bosalma_vekil,
            "usd_per_vekil_mn": round(mal_k, 2),
            "not": mal_cfg.get("not"),
        },
    }

    return {
        "cfg": str(KOPRU_CFG.relative_to(REPO)),
        "kopruler": kopruler,
    }


def tr_net_usd_coklu(tr_net_vekil: float, kopruler: dict[str, Any]) -> dict[str, Any]:
    v = abs(float(tr_net_vekil))
    out: dict[str, float] = {}
    for key, row in kopruler.items():
        k = float(row["usd_per_vekil_mn"])
        out[key] = round(v * k, 1)
    vals = [x for x in out.values() if x > 0]
    orta = round(math.exp(sum(math.log(x) for x in vals) / len(vals)), 1) if vals else 0.0
    return {**out, "geometrik_orta_mn": orta}


def from_akis_olcum(akis: dict[str, Any], bosalma_vekil: float | None = None) -> dict[str, Any]:
    mv = akis.get("model_vekil") or {}
    mal = akis.get("mal_akisi_usd_mn") or {}
    bos = bosalma_vekil
    if bos is None:
        bos = float(mv.get("turkiye_yaricevre_bosalma") or 0.0)
    base = hesapla(
        cicek_usd_mn=float(akis.get("cicek_usd_mn") or 0.0),
        merkez_rant_vekil=float(mv.get("merkez_artı_rant_cikis_toplam") or 1.0),
        rant_top_vekil=float(mv.get("tum_havza_rant_cikis_toplam") or 1.0),
        bosalma_vekil=float(bos or 1.0),
        net_ticaret_usd_mn=float(mal.get("net_ticaret") or 0.0),
    )
    return base
