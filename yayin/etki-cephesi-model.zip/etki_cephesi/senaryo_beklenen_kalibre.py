"""P2+: A/B/C kalibre yol + olasılık ağırlıklı beklenen TR net (yaşam maliyeti senaryo uygunluğu)."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
KALIBRE = DATA / "kalibre"
OUT = REPO / "reports" / "etki_cephesi"

if str(REPO / "etki_cephesi") not in sys.path:
    sys.path.insert(0, str(REPO / "etki_cephesi"))

from senaryo_gerceklik_kalibre import kalibre_yigin_refah  # noqa: E402
from usd_kopru import tr_net_usd_coklu  # noqa: E402


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _politika_uygunluk(sen: dict[str, Any]) -> float:
    er = float(sen.get("etki_erosyon_carpani") or 0.4)
    flex = float(sen.get("tr_diplomatik_flex") or 0.0)
    return round(max(0.25, min(1.0, 1.05 - er + flex)), 3)


def hesapla(senaryolar: tuple[str, ...] = ("A", "B", "C")) -> dict[str, Any]:
    capa = _load(KALIBRE / "gerceklik_capa.json")
    proj = _load(OUT / "PROJEKSIYON.json")
    akis = _load(OUT / "AKIS_OLCUM.json")
    fin = _load(OUT / "FINANS_KATMAN.json")
    sen_doc = _load(DATA / "senaryolar.json")
    yasam = _load(OUT / "YASAM_MALIYET_KATMAN.json") if (OUT / "YASAM_MALIYET_KATMAN.json").is_file() else {}
    coklu = _load(OUT / "SENARYO_COKLU_P2.json") if (OUT / "SENARYO_COKLU_P2.json").is_file() else None

    yasam_iy = float(yasam.get("iyilesme_vekil") or 0.0)
    yasam_gsyh = float(yasam.get("gsyh_yuzde_orta_son") or 0.0)
    kopruler = _load(OUT / "GERCEKLIK_KALIBRE.json").get("usd_kopruleri") or {}

    satirlar: list[dict[str, Any]] = []
    olas: dict[str, float] = {}
    for s in sen_doc.get("senaryolar") or []:
        olas[str(s["id"])] = float(s.get("olasilik_vekili") or 0.0)
    s_olas = sum(olas.values()) or 1.0
    olas = {k: v / s_olas for k, v in olas.items()}

    for sid in senaryolar:
        path = OUT / f"DIS_ULKE_REFAH_{sid}.json"
        if not path.is_file() and sid == "C":
            path = OUT / "DIS_ULKE_REFAH.json"
        refah = _load(path) if path.is_file() else None
        sen = next(s for s in sen_doc["senaryolar"] if s["id"] == sid)
        yigin = kalibre_yigin_refah(proj, refah, fin, capa, akis, senaryo=sen)
        pol = _politika_uygunluk(sen)
        tr_katman = float(yigin["tr_net_yol_10_son"])
        tr_yasam = round(tr_katman + yasam_iy * pol, 3)
        gsyh_k = float(yigin["gsyh_yuzde_son"])
        kp = yigin["usd_kopruleri"]
        gsyh_mn = float(yigin["gsyh_usd_mn"])
        gsyh_y = round(tr_net_usd_coklu(tr_yasam, kp)["geometrik_orta_mn"] / gsyh_mn * 100, 3)
        if sid == "C" and yasam:
            gsyh_y = yasam_gsyh
        satirlar.append(
            {
                "id": sid,
                "olasilik": round(olas.get(sid, 0.0), 4),
                "tr_c_refah": yigin["tr_c_refah"],
                "tr_net_katman_10y": tr_katman,
                "tr_net_10y_yasam_dahil": tr_yasam,
                "politika_uygunluk": pol,
                "gsyh_yuzde_orta_katman": gsyh_k,
                "gsyh_yuzde_orta_10y": gsyh_y,
                "sifir_nokta": yigin["sifir_nokta_takvim"],
            }
        )

    def ew(key: str) -> float:
        return round(sum(r["olasilik"] * float(r[key]) for r in satirlar), 3)

    tr_exp = ew("tr_net_10y_yasam_dahil")
    gsyh_exp = ew("gsyh_yuzde_orta_10y")
    usd_exp = tr_net_usd_coklu(tr_exp, kopruler) if kopruler else {}

    beklenti_modul = (coklu or {}).get("beklenti") or {}

    return {
        "olcum": "senaryo_beklenen_kalibre_p2plus",
        "senaryolar": satirlar,
        "beklenti": {
            "olasilik": {r["id"]: r["olasilik"] for r in satirlar},
            "beklenen_tr_net_10y_yasam": tr_exp,
            "beklenen_tr_net_katman_10y": ew("tr_net_katman_10y"),
            "beklenen_tr_net_entegre": beklenti_modul.get("beklenen_tr_net_entegre"),
            "beklenen_refah_dis_usd_mn": beklenti_modul.get("beklenen_refah_dis_usd_mn"),
            "beklenen_gsyh_yuzde_orta_10y": gsyh_exp,
            "beklenen_usd_mn_orta": round(usd_exp.get("geometrik_orta_mn", 0.0), 1) if usd_exp else None,
        },
        "not": "Katman yolu = senaryo defteri tabanı + ortak gerçekleşme tavanları; yaşam maliyeti × politika_uygunluk.",
        "kaynak": [
            "DIS_ULKE_REFAH_{A,B,C}.json",
            "GERCEKLIK_KALIBRE.json",
            "YASAM_MALIYET_KATMAN.json",
            "SENARYO_COKLU_P2.json",
        ],
    }


def _md(d: dict[str, Any]) -> str:
    b = d["beklenti"]
    lines = [
        "# Beklenen senaryo — kalibre (P2+)",
        "",
        "| Senaryo | P | TR taban | TR 10y katman | TR 10y + yaşam | GSYH % |",
        "| --- | ---: | ---: | ---: | ---: | ---: |",
    ]
    for r in d["senaryolar"]:
        lines.append(
            f"| **{r['id']}** | {r['olasilik']} | {r['tr_c_refah']} | {r['tr_net_katman_10y']} | "
            f"{r['tr_net_10y_yasam_dahil']} | {r['gsyh_yuzde_orta_10y']} |"
        )
    lines.extend(
        [
            "",
            "## Olasılık ağırlıklı",
            "",
            f"- Beklenen TR net (10y, yaşam dahil): **{b['beklenen_tr_net_10y_yasam']}** vekil",
            f"- Beklenen GSYH % orta: **{b['beklenen_gsyh_yuzde_orta_10y']}**",
            f"- Beklenen refah dış USD: **{b.get('beklenen_refah_dis_usd_mn')}** mn/yıl",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    data = hesapla()
    (OUT / "SENARYO_BEKLENEN_KALIBRE.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "SENARYO_BEKLENEN_KALIBRE.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'SENARYO_BEKLENEN_KALIBRE.md'}")


if __name__ == "__main__":
    main()
