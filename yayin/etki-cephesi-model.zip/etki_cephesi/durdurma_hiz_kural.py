"""Durdurma hızını belirleyen ÖLÇÜLEBİLİR kurallar (aktör ve halka bazlı değil, tek durum d).

Beş halka (üretim/koordinasyon/para sızıntısı/zarar aktarımı/dış kısıt) katmandır, hız modeli değil: burada kullanılmaz.
Zarar aktarımı stok-akış (SFC) hesabında kalır: akış = sabit kayıp + boşalma·(1−d) (durdurma_yolu_kural.akis).
Ölçülemeyen kurallar (dönüt, güven, tampon süresi, ücret-kredi bağı, başarı tanımı) bilerek dışarıda bırakıldı.

Kurallar:
  R1 finansman gereği: rezervin 10 yıl dayanması için gereken en küçük hız çarpanı m* (köprü başına).
  R2 gözlenen kapasite tavanı: katmanların gözlenen gerçekleşme oranlarından (en iyi / ortalama / en kötü).
  R3 mali alan: kapasite (1 − faiz/gelir) ile ölçeklenir; yol veri eğiminden uzatılır.
"""
from __future__ import annotations

import json
import statistics as st
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
import durdurma_yolu_kural as D  # noqa: E402

DATA, OUT, KOPRULER = D.DATA, D.OUT, D.KOPRULER


def simule(b: float, m_yol: list[float]) -> list[float]:
    d, yol = 0.0, []
    for m in m_yol:
        d = d + min(1.0, b * m) * (1.0 - d)
        yol.append(d)
    return yol


def kalibre(d_cal: list[float]) -> dict[str, Any]:
    n, hedef = len(d_cal), d_cal[-1]
    lo, hi = 1e-6, 5.0
    for _ in range(100):
        mid = (lo + hi) / 2
        if simule(mid, [1.0] * n)[-1] < hedef:
            lo = mid
        else:
            hi = mid
    b = (lo + hi) / 2
    yol = simule(b, [1.0] * n)
    rmse = (sum((x - y) ** 2 for x, y in zip(yol, d_cal)) / n) ** 0.5
    return {"b": b, "rmse": rmse, "yol": yol}


def gereken_m(G: dict[str, Any], b: float, n: int, ust: float = 50.0) -> dict[str, float | None]:
    out: dict[str, float | None] = {}
    for k in KOPRULER:
        def tukenir(m: float) -> bool:
            return D.akis(G, simule(b, [m] * n))[k]["rezerv_tukenme_yili"] is not None

        if not tukenir(1.0):
            out[k] = 1.0
        elif tukenir(ust):
            out[k] = None
        else:
            lo, hi = 1.0, ust
            for _ in range(40):
                mid = (lo + hi) / 2
                lo, hi = (mid, hi) if tukenir(mid) else (lo, mid)
            out[k] = round(hi, 2)
    return out


def faiz_yolu(seri: dict[str, float], yillar: list[int], mod: str) -> list[float]:
    ks = sorted(seri)
    son = seri[ks[-1]]
    egim = (son - seri["2022-12"]) / (int(ks[-1][:4]) + int(ks[-1][5:7]) / 12 - 2022 - 1.0)
    if mod == "sabit":
        return [son] * len(yillar)
    return [min(0.5, son + egim * (i + 1)) for i in range(len(yillar))]


def calistir() -> dict[str, Any]:
    G = D._girdiler()
    n = len(G["d_cal"])
    kal = kalibre(G["d_cal"])
    real = json.loads((DATA / "kalibre" / "gerceklik_realizasyon.json").read_text(encoding="utf-8"))["gerceklesme_oranlari"]
    kat = {k: float(real[k]) for k in ("zarar_teorisi", "uretim_ic_akis", "finans_katman")}
    g_ort = st.mean(kat.values())
    m_kap = {"en_kotu_katman": min(kat.values()) / g_ort, "ortalama": 1.0, "en_iyi_katman": max(kat.values()) / g_ort}
    faiz = json.loads((DATA / "gozlem" / "butce_faiz_gelir.json").read_text(encoding="utf-8"))
    r_ref = float(faiz["seri"][faiz["son_donem"]])
    gerek = gereken_m(G, kal["b"], n)
    yillar = G["yillar"]
    sen: dict[str, Any] = {}
    for fm in ("sabit", "veri_egimi"):
        r_yol = faiz_yolu(faiz["seri"], yillar, fm)
        k_faiz = [(1 - r) / (1 - r_ref) for r in r_yol]
        for ad, mk in m_kap.items():
            m_yol = [mk * k for k in k_faiz]
            d = simule(kal["b"], m_yol)
            fin = D.akis(G, d)
            sen[f"{ad}__faiz_{fm}"] = {
                "kapasite_m": round(mk, 3), "faiz_gelir_son_yil": round(r_yol[-1], 4), "mali_alan_carpani_son_yil": round(k_faiz[-1], 3),
                "d_son": round(d[-1], 4), "d_yol": [round(x, 3) for x in d],
                "rezerv_tukenme_yili": {k: fin[k]["rezerv_tukenme_yili"] for k in KOPRULER},
            }
    d_all = {
        "olcum": "durdurma_hiz_kural_olculebilir", "etiket": "tani_girdi_degil",
        "kalibrasyon": {"b": round(kal["b"], 5), "rmse_d": round(kal["rmse"], 5), "d_kalibre_yol": [round(x, 4) for x in G["d_cal"]], "d_kural_yolu": [round(x, 4) for x in kal["yol"]], "yillar": yillar},
        "R1_gereken_m_rezerv_dayansin": gerek,
        "R2_gozlenen_kapasite": {"katman_gerceklesme": {k: round(v, 4) for k, v in kat.items()}, "ortalama": round(g_ort, 4), "m_kapasite": {k: round(v, 3) for k, v in m_kap.items()}},
        "R3_mali_alan": {"faiz_gelir_son": r_ref, "donem": faiz["son_donem"], "seri": faiz["seri"]},
        "senaryolar": sen,
        "disarida_birakilan": ["dönüt kuralı", "güven kapısı", "tampon/geciktirme süresi", "ücret–kredi bağı", "başarı tanımı (H1 ölçütü)"],
        "not": "Beş halka katmandır, kullanılmadı; zarar aktarımı stok-akışta (akış = sabit kayıp + boşalma·(1−d)). Kapasite tavanı gözlenen katman gerçekleşme oranlarından; 'tüm katmanlar en iyi katman kadar hızlı' iyimser üst sınırdır. Kurallar yön ve gerek/yeter karşılaştırması verir, tahmin vermez.",
    }
    (OUT / "DURDURMA_HIZ_KURAL.json").write_text(json.dumps(d_all, ensure_ascii=False, indent=2), encoding="utf-8")
    L = ["# Durdurma hızını belirleyen ölçülebilir kurallar", "", d_all["not"], "",
         f"Tek durum d; hız sabiti b = {d_all['kalibrasyon']['b']} (m = 1 kalibre C yolunu üretir; RMSE {d_all['kalibrasyon']['rmse_d']}).", "",
         "## R1 Finansman gereği: rezerv 10 yıl dayansın diye gereken hız çarpanı m*", "",
         ", ".join(f"{k}: {v if v is not None else 'ulaşılamaz'}" for k, v in gerek.items()), "",
         "## R2 Gözlenen kapasite (katman gerçekleşme oranlarından)", "",
         "Katman oranları: " + ", ".join(f"{k} {v}" for k, v in d_all["R2_gozlenen_kapasite"]["katman_gerceklesme"].items()) + f"; ortalama {d_all['R2_gozlenen_kapasite']['ortalama']}.",
         "Kapasite çarpanı: " + ", ".join(f"{k} {v}" for k, v in d_all["R2_gozlenen_kapasite"]["m_kapasite"].items()), "",
         f"## R3 Mali alan: faiz/gelir {r_ref:.3f} ({faiz['son_donem']}); kapasite (1 − faiz/gelir) ile ölçeklenir", "",
         "| Senaryo | m kapasite | faiz/gelir son yıl | mali alan çarpanı | d(son) | Rezerv tükenme (BoP / mal / rant) |", "| --- | ---: | ---: | ---: | ---: | --- |"]
    for ad, v in sen.items():
        L.append(f"| {ad} | {v['kapasite_m']} | {v['faiz_gelir_son_yil']} | {v['mali_alan_carpani_son_yil']} | {v['d_son']} | " + " / ".join(str(v["rezerv_tukenme_yili"][k] or "—") for k in KOPRULER) + " |")
    mal = gerek["mal_net_ticaret"]
    en_iyi = sen["en_iyi_katman__faiz_sabit"]["kapasite_m"]
    L += ["", "## Sonuç", "",
          f"Rezervin dayanması için gereken hız (mal köprüsü) m* = {mal}, rant köprüsü m* = {gerek['tum_havza_rant']}; gözlenen en iyi katman hızı m = {en_iyi}. Ölçülebilir kurallarla 4–5 kat hızı destekleyen bir koşul yok: açık, kapasite ile gereğin farkıdır.",
          "Dışarıda bırakılan kurallar (dönüt, güven, tampon süresi, ücret–kredi bağı, başarı tanımı) ölçülemediği için bu sonuca girmez; açılırlarsa hız artabilir, ama büyüklüğü bu verilerle söylenemez.", ""]
    (OUT / "DURDURMA_HIZ_KURAL.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    return d_all


if __name__ == "__main__":
    calistir()
    print("DURDURMA_HIZ_KURAL ok")
