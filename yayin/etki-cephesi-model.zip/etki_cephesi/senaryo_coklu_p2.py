"""P2: A/B/C modül zinciri, olasılık ağırlıklı beklenti, senaryo başına rapor kopyaları."""
from __future__ import annotations

import json
import sys
from pathlib import Path
import _olasilik
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"

if str(REPO / "etki_cephesi") not in sys.path:
    sys.path.insert(0, str(REPO / "etki_cephesi"))

from dis_rant_parasal_akisi import hesapla as rant_hesapla  # noqa: E402
from refah_dis_entegrasyon import entegre_et  # noqa: E402
from uluslararasi_stok_akis import matris_olustur  # noqa: E402


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _yaz(p: Path, data: dict[str, Any]) -> None:
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def senaryo_paketi(senaryo_id: str, projeksiyon_var: bool = True) -> dict[str, Any]:
    defter = entegre_et(senaryo_id, yeniden_projeksiyon=not projeksiyon_var)
    rant = rant_hesapla(senaryo_id)
    matris = matris_olustur(defter=defter, rant=rant)

    sid = senaryo_id
    _yaz(OUT / f"DIS_ULKE_REFAH_{sid}.json", defter)
    _yaz(OUT / f"DIS_RANT_PARASAL_{sid}.json", rant)
    _yaz(OUT / f"ULUSLARARASI_STOK_AKIS_{sid}.json", matris)

    tr = defter.get("tr_ozet") or {}
    oz = rant.get("ozet") or {}
    k = matris.get("kalibrasyon") or {}
    return {
        "id": sid,
        "tr_net_entegre": tr.get("net_refah_entegre"),
        "refah_dis_usd_mn": oz.get("refah_dis_usd_mn_toplam"),
        "refah_tr_ic_usd_mn": oz.get("refah_tr_ic_usd_mn"),
        "fark_bosluk_minus_refah_usd_mn": oz.get("fark_bosluk_minus_refah_dis_usd_mn"),
        "stok_kapanis_ok": k.get("kapanis_ok"),
        "stok_net_vekil": k.get("stok_net_toplam_vekil"),
        "balkan_defter": (defter.get("balkan_eu_defter") or {}).get("uygulandi"),
    }


def olasilik_beklenti(satirlar: list[dict[str, Any]], sen_doc: dict[str, Any]) -> dict[str, Any]:
    olas: dict[str, float] = {}
    for s in sen_doc.get("senaryolar") or []:
        olas[str(s["id"])] = _olasilik.vekil_s(s)
    s_olas = sum(olas.values()) or 1.0
    olas = {k: v / s_olas for k, v in olas.items()}

    def ew(key: str) -> float | None:
        tot = 0.0
        w = 0.0
        for r in satirlar:
            p = olas.get(r["id"], 0.0)
            v = r.get(key)
            if v is None:
                continue
            tot += p * float(v)
            w += p
        return round(tot / w, 3) if w > 0 else None

    return {
        "olasilik_normalize": {k: round(v, 4) for k, v in olas.items()},
        "beklenen_tr_net_entegre": ew("tr_net_entegre"),
        "beklenen_refah_dis_usd_mn": ew("refah_dis_usd_mn"),
        "beklenen_fark_bosluk_minus_refah_usd_mn": ew("fark_bosluk_minus_refah_usd_mn"),
        "beklenen_stok_net_vekil": ew("stok_net_vekil"),
    }


def calistir(senaryolar: tuple[str, ...] = ("A", "B", "C"), referans: str = "C") -> dict[str, Any]:
    OUT.mkdir(parents=True, exist_ok=True)
    sen_doc = _load(DATA / "senaryolar.json")
    proj = OUT / "PROJEKSIYON.json"
    if not proj.is_file():
        entegre_et("C", yeniden_projeksiyon=True)
    satirlar = [senaryo_paketi(sid, projeksiyon_var=proj.is_file()) for sid in senaryolar]
    beklenti = olasilik_beklenti(satirlar, sen_doc)

    if referans in senaryolar:
        ref = referans
        for stem in ("DIS_ULKE_REFAH", "DIS_RANT_PARASAL", "ULUSLARARASI_STOK_AKIS"):
            src = OUT / f"{stem}_{ref}.json"
            if src.is_file():
                (OUT / f"{stem}.json").write_text(src.read_text(encoding="utf-8"), encoding="utf-8")

    out = {
        "olcum": "senaryo_coklu_modul_p2",
        "senaryolar": satirlar,
        "beklenti": beklenti,
        "referans_raporlar": referans,
        "cikti_dosyalar": [
            name
            for s in senaryolar
            for name in (
                f"DIS_ULKE_REFAH_{s}.json",
                f"DIS_RANT_PARASAL_{s}.json",
                f"ULUSLARARASI_STOK_AKIS_{s}.json",
            )
        ],
    }
    return out


def _md(d: dict[str, Any]) -> str:
    b = d["beklenti"]
    lines = [
        "# Senaryo A/B/C — modül paketi (P2)",
        "",
        "| Senaryo | TR net entegre | Refah dış USD mn | Fark (boşluk−refah) | Stok Σ | Kapanış |",
        "| --- | ---: | ---: | ---: | ---: | --- |",
    ]
    for r in d["senaryolar"]:
        ok = "OK" if r.get("stok_kapanis_ok") else "—"
        rd = r.get("refah_dis_usd_mn")
        fd = r.get("fark_bosluk_minus_refah_usd_mn")
        lines.append(
            f"| **{r['id']}** | {r.get('tr_net_entegre')} | {rd if rd is None else f'{rd:,}'} | "
            f"{fd if fd is None else f'{fd:,}'} | {r.get('stok_net_vekil')} | {ok} |"
        )
    lines.extend(
        [
            "",
            "## Olasılık ağırlıklı beklenti",
            "",
            f"- P(A,B,C): {b.get('olasilik_normalize')}",
            f"- Beklenen TR net entegre: **{b.get('beklenen_tr_net_entegre')}**",
            f"- Beklenen refah dış USD: **{b.get('beklenen_refah_dis_usd_mn'):,}** mn/yıl",
            f"- Beklenen fark (boşluk−refah): **{b.get('beklenen_fark_bosluk_minus_refah_usd_mn'):,}** mn",
            "",
            f"Ana raporlar (`DIS_ULKE_REFAH.json` …) senaryo **{d['referans_raporlar']}** kopyasıdır.",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    data = calistir()
    (OUT / "SENARYO_COKLU_P2.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "SENARYO_COKLU_P2.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'SENARYO_COKLU_P2.md'}")


if __name__ == "__main__":
    main()
