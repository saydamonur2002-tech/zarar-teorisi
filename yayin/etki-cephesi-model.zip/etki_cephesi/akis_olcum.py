"""Gözlemlenebilir USD akımı ↔ etki cephesi vekili (MFIN, rant kanalları, mal ticareti)."""
from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
EMPIRIK = DATA / "empirik"
OUT = REPO / "reports" / "etki_cephesi"

import sys

if str(REPO / "etki_cephesi") not in sys.path:
    sys.path.insert(0, str(REPO / "etki_cephesi"))
from usd_kopru import from_akis_olcum, tr_net_usd_coklu  # noqa: E402
from rant_kanal_eslesme import akis_kanal_etiket  # noqa: E402


def _load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _senaryo(doc: dict[str, Any], sid: str = "A") -> dict[str, Any]:
    for s in doc.get("senaryolar") or []:
        if s.get("id") == sid:
            return s
    raise KeyError(f"Senaryo {sid} yok")


def _mfin_kenar_toplam(sen: dict[str, Any]) -> tuple[float, list[dict[str, Any]]]:
    kenarlar = [
        e
        for e in (sen.get("akis_kenarlari") or [])
        if e.get("hedef") == "merkez_finans" and e.get("tur") == "sizinti"
    ]
    top = round(sum(float(e["akis_endeks"]) for e in kenarlar), 3)
    return top, kenarlar


def _rant_etiket_dagilim(sen: dict[str, Any]) -> dict[str, float]:
    by_tag: dict[str, float] = defaultdict(float)
    for row in sen.get("bolgesel_net") or []:
        kar = float(row.get("rant_kanal_cikis_kar") or 0.0)
        tags = row.get("rant_kanallar") or []
        if kar <= 0 or not tags:
            continue
        share = kar / len(tags)
        for t in tags:
            by_tag[akis_kanal_etiket(str(t))] += share
    tot = sum(by_tag.values()) or 1.0
    return {k: round(v / tot, 4) for k, v in sorted(by_tag.items(), key=lambda x: -x[1])}


def _vekil_usd(vekil: float, cicek_usd: float, vekil_toplam: float) -> float:
    if vekil_toplam <= 0:
        return 0.0
    return round(vekil * (cicek_usd / vekil_toplam), 1)


def _referans_senaryo() -> str:
    doc = _load(DATA / "senaryolar.json")
    return str(doc.get("referans_senaryo") or "C")


def olcum(senaryo_id: str | None = None) -> dict[str, Any]:
    if senaryo_id is None:
        senaryo_id = _referans_senaryo()
    fin = _load(EMPIRIK / "tr_finans_akisi_2024.json")
    tic = _load(EMPIRIK / "tr_dis_ticaret_2024.json")
    proj = _load(OUT / "PROJEKSIYON.json")

    sen = _senaryo(proj, senaryo_id)
    mfin_kenar, mfin_kenarlar = _mfin_kenar_toplam(sen)
    merkez_top = float(sen.get("merkez_finans_sizinti_toplam") or 0.0)
    belirsiz = round(max(0.0, merkez_top - mfin_kenar), 3)
    rant_top = float(sen.get("tum_havza_rant_cikis_toplam") or 0.0)
    merkez_rant = float(sen.get("merkez_artı_rant_cikis_toplam") or 0.0)

    satirlar = fin.get("akis_satirlari") or {}
    olcek_key = str(fin.get("model_olcek_satir") or "birincil_gelir_yatirim_gideri")
    cicek = float((satirlar.get(olcek_key) or {}).get("usd_mn") or 0.0)

    rant_tags = _rant_etiket_dagilim(sen)

    mfin_usd = _vekil_usd(mfin_kenar, cicek, merkez_rant)
    belirsiz_usd = _vekil_usd(belirsiz, cicek, merkez_rant)
    merkez_usd = _vekil_usd(merkez_top, cicek, merkez_rant)
    rant_usd = _vekil_usd(rant_top, cicek, merkez_rant)

    havza_mfin: list[dict[str, Any]] = []
    for e in sorted(mfin_kenarlar, key=lambda x: -float(x["akis_endeks"]))[:25]:
        v = float(e["akis_endeks"])
        havza_mfin.append(
            {
                "kaynak": e.get("kaynak"),
                "kaynak_ad": e.get("kaynak_ad"),
                "akis_endeks": v,
                "usd_mn_vekil": _vekil_usd(v, cicek, merkez_rant),
            }
        )

    rant_usd_by_tag: list[dict[str, Any]] = []
    for tag, pay in rant_tags.items():
        rant_usd_by_tag.append(
            {
                "kanal": tag,
                "rant_vekil_pay": pay,
                "usd_mn_vekil": round(rant_usd * pay, 1),
            }
        )

    payda = fin.get("global_payda") or {}
    tds_tr = float((satirlar.get("dis_borc_servisi_tds") or {}).get("usd_mn") or 0.0)
    tds_gl = float((payda.get("dis_borc_servisi_tds_toplam_vekili") or {}).get("usd_mn") or 1.0)
    inv_gl = float((payda.get("global_yatirim_geliri_gideri_vekili") or {}).get("usd_mn") or 1.0)
    bis_gl = float((payda.get("bis_cross_border_claims") or {}).get("usd_mn") or 1.0)

    global_paylar = {
        "tds_tr_dunya_yuzde": round(100.0 * tds_tr / tds_gl, 3),
        "yatirim_geliri_gideri_tr_dunya_yuzde": round(100.0 * cicek / inv_gl, 3),
        "tds_tr_bis_cross_border_yuzde": round(100.0 * tds_tr / bis_gl, 4),
    }

    gozlemlenebilir = {
        k: v.get("usd_mn")
        for k, v in satirlar.items()
        if isinstance(v, dict) and "usd_mn" in v
    }

    mal = fin.get("mal_akisi") or {}
    exp = float(mal.get("ihracat_usd_mn") or tic.get("toplam_ihracat_usd_mn") or 0.0)
    imp = float(mal.get("ithalat_usd_mn") or tic.get("toplam_ithalat_usd_mn") or 0.0)

    bosalma = float(sen.get("turkiye_yaricevre_bosalma") or 0.0)
    tr_net = 0.0
    for a in sen.get("aktör_birlesik") or []:
        if a.get("aktor") == "TR":
            tr_net = float(a.get("net_birlesik_vekil") or 0.0)
            break

    payload = {
        "olcum": "tr_finans_ve_mal_akisi_2024",
        "senaryo": senaryo_id,
        "cicek_satir": olcek_key,
        "cicek_usd_mn": cicek,
        "model_vekil": {
            "merkez_finans_sizinti_toplam": merkez_top,
            "mfin_kenar_toplam": mfin_kenar,
            "merkez_belirsiz_havuz": belirsiz,
            "tum_havza_rant_cikis_toplam": rant_top,
            "merkez_artı_rant_cikis_toplam": merkez_rant,
            "turkiye_yaricevre_bosalma": bosalma,
            "tr_net_birlesik_vekil": tr_net,
        },
        "modelden_usd_vekili": {
            "mfin_kenar_usd_mn": mfin_usd,
            "merkez_belirsiz_usd_mn": belirsiz_usd,
            "merkez_toplam_usd_mn": merkez_usd,
            "rant_toplam_usd_mn": rant_usd,
            "not": f"1 vekil birim ≈ {round(cicek / merkez_rant, 1)} mn USD ({olcek_key})",
        },
        "gozlemlenebilir_akis_usd_mn": gozlemlenebilir,
        "mal_akisi_usd_mn": {"ihracat": exp, "ithalat": imp, "net_ticaret": round(exp - imp, 1)},
        "global_paylar": global_paylar,
        "mfin_havza_top25": havza_mfin,
        "rant_kanal_usd_vekili": rant_usd_by_tag[:20],
        "kaynaklar": fin.get("kaynaklar"),
    }
    kopru = from_akis_olcum(payload, bosalma_vekil=bosalma)
    payload["usd_kopruleri"] = kopru["kopruler"]
    k = kopru["kopruler"]
    payload["modelden_usd_vekili"]["rant_usd_kopru_rant"] = _vekil_usd(
        rant_top, float(k["tum_havza_rant"]["usd_cicek_mn"]), rant_top
    )
    payload["modelden_usd_vekili"]["bosalma_usd_kopru_mal"] = _vekil_usd(
        bosalma, float(k["mal_net_ticaret"]["usd_cicek_mn"]), bosalma
    )
    payload["tr_net_usd_kopruleri"] = tr_net_usd_coklu(tr_net, k)
    return payload


def _md(r: dict[str, Any]) -> str:
    mv = r["model_vekil"]
    mu = r["modelden_usd_vekili"]
    gp = r["global_paylar"]
    lines = [
        "# Akım ölçümü — USD (2024) ↔ vekil (Senaryo " + r["senaryo"] + ")",
        "",
        f"**Çapa:** `{r['cicek_satir']}` = **{r['cicek_usd_mn']:,}** mn USD → model paketi "
        f"(`merkez_artı_rant` = {mv['merkez_artı_rant_cikis_toplam']}) için {mu['not']}.",
        "",
        "## Gözlemlenebilir finans (mn USD)",
        "",
        "| Satır | USD mn |",
        "| --- | ---: |",
    ]
    for k, v in r["gozlemlenebilir_akis_usd_mn"].items():
        lines.append(f"| {k} | {v:,} |")
    mal = r["mal_akisi_usd_mn"]
    lines.extend(
        [
            "",
            "## Mal ticareti (mn USD)",
            "",
            f"- İhracat: **{mal['ihracat']:,}**",
            f"- İthalat: **{mal['ithalat']:,}**",
            f"- Net: **{mal['net_ticaret']:,}**",
            "",
            "## Model vekili → USD (aynı çapa)",
            "",
            "| Bileşen | Vekil | USD mn (vekili) |",
            "| --- | ---: | ---: |",
            f"| MFIN kenar | {mv['mfin_kenar_toplam']} | {mu['mfin_kenar_usd_mn']:,} |",
            f"| Merkez belirsiz havuz | {mv['merkez_belirsiz_havuz']} | {mu['merkez_belirsiz_usd_mn']:,} |",
            f"| Merkez toplam | {mv['merkez_finans_sizinti_toplam']} | {mu['merkez_toplam_usd_mn']:,} |",
            f"| Rant çıkış (tüm havza) | {mv['tum_havza_rant_cikis_toplam']} | {mu['rant_toplam_usd_mn']:,} |",
            "",
            "## USD köprüleri (vekil birimi)",
            "",
        ]
    )
    for key, row in (r.get("usd_kopruleri") or {}).items():
        lines.append(
            f"- **{key}:** 1 vekil ≈ **{row['usd_per_vekil_mn']:,}** mn USD "
            f"({row.get('not') or row.get('cicek_satir') or 'mal/ticaret'})"
        )
    trk = r.get("tr_net_usd_kopruleri") or {}
    if trk:
        lines.extend(
            [
                "",
                f"TR net vekil **{mv.get('tr_net_birlesik_vekil')}** → USD: "
                f"BoP **{trk.get('bop_merkez_rant', 0):,}** · "
                f"rant **{trk.get('tum_havza_rant', 0):,}** · "
                f"mal **{trk.get('mal_net_ticaret', 0):,}** · "
                f"orta **{trk.get('geometrik_orta_mn', 0):,}** mn",
                "",
            ]
        )
    lines.extend(
        [
            "## Küresel pay (vekili payda)",
            "",
            f"- TR dış borç servisi / küresel TDS vekili: **%{gp['tds_tr_dunya_yuzde']}**",
            f"- TR yatırım geliri gideri / küresel vekili: **%{gp['yatirim_geliri_gideri_tr_dunya_yuzde']}**",
            f"- TR TDS / BIS cross-border claims vekili: **%{gp['tds_tr_bis_cross_border_yuzde']}**",
            "",
            "## MFIN — havza kenarları (top 25, USD vekili)",
            "",
            "| Havza | Vekil | USD mn |",
            "| --- | ---: | ---: |",
        ]
    )
    for row in r["mfin_havza_top25"]:
        ad = row.get("kaynak_ad") or row.get("kaynak")
        lines.append(f"| {ad} | {row['akis_endeks']} | {row['usd_mn_vekil']:,} |")
    lines.extend(
        [
            "",
            "## Rant kanalları (USD vekili, top 20)",
            "",
            "| Kanal | Rant vekil pay | USD mn |",
            "| --- | ---: | ---: |",
        ]
    )
    for row in r["rant_kanal_usd_vekili"]:
        lines.append(
            f"| {row['kanal']} | {row['rant_vekil_pay']} | {row['usd_mn_vekil']:,} |"
        )
    lines.extend(["", "## Kaynaklar", ""])
    for k in r.get("kaynaklar") or []:
        lines.append(f"- {k}")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    sid = _referans_senaryo()
    res = olcum(sid)
    (OUT / "AKIS_OLCUM.json").write_text(
        json.dumps(res, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (OUT / "AKIS_OLCUM.md").write_text(_md(res), encoding="utf-8")
    # A, B, C için aynı ayrıntı: AKIS_OLCUM_{X}.{json,md}. AKIS_OLCUM.* yalnız alt modüllerin tek-girdi dosyasıdır.
    for x in ("A", "B", "C"):
        r = olcum(x)
        (OUT / f"AKIS_OLCUM_{x}.json").write_text(json.dumps(r, ensure_ascii=False, indent=2), encoding="utf-8")
        (OUT / f"AKIS_OLCUM_{x}.md").write_text(_md(r), encoding="utf-8")
    print(f"Wrote {OUT / 'AKIS_OLCUM.md'} (+ A/B/C)")


if __name__ == "__main__":
    main()
