"""TİM/Ticaret 2024 vekili → etki_vekili + dis_aktör pay kalibrasyonu."""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
EMPIRIK = DATA / "empirik"
KALIBRE = DATA / "kalibre"
OUT = REPO / "reports" / "etki_cephesi"

_AKTOR_MAP = {
    "AE": "AE",
    "SA": "SA",
    "AZ": "AZ",
    "GR": "GR",
}


def _load(name: str, base: Path = DATA) -> dict[str, Any]:
    return json.loads((base / name).read_text(encoding="utf-8"))


def _normalize_pay(row: dict[str, float], tr_floor: float = 0.12) -> dict[str, float]:
    tr = float(row.get("TR", 0.15))
    tr = max(tr_floor, min(0.55, tr))
    rest = {k: v for k, v in row.items() if k != "TR"}
    s = sum(rest.values()) or 1.0
    out = {k: (v / s) * (1.0 - tr) for k, v in rest.items()}
    out["TR"] = round(tr, 3)
    tot = sum(out.values())
    if abs(tot - 1.0) > 0.001:
        scale = 1.0 / tot
        out = {k: round(v * scale, 3) for k, v in out.items()}
    return out


def kalibre_et() -> dict[str, Any]:
    tic = _load("tr_dis_ticaret_2024.json", EMPIRIK)
    hav = _load("bolge_havza_ticaret.json", EMPIRIK)
    bolgeler = _load("bolgeler.json")["bolgeler"]
    dis_orig = _load("dis_aktör_pay.json")
    ith_rakip = tic.get("ithalat_rakip_pay_2024") or {}
    exp_by_havza: dict[str, float] = hav.get("havza_ihracat_usd_mn") or {}
    rakip_on: dict[str, list[str]] = hav.get("havza_rakip_oncelik") or {}

    max_exp = max(exp_by_havza.values()) if exp_by_havza else 1.0
    total_exp = float(tic.get("toplam_ihracat_usd_mn", 261925))

    vek_updates: dict[str, float] = {}
    pay_updates: dict[str, dict[str, float]] = {}
    satirlar: list[dict[str, Any]] = []

    for b in bolgeler:
        bid = b["id"]
        usd = float(exp_by_havza.get(bid, 0.0))
        share = usd / total_exp if total_exp else 0.0
        vek = round(0.35 + 4.65 * math.sqrt(usd / max_exp) if max_exp else 1.0, 2)
        vek_updates[bid] = vek

        tr_pay = max(0.12, min(0.52, 0.14 + share * 8.0))
        actors = rakip_on.get(bid) or ["US", "EU", "CN"]
        weights: dict[str, float] = {}
        for a in actors:
            if a in ("AE", "SA", "AZ", "GR", "FR"):
                weights[a] = 0.18
            elif a in ith_rakip:
                weights[a] = float(ith_rakip[a]) * 2.5
            elif a == "EU":
                weights[a] = 0.22
            elif a == "IL":
                weights[a] = 0.14
            else:
                weights[a] = 0.12
        leg = dis_orig.get("bolge_pay", {}).get(bid) or dis_orig.get("bolge_pay", {}).get(
            bid.replace("_bagdat", "").replace("_krg", "")
        )
        if leg:
            for k, v in leg.items():
                if k != "TR" and k in weights:
                    weights[k] = 0.45 * weights[k] + 0.55 * float(v)
                elif k != "TR":
                    weights[k] = 0.55 * float(v)
        row = {"TR": tr_pay, **weights}
        pay_updates[bid] = _normalize_pay(row)

        satirlar.append(
            {
                "havza": bid,
                "ihracat_usd_mn": usd,
                "ihracat_pay_toplam": round(share, 4),
                "etki_vekili_kalibre": vek,
                "tr_pay_kalibre": pay_updates[bid]["TR"],
            }
        )

    bolgeler_out = []
    for b in bolgeler:
        nb = dict(b)
        nb["etki_vekili_2026"] = vek_updates.get(b["id"], b["etki_vekili_2026"])
        nb["etki_vekili_kaynak"] = "TİM/Ticaret 2024 kalibrasyon"
        bolgeler_out.append(nb)

    dis_out = dict(dis_orig)
    dis_out["not"] = (
        "Kalibre: empirik/tr_dis_ticaret_2024 + bolge_havza_ticaret. "
        + (dis_orig.get("not") or "")
    )
    dis_out["bolge_pay"] = {**dis_orig.get("bolge_pay", {}), **pay_updates}

    KALIBRE.mkdir(parents=True, exist_ok=True)
    (KALIBRE / "bolgeler.json").write_text(
        json.dumps({"bolgeler": bolgeler_out}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (KALIBRE / "dis_aktör_pay.json").write_text(
        json.dumps(dis_out, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    meta = {
        "kaynak": tic.get("kaynaklar"),
        "toplam_ihracat_usd_mn": total_exp,
        "havza_sayisi": len(satirlar),
        "satirlar": satirlar,
    }
    (KALIBRE / "kalibrasyon_meta.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return meta


def main() -> None:
    meta = kalibre_et()
    OUT.mkdir(parents=True, exist_ok=True)
    lines = [
        "# Kalibrasyon — TİM/Ticaret 2024 vekili",
        "",
        f"Toplam ihracat: **{meta['toplam_ihracat_usd_mn']}** milyon USD",
        "",
        "| Havza | İhracat (mn $) | Pay | Vekil | TR pay |",
        "| --- | ---: | ---: | ---: | ---: |",
    ]
    for s in sorted(meta["satirlar"], key=lambda x: -x["ihracat_usd_mn"]):
        lines.append(
            f"| {s['havza']} | {s['ihracat_usd_mn']} | {s['ihracat_pay_toplam']} | "
            f"{s['etki_vekili_kalibre']} | {s['tr_pay_kalibre']} |"
        )
    lines.append("")
    (OUT / "KALIBRASYON.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote {KALIBRE} and {OUT / 'KALIBRASYON.md'}")


if __name__ == "__main__":
    main()
