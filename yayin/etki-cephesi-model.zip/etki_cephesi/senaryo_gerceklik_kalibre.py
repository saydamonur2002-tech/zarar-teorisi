"""Katman yığınını 2024 BoP/ticaret/GSYH çapalarına göre gerçekleşme oranıyla kalibre et."""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
KALIBRE = DATA / "kalibre"
OUT = REPO / "reports" / "etki_cephesi"
CAPA = KALIBRE / "gerceklik_capa.json"

import sys

if str(REPO / "etki_cephesi") not in sys.path:
    sys.path.insert(0, str(REPO / "etki_cephesi"))
from usd_kopru import from_akis_olcum, tr_net_usd_coklu  # noqa: E402


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _run(mod: str) -> None:
    subprocess.check_call([sys.executable, str(REPO / "etki_cephesi" / mod)])


def _pipeline() -> None:
    if not (KALIBRE / "bolgeler.json").is_file():
        _run("kalibrasyon.py")
    _run("projeksiyon.py")
    _run("refah_dis_entegrasyon.py")
    _run("akis_olcum.py")
    _run("zarar_cozum_entegrasyon.py")
    _run("uretim_ic_akis.py")
    _run("finans_katman_senaryo_coklu.py")


def _tr_c_taban(proj: dict[str, Any], refah: dict[str, Any] | None, sid: str = "C") -> float:
    if refah and refah.get("tr_ozet"):
        return float(refah["tr_ozet"].get("net_refah_entegre", -17.7))
    sen = next(s for s in proj["senaryolar"] if s["id"] == sid)
    for a in sen.get("aktör_birlesik") or []:
        if a.get("aktor") == "TR":
            return float(a["net_birlesik_vekil"])
    return -18.015


def _refah_dosya(sid: str) -> Path | None:
    p = OUT / f"DIS_ULKE_REFAH_{sid}.json"
    if p.is_file():
        return p
    if sid == "C" and (OUT / "DIS_ULKE_REFAH.json").is_file():
        return OUT / "DIS_ULKE_REFAH.json"
    return None


def _usd_kopruleri(akis: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    kopru = from_akis_olcum(akis)
    k = kopru["kopruler"]
    bop_k = float(k["bop_merkez_rant"]["usd_per_vekil_mn"])
    return kopru, k


def _gerceklesme(delta_vekil: float, tavan_usd: float, usd_per_v: float, taban: float) -> float:
    if delta_vekil <= 0 or usd_per_v <= 0:
        return 1.0
    delta_usd = delta_vekil * usd_per_v
    otomatik = tavan_usd / delta_usd if delta_usd > 0 else 1.0
    return round(min(1.0, max(taban, otomatik)), 4)


def _tr_net_usd_satir(tr_net: float, kopruler: dict[str, Any]) -> dict[str, float]:
    return tr_net_usd_coklu(tr_net, kopruler)


def _gsyh_usd_mn(capa: dict[str, Any]) -> float:
    tl = float(capa.get("gsyh_tl") or 0.0)
    kur = float(capa.get("kur_tl_usd") or 1.0)
    return round(tl / kur / 1_000_000, 1)


def _koridor(y0: int, steps: int, bas: float, hedef: float, yil: float) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for i in range(steps + 1):
        u = min(1.0, i / yil) if yil > 0 else 1.0
        rows.append({"yil": y0 + i, "tr_net": round(bas + (hedef - bas) * u, 3)})
    return rows


def _senaryo_kalibre_carpanlari(sen: dict[str, Any] | None) -> tuple[float, float]:
    """P3: politika gerçekleşme çarpanı + delta ölçeği (C erosyon = 1.0)."""
    if not sen:
        return 1.0, 1.0
    er = float(sen.get("etki_erosyon_carpani") or 0.22)
    flex = float(sen.get("tr_diplomatik_flex") or 0.0)
    pol = max(0.25, min(1.0, 1.05 - er + flex))
    er_c = 0.22
    delta_scale = max(0.5, min(1.4, er / er_c))
    return pol, delta_scale


def kalibre_yigin_refah(
    proj: dict[str, Any],
    refah: dict[str, Any] | None,
    fin: dict[str, Any],
    capa: dict[str, Any],
    akis: dict[str, Any],
    senaryo: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Refah defterine göre katman yığını + 10y koridor (senaryo başına tekrarlanabilir)."""
    _, kopruler = _usd_kopruleri(akis)
    usd_v = float(kopruler["bop_merkez_rant"]["usd_per_vekil_mn"])
    gsyh = _gsyh_usd_mn(capa)
    usd = capa["usd_mn"]
    tavan = capa["iyilesme_tavan_yuzde_10y"]
    taban = capa["gerceklesme_taban"]
    yat = float(usd["yatirim_geliri_gideri"])
    tic = abs(float(usd["net_ticaret"]))

    sid_fin = str(senaryo.get("id") if senaryo else "C")
    fin_path = OUT / f"FINANS_KATMAN_{sid_fin}.json"
    fin_doc = _load(fin_path) if fin_path.is_file() else fin
    stack = fin_doc["katman_yigini"]
    tr_c = _tr_c_taban(proj, refah, sid_fin)
    eski_c = float(stack[0]["tr_net"])
    kaydir = tr_c - eski_c
    tr_z = float(stack[1]["tr_net"]) + kaydir
    tr_u = float(stack[2]["tr_net"]) + kaydir
    tr_f = float(stack[3]["tr_net"]) + kaydir

    d_z = tr_z - tr_c
    d_u = tr_u - tr_z
    d_f = tr_f - tr_u

    pol, delta_scale = _senaryo_kalibre_carpanlari(senaryo)
    if senaryo:
        d_z *= delta_scale
        d_u *= delta_scale
        d_f *= delta_scale

    r_z = _gerceklesme(d_z, tavan["zarar_teorisi_yatirim_geliri"] * yat, usd_v, float(taban["zarar_teorisi"]))
    r_u = _gerceklesme(d_u, tavan["uretim_rant_net_ticaret"] * tic, usd_v, float(taban["uretim_ic_akis"]))
    r_f = _gerceklesme(d_f, tavan["finans_yatirim_geliri"] * yat, usd_v, float(taban["finans_katman"]))
    if senaryo:
        r_z = round(min(1.0, r_z * pol), 4)
        r_u = round(min(1.0, r_u * pol), 4)
        r_f = round(min(1.0, r_f * pol), 4)

    tr_z_k = round(tr_c + d_z * r_z, 3)
    tr_u_k = round(tr_z_k + d_u * r_u, 3)
    tr_f_k = round(tr_u_k + d_f * r_f, 3)

    def _katman_row(name: str, tr: float, g: float | None = None) -> dict[str, Any]:
        usd = _tr_net_usd_satir(tr, kopruler)
        row: dict[str, Any] = {
            "katman": name,
            "tr_net": tr,
            "tr_net_usd_mn_bop": usd["bop_merkez_rant"],
            "tr_net_usd_mn_rant": usd["tum_havza_rant"],
            "tr_net_usd_mn_mal": usd["mal_net_ticaret"],
            "tr_net_usd_mn_orta": usd["geometrik_orta_mn"],
            "gsyh_yuzde_orta": round(usd["geometrik_orta_mn"] / gsyh * 100, 3),
        }
        if g is not None:
            row["gerceklesme"] = g
        return row

    katman_k = [
        _katman_row("C_refah_entegre", tr_c),
        _katman_row("zarar_teorisi", tr_z_k, r_z),
        _katman_row("uretim_ic_akis", tr_u_k, r_u),
        _katman_row("finans_katman", tr_f_k, r_f),
    ]

    model_ham_usd = _tr_net_usd_satir(tr_f, kopruler)
    model_ham = {"tr_net": tr_f, "tr_net_usd_mn": model_ham_usd}
    cap_z_usd = round(tavan["zarar_teorisi_yatirim_geliri"] * yat, 1)
    cap_u_usd = round(tavan["uretim_rant_net_ticaret"] * tic, 1)
    cap_f_usd = round(tavan["finans_yatirim_geliri"] * yat, 1)

    olgunluk = {"zarar": 7.0, "uretim": 12.0, "finans": 10.0}
    y0 = int(capa.get("yil", 2026)) + 2
    yol: list[dict[str, Any]] = []
    cur = tr_c
    y = y0
    for name, hedef, yrs in [
        ("zarar", tr_z_k, olgunluk["zarar"]),
        ("uretim", tr_u_k, olgunluk["uretim"]),
        ("finans", tr_f_k, olgunluk["finans"]),
    ]:
        seg = _koridor(y, int(yrs), cur, hedef, yrs)
        for row in seg[1:]:
            yol.append({**row, "faz": name})
        y = yol[-1]["yil"] + 1 if yol else y
        cur = hedef

    sifir: int | None = None
    for row in yol:
        if row["tr_net"] >= 0:
            sifir = int(row["yil"])
            break
    if sifir is None and tr_f_k < 0 and tr_f_k > tr_c:
        slope = (tr_f_k - tr_c) / sum(olgunluk.values())
        if slope > 0.08:
            sifir = int(round(y0 + sum(olgunluk.values()) + (-tr_f_k) / slope))
    if sifir is not None and sifir > y0 + 35:
        sifir = None

    y10 = yol[9]["tr_net"] if len(yol) > 9 else (yol[-1]["tr_net"] if yol else tr_f_k)
    sid = str(senaryo.get("id")) if senaryo else "C"
    return {
        "senaryo_id": sid,
        "senaryo_pol_carpan": round(pol, 3) if senaryo else 1.0,
        "senaryo_delta_olcek": round(delta_scale, 3) if senaryo else 1.0,
        "tr_c_refah": tr_c,
        "tr_net_kalibre_son": tr_f_k,
        "tr_net_yol_10_son": round(float(y10), 3),
        "gsyh_yuzde_son": katman_k[-1]["gsyh_yuzde_orta"],
        "gerceklesme_oranlari": {"zarar_teorisi": r_z, "uretim_ic_akis": r_u, "finans_katman": r_f},
        "katman_yigini_kalibre": katman_k,
        "yol_koridor": yol,
        "sifir_nokta_takvim": sifir,
        "model_ham_finans_son": model_ham,
        "iyilesme_tavan_usd_mn": {"zarar": cap_z_usd, "uretim": cap_u_usd, "finans": cap_f_usd},
        "usd_kopruleri": kopruler,
        "usd_per_vekil_mn": round(usd_v, 2),
        "gsyh_usd_mn": gsyh,
        "tr_net_usd_mn_son": _tr_net_usd_satir(tr_f_k, kopruler),
    }


def _gerceklik_paket(
    sid: str,
    proj: dict[str, Any],
    capa: dict[str, Any],
    akis: dict[str, Any],
    refah: dict[str, Any] | None,
    sen: dict[str, Any] | None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    fin_path = OUT / f"FINANS_KATMAN_{sid}.json"
    if not fin_path.is_file():
        fin_path = OUT / "FINANS_KATMAN.json"
    fin = _load(fin_path)
    yigin = kalibre_yigin_refah(proj, refah, fin, capa, akis, senaryo=sen)
    refah_oz = (refah or {}).get("refah_rant_ozet") or {}
    usd = capa["usd_mn"]
    dogrulama = {
        "mfin_kenar_usd_model": akis.get("modelden_usd_vekili", {}).get("mfin_kenar_usd_mn"),
        "cicek_usd": akis.get("cicek_usd_mn"),
        "net_ticaret_usd": usd["net_ticaret"],
        "global_yatirim_geliri_tr_yuzde": akis.get("global_paylar", {}).get("yatirim_geliri_gideri_tr_dunya_yuzde"),
        "kalibre_ticaret_2024": proj.get("kalibre_2024_ticaret"),
        "rant_modeli": proj.get("rant_modeli"),
        "refah_rant_toplam_vekil": refah_oz.get("toplam"),
        "tr_refah_ic_pay_vekil": refah_oz.get("tr_ic_pay"),
    }
    kopruler = yigin["usd_kopruleri"]
    usd_v = yigin["usd_per_vekil_mn"]
    out = {
        "olcum": "senaryo_gerceklik_kalibre",
        "senaryo_id": sid,
        "capa_dosya": str(CAPA.relative_to(REPO)),
        "rant_modeli": proj.get("rant_modeli"),
        "usd_per_vekil_mn": round(usd_v, 2),
        "usd_kopruleri": kopruler,
        "gsyh_usd_mn": yigin["gsyh_usd_mn"],
        "model_ham_finans_son": yigin["model_ham_finans_son"],
        "iyilesme_tavan_usd_mn": yigin["iyilesme_tavan_usd_mn"],
        "gerceklesme_oranlari": yigin["gerceklesme_oranlari"],
        "katman_yigini_kalibre": yigin["katman_yigini_kalibre"],
        "tr_net_kalibre_son": yigin["tr_net_kalibre_son"],
        "tr_net_usd_mn_son": yigin["tr_net_usd_mn_son"],
        "gsyh_yuzde_son": yigin["gsyh_yuzde_son"],
        "sifir_nokta_takvim": yigin["sifir_nokta_takvim"],
        "yol_koridor": yigin["yol_koridor"],
        "tr_net_yol_10_son": yigin["tr_net_yol_10_son"],
        "dogrulama_2024": dogrulama,
        "not": (
            f"Taban: {sid} + refah rant entegrasyonu. "
            "Reform katmanları politika USD tavanlarına göre gerçekleşme ile kısıldı. "
            "TR net USD: üç köprü + geometrik orta; GSYH WB TL/kur."
        ),
    }
    return out, yigin


def kalibre_et(pipeline: bool = True, senaryolar: tuple[str, ...] = ("A", "B", "C")) -> dict[str, Any]:
    if pipeline:
        _pipeline()
    capa = _load(CAPA)
    proj = _load(OUT / "PROJEKSIYON.json")
    akis = _load(OUT / "AKIS_OLCUM.json")
    sen_doc = _load(DATA / "senaryolar.json")

    satirlar: list[dict[str, Any]] = []
    out_c: dict[str, Any] | None = None
    for sid in senaryolar:
        ref_path = _refah_dosya(sid)
        refah = _load(ref_path) if ref_path else None
        sen = next(s for s in sen_doc["senaryolar"] if s["id"] == sid)
        out, yigin = _gerceklik_paket(sid, proj, capa, akis, refah, sen)
        (OUT / f"GERCEKLIK_KALIBRE_{sid}.json").write_text(
            json.dumps(out, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        satirlar.append(
            {
                "id": sid,
                "tr_net_kalibre_son": out["tr_net_kalibre_son"],
                "tr_net_yol_10_son": yigin["tr_net_yol_10_son"],
                "gsyh_yuzde_son": out["gsyh_yuzde_son"],
                "gerceklesme_oranlari": out["gerceklesme_oranlari"],
                "sifir_nokta_takvim": out["sifir_nokta_takvim"],
            }
        )
        if sid == "C":
            out_c = out

    if out_c is None and satirlar:
        out_c = _gerceklik_paket("C", proj, capa, akis, _load(_refah_dosya("C")) if _refah_dosya("C") else None, None)[0]

    assert out_c is not None
    (OUT / "GERCEKLIK_KALIBRE.json").write_text(
        json.dumps(out_c, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    coklu = {
        "olcum": "gerceklik_kalibre_senaryo_coklu",
        "referans_senaryo": "C",
        "senaryolar": satirlar,
    }
    (OUT / "GERCEKLIK_SENARYO_COKLU.json").write_text(
        json.dumps(coklu, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (KALIBRE / "gerceklik_realizasyon.json").write_text(
        json.dumps(
            {
                "gerceklesme_oranlari": out_c["gerceklesme_oranlari"],
                "iyilesme_tavan_usd_mn": out_c["iyilesme_tavan_usd_mn"],
                "usd_per_vekil_mn": out_c["usd_per_vekil_mn"],
                "usd_kopruleri": out_c["usd_kopruleri"],
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    return out_c


def _md(d: dict[str, Any]) -> str:
    lines = [
        "# Senaryo — gerçeklik kalibrasyonu (2024 çapa)",
        "",
        d["not"],
        "",
        f"- **BoP (merkez+rant):** 1 vekil ≈ {d['usd_per_vekil_mn']:,} mn USD",
        f"- **GSYH (vekili):** {d['gsyh_usd_mn']:,} mn USD",
        "",
        "### USD köprüleri",
        "",
    ]
    for key, row in (d.get("usd_kopruleri") or {}).items():
        lines.append(f"- **{key}:** 1 vekil ≈ **{row['usd_per_vekil_mn']:,}** mn USD")
    lines.extend(
        [
        "",
        "",
        "## Doğrulama (2024)",
        "",
        f"- MFIN kenar USD (model C): {d['dogrulama_2024']['mfin_kenar_usd_model']:,} mn",
        f"- Yatırım geliri gideri: {d['dogrulama_2024']['cicek_usd']:,} mn",
        f"- Net ticaret: {d['dogrulama_2024']['net_ticaret_usd']:,} mn",
        f"- TR küresel yatırım geliri payı: %{d['dogrulama_2024']['global_yatirim_geliri_tr_yuzde']}",
        f"- TİM/Ticaret kalibrasyonu aktif: {d['dogrulama_2024']['kalibre_ticaret_2024']}",
        f"- Rant modeli: **{d.get('rant_modeli') or d['dogrulama_2024'].get('rant_modeli')}**",
        f"- Refah rant (toplam / TR iç): {d['dogrulama_2024'].get('refah_rant_toplam_vekil')} / "
        f"{d['dogrulama_2024'].get('tr_refah_ic_pay_vekil')} vekil",
        "",
        "## İyileşme tavanları (10 yıl, USD mn)",
        "",
        f"- Zarar teorisi: {d['iyilesme_tavan_usd_mn']['zarar']}",
        f"- Üretim/rant: {d['iyilesme_tavan_usd_mn']['uretim']}",
        f"- Finans: {d['iyilesme_tavan_usd_mn']['finans']}",
        "",
        "## Gerçekleşme oranları",
        "",
        f"- Zarar: **{d['gerceklesme_oranlari']['zarar_teorisi']}**",
        f"- Üretim/iç akış: **{d['gerceklesme_oranlari']['uretim_ic_akis']}**",
        f"- Finans: **{d['gerceklesme_oranlari']['finans_katman']}**",
        "",
        "## Kalibre katman yığını",
        "",
        "| Katman | TR net | USD BoP | USD rant | USD mal | Orta | GSYH% orta |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: |",
        ]
    )
    for k in d["katman_yigini_kalibre"]:
        lines.append(
            f"| {k['katman']} | {k['tr_net']} | {k['tr_net_usd_mn_bop']:,} | "
            f"{k['tr_net_usd_mn_rant']:,} | {k['tr_net_usd_mn_mal']:,} | "
            f"{k['tr_net_usd_mn_orta']:,} | {k['gsyh_yuzde_orta']} |"
        )
    lines.extend(
        [
            "",
            f"**Ham model (finans son):** {d['model_ham_finans_son']['tr_net']} vekil — kalibre sonrası "
            f"**{d['tr_net_kalibre_son']}** vekil (USD orta **{d['tr_net_usd_mn_son']['geometrik_orta_mn']:,}** mn, "
            f"**%{d['gsyh_yuzde_son']}** GSYH).",
            "",
            f"**Sıfır noktası (kalibre orta yol):** {d['sifir_nokta_takvim'] or '— (net pozitife çıkmıyor)'}",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    import argparse

    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-pipeline", action="store_true", help="Mevcut zarar/uretim/finans raporları üzerinde kalibre")
    args = ap.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    data = kalibre_et(pipeline=not args.skip_pipeline)
    (OUT / "GERCEKLIK_KALIBRE.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'GERCEKLIK_KALIBRE.md'} + GERCEKLIK_SENARYO_COKLU.json")


if __name__ == "__main__":
    main()
