"""Dış rant kanalları — zarar (boşluk) vs refah parasal akış (USD)."""
from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"

if str(REPO / "etki_cephesi") not in sys.path:
    sys.path.insert(0, str(REPO / "etki_cephesi"))
from rant_kanal_eslesme import akis_kanal_etiket, load_eslesme  # noqa: E402


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _bolge_key(bid: str) -> str:
    leg = {
        "irak_bagdat": "irak",
        "irak_krg": "irak",
        "dogu_akdeniz_gaz": "dogu_akdeniz",
        "dogu_akdeniz_kefalet": "dogu_akdeniz",
    }
    return leg.get(bid, bid)


def _refah_endeks(iso: str, sysdoc: dict[str, Any]) -> float:
    return float((sysdoc.get("ulkeler") or {}).get(iso, {}).get("refah_endeks") or 0.5)


def _dis_weights(bid: str, pay_tab: dict[str, Any], ulke_sys: dict[str, Any]) -> dict[str, float]:
    pkey = _bolge_key(bid)
    row = pay_tab.get(pkey) or pay_tab.get(bid) or {}
    weights = {a: float(p) * _refah_endeks(a, ulke_sys) for a, p in row.items() if a != "TR"}
    s = sum(weights.values()) or 1.0
    return {a: w / s for a, w in weights.items()}


def _ulke_kanal_dagilim(
    sen: dict[str, Any],
    pay_tab: dict[str, Any],
    ulke_sys: dict[str, Any],
    usd_per_rant: float,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    """Ülke × AKIS kanal — refah dış havuz ve zarar (boşluk) vekili/USD."""
    ref: dict[tuple[str, str], dict[str, float]] = defaultdict(
        lambda: {"refah_dis_vekil": 0.0, "zarar_vekil": 0.0}
    )
    ulke_ref_tot: dict[str, float] = defaultdict(float)
    ulke_zar_tot: dict[str, float] = defaultdict(float)

    for b in sen.get("bolgesel_net") or []:
        bid = b["bolge"]
        wtab = _dis_weights(bid, pay_tab, ulke_sys)
        tags = [akis_kanal_etiket(str(t)) for t in (b.get("rant_kanallar") or ["refah_rant"])]
        n = len(tags) or 1
        bos = float(b.get("bosluk_rant_karsiligi") or 0.0) / n
        dis_h = float(b.get("refah_rant_dis_havuz") or 0.0) / n
        for kanal in tags:
            for iso, w in wtab.items():
                ref[(iso, kanal)]["refah_dis_vekil"] += dis_h * w
                ref[(iso, kanal)]["zarar_vekil"] += bos * w
                ulke_ref_tot[iso] += dis_h * w
                ulke_zar_tot[iso] += bos * w

    hucreler: list[dict[str, Any]] = []
    for (iso, kanal), v in ref.items():
        rv, zv = v["refah_dis_vekil"], v["zarar_vekil"]
        if rv < 1e-6 and zv < 1e-6:
            continue
        hucreler.append(
            {
                "ulke": iso,
                "kanal_akis": kanal,
                "refah_dis_vekil": round(rv, 4),
                "zarar_bosluk_vekil": round(zv, 4),
                "refah_dis_usd_mn": round(rv * usd_per_rant, 1),
                "zarar_usd_mn": round(zv * usd_per_rant, 1),
                "fark_bosluk_minus_refah_usd_mn": round((zv - rv) * usd_per_rant, 1),
                "refah_ulke_icinde_pay": round(rv / ulke_ref_tot[iso], 4) if ulke_ref_tot[iso] > 0 else 0.0,
            }
        )
    hucreler.sort(key=lambda x: -(x["refah_dis_usd_mn"] + x["zarar_usd_mn"]))

    ulke_ozet: list[dict[str, Any]] = []
    for iso in sorted(set(ulke_ref_tot) | set(ulke_zar_tot), key=lambda x: -ulke_ref_tot.get(x, 0)):
        kanallar = [h for h in hucreler if h["ulke"] == iso]
        kanallar.sort(key=lambda x: -x["refah_dis_usd_mn"])
        ref_u = round(ulke_ref_tot[iso] * usd_per_rant, 1)
        zar_u = round(ulke_zar_tot[iso] * usd_per_rant, 1)
        ulke_ozet.append(
            {
                "ulke": iso,
                "refah_dis_toplam_usd_mn": ref_u,
                "zarar_toplam_usd_mn": zar_u,
                "fark_bosluk_minus_refah_usd_mn": round(zar_u - ref_u, 1),
                "kanal_sayisi": len(kanallar),
                "en_buyuk_kanallar": kanallar[:6],
            }
        )

    kanal_top: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for h in hucreler:
        kanal_top[h["kanal_akis"]].append(h)
    kanal_ozet: list[dict[str, Any]] = []
    for kanal, rows in sorted(kanal_top.items(), key=lambda x: -sum(r["refah_dis_usd_mn"] for r in x[1])):
        rows.sort(key=lambda x: -x["refah_dis_usd_mn"])
        ref_t = round(sum(r["refah_dis_usd_mn"] for r in rows), 1)
        zar_t = round(sum(r["zarar_usd_mn"] for r in rows), 1)
        kanal_ozet.append(
            {
                "kanal_akis": kanal,
                "refah_dis_usd_mn_toplam": ref_t,
                "zarar_usd_mn_toplam": zar_t,
                "fark_bosluk_minus_refah_usd_mn": round(zar_t - ref_t, 1),
                "ulke_dagilimi": rows[:8],
            }
        )

    return hucreler, ulke_ozet, kanal_ozet


def hesapla(senaryo_id: str = "C") -> dict[str, Any]:
    proj = _load(OUT / "PROJEKSIYON.json")
    akis = _load(OUT / "AKIS_OLCUM.json")
    dis = _load(DATA / "dis_aktör_pay.json")
    ulke_sys = _load(DATA / "dis_ulke_sistemi.json")
    kosul = _load(DATA / "modul_kosullari.json")

    sen = next(s for s in proj["senaryolar"] if s["id"] == senaryo_id)
    kopruler = akis["usd_kopruleri"]
    usd_per_rant = float(kopruler["tum_havza_rant"]["usd_per_vekil_mn"])

    kanal_ham: dict[str, dict[str, float]] = defaultdict(
        lambda: {"zarar_vekil": 0.0, "refah_dis_vekil": 0.0, "refah_tr_ic_vekil": 0.0}
    )
    kanal: dict[str, dict[str, float]] = defaultdict(
        lambda: {"zarar_vekil": 0.0, "refah_dis_vekil": 0.0, "refah_tr_ic_vekil": 0.0}
    )
    bolge_rows: list[dict[str, Any]] = []
    eslesme_doc = load_eslesme()

    akis_pay: dict[str, float] = {}
    for row in akis.get("rant_kanal_usd_vekili") or []:
        akis_pay[str(row["kanal"])] = float(row.get("rant_vekil_pay") or 0.0)

    for b in sen.get("bolgesel_net") or []:
        tags_raw = b.get("rant_kanallar") or ["refah_rant"]
        tags = [akis_kanal_etiket(str(t)) for t in tags_raw]
        n = len(tags) or 1
        bos = float(b.get("bosluk_rant_karsiligi") or 0.0)
        dis_h = float(b.get("refah_rant_dis_havuz") or 0.0)
        tr_ic = float(b.get("refah_rant_tr_ic") or 0.0)
        for tr, ta in zip(tags_raw, tags):
            kanal_ham[str(tr)]["zarar_vekil"] += bos / n
            kanal_ham[str(tr)]["refah_dis_vekil"] += dis_h / n
            kanal_ham[str(tr)]["refah_tr_ic_vekil"] += tr_ic / n
            kanal[ta]["zarar_vekil"] += bos / n
            kanal[ta]["refah_dis_vekil"] += dis_h / n
            kanal[ta]["refah_tr_ic_vekil"] += tr_ic / n
        bolge_rows.append(
            {
                "bolge": b["bolge"],
                "zarar_bosluk_vekil": bos,
                "refah_dis_vekil": dis_h,
                "refah_tr_ic_vekil": tr_ic,
            }
        )

    kanal_list: list[dict[str, Any]] = []
    tot_z = tot_r = 0.0
    for name, v in sorted(kanal.items(), key=lambda x: -(x[1]["zarar_vekil"] + x[1]["refah_dis_vekil"])):
        zv, rv, tv = v["zarar_vekil"], v["refah_dis_vekil"], v["refah_tr_ic_vekil"]
        tot_z += zv
        tot_r += rv + tv
        kanal_list.append(
            {
                "kanal": name,
                "zarar_bosluk_vekil": round(zv, 3),
                "refah_dis_vekil": round(rv, 3),
                "refah_tr_ic_vekil": round(tv, 3),
                "zarar_usd_mn": round(zv * usd_per_rant, 1),
                "refah_dis_usd_mn": round(rv * usd_per_rant, 1),
                "refah_tr_ic_usd_mn": round(tv * usd_per_rant, 1),
                "fark_usd_mn": round((zv - rv) * usd_per_rant, 1),
            }
        )

    pay_tab = dis.get("bolge_pay") or {}
    ulke_refah: dict[str, float] = defaultdict(float)
    ulke_zarar: dict[str, float] = defaultdict(float)
    for b in sen.get("bolgesel_net") or []:
        wtab = _dis_weights(b["bolge"], pay_tab, ulke_sys)
        for a, w in wtab.items():
            ulke_refah[a] += float(b.get("refah_rant_dis_havuz") or 0) * w
            ulke_zarar[a] += float(b.get("bosluk_rant_karsiligi") or 0) * w

    ulke_kanal_hucre, ulke_kanal_ozet, kanal_ulke_ozet = _ulke_kanal_dagilim(
        sen, pay_tab, ulke_sys, usd_per_rant
    )

    ulke_list = []
    for iso in sorted(set(ulke_refah) | set(ulke_zarar), key=lambda x: -ulke_refah.get(x, 0)):
        rv = ulke_refah.get(iso, 0.0)
        zv = ulke_zarar.get(iso, 0.0)
        ulke_list.append(
            {
                "ulke": iso,
                "refah_dis_vekil": round(rv, 3),
                "zarar_bosluk_vekil": round(zv, 3),
                "refah_dis_usd_mn": round(rv * usd_per_rant, 1),
                "zarar_usd_mn": round(zv * usd_per_rant, 1),
                "fark_bosluk_minus_refah_usd_mn": round((zv - rv) * usd_per_rant, 1),
            }
        )

    tr_ic_top = sum(float(b.get("refah_rant_tr_ic") or 0) for b in sen.get("bolgesel_net") or [])

    refah_dis_top = sum(k["refah_dis_vekil"] for k in kanal_list)
    kanal_akis: list[dict[str, Any]] = []
    for name, v in sorted(kanal.items(), key=lambda x: -(x[1]["refah_dis_vekil"] + x[1]["zarar_vekil"])):
        zv, rv, tv = v["zarar_vekil"], v["refah_dis_vekil"], v["refah_tr_ic_vekil"]
        pay_akis = akis_pay.get(name)
        pay_refah = round(rv / refah_dis_top, 4) if refah_dis_top > 0 else 0.0
        kanal_akis.append(
            {
                "kanal_akis": name,
                "akis_rant_vekil_pay": pay_akis,
                "refah_dis_pay_model": pay_refah,
                "pay_farki": round((pay_refah - pay_akis), 4) if pay_akis is not None else None,
                "zarar_bosluk_vekil": round(zv, 3),
                "refah_dis_vekil": round(rv, 3),
                "refah_tr_ic_vekil": round(tv, 3),
                "zarar_usd_mn": round(zv * usd_per_rant, 1),
                "refah_dis_usd_mn": round(rv * usd_per_rant, 1),
                "refah_tr_ic_usd_mn": round(tv * usd_per_rant, 1),
                "fark_bosluk_minus_refah_usd_mn": round((zv - rv) * usd_per_rant, 1),
            }
        )

    eslesme_tab = eslesme_doc.get("etiket_akis_kanal") or {}
    ref_dis_usd = sum(k["refah_dis_vekil"] for k in kanal_list) * usd_per_rant
    zar_usd = tot_z * usd_per_rant

    return {
        "olcum": "dis_rant_kanali_parasal_akisi",
        "modul_kosul": kosul.get("dis_rant_parasal_akisi"),
        "senaryo": senaryo_id,
        "rant_modeli": proj.get("rant_modeli"),
        "usd_per_vekil_rant_mn": usd_per_rant,
        "ozet": {
            "zarar_bosluk_toplam_vekil": round(tot_z, 3),
            "refah_dis_toplam_vekil": round(sum(k["refah_dis_vekil"] for k in kanal_list), 3),
            "refah_tr_ic_toplam_vekil": round(tr_ic_top, 3),
            "zarar_usd_mn_toplam": round(tot_z * usd_per_rant, 1),
            "refah_dis_usd_mn_toplam": round(
                sum(k["refah_dis_vekil"] for k in kanal_list) * usd_per_rant, 1
            ),
            "refah_tr_ic_usd_mn": round(tr_ic_top * usd_per_rant, 1),
            "tasarruf_refah_vs_zarar_usd_mn": round((tot_z - sum(k["refah_dis_vekil"] for k in kanal_list)) * usd_per_rant, 1),
            "fark_bosluk_minus_refah_dis_usd_mn": round(zar_usd - ref_dis_usd, 1),
            "tr_refah_ic_usd_mn": round(tr_ic_top * usd_per_rant, 1),
            "tr_toplam_refah_kazanc_usd_mn": round(
                (tot_z - sum(k["refah_dis_vekil"] for k in kanal_list) + tr_ic_top) * usd_per_rant, 1
            ),
        },
        "bosluk_vs_refah_not": (
            "fark_bosluk_minus_refah = boşluk karşı senaryosu − refah dış havuz (mn USD/yıl). "
            "TR refah iç payı boşluk tablosunda yok; tr_toplam_refah_kazanc = fark dış + TR iç."
        ),
        "kanal_dagilimi": kanal_list[:25],
        "kanal_dagilimi_akis_eslesmeli": kanal_akis,
        "eslesme_sozlugu": eslesme_tab,
        "ulke_dagilimi_dis": ulke_list[:20],
        "ulke_rant_kanal": {
            "not": "Bölge rant_kanallar → AKIS kanal; ülke payı = dis_aktör_pay × refah_endeks",
            "hucre_top120": ulke_kanal_hucre[:120],
            "ulke_bazinda": ulke_kanal_ozet[:25],
            "kanal_bazinda": kanal_ulke_ozet,
        },
        "kaynak": [
            "PROJEKSIYON.json",
            "AKIS_OLCUM.json",
            "kalibre/rant_kanal_akis_eslesme.json",
            "modul_kosullari.json",
        ],
    }


def _md(d: dict[str, Any]) -> str:
    o = d["ozet"]
    lines = [
        "# Dış rant kanalları — parasal akış (zarar vs refah)",
        "",
        f"Senaryo **{d['senaryo']}** · rant modeli **{d['rant_modeli']}** · "
        f"1 rant vekil ≈ **{d['usd_per_vekil_rant_mn']:,}** mn USD",
        "",
        "## Özet (mn USD / yıl vekili)",
        "",
        f"| | Vekil | USD |",
        f"| --- | ---: | ---: |",
        f"| Zarar (boşluk rant) | {o['zarar_bosluk_toplam_vekil']} | {o['zarar_usd_mn_toplam']:,} |",
        f"| Refah — dış havuz | {o['refah_dis_toplam_vekil']} | {o['refah_dis_usd_mn_toplam']:,} |",
        f"| Refah — TR iç | {o['refah_tr_ic_toplam_vekil']} | {o['refah_tr_ic_usd_mn']:,} |",
        f"| Fark (boşluk−refah dış) | — | **{o['fark_bosluk_minus_refah_dis_usd_mn']:,}** |",
        f"| TR refah iç | {o['refah_tr_ic_toplam_vekil']} | {o['tr_refah_ic_usd_mn']:,} |",
        f"| **TR toplam refah kazancı** | — | **{o['tr_toplam_refah_kazanc_usd_mn']:,}** |",
        "",
        "## Kanal dağılımı — AKIS eşleşmeli",
        "",
        "Etiketler `kalibre/rant_kanal_akis_eslesme.json` ile `AKIS_OLCUM.rant_kanal_usd_vekili` anahtarına indirgenir.",
        "",
        "| AKIS kanal | AKIS pay | Refah dış pay | Zarar USD | Refah dış USD | Fark |",
        "| --- | ---: | ---: | ---: | ---: | ---: |",
    ]
    for k in (d.get("kanal_dagilimi_akis_eslesmeli") or [])[:18]:
        ap = k.get("akis_rant_vekil_pay")
        ap_s = f"{ap:.4f}" if ap is not None else "—"
        lines.append(
            f"| {k['kanal_akis']} | {ap_s} | {k['refah_dis_pay_model']:.4f} | "
            f"{k['zarar_usd_mn']:,} | {k['refah_dis_usd_mn']:,} | {k['fark_bosluk_minus_refah_usd_mn']:,} |"
        )
    lines.extend(["", "## Ülke toplam (dış havuz)", ""])
    for u in d["ulke_dagilimi_dis"][:12]:
        lines.append(
            f"- **{u['ulke']}:** refah {u['refah_dis_usd_mn']:,} · zarar {u['zarar_usd_mn']:,} · "
            f"fark **{u['fark_bosluk_minus_refah_usd_mn']:,}** mn $"
        )

    uk = d.get("ulke_rant_kanal") or {}
    lines.extend(
        [
            "",
            "## Dış ülkeler — rant kanalından alınan akış (mn USD/yıl vekili)",
            "",
            "### Kanal → ülke (refah dış havuz, top)",
            "",
            "| Kanal | Refah USD | Zarar USD | Fark | Önde gelen ülkeler |",
            "| --- | ---: | ---: | ---: | --- |",
        ]
    )
    for k in (uk.get("kanal_bazinda") or [])[:12]:
        ulk = ", ".join(
            f"{r['ulke']} {r['refah_dis_usd_mn']:,.0f}" for r in (k.get("ulke_dagilimi") or [])[:4]
        )
        lines.append(
            f"| {k['kanal_akis']} | {k['refah_dis_usd_mn_toplam']:,} | {k['zarar_usd_mn_toplam']:,} | "
            f"{k['fark_bosluk_minus_refah_usd_mn']:,} | {ulk} |"
        )
    lines.extend(["", "### Ülke → kanal kırılımı (refah, top 8 ülke)", ""])
    for u in (uk.get("ulke_bazinda") or [])[:8]:
        lines.append(f"**{u['ulke']}** — refah **{u['refah_dis_toplam_usd_mn']:,}** · zarar {u['zarar_toplam_usd_mn']:,} mn $")
        for ch in (u.get("en_buyuk_kanallar") or [])[:5]:
            lines.append(
                f"  - {ch['kanal_akis']}: refah {ch['refah_dis_usd_mn']:,} · zarar {ch['zarar_usd_mn']:,}"
            )
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    data = hesapla()
    (OUT / "DIS_RANT_PARASAL.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "DIS_RANT_PARASAL.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'DIS_RANT_PARASAL.md'}")


if __name__ == "__main__":
    main()
