"""Dış ülkeler (tam metadata) + uluslararası kurumlar — refah defterine ek katman."""
from __future__ import annotations

import json
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _kurum_vekiller(
    kurum_doc: dict[str, Any],
    rant: dict[str, Any],
    mfin_sizinti_vekil: float,
) -> list[dict[str, Any]]:
    usd_v = float(rant.get("usd_per_vekil_rant_mn") or 5383.0)
    kanallar = rant.get("kanal_dagilimi_akis_eslesmeli") or []
    kanal_usd: dict[str, float] = {}
    for row in kanallar:
        k = str(row.get("kanal_akis") or "")
        kanal_usd[k] = kanal_usd.get(k, 0.0) + float(row.get("refah_dis_usd_mn") or 0.0)

    pay_top = sum(float(k.get("merkez_sizinti_pay") or 0) for k in kurum_doc.get("kurumlar") or [])
    pay_top = pay_top or 1.0

    rows: list[dict[str, Any]] = []
    for k in kurum_doc.get("kurumlar") or []:
        kid = str(k["id"])
        usd = 0.0
        for ch, pay in (k.get("kanal_usd_pay") or {}).items():
            usd += kanal_usd.get(str(ch), 0.0) * float(pay)
        ms_pay = float(k.get("merkez_sizinti_pay") or 0.0)
        usd += (mfin_sizinti_vekil * usd_v) * (ms_pay / pay_top) * 0.15
        vekil_rant = usd / usd_v if usd_v > 0 else 0.0
        ms_vekil = round(mfin_sizinti_vekil * (ms_pay / pay_top) * 0.12, 3)
        kan_vekil = round(vekil_rant * 0.55, 3)
        net = round(kan_vekil + ms_vekil, 3)
        rows.append(
            {
                "ulke": kid,
                "ad": k.get("ad", kid),
                "tur": k.get("tur", "uluslararasi_kurum"),
                "refah_endeks": float(k.get("refah_endeks") or 0.5),
                "havza_net": 0.0,
                "kanal_kazanc": kan_vekil,
                "ikame_kazanc": 0.0,
                "merkez_sizinti": ms_vekil,
                "merkez_belirsiz": 0.0,
                "refah_rant": round(vekil_rant * 0.45, 3),
                "dis_toplam_vekili": round(kan_vekil + ms_vekil + vekil_rant * 0.45, 3),
                "havza_kayip": 0.0,
                "net_refah_entegre": net,
                "refah_dis_usd_mn_vekili": round(usd, 1),
            }
        )
    rows.sort(key=lambda x: -x["net_refah_entegre"])
    return rows


def _ulke_metadata_zenginlestir(defter: dict[str, Any], ulke_sys: dict[str, Any], ek: dict[str, Any]) -> None:
    base = ulke_sys.get("ulkeler") or {}
    for row in defter.get("ulke_defteri") or []:
        iso = str(row["ulke"])
        meta = {**(base.get(iso) or {}), **(ek.get(iso) or {})}
        if meta.get("ad"):
            row["ad"] = meta["ad"]
        if meta.get("rol"):
            row["rol"] = meta["rol"]
        if meta.get("refah_endeks") is not None and row.get("refah_endeks") is None:
            row["refah_endeks"] = meta["refah_endeks"]
        if iso not in ("MFIN", "HAVZA", "TR") and not row.get("tur"):
            row["tur"] = "devlet_aktor"


def genislet(
    defter: dict[str, Any],
    rant: dict[str, Any] | None = None,
) -> dict[str, Any]:
    kurum_doc = _load(DATA / "dis_kurum_sistemi.json")
    ulke_sys = _load(DATA / "dis_ulke_sistemi.json")
    if rant is None:
        rp = OUT / "DIS_RANT_PARASAL.json"
        rant = _load(rp) if rp.is_file() else {}

    d = deepcopy(defter)
    _ulke_metadata_zenginlestir(d, ulke_sys, kurum_doc.get("ulke_ek_metadata") or {})

    mfin = next((r for r in d.get("ulke_defteri") or [] if r.get("ulke") == "MFIN"), {})
    mfin_ms = float(mfin.get("merkez_sizinti") or 0.0)

    kurum_ids = {str(k["id"]) for k in kurum_doc.get("kurumlar") or []}
    kurumlar = _kurum_vekiller(kurum_doc, rant, mfin_ms)
    ulkeler = [r for r in d.get("ulke_defteri") or [] if str(r.get("ulke")) not in kurum_ids]
    birlesik = sorted(ulkeler + kurumlar, key=lambda x: -float(x.get("net_refah_entegre") or 0))

    d["ulke_defteri"] = birlesik
    d["kurum_defteri"] = kurumlar
    d["ulke_sayisi"] = len(ulkeler)
    d["kurum_sayisi"] = len(kurumlar)
    d["kurum_refah_usd_mn_toplam"] = round(sum(k.get("refah_dis_usd_mn_vekili") or 0 for k in kurumlar), 1)
    d["olcum_ek"] = "dis_ulke_kurum_genisletme"
    return d


def dosya_genislet(kaynak: Path, hedef: Path, rant_path: Path | None = None) -> dict[str, Any]:
    defter = _load(kaynak)
    rant = _load(rant_path) if rant_path and rant_path.is_file() else None
    out = genislet(defter, rant)
    hedef.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    return out


def _md(d: dict[str, Any]) -> str:
    lines = [
        "# Dış ülkeler + uluslararası kurumlar",
        "",
        f"**{d.get('ulke_sayisi', '—')}** ülke · **{d.get('kurum_sayisi', '—')}** kurum · "
        f"kurum refah USD vekili **{d.get('kurum_refah_usd_mn_toplam', 0):,}** mn/yıl",
        "",
        "## Kurumlar (net entegre vekil)",
        "",
        "| Kurum | Tür | Net | USD vekili |",
        "| --- | --- | ---: | ---: |",
    ]
    for k in d.get("kurum_defteri") or []:
        lines.append(
            f"| {k['ad']} | {k.get('tur', '—')} | {k['net_refah_entegre']} | {k.get('refah_dis_usd_mn_vekili', '—')} |"
        )
    lines.extend(["", "## Ülkeler (top 12 net)", ""])
    devlet = [r for r in d.get("ulke_defteri") or [] if r.get("tur") != "uluslararasi_kurum" and r.get("tur") != "bolgesel_kurum" and r.get("tur") != "altyapi_kurum"]
    devlet = [r for r in devlet if str(r.get("ulke")) not in {x["ulke"] for x in d.get("kurum_defteri") or []}]
    for u in sorted(devlet, key=lambda x: -float(x.get("net_refah_entegre") or 0))[:12]:
        lines.append(f"- **{u.get('ad', u['ulke'])}** ({u.get('rol', '—')}): net **{u['net_refah_entegre']}**")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    src = OUT / "DIS_ULKE_REFAH.json"
    if not src.is_file():
        raise SystemExit("Önce refah_dis_entegrasyon.py")
    data = dosya_genislet(src, OUT / "DIS_ULKE_REFAH_GENIS.json")
    (OUT / "DIS_ULKE_KURUM.md").write_text(_md(data), encoding="utf-8")

    for sid in ("A", "B", "C"):
        p = OUT / f"DIS_ULKE_REFAH_{sid}.json"
        rp = OUT / f"DIS_RANT_PARASAL_{sid}.json"
        if p.is_file():
            dosya_genislet(p, OUT / f"DIS_ULKE_REFAH_GENIS_{sid}.json", rp if rp.is_file() else None)

    print(f"Wrote {OUT / 'DIS_ULKE_REFAH_GENIS.json'} and {OUT / 'DIS_ULKE_KURUM.md'}")


if __name__ == "__main__":
    main()
