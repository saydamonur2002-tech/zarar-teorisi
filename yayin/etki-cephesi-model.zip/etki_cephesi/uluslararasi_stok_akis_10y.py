"""P2: 10 yıl uluslararası stok-akış serisi (kalibre TR yolu + refah olgunluk ölçeği)."""
from __future__ import annotations

import json
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"

if str(REPO / "etki_cephesi") not in sys.path:
    sys.path.insert(0, str(REPO / "etki_cephesi"))

from uluslararasi_stok_akis import matris_olustur  # noqa: E402


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _defter_olcek(
    base: dict[str, Any],
    tr_net_vekil: float,
    dis_olcek: float,
) -> dict[str, Any]:
    """Defter satırlarını yıl için ölçekle; TR net yolu kalibre yolundan."""
    d = deepcopy(base)
    rows: list[dict[str, Any]] = []
    flow_keys = (
        "refah_rant",
        "kanal_kazanc",
        "ikame_kazanc",
        "merkez_sizinti",
        "merkez_belirsiz",
    )
    for row in d.get("ulke_defteri") or []:
        r = dict(row)
        iso = str(r["ulke"])
        if iso == "TR":
            ref = float(r.get("refah_rant") or 0.0) * dis_olcek
            r["refah_rant"] = round(ref, 3)
            r["net_refah_entegre"] = round(tr_net_vekil, 3)
            rows.append(r)
            continue
        if iso in ("MFIN", "HAVZA"):
            rows.append(r)
            continue
        for k in flow_keys:
            if k in r:
                r[k] = round(float(r.get(k) or 0.0) * dis_olcek, 3)
        ref = float(r.get("refah_rant") or 0.0)
        dis_k = round(
            float(r.get("kanal_kazanc") or 0.0)
            + float(r.get("ikame_kazanc") or 0.0)
            + float(r.get("merkez_sizinti") or 0.0)
            + float(r.get("merkez_belirsiz") or 0.0)
            + ref,
            3,
        )
        hk = round(float(r.get("havza_kayip") or 0.0) * dis_olcek, 3)
        hn = float(r.get("havza_net") or 0.0) * dis_olcek
        r["dis_toplam_vekili"] = dis_k
        r["havza_kayip"] = hk
        r["net_refah_entegre"] = round(dis_k - hk + max(0.0, hn), 3)
        rows.append(r)
    d["ulke_defteri"] = rows
    return d


def _yol_10y() -> list[dict[str, Any]]:
    z10 = _load(OUT / "ZARAR_10Y_GSYH.json")
    seri = z10.get("yillik_seri") or []
    if seri:
        return [{"yil": int(s["yil"]), "tr_net": float(s["tr_net"])} for s in seri[:10]]
    ger = _load(OUT / "GERCEKLIK_KALIBRE.json")
    return [
        {"yil": int(r["yil"]), "tr_net": float(r["tr_net"])}
        for r in (ger.get("yol_koridor") or [])[:10]
    ]


def _rant_olcek(rant: dict[str, Any], olcek: float) -> dict[str, Any]:
    r = deepcopy(rant)
    oz = r.setdefault("ozet", {})
    for key in (
        "refah_dis_usd_mn_toplam",
        "refah_dis_toplam_vekil",
        "refah_tr_ic_usd_mn",
        "refah_tr_ic_toplam_vekil",
        "zarar_usd_mn_toplam",
        "zarar_bosluk_toplam_vekil",
    ):
        if key in oz and oz[key] is not None:
            oz[key] = round(float(oz[key]) * olcek, 3 if "vekil" in key else 1)
    return r


def _refah_olgunluk(yil: int, y0: int, y1: int, taban: float, hedef: float) -> float:
    if y1 <= y0:
        return hedef
    u = (yil - y0) / (y1 - y0)
    u = max(0.0, min(1.0, u))
    return taban + (hedef - taban) * u


def hesapla(senaryo_defter: str = "C") -> dict[str, Any]:
    base_path = OUT / f"DIS_ULKE_REFAH_{senaryo_defter}.json"
    if not base_path.is_file():
        base_path = OUT / "DIS_ULKE_REFAH.json"
    rant_path = OUT / f"DIS_RANT_PARASAL_{senaryo_defter}.json"
    if not rant_path.is_file():
        rant_path = OUT / "DIS_RANT_PARASAL.json"

    base_defter = _load(base_path)
    rant = _load(rant_path)
    ger = _load(OUT / "GERCEKLIK_KALIBRE.json")
    yol = _yol_10y()
    if not yol:
        raise SystemExit("ZARAR_10Y_GSYH veya GERCEKLIK yol yok")

    g = ger.get("gerceklesme_oranlari") or {}
    r_taban = min(float(g.get("zarar_teorisi") or 0.7), float(g.get("uretim_ic_akis") or 0.5))
    r_hedef = max(float(g.get("finans_katman") or 0.3), r_taban)
    y0, y1 = yol[0]["yil"], yol[-1]["yil"]

    snapshot_yillar = {y0, y0 + 3, y1}
    seri: list[dict[str, Any]] = []
    anlik: list[dict[str, Any]] = []
    for row in yol:
        y = int(row["yil"])
        tr = float(row["tr_net"])
        olcek = _refah_olgunluk(y, y0, y1, r_taban, 1.0)
        defter_y = _defter_olcek(base_defter, tr, olcek)
        mat = matris_olustur(defter=defter_y, rant=_rant_olcek(rant, olcek), ger=ger)
        k = mat["kalibrasyon"]
        stok = mat.get("stok") or {}
        top_win = sorted(
            ((iso, float(v.get("net_vekil") or 0)) for iso, v in stok.items() if iso not in ("HAVZA", "MFIN")),
            key=lambda x: -x[1],
        )[:5]
        kayit = {
            "yil": y,
            "tr_net_kalibre": tr,
            "refah_olgunluk_olcek": round(olcek, 4),
            "stok_net_vekil": k.get("stok_net_toplam_vekil"),
            "kapanis_ok": k.get("kapanis_ok"),
            "refah_dis_usd_kalibre_mn": k.get("refah_dis_usd_kalibre_mn"),
            "mfin_stok_vekil": (k.get("mfin_havza_denge") or {}).get("mfin_stok_vekil"),
            "havza_stok_vekil": (k.get("mfin_havza_denge") or {}).get("havza_stok_vekil"),
            "top5_stok_vekil": [{"ulke": u, "net": round(v, 3)} for u, v in top_win],
        }
        seri.append(kayit)
        if y in snapshot_yillar:
            stok_kompakt = {
                iso: {"net_vekil": v.get("net_vekil"), "net_usd_mn": v.get("net_usd_mn")}
                for iso, v in (mat.get("stok") or {}).items()
                if iso in ("TR", "MFIN", "HAVZA", "EU", "CN", "RU", "IR", "US", "RS", "BA", "BG")
            }
            kenar_oz = [
                {k: e[k] for k in ("kaynak", "hedef", "tur", "vekil", "usd_mn") if k in e}
                for e in (mat.get("akis_kenarlari") or [])[:80]
            ]
            anlik.append(
                {
                    "yil": y,
                    **kayit,
                    "stok": stok_kompakt,
                    "akis_kenar_sayisi": len(mat.get("akis_kenarlari") or []),
                    "akis_kenarlari_ornek": kenar_oz,
                    "havza_rapor": mat.get("havza_rapor"),
                }
            )

    return {
        "olcum": "uluslararasi_stok_akis_10y",
        "senaryo_defter": senaryo_defter,
        "not": "TR net = ZARAR_10Y yolu; dış refah/kanal akışları gerceklesme tabanı→1 olgunluk ölçeği",
        "refah_olgunluk": {"taban": round(r_taban, 4), "hedef": 1.0, "yil_araligi": [y0, y1]},
        "yillik_seri": seri,
        "anlik_goruntuler": anlik,
        "kaynak": [
            str(base_path.name),
            str(rant_path.name),
            "GERCEKLIK_KALIBRE.json",
            "ZARAR_10Y_GSYH.json",
        ],
    }


def _md(d: dict[str, Any]) -> str:
    lines = [
        "# Uluslararası stok-akış — 10 yıl seri (P2)",
        "",
        f"Defter senaryosu **{d['senaryo_defter']}** · refah olgunluk {d['refah_olgunluk']['taban']} → "
        f"{d['refah_olgunluk']['hedef']}",
        "",
        "| Yıl | TR net | Olgunluk | Refah dış USD mn | Σ stok | MFIN | HAVZA |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for r in d["yillik_seri"]:
        lines.append(
            f"| {r['yil']} | {r['tr_net_kalibre']} | {r['refah_olgunluk_olcek']} | "
            f"{r.get('refah_dis_usd_kalibre_mn', '—')} | {r['stok_net_vekil']} | "
            f"{r.get('mfin_stok_vekil', '—')} | {r.get('havza_stok_vekil', '—')} |"
        )
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    data = hesapla()
    (OUT / "ULUSLARARASI_STOK_AKIS_10Y.json").write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (OUT / "ULUSLARARASI_STOK_AKIS_10Y.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'ULUSLARARASI_STOK_AKIS_10Y.md'}")


if __name__ == "__main__":
    main()
