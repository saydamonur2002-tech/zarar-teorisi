"""P2: Tahvil/senet rant kanalı → Lm iç faiz payları → finans katman vekili köprüsü."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import numpy as np

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
KALIBRE = DATA / "kalibre"
OUT = REPO / "reports" / "etki_cephesi"
ZARAR_DIR = REPO / "_incoming" / "zarar-teorisi-main"
SEC = ["H", "F", "B", "K", "D"]
IDX = {s: i for i, s in enumerate(SEC)}


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _creditor_shares(lm_name: str, donem: str) -> dict[str, float]:
    path = ZARAR_DIR / f"Lm_{lm_name}_{donem}.csv"
    M = np.loadtxt(path, delimiter=",", skiprows=1, usecols=range(1, 6))
    col = M[:, IDX["K"]]
    col[IDX["K"]] = 0.0
    s = float(col.sum()) or 1.0
    return {SEC[i]: round(float(col[i]) / s, 4) for i in range(5) if SEC[i] != "K"}


def hesapla() -> dict[str, Any]:
    kopru = _load(KALIBRE / "finans_senet_faiz_kopru.json")
    rant = _load(OUT / "DIS_RANT_PARASAL.json")
    fin = _load(OUT / "FINANS_KATMAN.json")
    ger = _load(OUT / "GERCEKLIK_KALIBRE.json")
    akis = _load(OUT / "AKIS_OLCUM.json")

    donem = str(kopru.get("matris_donem") or "2026-Q1")
    lm = str(kopru.get("lm_tahvil") or "borclanma_senedi")
    shares = _creditor_shares(lm, donem)

    kanallar = set(kopru.get("rant_kanallari_usd") or ["tahvil", "AB_fon"])
    ref_usd = 0.0
    detay: list[dict[str, Any]] = []
    for row in rant.get("kanal_dagilimi_akis_eslesmeli") or []:
        k = str(row.get("kanal_akis") or "")
        if k not in kanallar:
            continue
        u = float(row.get("refah_dis_usd_mn") or 0.0)
        ref_usd += u
        detay.append({"kanal": k, "refah_dis_usd_mn": round(u, 1)})

    r_f = float(ger.get("gerceklesme_oranlari", {}).get("finans_katman") or 0.22)
    faiz_pay = float(kopru.get("faiz_rant_pay") or 0.18)
    faiz_usd = round(ref_usd * faiz_pay * r_f, 1)
    tranch = float(kopru.get("tr_finans_geri_tranchman") or 0.42)

    cicek_raw = akis.get("cicek_usd_mn")
    cicek = float(cicek_raw if not isinstance(cicek_raw, dict) else (cicek_raw.get("birincil_gelir_yatirim_gideri") or 18841))
    proj = _load(OUT / "PROJEKSIYON.json")
    sen_c = next(s for s in proj["senaryolar"] if s["id"] == "C")
    merkez_rant = float(sen_c.get("merkez_artı_rant_cikis_toplam") or 1.0)
    vekil_faiz = round(faiz_usd * merkez_rant / cicek, 4) if cicek > 0 else 0.0
    vekil_tr_finans = round(vekil_faiz * tranch, 4)

    fin_son = float(fin.get("finans_katman_tam", {}).get("tr_net_birlesik_vekil") or 0.0)
    fin_kopru_son = round(fin_son + vekil_tr_finans, 3)

    faiz_sektor_usd = {s: round(faiz_usd * shares.get(s, 0.0), 1) for s in ("H", "F", "B", "D")}

    return {
        "olcum": "finans_senet_faiz_kopru",
        "lm_tahvil": lm,
        "ic_faiz_alacakli_paylari": shares,
        "rant_kanallari": detay,
        "refah_senet_usd_mn": round(ref_usd, 1),
        "faiz_rant_usd_mn": faiz_usd,
        "gerceklesme_finans": r_f,
        "vekil_faiz_kanal": vekil_faiz,
        "vekil_finans_geri_ek": vekil_tr_finans,
        "finans_katman_tr_net_once": fin_son,
        "finans_katman_tr_net_kopru_son": fin_kopru_son,
        "faiz_usd_sektor_dagilim": faiz_sektor_usd,
        "kaynak": [
            "DIS_RANT_PARASAL.json",
            "FINANS_KATMAN.json",
            f"Lm_{lm}_{donem}.csv",
            "kalibre/finans_senet_faiz_kopru.json",
        ],
    }


def _md(d: dict[str, Any]) -> str:
    lines = [
        "# Finans — senet/faiz köprüsü (P2)",
        "",
        f"Rant tahvil/AB kanalı: **{d['refah_senet_usd_mn']:,}** mn USD/yıl",
        f"Faiz vekili (× gerçekleşme finans): **{d['faiz_rant_usd_mn']:,}** mn USD",
        f"TR finans vekili ek: **{d['vekil_finans_geri_ek']}** → kopru son TR net **{d['finans_katman_tr_net_kopru_son']}**",
        "",
        "## İç faiz alacaklı payları (Lm K sütunu)",
        "",
    ]
    for s, p in (d.get("ic_faiz_alacakli_paylari") or {}).items():
        lines.append(f"- **{s}:** {p}")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    data = hesapla()
    (OUT / "FINANS_SENET_FAIZ.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "FINANS_SENET_FAIZ.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'FINANS_SENET_FAIZ.md'}")


if __name__ == "__main__":
    main()
