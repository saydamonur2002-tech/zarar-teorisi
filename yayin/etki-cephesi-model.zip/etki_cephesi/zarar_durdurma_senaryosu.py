"""Zararı durdurma + refah rantına bağlama senaryosu (D): C'den türeyen politika kaldıraçları taraması.

`projeksiyon.hesapla_senaryo` aynı kod yoluyla çalışır (A/B/C ile birebir aynı hesap); yalnız C'nin erozyon çarpanı (1−d) ile küçültülür
(boşalma erozyonla doğrusal), bağ modu ve TR'nin refah iç payı varyantlarla değiştirilir. Parametreler atanmıştır (data/etki_cephesi/zarar_durdurma.json).
Ölçülenler (projeksiyon düzeyi; defterdeki refah dış havuzu kazancı ve bant hariç, bu yüzden mutlak değerleri defterle birebir değil, C ile aynı ölçüde karşılaştırılır):
  TR net = refah iç rant − TR kaybı; havza net toplamı; dış aktörlerin net'i (kazanç − kayıp vekili − sürdürme maliyeti); sistem toplamı;
  durdurmaya karşı çıkacak aktörler (net'i d arttıkça düşenler); kısa vade finansman (TR kayıp akışı / cari açık).
Tanı raporu: başka modüle girdi olmaz.
"""
from __future__ import annotations

import copy
import json
import sys
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"
sys.path.insert(0, str(Path(__file__).resolve().parent))

import _gecmis  # noqa: E402
import projeksiyon as P  # noqa: E402

AKTORLER = ("MFIN", "CN", "RU", "US", "EU", "AE", "SA", "FR", "GR", "IR", "IL", "EG")
KOPRULER = ("bop_merkez_rant", "mal_net_ticaret", "tum_havza_rant")


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _refah_varyant(refah: dict[str, Any], carpan: float, ust: float) -> dict[str, Any]:
    r = copy.deepcopy(refah)
    vh = r.get("varsayilan_havza") or {}
    if "tr_ic_refah_pay" in vh:
        vh["tr_ic_refah_pay"] = round(min(ust, float(vh["tr_ic_refah_pay"]) * carpan), 4)
    for h in (r.get("havza") or {}).values():
        if "tr_ic_refah_pay" in h:
            h["tr_ic_refah_pay"] = round(min(ust, float(h["tr_ic_refah_pay"]) * carpan), 4)
    return r


def _senaryo(d: float, varyant: dict[str, Any], B: dict[str, Any], cfg: dict[str, Any]) -> dict[str, Any]:
    c = next(s for s in B["senaryolar_doc"]["senaryolar"] if s["id"] == cfg["referans_senaryo"])
    sen = copy.deepcopy(c)
    # id "C" kalır: senaryo çarpanları (yerel_rant_kanal: dış bağlama/rant çıkışı) id ile aranır; d=0 + mevcut bağ = C birebir olmalı
    sen["ad"] = f"Zararı durdur (d={d}) + refah bağı ({varyant['ad']})"
    sen["etki_erosyon_carpani"] = float(c["etki_erosyon_carpani"]) * (1.0 - d)
    if varyant["bag_modu"]:
        sen["bag_modu"] = varyant["bag_modu"]
    refah = _refah_varyant(B["refah_doc"], float(varyant["tr_ic_refah_pay_carpan"]), float(cfg["tr_ic_pay_ust_sinir"]))
    merkez_c = float(_gecmis.merkez_carpan()[cfg["referans_senaryo"]])
    # φ (ticaret dışı kanal çarpanı) yapısal parametre: politika senaryosunda yeniden kalibre edilmez, C'nin değeri sabit kalır.
    # (Yeniden kalibrasyon, TR kaybı küçülürken φ'yi şişirip Çin/Rusya/AB'nin ticaret kaybını yapay biçimde yüksek tutardı.)
    c_row = next(s for s in _load(OUT / "PROJEKSIYON.json")["senaryolar"] if s["id"] == cfg["referans_senaryo"])
    phi = next(a["kayip_dis_veri"]["phi"] for a in c_row["aktör_birlesik"] if a.get("kayip_dis_veri"))
    P._PHI_SABIT = [phi["min"], phi["medyan"], phi["maks"]]
    try:
        row = P.hesapla_senaryo(sen, B, merkez_c, refah)
    finally:
        P._PHI_SABIT = None
    row["id"] = "D"
    return row


def _olc(row: dict[str, Any], cari: float, kop: dict[str, Any]) -> dict[str, Any]:
    ab = {a["aktor"]: a for a in row["aktör_birlesik"]}
    bn = row["bolgesel_net"]
    tr_kayip = float(ab["TR"]["havza_kayip"])
    refah_ic = sum(float(b["refah_rant_tr_ic"]) for b in bn)
    net = {}
    for i in AKTORLER:
        a = ab.get(i)  # boşalma sıfırlanınca kazancı/kaybı kalmayan aktör satırı düşer: net 0
        net[i] = float(a.get("net_birlesik_maliyetli", a["net_birlesik_vekil"])) if a else 0.0
    sistem = refah_ic - tr_kayip + sum(float(a.get("net_birlesik_maliyetli", a["net_birlesik_vekil"])) for k, a in ab.items() if k != "TR")
    akis = {k: tr_kayip * float(kop[k]["usd_per_vekil_mn"]) for k in KOPRULER}
    return {
        "bosalma": float(row["turkiye_yaricevre_bosalma"]),
        "tr_kayip": round(tr_kayip, 3),
        "tr_refah_ic_rant": round(refah_ic, 3),
        "tr_net": round(refah_ic - tr_kayip, 3),
        "havza_net_toplam": round(sum(float(b["net_endeks"]) for b in bn), 3),
        "sistem_net_toplam": round(sistem, 3),
        "dis_aktor_net": {k: round(v, 3) for k, v in net.items()},
        "akis_cari_aciga_oran": {k: round(v / cari, 2) for k, v in akis.items()},
        "gecerli_olcek_s": {k: round(min(1.0, cari / v), 3) if v > 0 else 1.0 for k, v in akis.items()},
    }


def calistir() -> dict[str, Any]:
    cfg = _load(DATA / "zarar_durdurma.json")
    B = P._baglam()
    kop = _load(DATA / "kalibre" / "gerceklik_realizasyon.json")["usd_kopruleri"]
    w = _load(DATA / "gozlem" / "tr_bagimsiz_olcek.json")
    y = w["yillar"]
    gsyh = float(w["TUR"]["gsyh_usd"][y[-1]]) / 1e6
    cari = sum(-float(w["TUR"]["cari_denge_gsyh"][k]) for k in y) / len(y) / 100 * gsyh
    sonuc: dict[str, Any] = {}
    for ad, v in cfg["baglama_varyantlari"].items():
        v = {**v, "ad": ad}
        sonuc[ad] = {}
        for d in cfg["durdurma_izgara"]:
            sonuc[ad][str(d)] = _olc(_senaryo(d, v, B, cfg), cari, kop)
    # tutarlılık: d=0 + mevcut = C (projeksiyon çıktısı)
    c_row = next(s for s in _load(OUT / "PROJEKSIYON.json")["senaryolar"] if s["id"] == cfg["referans_senaryo"])
    c_olc = _olc(c_row, cari, kop)
    # durdurmaya karşı çıkanlar: d=1'de net'i d=0'a göre düşen aktörler (bağlı varyant)
    son = str(cfg["durdurma_izgara"][-1])
    bagli0, bagli1 = sonuc["bagli"]["0.0"], sonuc["bagli"][son]
    karsi = {k: round(bagli1["dis_aktor_net"][k] - bagli0["dis_aktor_net"][k], 3) for k in bagli0["dis_aktor_net"] if bagli1["dis_aktor_net"][k] < bagli0["dis_aktor_net"][k] - 1e-9}
    d = {
        "olcum": "zarar_durdurma_refah_baglama_senaryosu",
        "etiket": "tani_girdi_degil",
        "parametreler": cfg,
        "c_referans": c_olc,
        "varyantlar": sonuc,
        "durdurmaya_karsi_cikanlar_bagli_dson_eksi_d0": karsi,
        "cari_acik_mn_usd": round(cari),
        "not": "Atanmış kaldıraçlar taraması (tahmin değil). Projeksiyon düzeyi; defter refah dış havuzu ve bant hariç. Kısa vade: tek yıl TR kayıp akışı (yol modellenmedi).",
    }
    (OUT / "ZARAR_DURDURMA_SENARYOSU.json").write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    L = ["# Zararı durdurma + refah rantına bağlama (senaryo D)", "", d["not"], "",
         "Referans C (projeksiyon düzeyi): TR net " + f"{c_olc['tr_net']:+.2f}" + ", Σ net " + f"{c_olc['sistem_net_toplam']:+.2f}" + ", havza net " + f"{c_olc['havza_net_toplam']:+.2f}" + ".", ""]
    for ad, tab in sonuc.items():
        L += [f"## Bağlama: {ad}", "",
              "| Durdurma d | TR kaybı | TR refah iç rant | TR net | Havza net Σ | Σ net (sistem) | Akış / cari açık (BoP / mal / rant) | Geçerli ölçek s (BoP / mal / rant) |",
              "| ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |"]
        for dd, r in tab.items():
            a, g = r["akis_cari_aciga_oran"], r["gecerli_olcek_s"]
            L.append(f"| {dd} | {r['tr_kayip']:.2f} | {r['tr_refah_ic_rant']:.2f} | {r['tr_net']:+.2f} | {r['havza_net_toplam']:+.2f} | {r['sistem_net_toplam']:+.2f} | {a['bop_merkez_rant']} / {a['mal_net_ticaret']} / {a['tum_havza_rant']} | {g['bop_merkez_rant']} / {g['mal_net_ticaret']} / {g['tum_havza_rant']} |")
        L += ["", "Dış aktör net'i (kazanç − kayıp vekili − maliyet):", "", "| d | " + " | ".join(AKTORLER) + " |", "| ---: | " + " | ".join("---:" for _ in AKTORLER) + " |"]
        for dd, r in tab.items():
            L.append(f"| {dd} | " + " | ".join(f"{r['dis_aktor_net'].get(i, float('nan')):+.2f}" for i in AKTORLER) + " |")
        L.append("")
    L += ["## Durdurmaya karşı çıkacaklar (bağlı varyant, d=0,9 − d=0 net farkı)", "", ", ".join(f"{k} {v:+.2f}" for k, v in karsi.items()) or "—"]
    (OUT / "ZARAR_DURDURMA_SENARYOSU.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    return d


if __name__ == "__main__":
    calistir()
    print("ZARAR_DURDURMA_SENARYOSU ok")
