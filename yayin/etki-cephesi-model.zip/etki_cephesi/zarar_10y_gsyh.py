"""10 yıl: kalibre TR net kaybı → USD köprüleri → GSYH etkisi."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
KALIBRE = DATA / "kalibre"
OUT = REPO / "reports" / "etki_cephesi"

if str(REPO / "etki_cephesi") not in sys.path:
    sys.path.insert(0, str(REPO / "etki_cephesi"))
from usd_kopru import tr_net_usd_coklu  # noqa: E402


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _gsyh_usd(capa: dict[str, Any]) -> float:
    return float(capa["gsyh_tl"]) / float(capa["kur_tl_usd"]) / 1_000_000


def _yol_10y(ger: dict[str, Any], y0: int, y1: int) -> list[dict[str, Any]]:
    yol = {int(r["yil"]): r for r in ger.get("yol_koridor") or []}
    rows: list[dict[str, Any]] = []
    last = None
    for y in range(y0, y1 + 1):
        if y in yol:
            last = yol[y]
        elif last is None:
            continue
        rows.append({"yil": y, "tr_net": last["tr_net"], "faz": last.get("faz")})
    return rows


def hesapla() -> dict[str, Any]:
    ger = _load(OUT / "GERCEKLIK_KALIBRE.json")
    capa = _load(KALIBRE / "gerceklik_capa.json")
    kopruler = ger["usd_kopruleri"]
    gsyh = _gsyh_usd(capa)

    kat = {k["katman"]: k for k in ger["katman_yigini_kalibre"]}
    taban = kat["C_refah_entegre"]
    yol_raw = _yol_10y(ger, 2027, 2036)
    if not yol_raw:
        yol_raw = _yol_10y(ger, 2027, 2057)
    y0 = yol_raw[0]["yil"]
    y1 = yol_raw[min(9, len(yol_raw) - 1)]["yil"]
    yol = yol_raw[:10] if len(yol_raw) >= 10 else yol_raw

    tr0 = float(taban["tr_net"])
    usd0 = tr_net_usd_coklu(tr0, kopruler)

    seri: list[dict[str, Any]] = []
    kum_vekil = 0.0
    kum_usd_orta = 0.0
    for row in yol:
        tr = float(row["tr_net"])
        usd = tr_net_usd_coklu(tr, kopruler)
        iy_vekil = round(abs(tr0) - abs(tr), 3)
        seri.append(
            {
                "yil": row["yil"],
                "faz": row["faz"],
                "tr_net": tr,
                "iyilesme_vekil_ytd": iy_vekil,
                "gsyh_yuzde_orta": round(usd["geometrik_orta_mn"] / gsyh * 100, 3),
                "gsyh_yuzde_bop": round(usd["bop_merkez_rant"] / gsyh * 100, 3),
                "gsyh_yuzde_mal": round(usd["mal_net_ticaret"] / gsyh * 100, 3),
                "usd_mn_orta": usd["geometrik_orta_mn"],
                "usd_mn_bop": usd["bop_merkez_rant"],
                "kumulatif_kazanim_usd_orta_mn": None,
            }
        )
        kum_vekil += iy_vekil
        kum_usd_orta += max(0.0, usd0["geometrik_orta_mn"] - usd["geometrik_orta_mn"])

    for i, s in enumerate(seri):
        s["kumulatif_kazanim_usd_orta_mn"] = round(
            sum(
                max(0.0, usd0["geometrik_orta_mn"] - tr_net_usd_coklu(seri[j]["tr_net"], kopruler)["geometrik_orta_mn"])
                for j in range(i + 1)
            ),
            1,
        )

    son = seri[-1] if seri else {}
    tr_son = float(son.get("tr_net", tr0))
    usd_son = tr_net_usd_coklu(tr_son, kopruler)

    return {
        "olcum": "zarar_10y_gsyh_etkisi",
        "not": (
            "TR net vekil (negatif = yapısal kayıp). Kalibre yol (GERCEKLIK_KALIBRE); "
            "GSYH % = |kayıp| USD orta / GSYH 2024 vekili. Kumulatif kazanım = yıllık tabana göre "
            "azalan kayıp USD (geometrik orta köprü, basit toplam vekili)."
        ),
        "horizon": {"bas_yil": y0, "bit_yil": y1, "yil_sayisi": 10},
        "gsyh_usd_mn_2024": round(gsyh, 1),
        "taban_C_refah": {
            "tr_net": tr0,
            "gsyh_yuzde_orta": taban["gsyh_yuzde_orta"],
            "usd_mn_orta": taban["tr_net_usd_mn_orta"],
        },
        "yil_10_son": {
            "tr_net": tr_son,
            "iyilesme_vekil": round(abs(tr0) - abs(tr_son), 3),
            "gsyh_yuzde_orta": son.get("gsyh_yuzde_orta"),
            "gsyh_pp_dusus": round(taban["gsyh_yuzde_orta"] - float(son.get("gsyh_yuzde_orta", 0)), 3),
            "usd_mn_orta": usd_son["geometrik_orta_mn"],
        },
        "zarar_teorisi_faz_ozet": {
            "not": "İlk ~7 yıl ağırlık zarar teorisi (gerçekleşme 0.7)",
            "tr_net_faz_sonu_vekili": next((s["tr_net"] for s in seri if s["yil"] == min(y0 + 6, y1)), tr_son),
        },
        "yillik_seri": seri,
        "kaynak": ["GERCEKLIK_KALIBRE.json", "gerceklik_capa.json", "usd_kopruleri.json"],
    }


def _md(d: dict[str, Any]) -> str:
    h = d["horizon"]
    t = d["taban_C_refah"]
    s = d["yil_10_son"]
    lines = [
        "# 10 yıl — zarar (TR net) azalması ve GSYH etkisi",
        "",
        d["not"],
        "",
        f"**Dönem:** {h['bas_yil']}–{h['bit_yil']} · GSYH çapası (2024 vekili): **{d['gsyh_usd_mn_2024']:,}** mn USD",
        "",
        "## Özet",
        "",
        f"| | Taban (C+refah) | 10. yıl sonu |",
        f"| --- | ---: | ---: |",
        f"| TR net vekil | {t['tr_net']} | **{s['tr_net']}** |",
        f"| İyileşme (vekil) | — | **{s['iyilesme_vekil']}** |",
        f"| GSYH % (USD orta köprü) | {t['gsyh_yuzde_orta']} | **{s['gsyh_yuzde_orta']}** |",
        f"| GSYH puan düşüş | — | **{s['gsyh_pp_dusus']}** pp |",
        f"| Yapısal kayıp USD (orta) | {t['usd_mn_orta']:,} | **{s['usd_mn_orta']:,}** mn |",
        "",
        "**Yorum:** 10 yıl içinde tam paket (zarar→üretim→finans, kalibre gerçekleşme) bitmez; "
        "finans fazının tamamı ~2057 vekiline uzanır. Bu tablo **ilk 10 takvim yılında** "
        "gerçekleşen kısmi iyileşmeyi gösterir (ağırlık zarar + üretim başlangıcı).",
        "",
        "## Yıllık seri",
        "",
        "| Yıl | Faz | TR net | Δ vekil (tabana göre) | GSYH % orta | GSYH % mal | Kum. kazanım USD orta |",
        "| --- | --- | ---: | ---: | ---: | ---: | ---: |",
    ]
    for r in d["yillik_seri"]:
        lines.append(
            f"| {r['yil']} | {r['faz']} | {r['tr_net']} | {r['iyilesme_vekil_ytd']} | "
            f"{r['gsyh_yuzde_orta']} | {r['gsyh_yuzde_mal']} | {r['kumulatif_kazanim_usd_orta_mn']:,} |"
        )
    z = d["zarar_teorisi_faz_ozet"]
    lines.extend(
        [
            "",
            f"**Zarar teorisi ağırlıklı 7 yıl sonu vekili (yaklaşık):** {z['tr_net_faz_sonu_vekili']}",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    data = hesapla()
    (OUT / "ZARAR_10Y_GSYH.json").write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (OUT / "ZARAR_10Y_GSYH.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'ZARAR_10Y_GSYH.md'}")


if __name__ == "__main__":
    main()
