"""EVDS ödemeler dengesi aylık gözlem verisini yeniler (ağ gerekir)."""
from __future__ import annotations

import csv
import sys
from collections import defaultdict
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
ZARAR_DIR = REPO / "_incoming" / "zarar-teorisi-main"
OUT = REPO / "data" / "etki_cephesi" / "gozlem" / "evds_odeme_dengesi_aylik.csv"
SERILER = {"Q5": "X", "Q6": "M", "Q76": "YG", "Q75": "YGgelir", "Q70": "PGgider"}

if str(ZARAR_DIR) not in sys.path:
    sys.path.insert(0, str(ZARAR_DIR))
import evds_cek  # noqa: E402


def main() -> None:
    rows, _ = evds_cek.fetch_group("bie_odeayrsunum6", start="01-01-2015", end="31-12-2036", freq="5")
    d: dict[str, dict[str, float]] = defaultdict(dict)
    for _g, t, s, _ad, _agg, v in rows:
        k = s.replace("TP.ODEAYRSUNUM6.", "")
        if k in SERILER:
            d[SERILER[k]][t] = v
    per = sorted(set(d["X"]) & set(d["YG"]))
    with OUT.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, lineterminator="\r\n")
        w.writerow(["Donem", "X_mal_ihracati", "M_mal_ithalati", "YG_yatirim_geliri_gideri", "YG_yatirim_geliri_geliri", "PG_birincil_gelir_gideri"])
        for t in per:
            w.writerow([t] + [d[k].get(t, "") for k in ("X", "M", "YG", "YGgelir", "PGgider")])
    print(f"Wrote {OUT} ({len(per)} ay, {per[0]}..{per[-1]})")


if __name__ == "__main__":
    main()
