"""Refah rantı dağıtımı + dış ülke entegre defteri (PROJEKSIYON sonrası)."""
from __future__ import annotations

import json
import subprocess
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
KALIBRE = DATA / "kalibre"
OUT = REPO / "reports" / "etki_cephesi"
PROJ = OUT / "PROJEKSIYON.json"


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _bolge_key(bid: str) -> str:
    leg = {
        "irak_bagdat": "irak",
        "irak_krg": "irak",
        "dogu_akdeniz_gaz": "dogu_akdeniz",
        "dogu_akdeniz_kefalet": "dogu_akdeniz",
    }
    return leg.get(bid, bid)


def _refah_endeks(iso: str, ulke_sys: dict[str, Any]) -> float:
    row = (ulke_sys.get("ulkeler") or {}).get(iso) or {}
    return float(row.get("refah_endeks") or 0.5)


def _acc_sifir() -> dict[str, float]:
    return {
        "havza_net": 0.0,
        "kanal_kazanc": 0.0,
        "ikame_kazanc": 0.0,
        "merkez_sizinti": 0.0,
        "merkez_belirsiz": 0.0,
        "refah_rant": 0.0,
    }


def _balkan_eu_defter_ayir(
    acc: dict[str, dict[str, float]],
    ulke_sys: dict[str, Any],
) -> dict[str, Any]:
    """EU satırından Balkan aktörlere kanal/ikame/refah payı (defter düzeyi, P2)."""
    capa_path = KALIBRE / "uluslararasi_stok_akis_capa.json"
    if not capa_path.is_file():
        return {"uygulandi": False}
    capa = _load(capa_path)
    if not capa.get("balkan_defter_ayir_aktif", True):
        return {"uygulandi": False}
    balkan = list(capa.get("balkan_aktörler") or [])
    pay = float(capa.get("eu_satir_balkan_kanal_pay") or 0.68)
    eu = acc.get("EU")
    if not eu or pay <= 0:
        return {"uygulandi": False}
    keys = ("kanal_kazanc", "ikame_kazanc", "refah_rant")
    ham = sum(float(eu.get(k) or 0) for k in keys)
    if ham <= 1e-9:
        return {"uygulandi": False, "not": "EU kanal/refah yok"}
    aktar = {k: float(eu.get(k) or 0) * pay for k in keys}
    for k in keys:
        eu[k] = float(eu.get(k) or 0) * (1.0 - pay)
    weights = {b: _refah_endeks(b, ulke_sys) for b in balkan}
    s = sum(weights.values()) or float(len(balkan) or 1)
    dagitim: dict[str, float] = {}
    for b in balkan:
        if b not in acc:
            acc[b] = _acc_sifir()
        w = weights.get(b, 1.0) / s
        for k in keys:
            acc[b][k] += aktar[k] * w
        dagitim[b] = round(sum(aktar[k] * w for k in keys), 3)
    return {
        "uygulandi": True,
        "eu_satir_balkan_kanal_pay": pay,
        "eu_aktarilan_toplam_vekil": round(sum(aktar.values()), 3),
        "balkan_dagilim_vekil": dagitim,
    }


def entegre_et(senaryo_id: str = "C", yeniden_projeksiyon: bool = True) -> dict[str, Any]:
    if yeniden_projeksiyon or not PROJ.is_file():
        subprocess.check_call([sys.executable, str(REPO / "etki_cephesi" / "projeksiyon.py")])

    proj = _load(PROJ)
    sen = next(s for s in proj["senaryolar"] if s["id"] == senaryo_id)
    dis_pay = _load(DATA / "dis_aktör_pay.json").get("bolge_pay") or {}
    ulke_sys = _load(DATA / "dis_ulke_sistemi.json")
    refah = _load(DATA / "refah_rant_model.json")

    refah_toplam = 0.0
    refah_tr_ic = 0.0
    refah_dis_havuz = 0.0
    bosluk_rant_eski = 0.0
    bolge_refah: list[dict[str, Any]] = []

    for b in sen.get("bolgesel_net") or []:
        rr = float(b.get("refah_rant_vekili") or b.get("rant_kanal_cikis_kar") or 0.0)
        tr_ic = float(b.get("refah_rant_tr_ic") or 0.0)
        dis = float(b.get("refah_rant_dis_havuz") or rr)
        old = float(b.get("bosluk_rant_karsiligi") or 0.0)
        refah_toplam += rr
        refah_tr_ic += tr_ic
        refah_dis_havuz += dis
        bosluk_rant_eski += old
        bolge_refah.append(
            {
                "bolge": b["bolge"],
                "refah_rant": round(rr, 3),
                "tr_ic_refah": round(tr_ic, 3),
                "dis_havuz": round(dis, 3),
            }
        )

    acc: dict[str, dict[str, float]] = defaultdict(_acc_sifir)

    for u in sen.get("ulke_kayiplari") or []:
        iso = u["ulke"]
        acc[iso]["havza_net"] += float(u.get("net_endeks") or 0.0)

    for d in sen.get("dis_aktör_kazanc") or []:
        iso = d["aktor"]
        # `kanal` kuralı kaldırıldı; defterde bu yuva artık kalan boşluk-payı kuralını (matris) taşır
        acc[iso]["kanal_kazanc"] += float(d.get("kanal_kazanc") or 0.0) + float(d.get("matris_kazanc") or 0.0)
        acc[iso]["ikame_kazanc"] += float(d.get("ikame_kazanc") or 0.0)
        acc[iso]["merkez_sizinti"] += float(d.get("merkez_sizinti") or 0.0)
        acc[iso]["merkez_belirsiz"] += float(d.get("merkez_belirsiz_vekil") or 0.0)

    acc["TR"]["refah_rant"] += refah_tr_ic

    for b in sen.get("bolgesel_net") or []:
        bid = b["bolge"]
        dis = float(b.get("refah_rant_dis_havuz") or 0.0)
        if dis <= 0:
            continue
        pkey = _bolge_key(bid)
        pay_row = dis_pay.get(pkey) or dis_pay.get(bid) or {}
        weights: dict[str, float] = {}
        for actor, pay in pay_row.items():
            if actor == "TR":
                continue
            w = float(pay) * _refah_endeks(actor, ulke_sys)
            if w > 0:
                weights[actor] = w
        s = sum(weights.values()) or 1.0
        for actor, w in weights.items():
            acc[actor]["refah_rant"] += dis * (w / s)

    balkan_meta = _balkan_eu_defter_ayir(acc, ulke_sys)

    names = {k: v.get("ad", k) for k, v in (ulke_sys.get("ulkeler") or {}).items()}
    for u in sen.get("ulke_kayiplari") or []:
        names[u["ulke"]] = u.get("ad") or names.get(u["ulke"], u["ulke"])
    for d in sen.get("dis_aktör_kazanc") or []:
        names[d["aktor"]] = d.get("ad") or names.get(d["aktor"], d["aktor"])

    ledger: list[dict[str, Any]] = []
    for iso, v in acc.items():
        ref = round(v["refah_rant"], 3)
        dis_k = round(v["kanal_kazanc"] + v["ikame_kazanc"] + v["merkez_sizinti"] + v["merkez_belirsiz"] + ref, 3)
        havza_k = round(max(0.0, -v["havza_net"]), 3)
        net = round(dis_k - havza_k + max(0.0, v["havza_net"]), 3)
        if iso == "TR":
            havza_k = round(float(next((a for a in sen.get("aktör_birlesik") or [] if a.get("aktor") == "TR"), {}).get("havza_kayip", 0.0)), 3)
            dis_k = round(float(next((a for a in sen.get("aktör_birlesik") or [] if a.get("aktor") == "TR"), {}).get("dis_kazanc_vekili", 0.0)) + ref, 3)
            net = round(dis_k - havza_k, 3)
        if abs(net) < 0.02 and ref < 0.02 and iso not in ("TR", "CN", "RU", "US", "MFIN"):
            continue
        ledger.append(
            {
                "ulke": iso,
                "ad": names.get(iso, iso),
                "refah_endeks": _refah_endeks(iso, ulke_sys),
                **{k: round(v[k], 3) for k in v},
                "dis_toplam_vekili": dis_k,
                "havza_kayip": havza_k,
                "net_refah_entegre": net,
            }
        )
    ledger.sort(key=lambda x: -x["dis_toplam_vekili"])

    tr_row = next((x for x in ledger if x["ulke"] == "TR"), None)
    out = {
        "olcum": "dis_ulke_refah_entegrasyon",
        "senaryo": senaryo_id,
        "rant_modeli": "refah" if refah.get("aktif") else "bosluk",
        "refah_rant_ozet": {
            "toplam": round(refah_toplam, 3),
            "tr_ic_pay": round(refah_tr_ic, 3),
            "dis_ulke_havuz": round(refah_dis_havuz, 3),
            "bosluk_rant_karsiligi_eski_formul": round(bosluk_rant_eski, 3),
        },
        "tum_havza_rant_cikis_toplam": sen.get("tum_havza_rant_cikis_toplam"),
        "ulke_defteri": ledger,
        "balkan_eu_defter": balkan_meta,
        "tr_ozet": tr_row,
        "bolge_refah": bolge_refah[:20],
        "kaynak": ["PROJEKSIYON.json", "refah_rant_model.json", "dis_ulke_sistemi.json"],
    }
    return out


def _md(d: dict[str, Any]) -> str:
    o = d["refah_rant_ozet"]
    lines = [
        "# Dış ülkeler — refah rantı entegrasyonu",
        "",
        f"Senaryo **{d['senaryo']}** · rant modeli: **{d['rant_modeli']}** (boşluk dolgusu rant üretmez).",
        "",
        "## Refah rant özeti",
        "",
        f"- Toplam: **{o['toplam']}** vekil",
        f"- TR iç refah payı: **{o['tr_ic_pay']}**",
        f"- Dış ülke havuzu: **{o['dis_ulke_havuz']}**",
        f"- Eski boşluk-rant formülü (karşılaştırma): {o['bosluk_rant_karsiligi_eski_formul']}",
        "",
        "## Ülke defteri (entegre)",
        "",
        "| Ülke | Refah rant | Kanal | İkame | MFIN | Net entegre |",
        "| --- | ---: | ---: | ---: | ---: | ---: |",
    ]
    for u in d["ulke_defteri"][:22]:
        mfin = u["merkez_sizinti"] + u["merkez_belirsiz"]
        lines.append(
            f"| {u['ad']} | {u['refah_rant']} | {u['kanal_kazanc']} | {u['ikame_kazanc']} | "
            f"{round(mfin, 3)} | {u['net_refah_entegre']} |"
        )
    if d.get("tr_ozet"):
        t = d["tr_ozet"]
        lines.extend(
            [
                "",
                f"**TR:** refah rant **{t['refah_rant']}**, havza kayıp **{t['havza_kayip']}**, "
                f"net **{t['net_refah_entegre']}**.",
                "",
            ]
        )
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    data = entegre_et()
    (OUT / "DIS_ULKE_REFAH.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "DIS_ULKE_REFAH.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'DIS_ULKE_REFAH.md'}")


if __name__ == "__main__":
    main()
