"""Ülke × kanal — 10 yıl seri (A/B/C, refah olgunluk ölçeği × ZARAR_10Y yolu)."""
from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
import _olasilik
from typing import Any

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "etki_cephesi"


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _refah_olgunluk(yil: int, y0: int, y1: int, taban: float, hedef: float) -> float:
    if y1 <= y0:
        return hedef
    u = max(0.0, min(1.0, (yil - y0) / (y1 - y0)))
    return taban + (hedef - taban) * u


def _olgunluk_param(sid: str) -> tuple[float, float]:
    gp = OUT / f"GERCEKLIK_KALIBRE_{sid}.json"
    if not gp.is_file() and sid == "C":
        gp = OUT / "GERCEKLIK_KALIBRE.json"
    ger = _load(gp) if gp.is_file() else {}
    g = ger.get("gerceklesme_oranlari") or {}
    r_taban = min(float(g.get("zarar_teorisi") or 0.7), float(g.get("uretim_ic_akis") or 0.5))
    return round(r_taban, 4), 1.0


def _yol_senaryo(sid: str, zcok: dict[str, Any]) -> list[dict[str, Any]]:
    pak = next((p for p in zcok.get("senaryolar") or [] if p.get("id") == sid), None)
    if pak and pak.get("yillik_seri"):
        return [{"yil": int(s["yil"]), "tr_net": float(s["tr_net"])} for s in pak["yillik_seri"][:10]]
    ger = _load(OUT / "GERCEKLIK_KALIBRE.json")
    return [
        {"yil": int(r["yil"]), "tr_net": float(r["tr_net"])}
        for r in (ger.get("yol_koridor") or [])[:10]
    ]


def _hucre_taban(sid: str) -> list[dict[str, Any]]:
    rp = OUT / f"DIS_RANT_PARASAL_{sid}.json"
    if not rp.is_file():
        rp = OUT / "DIS_RANT_PARASAL.json"
    rant = _load(rp)
    return list((rant.get("ulke_rant_kanal") or {}).get("hucre_top120") or [])


def _yil_hucre_ozet(hucre: list[dict[str, Any]], olcek: float) -> tuple[list[dict[str, Any]], dict[str, float]]:
    by_ulke: dict[str, float] = defaultdict(float)
    by_kanal: dict[str, float] = defaultdict(float)
    for h in hucre:
        ref = round(float(h.get("refah_dis_usd_mn") or 0.0) * olcek, 1)
        zar = round(float(h.get("zarar_usd_mn") or 0.0) * olcek, 1)
        u = str(h.get("ulke") or "")
        k = str(h.get("kanal_akis") or "")
        by_ulke[u] += ref
        by_kanal[k] += ref
        _ = zar
    top_ulke = sorted(by_ulke.items(), key=lambda x: -x[1])[:12]
    kanal = {k: round(v, 1) for k, v in sorted(by_kanal.items(), key=lambda x: -x[1])[:10]}
    return [{"ulke": u, "refah_dis_usd_mn": v} for u, v in top_ulke], kanal


def hesapla(senaryolar: tuple[str, ...] = ("A", "B", "C")) -> dict[str, Any]:
    zpath = OUT / "ZARAR_10Y_SENARYO_COKLU.json"
    zcok = _load(zpath) if zpath.is_file() else {"senaryolar": []}

    senaryo_paket: list[dict[str, Any]] = []
    for sid in senaryolar:
        yol = _yol_senaryo(sid, zcok)
        if not yol:
            continue
        hucre = _hucre_taban(sid)
        r_taban, r_hedef = _olgunluk_param(sid)
        y0, y1 = yol[0]["yil"], yol[-1]["yil"]
        yillik: list[dict[str, Any]] = []
        for row in yol:
            y = int(row["yil"])
            olcek = _refah_olgunluk(y, y0, y1, r_taban, r_hedef)
            top_ulke, kanal = _yil_hucre_ozet(hucre, olcek)
            yillik.append(
                {
                    "yil": y,
                    "tr_net_kalibre": round(float(row["tr_net"]), 3),
                    "refah_olgunluk_olcek": round(olcek, 4),
                    "top_ulke_refah_dis_usd_mn": top_ulke,
                    "kanal_refah_dis_usd_mn": kanal,
                    "refah_dis_toplam_usd_mn": round(sum(u["refah_dis_usd_mn"] for u in top_ulke), 1),
                }
            )
        senaryo_paket.append(
            {
                "id": sid,
                "refah_olgunluk": {"taban": r_taban, "hedef": r_hedef, "yil_araligi": [y0, y1]},
                "yillik": yillik,
            }
        )

    zdoc = _load(REPO / "data" / "etki_cephesi" / "senaryolar.json")
    ow: dict[str, float] = {}
    for s in zdoc.get("senaryolar") or []:
        ow[str(s["id"])] = _olasilik.vekil_s(s)
    s_ = sum(ow.values()) or 1.0
    ow = {k: v / s_ for k, v in ow.items()}

    bek_yil10: dict[str, float] = {}
    bek_top: list[tuple[str, float]] = []
    if senaryo_paket:
        ulke_keys = set()
        for p in senaryo_paket:
            last = p["yillik"][-1]
            for u in last["top_ulke_refah_dis_usd_mn"]:
                ulke_keys.add(u["ulke"])
        for iso in ulke_keys:
            tot = 0.0
            w = 0.0
            for p in senaryo_paket:
                sid = p["id"]
                last = p["yillik"][-1]
                val = next((x["refah_dis_usd_mn"] for x in last["top_ulke_refah_dis_usd_mn"] if x["ulke"] == iso), 0.0)
                tot += ow.get(sid, 0.0) * val
                w += ow.get(sid, 0.0)
            if w > 0:
                bek_yil10[iso] = round(tot / w, 1)
        bek_top = sorted(bek_yil10.items(), key=lambda x: -x[1])[:12]

    return {
        "olcum": "ulke_kanal_dokum_10y",
        "not": "Kanal hücreleri DIS_RANT_PARASAL_{sid} tabanı × refah olgunluk; TR yolu ZARAR_10Y_SENARYO_COKLU",
        "senaryolar": senaryo_paket,
        "beklenen_yil_10_top_ulke": [{"ulke": u, "refah_dis_usd_mn": v} for u, v in bek_top] if senaryo_paket else [],
        "kaynak": ["ZARAR_10Y_SENARYO_COKLU.json", "DIS_RANT_PARASAL_{A,B,C}.json", "GERCEKLIK_KALIBRE_{A,B,C}.json"],
    }


def _md(d: dict[str, Any]) -> str:
    lines = [
        "# Ülke × kanal — 10 yıl seri",
        "",
        d["not"],
        "",
    ]
    for p in d.get("senaryolar") or []:
        lines.append(f"## Senaryo **{p['id']}**")
        lines.append("")
        lines.append("| Yıl | TR net | Olgunluk | Refah dış Σ (top12) |")
        lines.append("| --- | ---: | ---: | ---: |")
        for r in p["yillik"]:
            lines.append(
                f"| {r['yil']} | {r['tr_net_kalibre']} | {r['refah_olgunluk_olcek']} | "
                f"{r['refah_dis_toplam_usd_mn']:,} |"
            )
        lines.append("")
    if d.get("beklenen_yil_10_top_ulke"):
        lines.extend(["## Beklenen — yıl 10 top ülke (refah dış USD mn)", ""])
        for row in d["beklenen_yil_10_top_ulke"][:10]:
            lines.append(f"- **{row['ulke']}:** {row['refah_dis_usd_mn']:,}")
        lines.append("")
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    data = hesapla()
    (OUT / "ULKE_KANAL_DOKUM_10Y.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "ULKE_KANAL_DOKUM_10Y.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'ULKE_KANAL_DOKUM_10Y.md'}")


if __name__ == "__main__":
    main()
