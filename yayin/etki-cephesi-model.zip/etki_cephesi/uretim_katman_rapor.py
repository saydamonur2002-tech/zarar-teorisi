"""Üretim katmanı modeli: Drive belgesinin yeniden üretimi, sisteme bağlanışı ve etkisi (tanı raporu).

1) Belgenin cari açık stres testi/revizyon sayıları, parametrelerden yeniden hesaplanır ve belge değerleriyle karşılaştırılır.
2) İhracat esnekliği ε duyarlılığı.
3) Sisteme iki bağ: üretim bağımlılığı halka çarpanı (eski atanmış 0,68 → modelden türetilmiş) ve üretim katmanı iyileşme tavanı (eski %2,5 × net ticaret → modelin net iyileşmesi).
4) Üretim katmanı gerçekleşmesinde taban (atanmış) mı yoksa tavan/ihtiyaç oranı mı belirleyici?
Tanı raporu: başka modüle girdi olmaz.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _uretim_katman as U  # noqa: E402

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"
SEVIYELER = ("koordinasyon", "orta_reform", "guclu_reform")
ESKI_HALKA_CARPAN = 0.68  # uretim_ic_akis_kopru.json (atanmış)
ESKI_TAVAN_YUZDE = 0.025  # gerceklik_capa.json iyilesme_tavan_yuzde_10y.uretim_rant_net_ticaret (atanmış)


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def calistir() -> dict[str, Any]:
    cfg = _load(DATA / "uretim_katman_model.json")
    dog = cfg["belge_degerleri_dogrulama"]
    yeniden = {
        "adreslenebilir_taban_mrd_usd": round(U.adreslenebilir_taban_mrd(), 3),
        "brut_ithalat_tasarrufu_mrd_usd": {s: round(U.brut_tasarruf_mrd(s), 3) for s in SEVIYELER[1:]},
        "revize_net_iyilesme_mrd_usd": {s: round(U.net_iyilesme_mrd(s), 3) for s in SEVIYELER},
        "revize_cari_acik_kapanma_orani": {s: round(U.cari_kapanma_orani(s), 3) for s in SEVIYELER},
    }
    eps_tab = {str(e): {s: round(U.net_iyilesme_mrd(s, e), 3) for s in SEVIYELER} for e in (0.0, 0.15, 0.30, 0.50, 0.75, 1.0)}
    # sisteme bağ
    akis = _load(OUT / "AKIS_OLCUM.json")["usd_kopruleri"]
    usd_mal = float(akis["mal_net_ticaret"]["usd_per_vekil_mn"])
    usd_bop = float(akis["bop_merkez_rant"]["usd_per_vekil_mn"])
    proj = _load(OUT / "PROJEKSIYON.json")
    sen_c = next(s for s in proj["senaryolar"] if s["id"] == "C")
    halka_u = sum(float(h["delta_endeks"]) for r in sen_c["tr_bosalma_detay"] for h in r["bes_halka"] if h["halka"] == "uretim_bagimlilik")
    capa = _load(DATA / "kalibre" / "gerceklik_capa.json")
    tic = abs(float(capa["usd_mn"]["net_ticaret"]))
    kopru = _load(DATA / "uretim_ic_akis_kopru.json")
    bag = cfg["sisteme_baglama"]
    carpan = {s: round(U.halka_carpani(halka_u, usd_mal, s), 4) for s in SEVIYELER}
    tavan = {s: round(U.tavan_usd_mn(s), 1) for s in SEVIYELER}
    # gerçekleşme: taban mı tavan/ihtiyaç mı?
    kal = _load(OUT / "GERCEKLIK_KALIBRE_C.json")
    rows = {r["katman"]: r for r in kal["katman_yigini_kalibre"]}
    r_u = float(rows["uretim_ic_akis"]["gerceklesme"])
    d_u_gercek = (float(rows["uretim_ic_akis"]["tr_net"]) - float(rows["zarar_teorisi"]["tr_net"])) / r_u if r_u else 0.0
    ihtiyac_usd = d_u_gercek * usd_bop
    taban = float(capa["gerceklesme_taban"]["uretim_ic_akis"])
    sonuc = {
        "olcum": "uretim_katman_modeli",
        "etiket": "tani_girdi_degil",
        "kaynak": cfg["kaynak"],
        "belge_degerleri": dog,
        "yeniden_uretim": yeniden,
        "ihracat_esnekligi_duyarlilik_net_iyilesme_mrd_usd": eps_tab,
        "sisteme_baglama": {
            "aktif": {"carpan": bool(bag.get("carpan_kullan")), "tavan": bool(bag.get("tavan_kullan")), "referans_seviye": bag["referans_seviye"]},
            "halka_uretim_bagimlilik_vekil_C": round(halka_u, 3),
            "halka_usd_mn_mal_koprusu": round(halka_u * usd_mal),
            "halka_carpani": {"eski_atanmis": ESKI_HALKA_CARPAN, "modelden_seviye_basina": carpan, "sistemde_kullanilan": float(U.halka_carpani(halka_u, usd_mal))},
            "tavan_usd_mn": {"eski_atanmis": round(ESKI_TAVAN_YUZDE * tic, 1), "modelden_seviye_basina": tavan, "sistemde_kullanilan": round(U.tavan_usd_mn(), 1)},
        },
        "gerceklesme_belirleyicisi": {
            "uretim_katmani_adim_vekil_C": round(d_u_gercek, 3),
            "ihtiyac_usd_mn_bop_koprusu": round(ihtiyac_usd),
            "tavan_over_ihtiyac_eski": round(ESKI_TAVAN_YUZDE * tic / ihtiyac_usd, 4) if ihtiyac_usd else None,
            "tavan_over_ihtiyac_model": round(U.tavan_usd_mn() / ihtiyac_usd, 4) if ihtiyac_usd else None,
            "taban_atanmis": taban,
            "uygulanan_gerceklesme": r_u,
            "belirleyici": "taban (atanmış)" if U.tavan_usd_mn() / ihtiyac_usd < taban else "tavan/ihtiyaç oranı",
        },
        "not": "Tipoloji katsayıları ölçülmemiştir (belgede VARSAYIM). İhracat kaybı penaltı sabitleri belge hücrelerinden alındı. Üretim katmanı gerçekleşmesi, tavan/ihtiyaç oranı tabanın altında kaldığı için tabanla belirlenir.",
    }
    (OUT / "URETIM_KATMAN_MODEL.json").write_text(json.dumps(sonuc, ensure_ascii=False, indent=2), encoding="utf-8")
    L = ["# Üretim katmanı modeli (Drive) ve sisteme bağlanışı", "", sonuc["not"], "", "## Kaynak belgeler", ""]
    for k in cfg["kaynak"]:
        L.append(f"- **{k['baslik']}** ({k['tarih']}, `{k['drive_id']}`): {k['kullanim']}")
    L += ["", "## 1. Belge sayıları parametrelerden yeniden üretildi", "",
          "| Büyüklük | Belge | Yeniden hesap |", "| --- | ---: | ---: |",
          f"| Adreslenebilir ara malı tabanı (mrd $) | {dog['adreslenebilir_ara_mali_tabani_mrd_usd']} | {yeniden['adreslenebilir_taban_mrd_usd']} |"]
    for s in SEVIYELER[1:]:
        L.append(f"| Brüt ithalat tasarrufu, {s} (mrd $) | {dog['brut_ithalat_tasarrufu_mrd_usd'][s]} | {yeniden['brut_ithalat_tasarrufu_mrd_usd'][s]} |")
    for s in SEVIYELER:
        L.append(f"| Revize net iyileşme, {s} (mrd $) | {dog['revize_net_iyilesme_mrd_usd'][s]} | {yeniden['revize_net_iyilesme_mrd_usd'][s]} |")
    for s in SEVIYELER:
        L.append(f"| Cari açık kapanma oranı, {s} | {dog['revize_cari_acik_kapanma_orani'][s]} | {yeniden['revize_cari_acik_kapanma_orani'][s]} |")
    L += ["", "## 2. İhracat esnekliği ε duyarlılığı: revize net iyileşme (mrd $/yıl)", "", "| ε | koordinasyon | orta reform | güçlü reform |", "| ---: | ---: | ---: | ---: |"]
    for e, r in eps_tab.items():
        L.append(f"| {e} | {r['koordinasyon']} | {r['orta_reform']} | {r['guclu_reform']} |")
    L += ["", f"Kritik eşik ε ≈ {dog['kritik_esneklik']}: orta ve güçlü reform nötr/negatif.", "",
          "## 3. Sisteme iki bağ", "", f"- Üretim bağımlılığı halkası (C): {sonuc['sisteme_baglama']['halka_uretim_bagimlilik_vekil_C']} vekil ≈ {sonuc['sisteme_baglama']['halka_usd_mn_mal_koprusu']:,} mn $ (mal ticareti köprüsü).",
          f"- **Halka çarpanı:** eski atanmış {ESKI_HALKA_CARPAN}; modelden koordinasyon {carpan['koordinasyon']}, orta reform **{carpan['orta_reform']}** (kullanılan), güçlü reform {carpan['guclu_reform']}.",
          f"- **İyileşme tavanı (mn $/yıl):** eski {sonuc['sisteme_baglama']['tavan_usd_mn']['eski_atanmis']:,}; modelden koordinasyon {tavan['koordinasyon']:,}, orta reform **{tavan['orta_reform']:,}** (kullanılan), güçlü reform {tavan['guclu_reform']:,}.", "",
          "## 4. Üretim katmanı gerçekleşmesini ne belirliyor?", "",
          f"Üretim katmanının adımı {sonuc['gerceklesme_belirleyicisi']['uretim_katmani_adim_vekil_C']} vekil ≈ {sonuc['gerceklesme_belirleyicisi']['ihtiyac_usd_mn_bop_koprusu']:,} mn $ (BoP köprüsü). Tavan/ihtiyaç oranı: eski {sonuc['gerceklesme_belirleyicisi']['tavan_over_ihtiyac_eski']}, modelden **{sonuc['gerceklesme_belirleyicisi']['tavan_over_ihtiyac_model']}**; atanmış taban {taban}. Uygulanan gerçekleşme {r_u}: belirleyici **{sonuc['gerceklesme_belirleyicisi']['belirleyici']}**."]
    (OUT / "URETIM_KATMAN_MODEL.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    return sonuc


if __name__ == "__main__":
    calistir()
    print("URETIM_KATMAN_MODEL ok")
