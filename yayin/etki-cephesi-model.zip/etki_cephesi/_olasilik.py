"""Senaryo olasılıkları: ölçülebilir kapılardan, SAF hesap (rapor okumaz → döngü yok).

Bu modül pipeline raporlarını OKUMAZ; yalnız `senaryolar.json`, `finans_katman_kopru.json` ve EVDS gözlem CSV'lerini okur.
Pipeline modülleri olasılığı `vekil()` ile buradan alır. Karar eşiği/duyarlılık bağlantısı `olasilik_duyarlilik.py`'dedir.

P(C) yeniden kurulumu: ölçülebilir kapılarla (el ataması yok).

Eski: `senaryolar.json` olasilik_vekili A 0,22 / B 0,18 / C 0,60 (elle atanmış, dayanak yok).
Yeni:
  * prior = tekdüze (1/3 her senaryo): bilgi yoksa ağırlık yok.
  * P(C) yalnız KAPI gözlemleriyle hareket eder. Her kapı: gözlenebilir seri, önceden yazılmış kontrol noktaları,
    senaryo başına olabilirlik. Olabilirliğin kaynağı yazılır: `turetilmis` (senaryolar.json parametresinden)
    ya da `varsayim` (tek parametreli, duyarlılığı raporlanır).
  * Gözlem yoksa güncelleme yok: bilinmiyor sıfır değildir. Ölçüm penceresi baz yıldan sonra başlar.
  * Kapı verisi yoksa kapı kapalı sayılır (olasılığa girmez), uydurma değer yazılmaz.

Kapılar:
  K1 merkez sızıntı sürüklenmesi (EVDS, ödemeler dengesi)  — turetilmis (merkez_sizinti_carpan); ayırt gücü yok.
  K2 dış kısıt: borç çevirme oranı (EVDS bie_oderoll)       — varsayim (δ); kontrol noktaları 2027-12, 2029-12, 2031-12.
  K3 etki erozyonu (bölge ihracat payı)                       — kaynak EVDS dışı; veri yok → kapalı.
  K4 bağ kullanımı                                            — gözlenebilir seri yok → kapalı.
"""
from __future__ import annotations

import csv
import json
import math
from pathlib import Path
from typing import Any

from functools import lru_cache

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
CEVIRME = DATA / "gozlem" / "evds_borc_cevirme_aylik.csv"
SENARYOLAR = ("A", "B", "C")
KONTROL = ("2027-12", "2029-12", "2031-12")
ESIK_ACIK = 100.0  # %: çevirme >= 100 = dış finansman açık
DELTA = 0.10  # K2 varsayımı: p_C = p0 + δ, p_B = p0 − δ, p_A = p0
DELTA_BANT = (0.0, 0.05, 0.10, 0.15, 0.20)
UNIFORM = {s: 1 / 3 for s in SENARYOLAR}


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _cevirme() -> dict[str, dict[str, float]]:
    d: dict[str, dict[str, float]] = {}
    with CEVIRME.open(encoding="utf-8", newline="") as f:
        for r in csv.DictReader(f):
            try:
                d[r["Donem"]] = {"K1": float(r["K1_bankalar"]), "K2": float(r["K2_diger_sektorler"])}
            except ValueError:
                continue
    return d


def _ort12(d: dict[str, dict[str, float]]) -> dict[str, tuple[float, float]]:
    ps = sorted(d)
    out = {}
    for i in range(11, len(ps)):
        w = ps[i - 11 : i + 1]
        y0, m0, y1, m1 = int(w[0][:4]), int(w[0][5:7]), int(w[-1][:4]), int(w[-1][5:7])
        if (y1 - y0) * 12 + (m1 - m0) != 11:
            continue
        out[ps[i]] = (sum(d[t]["K1"] for t in w) / 12, sum(d[t]["K2"] for t in w) / 12)
    return out


def _acik(k1: float, k2: float) -> bool:
    return k1 >= ESIK_ACIK and k2 >= ESIK_ACIK


def _norm(w: dict[str, float]) -> dict[str, float]:
    s = sum(w.values())
    return {k: v / s for k, v in w.items()}


def _k2_p(p0: float, delta: float) -> dict[str, float]:
    c = lambda x: min(0.95, max(0.05, x))  # noqa: E731
    return {"A": c(p0), "B": c(p0 - delta), "C": c(p0 + delta)}


def _binom_lik(p: dict[str, float], k: int, n: int) -> dict[str, float]:
    return {s: p[s] ** k * (1 - p[s]) ** (n - k) for s in SENARYOLAR}  # binom katsayısı senaryolar arası sabit


def hesapla_P() -> dict[str, Any]:
    from c_dinamik_olcut import _aylik, _oran12, _yillik_degisim, _surukleme, _posterior  # noqa: E402  (lazy: döngüsel import yok)

    sen = _load(DATA / "senaryolar.json")
    ph = _load(DATA / "finans_katman_kopru.json")
    baz = int(sen["baz_yil"])
    eski = {s["id"]: float(s["olasilik_vekili_eski_el_atamasi"]) for s in sen["senaryolar"]}

    # K2 tarihçe: 12 aylık ortalama çevirme; "açık" payı = senaryodan bağımsız taban oran p0
    ort = _ort12(_cevirme())
    acik_pay = sum(_acik(*v) for v in ort.values()) / len(ort)
    p0 = acik_pay
    son = max(ort)
    k2_son = {"donem": son, "K1_bankalar": round(ort[son][0], 1), "K2_diger": round(ort[son][1], 1), "acik": _acik(*ort[son])}
    gozlenen = {t: _acik(*ort[t]) for t in KONTROL if t in ort and int(t[:4]) > baz}

    # K1: baz yıl sonrası yıllık sürüklenme gözlemi (şimdilik yok)
    d = _aylik()
    r = _oran12(d)
    g = _yillik_degisim(r)
    import numpy as np  # noqa: E402

    on = [v for y, v in sorted(g.items()) if y <= baz]
    mu, sigma = float(np.mean(on)), float(np.std(on, ddof=1))
    drift = _surukleme(sen, float(ph["tam_olgunluk_yil"]))
    uygun = [g[y] for y in sorted(g) if y > baz]
    l1 = _posterior(UNIFORM, uygun, mu, sigma, drift) if uygun else dict(UNIFORM)

    # K2 olabilirlik (gözlem varsa)
    pk2 = _k2_p(p0, DELTA)
    n_g = len(gozlenen)
    k_g = sum(gozlenen.values())
    l2 = _binom_lik(pk2, k_g, n_g) if n_g else {s: 1.0 for s in SENARYOLAR}

    def birlestir(prior, lik1_post, lik2):
        w = {s: prior[s] * (lik1_post[s] / UNIFORM[s]) * lik2[s] for s in SENARYOLAR}
        return _norm(w)

    bugun = birlestir(UNIFORM, l1, l2)

    # Kapı sonuç tablosu: K2 kontrol noktalarında k/3 açık → P(C)
    tablo = []
    n = len(KONTROL)
    for k in range(n + 1):
        post = birlestir(UNIFORM, dict(UNIFORM), _binom_lik(pk2, k, n))
        satir = {"k_acik": k, "n": n, "P": {s: round(post[s], 3) for s in SENARYOLAR}}
        satir["olasilik_tam"] = {s: post[s] for s in SENARYOLAR}  # duyarlılık raporu karar bağlantısı için
        tablo.append(satir)

    # duyarlılık: δ ve prior seçimi (k=n: en lehte, k=0: en aleyhte)
    duy = []
    for dl in DELTA_BANT:
        p = _k2_p(p0, dl)
        e = {}
        for ad, pr in (("tekduze", UNIFORM), ("eski_el_atamasi", _norm(eski))):
            e[ad] = {
                "k=0": round(birlestir(pr, dict(UNIFORM), _binom_lik(p, 0, n))["C"], 3),
                "k=n": round(birlestir(pr, dict(UNIFORM), _binom_lik(p, n, n))["C"], 3),
            }
        duy.append({"delta": dl, "p_acik": {k: round(v, 3) for k, v in p.items()}, **e})

    en_iyi = max(t["P"]["C"] for t in tablo)
    kapilar = [
        {
            "kapi": "K1 merkez sızıntı sürüklenmesi",
            "kaynak": "EVDS TP.ODEAYRSUNUM6.Q76/Q5",
            "olabilirlik": "turetilmis",
            "esleme": "d_s = ln(merkez_sizinti_carpan_s)/T",
            "durum": "olcum_bekliyor" if not uygun else "olculdu",
            "ayirt_gucu": "yok (C vs B ≥ 307 yıl)",
            "P_C_etkisi": round(l1["C"], 3),
        },
        {
            "kapi": "K2 dış kısıt (borç çevirme ≥ %100: bankalar ve diğer sektörler)",
            "kaynak": "EVDS bie_oderoll TP.ODEROLL.K1, K2 (12 ay ort.)",
            "olabilirlik": "varsayim",
            "esleme": f"p_A = taban oran p0 = {p0:.3f} (tarihçede 'açık' pay); p_B = p0 − δ; p_C = p0 + δ; δ = {DELTA}",
            "kontrol_noktalari": list(KONTROL),
            "durum": "olcum_bekliyor" if not n_g else f"olculdu ({k_g}/{n_g} acik)",
            "bugunku_deger_bilgi": k2_son,
            "ayirt_gucu": f"zayıf: tek kapıdan en iyi P(C) = {en_iyi:.3f}",
        },
        {"kapi": "K3 etki erozyonu (bölge ihracat payı)", "kaynak": "TİM; EVDS ülke grubu serisi katalogda yok", "olabilirlik": "turetilmis (etki_erosyon_carpani) ama σ ölçülemez", "durum": "veri_yok", "P_C_etkisi": None},
        {"kapi": "K4 bağ kullanımı", "kaynak": "—", "olabilirlik": "tanımsız", "durum": "olculmedi", "P_C_etkisi": None},
    ]
    return {
        "olcum": "olasilik_kapilar",
        "etiket": "olasilik_olculmedi_kapi_iskeleti",
        "prior": {s: round(UNIFORM[s], 4) for s in SENARYOLAR},
        "eski_el_atamasi": eski,
        "baz_yil": baz,
        "bugunku_P": {s: round(bugun[s], 3) for s in SENARYOLAR},
        "bugunku_P_tam": {s: bugun[s] for s in SENARYOLAR},
        "bugunku_durum": "ölçüm başlamadı: P(C) = prior (1/3). 0,60 hiçbir ölçüme dayanmıyordu." if not (uygun or n_g) else "gözlem var",
        "kapilar": kapilar,
        "k2_tarihce": {"taban_acik_pay": round(p0, 3), "n_pencere": len(ort), "son": k2_son},
        "k2_sonuc_tablosu": tablo,
        "k2_duyarlilik": duy,
        "en_iyi_tek_kapi_P_C": en_iyi,
    }


@lru_cache(maxsize=1)
def _bugun() -> dict[str, float]:
    return dict(hesapla_P()["bugunku_P_tam"])


def vekil() -> dict[str, float]:
    """Pipeline'ın kullandığı senaryo olasılıkları: kapı gözlemlerinden (gözlem yokken tekdüze)."""
    return dict(_bugun())


def vekil_s(s: dict[str, Any]) -> float:
    return vekil()[str(s["id"])]
