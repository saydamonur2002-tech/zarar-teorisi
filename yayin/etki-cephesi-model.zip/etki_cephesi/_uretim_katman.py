"""Kullanıcının üretim katmanı modeli (Drive: 81 İl Sızıntı Matrisi, Zarar Teorisi 3↔2↔1) — saf hesap.

Belgedeki cari açık stres testi ve revizyon (adreslenebilir taban, ihracat esnekliği ε) aynen yeniden kurulur; sonuçları iki yere bağlanır:
  (1) Üretim katmanının iyileşme TAVANI (mn $/yıl): uretim_rant_net_ticaret × net ticaret yerine modelin net cari denge iyileşmesi.
  (2) 'uretim_bagimlilik' halka düzeltme çarpanı: 1 − net iyileşme / halka boşalmasının USD karşılığı (mal ticareti köprüsü).
Diğer dört halkanın çarpanları atanmış kalır. Bu modül başka modülden veri okumaz (pure); köprü girdileri çağıran tarafından verilir.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"


def _cfg() -> dict[str, Any]:
    return json.loads((DATA / "uretim_katman_model.json").read_text(encoding="utf-8"))


def adreslenebilir_taban_mrd(cfg: dict[str, Any] | None = None) -> float:
    c = cfg or _cfg()
    m = c["makro_girdiler"]
    ara = m["mal_ithalati_mrd_usd"]["deger"] * m["ara_mali_ithalat_payi"]["deger"]
    dusen = m["enerji_altin_ithalati_mrd_usd"]["deger"] * m["enerji_altin_ara_mali_tabanina_dahil_payi"]["deger"]
    return ara - dusen


def ara_mali_taban_mrd(cfg: dict[str, Any] | None = None) -> float:
    m = (cfg or _cfg())["makro_girdiler"]
    return m["mal_ithalati_mrd_usd"]["deger"] * m["ara_mali_ithalat_payi"]["deger"]


def brut_tasarruf_mrd(seviye: str, adreslenebilir: bool = False, cfg: dict[str, Any] | None = None) -> float:
    c = cfg or _cfg()
    s = c["senaryolar"][seviye]
    taban = adreslenebilir_taban_mrd(c) if adreslenebilir else ara_mali_taban_mrd(c)
    return taban * s["etkilenen_taban_payi"] * s["m_azalma"]


def net_tasarruf_mrd(seviye: str, adreslenebilir: bool = True, cfg: dict[str, Any] | None = None) -> float:
    c = cfg or _cfg()
    return brut_tasarruf_mrd(seviye, adreslenebilir, c) * (1.0 - c["senaryolar"][seviye]["gecis_kaybi"])


def ihracat_kaybi_mrd(seviye: str, eps: float | None = None, cfg: dict[str, Any] | None = None) -> float:
    c = cfg or _cfg()
    e0 = float(c["ihracat_esnekligi"]["eps_baz"])
    e = e0 if eps is None else float(eps)
    return float(c["senaryolar"][seviye]["ihracat_kaybi_sabit_mrd_usd_eps030"]) * e / e0


def net_iyilesme_mrd(seviye: str, eps: float | None = None, cfg: dict[str, Any] | None = None) -> float:
    """Revize net cari denge iyileşmesi (mrd $/yıl): enerji arındırılmış net ithal ikamesi − ihracat kaybı penaltisi."""
    c = cfg or _cfg()
    return net_tasarruf_mrd(seviye, True, c) - ihracat_kaybi_mrd(seviye, eps, c)


def cari_kapanma_orani(seviye: str, eps: float | None = None, cfg: dict[str, Any] | None = None) -> float:
    c = cfg or _cfg()
    return net_iyilesme_mrd(seviye, eps, c) / float(c["makro_girdiler"]["cari_acik_mrd_usd"]["deger"])


def tavan_usd_mn(seviye: str | None = None, eps: float | None = None) -> float:
    c = _cfg()
    sev = seviye or c["sisteme_baglama"]["referans_seviye"]
    return max(0.0, net_iyilesme_mrd(sev, eps, c) * 1000.0)


def halka_carpani(halka_vekil: float, usd_per_vekil_mn: float, seviye: str | None = None, eps: float | None = None) -> float:
    """1 − net iyileşme (mn $) / halkanın USD karşılığı. Koordinasyon düzeyinde (negatif iyileşme) 1'in üstüne çıkabilir (halka büyür)."""
    c = _cfg()
    sev = seviye or c["sisteme_baglama"]["referans_seviye"]
    halka_usd = float(halka_vekil) * float(usd_per_vekil_mn)
    if halka_usd <= 0:
        return 1.0
    return max(0.0, 1.0 - net_iyilesme_mrd(sev, eps, c) * 1000.0 / halka_usd)


def aktif() -> dict[str, Any] | None:
    c = _cfg()
    b = c["sisteme_baglama"]
    return b if (b.get("tavan_kullan") or b.get("carpan_kullan")) else None
