# Senaryo C + refah — uygulanabilirlik

**Skor: 66.4/100** · **uygulanabilir_kosullu** (C: 71.3, beklenen A/B/C: 57.3)

Politika yığını ve refah rantı, 2024 çapaları içinde tutarlı; kısmi gerçekleşme ile 10 yılda TR net iyileşir.

## Bileşenler (0–1)

| Bileşen | Değer | Ağırlık |
| --- | ---: | ---: |
| olasilik_senaryo_c | 0.6 | 18 |
| katman_gerceklesme_ort | 0.383 | 18 |
| bop_rant_uyumu | 1.0 | 12 |
| tr_10y_iyilesme | 0.898 | 15 |
| gsyh_pp_iyilesme | 0.314 | 10 |
| direnc_dusuk | 1.0 | 12 |
| halka_cevre_koalisyon | 0.75 | 8 |
| stok_kapanis | 1.0 | 7 |

## Beklenen (A/B/C olasılık)

- TR net 10y (yaşam dahil): **-16.666**
- GSYH % orta: **4.658**

## Skor — senaryo başına

| Senaryo | Skor |
| --- | ---: |
| A | 51.0 |
| B | 50.3 |
| C | 79.7 |


## Engeller

- —

## Kolaylaştırıcılar

- Halka çevre entegre kazanan: IR, IL, EG.
- Refah vs boşluk TR kazancı ~16,520.9 mn $/yıl vekili.
- Zarar teorisi katmanı en yüksek gerçekleşme (≈0,7).

**10y TR net (kalibre yol):** -11.803 vekil · GSYH % orta **3.284**
