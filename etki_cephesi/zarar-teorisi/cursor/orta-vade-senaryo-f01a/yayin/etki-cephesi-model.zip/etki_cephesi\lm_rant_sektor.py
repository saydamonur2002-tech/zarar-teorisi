"""P2: Rant kanalları × Lm enstrüman → SFC sektör yayılımı (L/G simulate)."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import numpy as np

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
KALIBRE = DATA / "kalibre"
OUT = REPO / "reports" / "etki_cephesi"
ZARAR_DIR = REPO / "_incoming" / "zarar-teorisi-main"
SEC = ["H", "F", "B", "K", "D"]
IDX = {s: i for i, s in enumerate(SEC)}

if str(ZARAR_DIR) not in sys.path:
    sys.path.insert(0, str(ZARAR_DIR))
from akis_model import simulate  # noqa: E402


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _matrices(donem: str) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    L = np.loadtxt(ZARAR_DIR / f"L_v2_{donem}.csv", delimiter=",", skiprows=1, usecols=range(1, 6))
    G = np.loadtxt(ZARAR_DIR / f"G_v2_{donem}.csv", delimiter=",", skiprows=1, usecols=range(1, 6))
    oz = _load(ZARAR_DIR / "akis_model_ozeti.json")
    nfp = np.array([float(oz["nfp_2026Q1_trilyonTL"][s]) * 1e9 for s in SEC])
    return L, G, nfp


def _usd_mn_to_x(usd_mn: float, kur: float) -> float:
    return usd_mn * kur * 1000.0


def _impact_dict(v: np.ndarray) -> dict[str, float]:
    return {s: round(float(v[i]) / 1e9, 4) for i, s in enumerate(SEC)}


def _lm_col_k_pay(lm_name: str, donem: str) -> dict[str, float]:
    path = ZARAR_DIR / f"Lm_{lm_name}_{donem}.csv"
    if not path.is_file():
        return {}
    M = np.loadtxt(path, delimiter=",", skiprows=1, usecols=range(1, 6))
    col_k = M[:, IDX["K"]]
    s = float(col_k.sum()) or 1.0
    return {SEC[i]: round(float(col_k[i]) / s, 4) for i in range(5)}


def hesapla() -> dict[str, Any]:
    kopru = _load(KALIBRE / "lm_rant_kopru.json")
    zt = _load(DATA / "zarar_teorisi_kopru.json")
    capa = _load(KALIBRE / "gerceklik_capa.json")
    rant = _load(OUT / "DIS_RANT_PARASAL.json")
    ger = _load(OUT / "GERCEKLIK_KALIBRE.json")

    donem = str(kopru.get("matris_donem") or "2026-Q1")
    L, G, nfp = _matrices(donem)
    lam = float(zt["etki_cephesi_carpanlari"]["ic_dongu_kazanim"])
    kappa = float((_load(DATA / "stok_akis_kopru.json").get("simulate") or {}).get("kappa") or 0.1)
    kur = float(capa["kur_tl_usd"])
    r_z = float(ger.get("gerceklesme_oranlari", {}).get("zarar_teorisi") or 0.7)

    kanal_map = kopru.get("kanal_lm") or {}
    default = kopru.get("varsayilan") or {"lm": "kredi", "sektor_baslangic": "F", "tur": "kar"}
    kanallar = rant.get("kanal_dagilimi_akis_eslesmeli") or []

    gruplar: dict[str, dict[str, Any]] = {}
    for row in kanallar:
        key = str(row.get("kanal_akis") or "refah_rant")
        spec = {**default, **(kanal_map.get(key) or {})}
        gk = f"{spec['lm']}:{spec['sektor_baslangic']}:{spec['tur']}"
        g = gruplar.setdefault(
            gk,
            {"lm": spec["lm"], "sektor_baslangic": spec["sektor_baslangic"], "tur": spec["tur"], "usd_mn": 0.0, "kanallar": []},
        )
        ref_usd = float(row.get("refah_dis_usd_mn") or 0.0)
        zar_usd = float(row.get("zarar_usd_mn") or 0.0)
        g["usd_mn"] += max(0.0, ref_usd) * r_z
        g["kanallar"].append({"kanal": key, "refah_usd_mn": ref_usd, "zarar_usd_mn": zar_usd})

    satirlar: list[dict[str, Any]] = []
    x_top = np.zeros(5)
    for gk, g in sorted(gruplar.items(), key=lambda x: -x[1]["usd_mn"]):
        usd = g["usd_mn"]
        if usd <= 0:
            continue
        sec = str(g["sektor_baslangic"])
        x = np.zeros(5)
        mag = _usd_mn_to_x(usd, kur)
        if g["tur"] == "zarar":
            mag = -abs(mag)
        lm_pay = _lm_col_k_pay(str(g["lm"]), donem) if g["lm"] == "borclanma_senedi" else {}
        if lm_pay:
            for s, p in lm_pay.items():
                x[IDX[s]] += mag * p
        else:
            x[IDX[sec]] = mag
        imp = simulate(L, G, nfp, x, lam=lam, kappa=kappa)
        satirlar.append(
            {
                "grup": gk,
                "lm": g["lm"],
                "sektor_baslangic": sec,
                "usd_mn_girdi": round(usd, 1),
                "lm_k_yayilim": lm_pay or None,
                "kanallar": g["kanallar"][:6],
                "sektor_etkisi_trilyonTL": _impact_dict(imp),
            }
        )
        x_top += x

    imp_all = simulate(L, G, nfp, x_top, lam=lam, kappa=kappa)
    return {
        "olcum": "lm_rant_sektor_yayilim",
        "matris_donem": donem,
        "gerceklesme_zarar_katman": r_z,
        "gruplar": satirlar,
        "entegre": {
            "usd_mn_toplam": round(sum(s["usd_mn_girdi"] for s in satirlar), 1),
            "sektor_etkisi_trilyonTL": _impact_dict(imp_all),
        },
        "kaynak": ["DIS_RANT_PARASAL.json", "kalibre/lm_rant_kopru.json", f"L_v2_{donem}.csv"],
    }


def _md(d: dict[str, Any]) -> str:
    e = d["entegre"]["sektor_etkisi_trilyonTL"]
    lines = [
        "# Lm × rant kanalı — sektör yayılımı (P2)",
        "",
        f"Matris **{d['matris_donem']}** · entegre USD **{d['entegre']['usd_mn_toplam']:,}** mn",
        "",
        "| Sektör | Δ trilyon TL |",
        "| --- | ---: |",
    ]
    for s in SEC:
        lines.append(f"| {s} | {e[s]:,.4f} |")
    lines.extend(["", "## Gruplar (top)", ""])
    for g in d["gruplar"][:10]:
        lines.append(f"- **{g['grup']}** · {g['usd_mn_girdi']:,} mn USD")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    data = hesapla()
    (OUT / "LM_RANT_SEKTOR.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "LM_RANT_SEKTOR.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'LM_RANT_SEKTOR.md'}")


if __name__ == "__main__":
    main()
