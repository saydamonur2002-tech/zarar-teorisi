"""Etki cephesi tam zincir + P2 (A/B/C, 10y uluslararası)."""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
ETKI = REPO / "etki_cephesi"


def _run(name: str) -> None:
    parts = name.split()
    subprocess.check_call([sys.executable, str(ETKI / parts[0]), *parts[1:]])


def main() -> None:
    capa_apply = "--capa-apply" in sys.argv
    steps: list[str] = []
    if capa_apply:
        steps.append("gerceklik_capa_senkron.py --apply")
    steps.extend(
        [
        "kalibrasyon.py",
        "projeksiyon.py",
        "akis_olcum.py",
        "zarar_cozum_entegrasyon.py",
        "refah_dis_entegrasyon.py",
        "uretim_ic_akis.py",
        "finans_katman_senaryo_coklu.py",
        "senaryo_gerceklik_kalibre.py --skip-pipeline",
        "zarar_10y_gsyh.py",
        "modul_entegrasyon_kalibre.py --modules-only",
        ]
    )
    for s in steps:
        print(f"=== {s} ===")
        _run(s)


if __name__ == "__main__":
    main()
