# Beklenen senaryo — kalibre (P2+)

| Senaryo | P | TR taban | TR 10y katman | TR 10y + yaşam | GSYH % |
| --- | ---: | ---: | ---: | ---: | ---: |
| **A** | 0.22 | -24.917 | -17.622 | -17.136 | 4.769 |
| **B** | 0.18 | -39.896 | -32.989 | -32.704 | 9.101 |
| **C** | 0.6 | -17.191 | -12.343 | -11.683 | 3.284 |

## Olasılık ağırlıklı

- Beklenen TR net (10y, yaşam dahil): **-16.666** vekil
- Beklenen GSYH % orta: **4.658**
- Beklenen refah dış USD: **9924.328** mn/yıl
