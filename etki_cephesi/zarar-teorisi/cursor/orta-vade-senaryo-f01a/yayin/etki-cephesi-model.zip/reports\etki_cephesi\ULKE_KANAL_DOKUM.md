# Ülke × kanal dokümü (P4)

**345** hücre · **37** ülke · **10** kurum

## Top ülke — refah dış USD (kanal hücreleri, tüm senaryolar)

- **EU:** 6,622.6 mn $
- **CN:** 6,550.5 mn $
- **US:** 6,281.3 mn $
- **RU:** 6,122.0 mn $
- **IR:** 4,187.8 mn $
- **AE:** 2,278.2 mn $
- **IL:** 1,790.6 mn $
- **SA:** 1,552.3 mn $
- **FR:** 1,058.0 mn $
- **EG:** 859.1 mn $
- **AZ:** 678.6 mn $
- **GR:** 592.9 mn $
- **RS:** 114.6 mn $

## Kurumlar

- **IMF:** net 0.194 vekil · 797.9 mn $
- **AB kurumları (Komisyon/ECB vekili):** net 0.171 vekil · 737.6 mn $
- **Dünya Bankası:** net 0.159 vekil · 690.6 mn $
- **EBRD (Avrupa İmar ve Kalkınma Bankası):** net 0.131 vekil · 575.6 mn $
- **BIS (Bank for International Settlements):** net 0.128 vekil · 544.2 mn $
- **AIIB (Asya Altyapı Yatırım Bankası):** net 0.127 vekil · 613.4 mn $
- **NATO:** net 0.113 vekil · 480.7 mn $
- **SWIFT / ödeme altyapısı (vekil):** net 0.105 vekil · 482.0 mn $
- **WTO:** net 0.057 vekil · 240.9 mn $
- **Birleşmiş Milletler:** net 0.042 vekil · 179.6 mn $
