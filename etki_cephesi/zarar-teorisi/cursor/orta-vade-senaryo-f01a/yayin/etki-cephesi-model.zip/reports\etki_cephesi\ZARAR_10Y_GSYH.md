# 10 yıl — zarar (TR net) azalması ve GSYH etkisi

TR net vekil (negatif = yapısal kayıp). Kalibre yol (GERCEKLIK_KALIBRE); GSYH % = |kayıp| USD orta / GSYH 2024 vekili. Kumulatif kazanım = yıllık tabana göre azalan kayıp USD (geometrik orta köprü, basit toplam vekili).

**Dönem:** 2027–2036 · GSYH çapası (2024 vekili): **1,356,471.7** mn USD

## Özet

| | Taban (C+refah) | 10. yıl sonu |
| --- | ---: | ---: |
| TR net vekil | -17.191 | **-12.498** |
| İyileşme (vekil) | — | **4.693** |
| GSYH % (USD orta köprü) | 4.784 | **3.478** |
| GSYH puan düşüş | — | **1.306** pp |
| Yapısal kayıp USD (orta) | 64,891.5 | **47,176.7** mn |

**Yorum:** 10 yıl içinde tam paket (zarar→üretim→finans, kalibre gerçekleşme) bitmez; finans fazının tamamı ~2057 vekiline uzanır. Bu tablo **ilk 10 takvim yılında** gerçekleşen kısmi iyileşmeyi gösterir (ağırlık zarar + üretim başlangıcı).

## Yıllık seri

| Yıl | Faz | TR net | Δ vekil (tabana göre) | GSYH % orta | GSYH % mal | Kum. kazanım USD orta |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 2027 | zarar | -16.565 | 0.626 | 4.61 | 5.844 | 2,363.0 |
| 2028 | zarar | -15.939 | 1.252 | 4.435 | 5.623 | 7,089.0 |
| 2029 | zarar | -15.313 | 1.878 | 4.261 | 5.402 | 14,177.9 |
| 2030 | zarar | -14.688 | 2.503 | 4.087 | 5.182 | 23,626.0 |
| 2031 | zarar | -14.062 | 3.129 | 3.913 | 4.961 | 35,437.1 |
| 2032 | zarar | -13.436 | 3.755 | 3.739 | 4.74 | 49,611.2 |
| 2033 | zarar | -12.81 | 4.381 | 3.565 | 4.519 | 66,148.3 |
| 2034 | zarar | -12.81 | 4.381 | 3.565 | 4.519 | 82,685.4 |
| 2035 | uretim | -12.654 | 4.537 | 3.521 | 4.464 | 99,811.4 |
| 2036 | uretim | -12.498 | 4.693 | 3.478 | 4.409 | 117,526.2 |

**Zarar teorisi ağırlıklı 7 yıl sonu vekili (yaklaşık):** -12.81
