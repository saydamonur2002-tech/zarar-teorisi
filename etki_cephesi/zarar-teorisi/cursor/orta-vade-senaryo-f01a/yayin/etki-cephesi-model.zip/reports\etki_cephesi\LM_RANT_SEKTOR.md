# Lm × rant kanalı — sektör yayılımı (P2)

Matris **2026-Q1** · entegre USD **4,009.4** mn

| Sektör | Δ trilyon TL |
| --- | ---: |
| H | 0.0406 |
| F | 0.0079 |
| B | 0.0180 |
| K | 0.0215 |
| D | 0.0438 |

## Gruplar (top)

- **kredi:F:kar** · 2,988.5 mn USD
- **turev:D:kar** · 481.2 mn USD
- **borclanma_senedi:K:kar** · 198.4 mn USD
- **kredi:K:kar** · 142.0 mn USD
- **altin_sdr:D:kar** · 134.9 mn USD
- **kredi:D:kar** · 64.4 mn USD
