# Dış ülkeler — refah rantı entegrasyonu

Senaryo **C** · rant modeli: **refah** (boşluk dolgusu rant üretmez).

## Refah rant özeti

- Toplam: **2.062** vekil
- TR iç refah payı: **0.509**
- Dış ülke havuzu: **1.12**
- Eski boşluk-rant formülü (karşılaştırma): 4.189

## Ülke defteri (entegre)

| Ülke | Refah rant | Kanal | İkame | MFIN | Net entegre |
| --- | ---: | ---: | ---: | ---: | ---: |
| Merkez finans (vekil) | 0.0 | 0.0 | 0.0 | 5.662 | 5.662 |
| Çin | 0.197 | 2.81 | 0.737 | 0.062 | 3.806 |
| Rusya | 0.181 | 2.583 | 0.887 | 0.062 | 3.713 |
| ABD | 0.177 | 1.281 | 0.406 | 0.062 | 1.926 |
| İran | 0.121 | 1.01 | 0.257 | 0.062 | 1.173 |
| AB (Balkan vekil) | 0.064 | 0.756 | 0.126 | 0.062 | 1.009 |
| BAE | 0.068 | 0.527 | 0.133 | 0.062 | 0.79 |
| İsrail | 0.044 | 0.477 | 0.176 | 0.062 | 0.635 |
| Suudi Arabistan | 0.045 | 0.453 | 0.171 | 0.062 | 0.731 |
| Fransa | 0.029 | 0.439 | 0.065 | 0.062 | 0.595 |
| Mısır | 0.022 | 0.329 | 0.105 | 0.062 | 0.202 |
| Türkiye | 0.509 | 0.0 | 0.0 | 0.0 | -17.191 |
| Bulgaristan | 0.027 | 0.327 | 0.055 | 0.0 | 0.006 |
| Bosna-Hersek | 0.027 | 0.327 | 0.055 | 0.0 | 0.2 |
| Arnavutluk | 0.027 | 0.327 | 0.055 | 0.0 | 0.235 |
| Kuzey Makedonya | 0.027 | 0.327 | 0.055 | 0.0 | 0.239 |
| Sırbistan | 0.029 | 0.301 | 0.05 | 0.0 | -0.012 |
| Yunanistan | 0.014 | 0.246 | 0.052 | 0.062 | 0.374 |
| Ukrayna (vekil) | 0.0 | 0.0 | 0.0 | 0.062 | -0.312 |
| Kıbrıs Rum Kesimi (vekil) | 0.0 | 0.0 | 0.0 | 0.062 | -0.044 |
| Azerbaycan | 0.02 | 0.0 | 0.0 | 0.0 | -0.229 |
| Irak | 0.0 | 0.0 | 0.0 | 0.0 | -1.36 |

**TR:** refah rant **0.509**, havza kayıp **17.7**, net **-17.191**.
