# Senaryo A — ülke bazlı kayıp (10 yıl vekil)

| Ülke | Kayıp endeks | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Türkiye | 25.822 | -25.822 | 0.343 | 0.12 | 0.161 |
| Irak | 2.04 | -2.04 | 0.719 | 0.252 | 0.357 |
| Körfez (vekil) | 1.645 | -1.645 | 0.549 | 0.192 | 0.273 |
| Lübnan | 0.778 | -0.778 | 0.181 | 0.063 | 0.109 |
| Suriye | 0.776 | -0.776 | 0.24 | 0.084 | 0.144 |
| Somali | 0.652 | -0.652 | 0.08 | 0.028 | 0.048 |
| Bulgaristan | 0.584 | -0.584 | 0.219 | 0.077 | 0.086 |
| Sırbistan | 0.579 | -0.579 | 0.255 | 0.089 | 0.111 |
| Fas | 0.569 | -0.569 | 0.177 | 0.062 | 0.088 |
| Libya | 0.559 | -0.559 | 0.199 | 0.07 | 0.089 |
| Ukrayna/Karadeniz (vekil) | 0.552 | -0.552 | 0.221 | 0.077 | 0.109 |
| Mısır | 0.505 | -0.505 | 0.316 | 0.111 | 0.147 |
| Kazakistan | 0.461 | -0.461 | 0.192 | 0.067 | 0.095 |
| Özbekistan | 0.427 | -0.427 | 0.148 | 0.052 | 0.074 |
| İran | 0.417 | -0.417 | 0.32 | 0.112 | 0.153 |
| Cezayir | 0.413 | -0.413 | 0.138 | 0.048 | 0.061 |
| Azerbaycan | 0.384 | -0.384 | 0.221 | 0.077 | 0.11 |
| Gürcistan | 0.371 | -0.371 | 0.148 | 0.052 | 0.074 |
| Türkmenistan | 0.343 | -0.343 | 0.103 | 0.036 | 0.051 |
| Ermenistan | 0.31 | -0.31 | 0.114 | 0.04 | 0.057 |
| Bosna-Hersek | 0.306 | -0.306 | 0.107 | 0.037 | 0.042 |
| Kırgızistan | 0.273 | -0.273 | 0.075 | 0.026 | 0.037 |
| Tacikistan | 0.258 | -0.258 | 0.063 | 0.022 | 0.031 |
| Arnavutluk | 0.255 | -0.255 | 0.095 | 0.033 | 0.037 |
| Kuzey Makedonya | 0.252 | -0.252 | 0.086 | 0.03 | 0.034 |
| Tunus | 0.238 | -0.238 | 0.089 | 0.031 | 0.035 |
| İsrail (vekil) | 0.232 | -0.232 | 0.091 | 0.032 | 0.04 |
| Kıbrıs (vekil) | 0.197 | -0.197 | 0.077 | 0.027 | 0.034 |

## Levant — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Suriye | 0.776 | -0.776 | 0.24 | 0.084 | 0.144 |
| Lübnan | 0.778 | -0.778 | 0.181 | 0.063 | 0.109 |

## Orta Doğu (Fırat / Doğu Akdeniz) — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Irak | 2.04 | -2.04 | 0.719 | 0.252 | 0.357 |
| Kıbrıs (vekil) | 0.197 | -0.197 | 0.077 | 0.027 | 0.034 |
| İsrail (vekil) | 0.232 | -0.232 | 0.091 | 0.032 | 0.04 |
| Mısır | 0.505 | -0.505 | 0.316 | 0.111 | 0.147 |

## Körfez — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Körfez (vekil) | 1.645 | -1.645 | 0.549 | 0.192 | 0.273 |

## Kuzey Afrika — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Libya | 0.559 | -0.559 | 0.199 | 0.07 | 0.089 |
| Mısır | 0.505 | -0.505 | 0.316 | 0.111 | 0.147 |
| Tunus | 0.238 | -0.238 | 0.089 | 0.031 | 0.035 |
| Cezayir | 0.413 | -0.413 | 0.138 | 0.048 | 0.061 |
| Fas | 0.569 | -0.569 | 0.177 | 0.062 | 0.088 |

## Karadeniz — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Ukrayna/Karadeniz (vekil) | 0.552 | -0.552 | 0.221 | 0.077 | 0.109 |
| Sırbistan | 0.579 | -0.579 | 0.255 | 0.089 | 0.111 |

## Kafkasya — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Azerbaycan | 0.384 | -0.384 | 0.221 | 0.077 | 0.11 |
| Gürcistan | 0.371 | -0.371 | 0.148 | 0.052 | 0.074 |
| Ermenistan | 0.31 | -0.31 | 0.114 | 0.04 | 0.057 |

## Balkan — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Sırbistan | 0.579 | -0.579 | 0.255 | 0.089 | 0.111 |
| Bosna-Hersek | 0.306 | -0.306 | 0.107 | 0.037 | 0.042 |
| Arnavutluk | 0.255 | -0.255 | 0.095 | 0.033 | 0.037 |
| Kuzey Makedonya | 0.252 | -0.252 | 0.086 | 0.03 | 0.034 |
| Bulgaristan | 0.584 | -0.584 | 0.219 | 0.077 | 0.086 |

## Orta Asya — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Kazakistan | 0.461 | -0.461 | 0.192 | 0.067 | 0.095 |
| Özbekistan | 0.427 | -0.427 | 0.148 | 0.052 | 0.074 |
| Türkmenistan | 0.343 | -0.343 | 0.103 | 0.036 | 0.051 |
| Kırgızistan | 0.273 | -0.273 | 0.075 | 0.026 | 0.037 |
| Tacikistan | 0.258 | -0.258 | 0.063 | 0.022 | 0.031 |

## İran (yaricevre vekili) — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| İran | 0.417 | -0.417 | 0.32 | 0.112 | 0.153 |

## Afrika Boynu / geniş güney — ülkeler / vekiller

| Ülke | Kayıp | Net | Pasif | Araçsal | Temsil |
| --- | ---: | ---: | ---: | ---: | ---: |
| Somali | 0.652 | -0.652 | 0.08 | 0.028 | 0.048 |
