# Finans katmanı (üretim + halka üstü)

MFIN kenar, merkez sızıntı, finans halkaları (3)(4)(5), **birincil_gelir_yatirim_gideri** (18,841.0 mn USD) ve TDS vekili.

## Katman yığını (TR net vekil)

| Katman | TR net |
| --- | ---: |
| C | -17.7 |
| C_zarar_cozum | -11.112 |
| uretim_ic_akis | -3.237 |
| finans_katman | 0.241 |

## Üretim → finans

| | Üretim tam | + Finans |
| --- | ---: | ---: |
| TR net | -3.237 | **0.241** |
| Boşalma | 8.412 | 6.188 |
| Merkez sızıntı | 3.97 | 2.096 |
| MFIN kenar | 2.993 | 1.556 |
| Finans geri kazanım | — | 1.806 |

**Finans katmanı iyileşmesi:** 3.478 vekil

## USD ↔ vekil

- İçde tutulan yatırım geliri vekili: **1.263** (2,637.7 mn USD)
- TDS rahatı vekili: **0.006**

## Sıfır noktası

- Finans tam olgunluk sonrası net: **0.241**
- Tahmini takvim yılı (TR net ≥ 0, orta yol): **2035**
