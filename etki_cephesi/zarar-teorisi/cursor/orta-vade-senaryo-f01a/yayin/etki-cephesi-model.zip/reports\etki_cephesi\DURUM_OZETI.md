# Etki cephesi — durum özeti

**Tamam:** evet
- Uygulanabilirlik: **66.4** (C: 71.3, beklenen: 57.3)
- Stok kapanış: **True**
- Beklenen TR 10y: **-16.666** vekil
