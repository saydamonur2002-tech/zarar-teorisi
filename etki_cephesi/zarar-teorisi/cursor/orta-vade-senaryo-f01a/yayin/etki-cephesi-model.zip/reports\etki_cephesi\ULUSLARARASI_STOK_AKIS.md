# Uluslararası stok-akış matrisi (kalibre)

Senaryo **C** · refah · rant/inv geliri payı **0.320** → ölçek **1.0**

- Refah dış (kalibre): **6,029.1** mn $
- Stok kapanış (Σ net vekil): **0.0** · **OK**
- **HAVZA (clearing):** giriş **27.07** · çıkış **25.674** · stok **1.396** vekil (brüt kayıp kenar USD: 145,721.8 mn — stokla toplanmaz)
- **MFIN yapısal:** defter **5.662** → stok **6.111** (Σ net **0.0**)

## Balkan / EU ayrımı

- EU satır (ham): **1.009** vekil → **EU merkez (Balkan hariç): 0.366**
- Balkan grup toplam: **1.311** vekil (bireysel 0.668 + EU'dan aktarım 0.643)

  - **RS:** -0.012 vekil
  - **BA:** 0.2 vekil
  - **BG:** 0.006 vekil
  - **AL:** 0.235 vekil
  - **MK:** 0.239 vekil

## Akış türleri (mn USD/yıl vekili)

- **havza_kayip_brut_kenar:** 145,721.80000000002
- **kanal_ikame:** 88,563.7
- **merkez_sizinti:** 38,479.30000000001
- **balkan_eu_aktarim:** 10,830.899999999998
- **refah_rant_dis:** 8,424.4
- **havza_net_stok:** 7,514.9
- **refah_tr_ic:** 2,740.0
- **mfin_havza_denge:** 2,417.0

## Stok (seçili)

- **TR:** -17.191 vekil · -92,541.6 mn $
- **MFIN:** 6.111 vekil · 32,896.4 mn $
- **HAVZA:** 1.396 vekil · 7,514.9 mn $
- **IMF:** 0.194 vekil · 1,044.3 mn $
- **WB:** 0.159 vekil · 855.9 mn $
- **EUINST:** 0.171 vekil · 920.5 mn $
- **EU:** 1.009 vekil · 5,431.6 mn $
- **IR:** 1.173 vekil · 6,314.4 mn $
- **CN:** 3.806 vekil · 20,488.2 mn $
- **RS:** -0.012 vekil · -64.6 mn $
- **BA:** 0.2 vekil · 1,076.6 mn $
- **BG:** 0.006 vekil · 32.3 mn $
