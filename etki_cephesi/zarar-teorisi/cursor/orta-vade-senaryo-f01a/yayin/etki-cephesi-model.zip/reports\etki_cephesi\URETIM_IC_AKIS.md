# Üretime bağlı akış — halka düzeltmesi + rant artı değer

Taban: **C + zarar-teorisi**; üst katman: çevre halkalarının üretime bağlanması, GSYH’deki iç-talep/üretim kopukluğu vekili, rantın TR artı değeri.

## Halka toplamı (C ham delta)

- `uretim_bagimlilik`: 3.933
- `koordinasyon_kopuk`: 1.772
- `para_sizintisi`: 3.257
- `zarar_aktarimi`: 2.956
- `dis_kisit`: 5.479

**Boşalma oranı (düzeltme sonrası):** 0.6226

| | C+zarar | + üretim/iç akış |
| --- | ---: | ---: |
| TR net vekil | -11.112 | **-3.237** |
| TR boşalma | 13.51 | 8.412 |
| Rant çıkış | 0.975 | 0.776 |
| Rant TR artı | — | 0.234 |
| Merkez sızıntı | 4.782 | 3.97 |

**TR net iyileşme:** 7.875 vekil

## Sıfır noktası (TR net ≥ 0)

- Tam olgunluk vekili: **12.0 yıl**
- Tam katman sonrası net: **-3.237**
- Tahmini takvim yılı (orta yol): **2043**
- Tam olgunlukta net hâlâ negatifse sıfır yılı, aynı eğimin devamı varsayımıdır.
