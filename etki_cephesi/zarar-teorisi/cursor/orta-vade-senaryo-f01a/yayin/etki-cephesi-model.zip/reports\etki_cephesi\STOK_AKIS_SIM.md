# Stok-akış simülasyonu (SFC × etki cephesi)

Matris **2026-Q1** · λ=0.7181 · κ=0.1 · kur **32.87**

## Entegre sektör etkisi (trilyon TL)

| Sektör | Δ (trilyon TL) |
| --- | ---: |
| H | 0.119 |
| F | 0.153 |
| B | 0.088 |
| K | 0.117 |
| D | 0.109 |

## Akış pulsları

- **zarar_bosluk_rant_dis** (zarar, F): 12,402.5 mn USD → D dağılımı H=-0.038, F=-0.021, D=-0.218
- **zarar_bosluk_rant_d_absorpsiyon** (kar, D): 10,147.5 mn USD → D dağılımı H=0.123, F=0.087, D=0.0
- **refah_tasarruf** (kar, F): 10,986.4 mn USD → D dağılımı H=0.107, F=0.0, D=0.147
- **refah_tr_ic** (kar, H): 2,740.0 mn USD → D dağılımı H=0.0, F=0.021, D=0.04
- **yasam_maliyet_10y** (kar, H): 6,372.6 mn USD → D dağılımı H=0.0, F=0.048, D=0.094

## 10 yıl — F.4 stok yolu (beş adım)

- **2027:** F.4 stok **24685.5** milyar TL · itiş 0.0 · küm. etki D=0.014
- **2028:** F.4 stok **24031.3** milyar TL · itiş 0.0 · küm. etki D=0.042
- **2029:** F.4 stok **23377.0** milyar TL · itiş 0.0 · küm. etki D=0.084
- **2030:** F.4 stok **22722.7** milyar TL · itiş 0.0 · küm. etki D=0.139
- **2031:** F.4 stok **22068.4** milyar TL · itiş 0.0 · küm. etki D=0.209
- **2032:** F.4 stok **21414.2** milyar TL · itiş 0.0 · küm. etki D=0.293
- **2033:** F.4 stok **20759.9** milyar TL · itiş 0.0 · küm. etki D=0.39
- **2034:** F.4 stok **20105.6** milyar TL · itiş 0.0 · küm. etki D=0.502
- **2035:** F.4 stok **19451.3** milyar TL · itiş 0.0 · küm. etki D=0.627
- **2036:** F.4 stok **18797.1** milyar TL · itiş 0.0 · küm. etki D=0.907
