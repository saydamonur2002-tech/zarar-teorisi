"""P3: senaryo kalibre, capa senkron, snapshot."""
from __future__ import annotations

import json
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "etki_cephesi"


def test_zarar_10y_senaryo_coklu():
    p = OUT / "ZARAR_10Y_SENARYO_COKLU.json"
    assert p.is_file()
    d = json.loads(p.read_text(encoding="utf-8"))
    by_id = {x["id"]: x for x in d["senaryolar"]}
    assert by_id["C"]["yil_10_son"] > by_id["B"]["yil_10_son"]
    sifir_a = by_id["A"].get("sifir_nokta")
    assert sifir_a is None or int(sifir_a) < 2100


def test_capa_senkron():
    p = OUT / "GERCEKLIK_CAPA_SENKRON.json"
    assert p.is_file()
    d = json.loads(p.read_text(encoding="utf-8"))
    assert "usd_mn_oneri" in d
    assert abs(d["fark_mn"].get("net_ticaret", 0)) < 1.0


def test_stok_akis_senaryo_coklu():
    p = OUT / "STOK_AKIS_SIM_COKLU.json"
    assert p.is_file()
    d = json.loads(p.read_text(encoding="utf-8"))
    by_id = {x["id"]: x for x in d["senaryolar"]}
    assert by_id["C"]["entegre_D_trilyonTL"] >= by_id["B"]["entegre_D_trilyonTL"]


def test_uluslararasi_snapshots():
    idx = OUT / "ULUSLARARASI_SNAPSHOT_INDEX.json"
    assert idx.is_file()
    meta = json.loads(idx.read_text(encoding="utf-8"))
    assert len(meta["dosyalar"]) >= 3
    y = OUT / meta["dosyalar"][0]
    snap = json.loads(y.read_text(encoding="utf-8"))
    assert snap.get("akis_kenar_sayisi", 0) > 0
