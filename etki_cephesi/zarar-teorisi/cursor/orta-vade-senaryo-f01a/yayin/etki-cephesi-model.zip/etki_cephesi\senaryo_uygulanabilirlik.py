"""Senaryo C + refah — uygulanabilirlik değerlendirmesi (kalibre stok-akış üzerinden)."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
OUT = REPO / "reports" / "etki_cephesi"


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _skor_bilesen(
    tr_10: float,
    tr_bas: float,
    gsyh_son: float,
    gsyh_bas: float,
    g_mean: float,
    bop_skor: float,
    kapanis: bool,
) -> tuple[dict[str, float], float]:
    tr_yol_skor = max(0.0, min(1.0, (tr_10 - tr_bas) / 6.0))
    gsyh_skor = max(0.0, min(1.0, (gsyh_bas - gsyh_son) / max(gsyh_bas, 0.01)))
    bilesenler = {
        "katman_gerceklesme_ort": round(g_mean, 3),
        "bop_rant_uyumu": round(bop_skor, 3),
        "tr_10y_iyilesme": round(tr_yol_skor, 3),
        "gsyh_pp_iyilesme": round(gsyh_skor, 3),
        "stok_kapanis": 1.0 if kapanis else 0.35,
    }
    w_partial = {"katman_gerceklesme_ort": 18, "bop_rant_uyumu": 12, "tr_10y_iyilesme": 15, "gsyh_pp_iyilesme": 10, "stok_kapanis": 7}
    partial = sum(bilesenler[k] * w_partial[k] for k in w_partial)
    return bilesenler, partial


def degerlendir() -> dict[str, Any]:
    sen_doc = _load(DATA / "senaryolar.json")
    mat = _load(OUT / "ULUSLARARASI_STOK_AKIS.json")
    bek_path = OUT / "SENARYO_BEKLENEN_KALIBRE.json"
    bek = _load(bek_path) if bek_path.is_file() else None
    bolge = _load(OUT / "BOLGE_STOK_AKIS.json")
    modul = _load(OUT / "MODUL_KALIBRE.json")
    ger = _load(OUT / "GERCEKLIK_KALIBRE.json")
    z10 = _load(OUT / "ZARAR_10Y_GSYH.json")

    c = next(s for s in sen_doc["senaryolar"] if s["id"] == "C")
    p_c = float(c.get("olasilik_vekili") or 0.6)
    g = ger.get("gerceklesme_oranlari") or {}
    g_mean = sum(float(v) for v in g.values()) / max(len(g), 1)

    kal = mat["kalibrasyon"]
    kapanis = bool(kal.get("kapanis_ok"))
    pay = float(kal.get("rant_inv_geliri_pay_ham") or 0)
    hedef = float(_load(DATA / "kalibre" / "uluslararasi_stok_akis_capa.json")["rant_inv_geliri_hedef_pay"])
    bop_skor = max(0.0, min(1.0, 1.0 - abs(pay - hedef) / hedef))

    tr_bas = float(modul["tr_net_yigini_10y"]["C_refah_taban"])
    tr_10 = float(modul["tr_net_yigini_10y"]["artı_yasam_maliyet_politikasi"])
    iyilesme = tr_10 - tr_bas
    tr_yol_skor = max(0.0, min(1.0, iyilesme / 6.0))

    gsyh_bas = float(modul["gsyh_yuzde_orta"]["taban"])
    gsyh_son = float(modul["gsyh_yuzde_orta"]["yil_10_yasam_dahil"])
    gsyh_skor = max(0.0, min(1.0, (gsyh_bas - gsyh_son) / max(gsyh_bas, 0.01)))

    tr_bek = float((bek or {}).get("beklenti", {}).get("beklenen_tr_net_10y_yasam") or tr_10)
    gsyh_bek = float((bek or {}).get("beklenti", {}).get("beklenen_gsyh_yuzde_orta_10y") or gsyh_son)
    bek_bil, bek_partial = _skor_bilesen(tr_bek, tr_bas, gsyh_bek, gsyh_bas, g_mean, bop_skor, kapanis)

    direnc = bolge.get("rant_kanali_bosluk_taraftari") or []
    direnc_agir = len([a for a in direnc if (a.get("rant_kanal_bosluk_fark_usd_mn") or 0) > 1000])
    direnc_skor = max(0.0, 1.0 - direnc_agir / 8.0)

    halka = bolge.get("halka_cevre_kazanan") or []
    koalisyon_skor = min(1.0, len(halka) / 4.0)

    bilesenler = {
        "olasilik_senaryo_c": round(p_c, 3),
        "katman_gerceklesme_ort": round(g_mean, 3),
        "bop_rant_uyumu": round(bop_skor, 3),
        "tr_10y_iyilesme": round(tr_yol_skor, 3),
        "gsyh_pp_iyilesme": round(gsyh_skor, 3),
        "direnc_dusuk": round(direnc_skor, 3),
        "halka_cevre_koalisyon": round(koalisyon_skor, 3),
        "stok_kapanis": 1.0 if kapanis else 0.35,
    }

    agirlik = {
        "olasilik_senaryo_c": 18,
        "katman_gerceklesme_ort": 18,
        "bop_rant_uyumu": 12,
        "tr_10y_iyilesme": 15,
        "gsyh_pp_iyilesme": 10,
        "direnc_dusuk": 12,
        "halka_cevre_koalisyon": 8,
        "stok_kapanis": 7,
    }
    skor_c = sum(bilesenler[k] * agirlik[k] for k in agirlik)
    skor_c = round(min(100.0, max(0.0, skor_c)), 1)
    olas_c = bilesenler["olasilik_senaryo_c"]
    skor_bek = round(
        min(
            100.0,
            bek_partial
            + bek_bil["tr_10y_iyilesme"] * 12
            + direnc_skor * 12
            + koalisyon_skor * 8
            + olas_c * 18,
        ),
        1,
    )
    skor = round(0.65 * skor_c + 0.35 * skor_bek, 1) if bek else skor_c

    zcok_path = OUT / "ZARAR_10Y_SENARYO_COKLU.json"
    zcok = _load(zcok_path) if zcok_path.is_file() else None
    skor_senaryo: dict[str, float] = {}
    if zcok:
        olas_norm: dict[str, float] = {}
        for s in sen_doc.get("senaryolar") or []:
            olas_norm[str(s["id"])] = float(s.get("olasilik_vekili") or 0.0)
        s_olas = sum(olas_norm.values()) or 1.0
        olas_norm = {k: v / s_olas for k, v in olas_norm.items()}
        by_z = {x["id"]: x for x in zcok.get("senaryolar") or []}
        for sid in ("A", "B", "C"):
            row = by_z.get(sid)
            if not row:
                continue
            tr_s = float(row.get("yil_10_son") or tr_10)
            gsyh_s = float(row.get("gsyh_yuzde_10_son") or gsyh_son)
            bil_s, part_s = _skor_bilesen(tr_s, tr_bas, gsyh_s, gsyh_bas, g_mean, bop_skor, kapanis)
            skor_s = round(
                min(
                    100.0,
                    part_s
                    + bil_s["tr_10y_iyilesme"] * 12
                    + direnc_skor * 12
                    + koalisyon_skor * 8
                    + olas_norm.get(sid, 0.0) * 18,
                ),
                1,
            )
            skor_senaryo[sid] = skor_s

    if skor >= 62:
        karar = "uygulanabilir_kosullu"
        ozet = "Politika yığını ve refah rantı, 2024 çapaları içinde tutarlı; kısmi gerçekleşme ile 10 yılda TR net iyileşir."
    elif skor >= 45:
        karar = "kisitli_uygulanabilir"
        ozet = "Model yön doğru; merkez/rakip direnç ve düşük üretim/finans gerçekleşmesi tempo kısar."
    else:
        karar = "dusuk_uygulanabilirlik"
        ozet = "Stok kapanışı veya dış direnç zayıflatır; senaryo analitik senaryo olarak kalmalı."

    engeller = []
    if g_mean < 0.35:
        engeller.append("Katman gerçekleşme ortalaması düşük (üretim/finans ~0,25–0,35).")
    if direnc_agir >= 5:
        engeller.append("Rant kanalında boşluk senaryosunu tercih eden güçlü dış aktörler (EU, US, CN…).")
    if not kapanis:
        engeller.append("Uluslararası stok net toplamı kapanmıyor — vekil ölçeği abartılı olabilir.")
    if tr_10 > -8:
        engeller.append("TR net hâlâ derin negatif; hedef ‘sıfıra yakın’ değil.")

    kolaylastirici = []
    if halka:
        kolaylastirici.append(f"Halka çevre entegre kazanan: {', '.join(a['ulke'] for a in halka[:5])}.")
    kolaylastirici.append(f"Refah vs boşluk TR kazancı ~{modul['rant_parasal_ozet']['tasarruf_refah_vs_zarar_usd_mn']:,} mn $/yıl vekili.")
    if float(g.get("zarar_teorisi") or 0) >= 0.65:
        kolaylastirici.append("Zarar teorisi katmanı en yüksek gerçekleşme (≈0,7).")

    return {
        "olcum": "senaryo_c_refah_uygulanabilirlik",
        "skor_0_100": skor,
        "skor_senaryo_c": skor_c,
        "skor_beklenen_ab_c": skor_bek if bek else None,
        "skor_senaryo_ab_c": skor_senaryo or None,
        "karar": karar,
        "ozet": ozet,
        "bilesenler": bilesenler,
        "bilesenler_beklenen": bek_bil if bek else None,
        "agirliklar": agirlik,
        "referans_beklenen": (bek or {}).get("beklenti"),
        "engeller": engeller,
        "kolaylastiricilar": kolaylastirici,
        "referans": {
            "tr_net_10y": tr_10,
            "gsyh_yuzde_10y": gsyh_son,
            "z10_yil": z10.get("horizon", {}).get("bit_yil"),
        },
        "kaynak_raporlar": [
            "ULUSLARARASI_STOK_AKIS.json",
            "BOLGE_STOK_AKIS.json",
            "MODUL_KALIBRE.json",
            "GERCEKLIK_KALIBRE.json",
        ],
    }


def _md(d: dict[str, Any]) -> str:
    lines = [
        "# Senaryo C + refah — uygulanabilirlik",
        "",
        f"**Skor: {d['skor_0_100']}/100** · **{d['karar']}**"
        + (
            f" (C: {d['skor_senaryo_c']}, beklenen A/B/C: {d['skor_beklenen_ab_c']})"
            if d.get("skor_beklenen_ab_c") is not None
            else ""
        ),
        "",
        d["ozet"],
        "",
        "## Bileşenler (0–1)",
        "",
        "| Bileşen | Değer | Ağırlık |",
        "| --- | ---: | ---: |",
    ]
    for k, w in d["agirliklar"].items():
        lines.append(f"| {k} | {d['bilesenler'][k]} | {w} |")
    rb = d.get("referans_beklenen")
    ss = d.get("skor_senaryo_ab_c")
    if rb:
        lines.extend(
            [
                "",
                "## Beklenen (A/B/C olasılık)",
                "",
                f"- TR net 10y (yaşam dahil): **{rb.get('beklenen_tr_net_10y_yasam')}**",
                f"- GSYH % orta: **{rb.get('beklenen_gsyh_yuzde_orta_10y')}**",
                "",
            ]
        )
    if ss:
        lines.extend(
            [
                "## Skor — senaryo başına",
                "",
                "| Senaryo | Skor |",
                "| --- | ---: |",
            ]
        )
        for sid in ("A", "B", "C"):
            if sid in ss:
                lines.append(f"| {sid} | {ss[sid]} |")
        lines.append("")
    lines.extend(["", "## Engeller", ""])
    for e in d["engeller"] or ["—"]:
        lines.append(f"- {e}")
    lines.extend(["", "## Kolaylaştırıcılar", ""])
    for e in d["kolaylastiricilar"]:
        lines.append(f"- {e}")
    lines.extend(
        [
            "",
            f"**10y TR net (kalibre yol):** {d['referans']['tr_net_10y']} vekil · "
            f"GSYH % orta **{d['referans']['gsyh_yuzde_10y']}**",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    if not (OUT / "ULUSLARARASI_STOK_AKIS.json").is_file():
        import subprocess
        import sys

        subprocess.check_call([sys.executable, str(REPO / "etki_cephesi" / "uluslararasi_stok_akis.py")])
    data = degerlendir()
    (OUT / "SENARYO_UYGULANABILIRLIK.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "SENARYO_UYGULANABILIRLIK.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'SENARYO_UYGULANABILIRLIK.md'}")


if __name__ == "__main__":
    main()
