"""Stok-akış (SFC) simülasyonu — etki cephesi kalibre akışları × zarar-teorisi L/G."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import numpy as np

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
KALIBRE = DATA / "kalibre"
OUT = REPO / "reports" / "etki_cephesi"
ZARAR_DIR = REPO / "_incoming" / "zarar-teorisi-main"

SEC = ["H", "F", "B", "K", "D"]
IDX = {s: i for i, s in enumerate(SEC)}

if str(ZARAR_DIR) not in sys.path:
    sys.path.insert(0, str(ZARAR_DIR))
from akis_model import simulate  # noqa: E402


def _load(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _nested(doc: dict[str, Any], path: str) -> Any:
    cur: Any = doc
    for part in path.split("."):
        cur = cur[part]
    return cur


def _usd_mn_to_x(usd_mn: float, kur: float) -> float:
    """akis_model.simulate girdisi: bin TL (×1000 TL); 1e9 bin TL = 1 trilyon TL."""
    return usd_mn * kur * 1000.0


def _matrices(donem: str = "2026-Q1") -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    L = np.loadtxt(ZARAR_DIR / f"L_v2_{donem}.csv", delimiter=",", skiprows=1, usecols=range(1, 6))
    G = np.loadtxt(ZARAR_DIR / f"G_v2_{donem}.csv", delimiter=",", skiprows=1, usecols=range(1, 6))
    oz = _load(ZARAR_DIR / "akis_model_ozeti.json")
    nfp_t = oz["nfp_2026Q1_trilyonTL"]
    nfp = np.array([float(nfp_t[s]) * 1e9 for s in SEC])
    return L, G, nfp


def _shock_vec(
    usd_mn: float,
    kur: float,
    sektor: str,
    tur: str,
    pay: float = 1.0,
    gerceklesme: float = 1.0,
) -> np.ndarray:
    x = np.zeros(5)
    mag = _usd_mn_to_x(usd_mn, kur) * pay * gerceklesme
    if tur == "zarar":
        mag = -abs(mag)
    else:
        mag = abs(mag)
    x[IDX[sektor]] = mag
    return x


def _impact_dict(v: np.ndarray) -> dict[str, float]:
    return {s: round(float(v[i]) / 1e9, 3) for i, s in enumerate(SEC)}


def _stok_f4_yolu(yillar: list[int], tavan: float, stok0: float, itis: float) -> list[dict[str, Any]]:
    rows = []
    stok = stok0
    for i, y in enumerate(yillar):
        u = min(1.0, (i + 1) / len(yillar))
        sil = stok0 * tavan * u
        stok = max(stok0 * (1.0 - tavan * u), stok0 - sil)
        rows.append(
            {
                "yil": y,
                "stok_f4_milyar": round(stok, 1),
                "silinen_kumulatif_milyar": round(sil, 1),
                "yeni_itis_milyar": itis,
            }
        )
    return rows


def calistir(senaryo_id: str = "C") -> dict[str, Any]:
    sid = senaryo_id
    kopru = _load(DATA / "stok_akis_kopru.json")
    capa = _load(KALIBRE / "gerceklik_capa.json")
    zt_kopru = _load(DATA / "zarar_teorisi_kopru.json")
    lam = float(zt_kopru["etki_cephesi_carpanlari"]["ic_dongu_kazanim"])
    kappa = float(kopru["simulate"]["kappa"])
    kur = float(capa["kur_tl_usd"])

    modul = _load(OUT / "MODUL_KALIBRE.json") if (OUT / "MODUL_KALIBRE.json").is_file() else {}
    dis_path = OUT / f"DIS_RANT_PARASAL_{sid}.json"
    if not dis_path.is_file():
        dis_path = OUT / "DIS_RANT_PARASAL.json"
    dis = _load(dis_path) if dis_path.is_file() else {}
    yasam = _load(OUT / "YASAM_MALIYET_KATMAN.json") if (OUT / "YASAM_MALIYET_KATMAN.json").is_file() else {}
    ger_path = OUT / f"GERCEKLIK_KALIBRE_{sid}.json"
    if not ger_path.is_file() and sid == "C":
        ger_path = OUT / "GERCEKLIK_KALIBRE.json"
    ger = _load(ger_path) if ger_path.is_file() else {}

    sen_doc = _load(DATA / "senaryolar.json")
    sen = next((s for s in sen_doc.get("senaryolar") or [] if s.get("id") == sid), None)
    er = float((sen or {}).get("etki_erosyon_carpani") or 0.22)
    flex = float((sen or {}).get("tr_diplomatik_flex") or 0.0)
    pol = max(0.25, min(1.0, 1.05 - er + flex))
    docs = {
        "MODUL_KALIBRE.json": modul,
        "DIS_RANT_PARASAL.json": dis,
        "YASAM_MALIYET_KATMAN.json": yasam,
        "GERCEKLIK_KALIBRE.json": ger,
    }
    r_z = float(ger.get("gerceklesme_oranlari", {}).get("zarar_teorisi") or 0.7)
    r_y = float(yasam.get("gerceklesme") or 0.28)

    L, G, nfp = _matrices(str(kopru.get("matris_donem") or "2026-Q1"))

    pulslar: list[dict[str, Any]] = []
    x_toplam = np.zeros(5)
    for ad, spec in (kopru.get("akis_kaynaklari") or {}).items():
        rapor = str(spec["rapor"])
        doc = docs.get(rapor) or _load(OUT / rapor)
        usd = float(_nested(doc, spec["alan"]))
        g = float(spec.get("gerceklesme", 1.0))
        if spec.get("gerceklesme_kaynak"):
            src, fld = spec["gerceklesme_kaynak"].split(" → ")
            gdoc = docs.get(src.strip()) or _load(OUT / src.strip())
            if "gerceklesme_oranlari" in fld:
                key = fld.split(".")[-1]
                g = float(gdoc.get("gerceklesme_oranlari", {}).get(key) or r_z)
            else:
                g = float(gdoc.get(fld.strip()) or r_y)
        pay = float(spec.get("pay") or 1.0)
        x = _shock_vec(usd, kur, spec["sektor_baslangic"], spec["tur"], pay=pay, gerceklesme=g)
        imp = simulate(L, G, nfp, x, lam=lam, kappa=kappa)
        pulslar.append(
            {
                "id": ad,
                "usd_mn_girdi": round(usd * pay * g, 1),
                "sektor_baslangic": spec["sektor_baslangic"],
                "tur": spec["tur"],
                "gerceklesme": g,
                "x_trilyonTL": round(float(x[IDX[spec["sektor_baslangic"]]]) / 1e9, 3),
                "sektor_etkisi_trilyonTL": _impact_dict(imp),
            }
        )
        x_toplam += x

    imp_entegre = simulate(L, G, nfp, x_toplam, lam=lam, kappa=kappa)

    yillar = [int(r["yil"]) for r in yasam.get("yillik_seri") or []]
    if not yillar:
        yillar = list(range(2027, 2037))
    bes = kopru.get("bes_adim_stok") or {}
    stok_yolu = _stok_f4_yolu(
        yillar,
        float(bes.get("stok_silim_tavan") or 0.2582),
        float(bes.get("stok_bas_milyar") or 25339.8),
        float(bes.get("kredi_itis_milyar_yillik") or 0.0),
    )

    yillik: list[dict[str, Any]] = []
    x_kum = np.zeros(5)
    seri = yasam.get("yillik_seri") or []
    for i, y in enumerate(yillar):
        x_y = np.zeros(5)
        if seri and i < len(seri):
            h_usd = float(seri[i].get("hane_tasarruf_usd_mn") or 0)
            x_y += _shock_vec(h_usd, kur, "H", "kar", gerceklesme=1.0)
        if i == len(yillar) - 1:
            tas = float(
                (dis.get("ozet") or {}).get("tasarruf_refah_vs_zarar_usd_mn")
                or modul.get("rant_parasal_ozet", {}).get("tasarruf_refah_vs_zarar_usd_mn")
                or 0
            )
            x_y += _shock_vec(tas, kur, "F", "kar", gerceklesme=r_z * pol)
        x_kum += x_y
        imp_y = simulate(L, G, nfp, x_kum, lam=lam, kappa=kappa)
        yillik.append(
            {
                "yil": y,
                "stok_f4": stok_yolu[i] if i < len(stok_yolu) else None,
                "kumulatif_sektor_etkisi_trilyonTL": _impact_dict(imp_y),
            }
        )

    return {
        "olcum": "stok_akis_simulasyon",
        "senaryo_id": sid,
        "senaryo_politika_carpan": round(pol, 3),
        "matris_donem": kopru.get("matris_donem"),
        "lambda_yayilim": lam,
        "kappa": kappa,
        "kur_tl_usd": kur,
        "nfp_2026Q1_trilyonTL": _load(ZARAR_DIR / "akis_model_ozeti.json")["nfp_2026Q1_trilyonTL"],
        "pulslar": pulslar,
        "entegre_puls": {
            "x_trilyonTL_sektor": {s: round(float(x_toplam[i]) / 1e9, 3) for i, s in enumerate(SEC)},
            "sektor_etkisi_trilyonTL": _impact_dict(imp_entegre),
        },
        "yillik_stok_akis": yillik,
        "bes_adim_kisit": kopru.get("bes_adim_stok"),
        "kaynak": [
            "stok_akis_kopru.json",
            "MODUL_KALIBRE.json",
            "L_v2_2026-Q1.csv",
            "G_v2_2026-Q1.csv",
            "akis_model.simulate",
        ],
    }


def _md(d: dict[str, Any]) -> str:
    e = d["entegre_puls"]["sektor_etkisi_trilyonTL"]
    lines = [
        "# Stok-akış simülasyonu (SFC × etki cephesi)",
        "",
        f"Matris **{d['matris_donem']}** · λ={d['lambda_yayilim']} · κ={d['kappa']} · kur **{d['kur_tl_usd']}**",
        "",
        "## Entegre sektör etkisi (trilyon TL)",
        "",
        "| Sektör | Δ (trilyon TL) |",
        "| --- | ---: |",
    ]
    for s in SEC:
        lines.append(f"| {s} | {e[s]:,.3f} |")
    lines.extend(["", "## Akış pulsları", ""])
    for p in d["pulslar"]:
        lines.append(
            f"- **{p['id']}** ({p['tur']}, {p['sektor_baslangic']}): "
            f"{p['usd_mn_girdi']:,} mn USD → D dağılımı "
            f"H={p['sektor_etkisi_trilyonTL']['H']}, F={p['sektor_etkisi_trilyonTL']['F']}, "
            f"D={p['sektor_etkisi_trilyonTL']['D']}"
        )
    lines.extend(["", "## 10 yıl — F.4 stok yolu (beş adım)", ""])
    for row in d["yillik_stok_akis"]:
        st = row.get("stok_f4") or {}
        lines.append(
            f"- **{row['yil']}:** F.4 stok **{st.get('stok_f4_milyar', '—')}** milyar TL · "
            f"itiş {st.get('yeni_itis_milyar', 0)} · küm. etki D={row['kumulatif_sektor_etkisi_trilyonTL']['D']}"
        )
    lines.append("")
    return "\n".join(lines)


def calistir_coklu(senaryolar: tuple[str, ...] = ("A", "B", "C")) -> dict[str, Any]:
    OUT.mkdir(parents=True, exist_ok=True)
    satirlar: list[dict[str, Any]] = []
    for sid in senaryolar:
        data = calistir(sid)
        (OUT / f"STOK_AKIS_SIM_{sid}.json").write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        e = data["entegre_puls"]["sektor_etkisi_trilyonTL"]
        satirlar.append(
            {
                "id": sid,
                "politika_carpan": data.get("senaryo_politika_carpan"),
                "gerceklesme_zarar": data.get("pulslar", [{}])[0].get("gerceklesme") if data.get("pulslar") else None,
                "entegre_D_trilyonTL": e.get("D"),
                "entegre_F_trilyonTL": e.get("F"),
                "entegre_H_trilyonTL": e.get("H"),
            }
        )
    coklu = {"olcum": "stok_akis_sim_coklu", "senaryolar": satirlar}
    (OUT / "STOK_AKIS_SIM_COKLU.json").write_text(json.dumps(coklu, ensure_ascii=False, indent=2), encoding="utf-8")
    if "C" in senaryolar:
        c_data = _load(OUT / "STOK_AKIS_SIM_C.json") if (OUT / "STOK_AKIS_SIM_C.json").is_file() else calistir("C")
        (OUT / "STOK_AKIS_SIM.json").write_text(json.dumps(c_data, ensure_ascii=False, indent=2), encoding="utf-8")
        (OUT / "STOK_AKIS_SIM.md").write_text(_md(c_data), encoding="utf-8")
    return coklu


def main() -> None:
    calistir_coklu()
    print(f"Wrote {OUT / 'STOK_AKIS_SIM.md'} + STOK_AKIS_SIM_COKLU.json")


if __name__ == "__main__":
    main()
