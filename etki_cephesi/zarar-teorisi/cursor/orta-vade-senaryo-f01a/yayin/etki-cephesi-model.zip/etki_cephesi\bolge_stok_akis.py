"""Bölgesel stok-akış: tüm aktörler — entegre defter + rant kanalı; kazanan / kaybeden."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import numpy as np

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "data" / "etki_cephesi"
KALIBRE = DATA / "kalibre"
OUT = REPO / "reports" / "etki_cephesi"
ZARAR_DIR = REPO / "_incoming" / "zarar-teorisi-main"

SEC = ["H", "F", "B", "K", "D"]
IDX = {s: i for i, s in enumerate(SEC)}

CEVRE_ROL = frozenset({"bolge_guc", "tampon", "koridor", "rakip_yaricevre"})
MERKEZ_ROL = frozenset({"merkez_vekil", "merkez_yakin", "merkez_finans", "rant_havza"})

if str(ZARAR_DIR) not in sys.path:
    sys.path.insert(0, str(ZARAR_DIR))
from akis_model import simulate  # noqa: E402

from stok_akis_sim import _matrices, _shock_vec, _load  # noqa: E402


def _nfp_aktör(base: np.ndarray, iso: str, ulke_sys: dict[str, Any]) -> np.ndarray:
    u = (ulke_sys.get("ulkeler") or {}).get(iso) or {}
    e = float(u.get("refah_endeks") or 0.5)
    rol = str(u.get("rol") or "")
    nfp = base.copy()
    nfp *= 0.35 + 0.65 * e
    if rol in ("merkez_vekil", "merkez_yakin", "merkez_finans"):
        nfp[IDX["D"]] *= 1.15
        nfp[IDX["K"]] *= 1.08
    elif rol == "rant_havza":
        nfp[IDX["F"]] *= 1.1
        nfp[IDX["D"]] *= 1.05
    elif rol in ("rakip_yaricevre", "bolge_guc"):
        nfp[IDX["F"]] *= 0.95
    elif rol == "yaricevre":
        nfp[IDX["H"]] *= 1.05
        nfp[IDX["F"]] *= 0.88
    return nfp


def _sfc_skor(imp: np.ndarray) -> float:
    h, f, d = float(imp[IDX["H"]]), float(imp[IDX["F"]]), float(imp[IDX["D"]])
    return round((h + f - 0.45 * abs(d)) / 1e9, 4)


def _sinif_etiket(iso: str, rol: str, net_v: float, fark_usd: float | None) -> str:
    if iso == "TR":
        return "tr_yaricevre_refah_reformu"
    if net_v > 0.08:
        if rol in CEVRE_ROL:
            return "cevre_entegre_kazanan"
        if rol in MERKEZ_ROL:
            return "merkez_entegre_kazanan"
        return "entegre_kazanan"
    if net_v < -0.08:
        if rol in CEVRE_ROL:
            return "cevre_entegre_kaybeden"
        return "entegre_kaybeden"
    if fark_usd is not None and fark_usd > 400:
        return "rant_kanali_bosluk_taraftari"
    return "notr"


def calistir() -> dict[str, Any]:
    capa = _load(KALIBRE / "gerceklik_capa.json")
    zt = _load(DATA / "zarar_teorisi_kopru.json")
    ulke_sys = _load(DATA / "dis_ulke_sistemi.json")
    sen_doc = _load(DATA / "senaryolar.json")
    lam = float(zt["etki_cephesi_carpanlari"]["ic_dongu_kazanim"])
    kur = float(capa["kur_tl_usd"])
    kappa = 0.1

    rant = _load(OUT / "DIS_RANT_PARASAL.json")
    defter_doc = _load(OUT / "DIS_ULKE_REFAH.json")
    stok_tr = _load(OUT / "STOK_AKIS_SIM.json") if (OUT / "STOK_AKIS_SIM.json").is_file() else {}

    usd_per = float(rant.get("usd_per_vekil_rant_mn") or 5383.14)
    oz = rant.get("ozet") or {}
    rant_by_ulke = {
        r["ulke"]: r for r in (rant.get("ulke_rant_kanal") or {}).get("ulke_bazinda") or []
    }

    L, G, nfp_base = _matrices("2026-Q1")
    aktorler: list[dict[str, Any]] = []

    for row in defter_doc.get("ulke_defteri") or []:
        iso = str(row["ulke"])
        meta = (ulke_sys.get("ulkeler") or {}).get(iso) or {}
        rol = str(meta.get("rol") or row.get("rol") or "")
        net_v = float(row.get("net_refah_entegre") or 0.0)
        dis_v = float(row.get("dis_toplam_vekili") or 0.0)
        havza_k = float(row.get("havza_kayip") or 0.0)
        ref_r = float(row.get("refah_rant") or 0.0)

        rr = rant_by_ulke.get(iso) or {}
        fark_usd = float(rr["fark_bosluk_minus_refah_usd_mn"]) if rr else None
        ref_dis_usd = float(rr.get("refah_dis_toplam_usd_mn") or 0.0) if rr else round(ref_r * usd_per, 1)

        nfp = _nfp_aktör(nfp_base, iso, ulke_sys)
        x_ent = np.zeros(5)
        if dis_v > 0:
            x_ent += _shock_vec(dis_v * usd_per, kur, "F", "kar", gerceklesme=1.0)
        if havza_k > 0:
            x_ent += _shock_vec(havza_k * usd_per, kur, "F", "zarar", gerceklesme=0.35)
        sfc_net = (
            _sfc_skor(simulate(L, G, nfp, x_ent, lam=lam, kappa=kappa))
            if (dis_v > 0 or havza_k > 0)
            else 0.0
        )

        if iso == "TR":
            tr_sfc = (stok_tr.get("entegre_puls") or {}).get("sektor_etkisi_trilyonTL") or {}
            sfc_net = round(
                float(tr_sfc.get("H", 0)) + float(tr_sfc.get("F", 0)) - 0.45 * abs(float(tr_sfc.get("D", 0))), 3
            )

        sinif = _sinif_etiket(iso, rol, net_v, fark_usd)
        aktorler.append(
            {
                "ulke": iso,
                "ad": row.get("ad") or meta.get("ad") or iso,
                "rol": rol,
                "net_refah_entegre_vekil": round(net_v, 3),
                "net_refah_entegre_usd_mn": round(net_v * usd_per, 1),
                "dis_toplam_vekili": round(dis_v, 3),
                "havza_kayip_vekil": round(havza_k, 3),
                "refah_rant_vekil": round(ref_r, 3),
                "rant_kanal_refah_dis_usd_mn": ref_dis_usd,
                "rant_kanal_bosluk_fark_usd_mn": fark_usd,
                "sfc_net_trilyonTL": sfc_net,
                "sinif": sinif,
            }
        )

    tr_oz = oz
    for a in aktorler:
        if a["ulke"] == "TR":
            a["rant_reform_kazanc_usd_mn"] = float(tr_oz.get("tr_toplam_refah_kazanc_usd_mn") or 0)
            a["not"] = "Yapısal havza neti negatif; refah reformu ve 10y katmanlar ayrı yığın."

    entegre_kazanan = sorted(
        [a for a in aktorler if a["net_refah_entegre_vekil"] > 0.05 and a["ulke"] != "MFIN"],
        key=lambda x: -x["net_refah_entegre_vekil"],
    )
    cevre_kazanan = [a for a in entegre_kazanan if a["sinif"] == "cevre_entegre_kazanan"]
    halka_cevre_kazanan = [a for a in cevre_kazanan if a["rol"] in ("bolge_guc", "tampon", "koridor")]
    rakip_yaricevre_kazanan = [a for a in cevre_kazanan if a["rol"] == "rakip_yaricevre"]
    cevre_kaybeden = sorted(
        [a for a in aktorler if a["sinif"] == "cevre_entegre_kaybeden"],
        key=lambda x: x["net_refah_entegre_vekil"],
    )
    rant_bosluk_taraftari = sorted(
        [a for a in aktorler if a["sinif"] == "rant_kanali_bosluk_taraftari"],
        key=lambda x: -(x.get("rant_kanal_bosluk_fark_usd_mn") or 0),
    )

    c_sen = next(s for s in sen_doc["senaryolar"] if s["id"] == "C")
    destek = {
        "senaryo": "C",
        "olasilik_vekili": c_sen.get("olasilik_vekili"),
        "iki_katman_not": (
            "1) Rant kanalı: boşluk→refah geçişinde hayalet rant kaybedenler (EU, US, CN…). "
            "2) Entegre defter: havza+ikame+kanal+refah — çevrede IR, EG, GR vb. net pozitif."
        ),
        "halka_cevre_kazananlar": [f"{a['ulke']} ({a['ad']})" for a in halka_cevre_kazanan],
        "rakip_yaricevre_kazananlar": [f"{a['ulke']} ({a['ad']})" for a in rakip_yaricevre_kazanan],
        "cevre_kaybedenler": [f"{a['ulke']} ({a['ad']})" for a in cevre_kaybeden],
        "entegre_kazanan_top10": [a["ulke"] for a in entegre_kazanan[:10]],
        "rant_kanali_bosluk_taraftari": [a["ulke"] for a in rant_bosluk_taraftari[:8]],
    }

    return {
        "olcum": "bolge_stok_akis_kazanan_kaybeden",
        "rant_modeli": rant.get("rant_modeli"),
        "lambda": lam,
        "usd_per_vekil_rant_mn": usd_per,
        "senaryo_destek": destek,
        "aktorler": aktorler,
        "entegre_kazanan": entegre_kazanan,
        "cevre_kazanan": cevre_kazanan,
        "halka_cevre_kazanan": halka_cevre_kazanan,
        "rakip_yaricevre_kazanan": rakip_yaricevre_kazanan,
        "cevre_kaybeden": cevre_kaybeden,
        "rant_kanali_bosluk_taraftari": rant_bosluk_taraftari,
        "kaynak": ["DIS_ULKE_REFAH.json", "DIS_RANT_PARASAL.json", "STOK_AKIS_SIM.json"],
    }


def _md(d: dict[str, Any]) -> str:
    ds = d["senaryo_destek"]
    lines = [
        "# Bölgesel stok-akış — kazanan / kaybeden",
        "",
        f"*{ds['iki_katman_not']}*",
        "",
        "## Halka çevre — İran, Mısır, Yunanistan, … (entegre net > 0)",
        "",
    ]
    for a in d.get("halka_cevre_kazanan") or []:
        lines.append(
            f"- **{a['ulke']}** ({a['ad']}): net **{a['net_refah_entegre_vekil']}** vekil "
            f"≈ {a['net_refah_entegre_usd_mn']:,} mn $/yıl — refah rant {a['refah_rant_vekil']}, "
            f"havza kaybı {a['havza_kayip_vekil']}"
        )
    lines.extend(["", "*(Balkan vekili çoğunlukla **EU** satırında; **FR** ayrı net +0,595 vekil.)*", "", "## Rakip yarıçevre (CN, RU — entegre kazanan)", ""])
    for a in d.get("rakip_yaricevre_kazanan") or []:
        lines.append(f"- **{a['ulke']}:** net {a['net_refah_entegre_vekil']} vekil")
    lines.extend(["", "## Çevre kaybeden (Balkan / Kafkas tampon)", ""])
    for a in d["cevre_kaybeden"]:
        lines.append(
            f"- **{a['ulke']}** ({a['ad']}): net {a['net_refah_entegre_vekil']} vekil "
            f"(havza {a['havza_kayip_vekil']})"
        )
    lines.extend(
        [
            "",
            "## Tüm entegre kazananlar (top 12, vekil)",
            "",
            "| Ülke | Rol | Net entegre | USD mn | Refah rant | Rant kanalı fark |",
            "| --- | --- | ---: | ---: | ---: | ---: |",
        ]
    )
    for a in d["entegre_kazanan"][:12]:
        fk = a.get("rant_kanal_bosluk_fark_usd_mn")
        fk_s = f"{fk:,}" if fk is not None else "—"
        lines.append(
            f"| {a['ulke']} | {a['rol']} | {a['net_refah_entegre_vekil']} | "
            f"{a['net_refah_entegre_usd_mn']:,} | {a['refah_rant_vekil']} | {fk_s} |"
        )
    lines.extend(
        [
            "",
            "## TR (özel)",
            "",
        ]
    )
    tr = next(a for a in d["aktorler"] if a["ulke"] == "TR")
    lines.append(
        f"- Yapısal **net entegre {tr['net_refah_entegre_vekil']}** vekil (havza baskın); "
        f"**refah reform kazancı** ≈ {tr.get('rant_reform_kazanc_usd_mn', '—'):,} mn $/yıl (boşluk−refah + TR iç)."
    )
    lines.extend(["", "## Rant kanalı: boşluk senaryosunu tercih edenler (büyük fark)", ""])
    for a in d["rant_kanali_bosluk_taraftari"][:8]:
        lines.append(f"- **{a['ulke']}:** fark {a.get('rant_kanal_bosluk_fark_usd_mn', '—'):,} mn $")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    data = calistir()
    (OUT / "BOLGE_STOK_AKIS.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "BOLGE_STOK_AKIS.md").write_text(_md(data), encoding="utf-8")
    print(f"Wrote {OUT / 'BOLGE_STOK_AKIS.md'}")


if __name__ == "__main__":
    main()
