# Senaryo — gerçeklik kalibrasyonu (2024 çapa)

Taban: C + refah rant entegrasyonu. Reform katmanları politika USD tavanlarına göre gerçekleşme ile kısıldı. TR net USD: üç köprü + geometrik orta; GSYH WB TL/kur.

- **BoP (merkez+rant):** 1 vekil ≈ 2,087.88 mn USD
- **GSYH (vekili):** 1,356,471.7 mn USD

### USD köprüleri

- **bop_merkez_rant:** 1 vekil ≈ **2,087.88** mn USD
- **tum_havza_rant:** 1 vekil ≈ **5,383.14** mn USD
- **mal_net_ticaret:** 1 vekil ≈ **4,785.41** mn USD


## Doğrulama (2024)

- MFIN kenar USD (model C): 11,821.6 mn
- Yatırım geliri gideri: 18,841.0 mn
- Net ticaret: -82,175.0 mn
- TR küresel yatırım geliri payı: %0.897
- TİM/Ticaret kalibrasyonu aktif: True
- Rant modeli: **refah**
- Refah rant (toplam / TR iç): 2.062 / 0.509 vekil

## İyileşme tavanları (10 yıl, USD mn)

- Zarar teorisi: 1507.3
- Üretim/rant: 2054.4
- Finans: 1884.1

## Gerçekleşme oranları

- Zarar: **0.665**
- Üretim/iç akış: **0.2375**
- Finans: **0.2465**

## Kalibre katman yığını

| Katman | TR net | USD BoP | USD rant | USD mal | Orta | GSYH% orta |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| C_refah_entegre | -17.191 | 35,892.7 | 92,541.6 | 82,266.0 | 64,891.5 | 4.784 |
| zarar_teorisi | -12.81 | 26,745.7 | 68,958.0 | 61,301.1 | 48,354.4 | 3.565 |
| uretim_ic_akis | -10.94 | 22,841.4 | 58,891.6 | 52,352.4 | 41,295.6 | 3.044 |
| finans_katman | -10.083 | 21,052.1 | 54,278.2 | 48,251.3 | 38,060.7 | 2.806 |

**Ham model (finans son):** 0.7500000000000003 vekil — kalibre sonrası **-10.083** vekil (USD orta **38,060.7** mn, **%2.806** GSYH).

**Sıfır noktası (kalibre orta yol):** — (net pozitife çıkmıyor)
